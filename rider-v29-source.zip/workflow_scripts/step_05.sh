set -Eeuo pipefail
mkdir -p dist/tests
trap 'rc=$?; printf "Overlay install failed: exit %s, script line %s, command: %.240s\n" "$rc" "$LINENO" "$BASH_COMMAND" | tee -a dist/tests/OVERLAY_INSTALL_ERROR.txt >&2; exit "$rc"' ERR
# Only two committed files are required: this workflow and the source ZIP.
test -s rider-v29-source.zip
# Archive SHA-256 was checked by the mandatory bootstrap step.
source_dir=$(mktemp -d)
python3 -m zipfile -e rider-v29-source.zip "$source_dir"
(cd "$source_dir" && sha256sum -c RIDER_SOURCE_SHA256SUMS.txt)
mkdir -p radpro/rider_ci radpro/overlay
cp -a "$source_dir/rider_ci/." radpro/rider_ci/
cp -a "$source_dir/overlay/." radpro/overlay/
rm -rf -- "$source_dir"
# Browser uploads may not preserve executable bits.
chmod +x radpro/rider_ci/compare_build_v28.sh
chmod +x radpro/rider_ci/select_size_profile.sh
chmod +x radpro/rider_ci/tests/run.sh
chmod +x radpro/rider_ci/tests/run_compact_lossless.sh
chmod +x radpro/rider_ci/tests/run_datalog_v28.sh
chmod +x radpro/rider_ci/tests/run_lossless.sh
chmod +x radpro/rider_ci/tests/run_optimized_local.sh
echo 'RIDER_V291_FLASH_FIT verified source ZIP installed.'
# Keep CI source paths aligned with the embedded tarball layout.
# The save module is in rider_ci/, NOT rider_ci/src/.
for required in \
    rider_ci/src/rider_core.c rider_ci/src/rider_core.h \
    rider_ci/src/rider_render.c rider_ci/src/rider_render.h \
    rider_ci/rider_saves.c rider_ci/rider_saves.h \
    rider_ci/tests/run.sh rider_ci/tests/render_scenes.c \
    rider_ci/tests/bench_loop.c rider_ci/tests/flash_sim/test_saves.c \
    rider_ci/tests/test_v09.c rider_ci/tests/test_core.c \
    rider_ci/tests/test_visual_v09.c \
    rider_ci/tests/test_v10.c rider_ci/tests/test_v11.c \
    rider_ci/tests/test_reference_repairs.c rider_ci/tests/test_v12.c rider_ci/tests/test_v13.c rider_ci/tests/test_v14.c rider_ci/tests/test_v15.c rider_ci/tests/test_v16.c rider_ci/tests/test_v17.c rider_ci/tests/render_audit.c rider_ci/tests/render_run.c \
    rider_ci/README_V17.md rider_ci/README_V18.md rider_ci/README_V19.md rider_ci/README_V20.md rider_ci/README_V21.md rider_ci/tests/test_v21.c rider_ci/tests/test_lcd_extended.c rider_ci/tests/test_v18.c rider_ci/tests/test_v19.c rider_ci/tests/test_v20.c rider_ci/tests/render_timing.c rider_ci/tests/render_motion.c \
    overlay/platform.io/src/extras/rider_app.c \
    overlay/platform.io/src/extras/rider_saves.c \
    overlay/platform.io/src/extras/rider_saves.h \
    overlay/platform.io/src/ui/rider_screen.c \
    overlay/platform.io/src/ui/rider_render.h; do
  test -s "radpro/$required" || { echo "Bundled source is missing: $required" >&2; exit 1; }
done
cmp radpro/rider_ci/src/rider_render.c radpro/overlay/platform.io/src/ui/rider_render.c
cmp radpro/rider_ci/src/rider_core.c radpro/overlay/platform.io/src/extras/rider_core.c
cmp radpro/rider_ci/src/rider_core.h radpro/overlay/platform.io/src/extras/rider_core.h
cmp radpro/rider_ci/rider_screen.c radpro/overlay/platform.io/src/ui/rider_screen.c
test -s radpro/rider_ci/tests/test_v09.c
echo 'Verified save file root: radpro/rider_ci/rider_saves.c'
cmp radpro/rider_ci/rider_saves.c radpro/overlay/platform.io/src/extras/rider_saves.c
grep -q 'case EVENT_HEARTBEAT' radpro/overlay/platform.io/src/extras/rider_app.c
grep -q 'requestBacklightTrigger' radpro/overlay/platform.io/src/extras/rider_app.c
grep -q '^#define STRIP_ROWS 2$' radpro/rider_ci/src/rider_render.c
grep -Fq 'static uint8_t facet[W/4];' radpro/rider_ci/src/rider_render.c
grep -q '^MIN_STACK_HEADROOM = 3328' radpro/rider_ci/verify_expanded.py
echo 'v2.9: renderer 2421 B, snapshot 24 B, 960 B checksum cache; nominal SRAM threshold 3328 B.'
test -d radpro/platform.io/src || { echo 'Pinned Rad Pro source tree missing platform.io/src' >&2; exit 1; }
echo 'Installing verified overlay into pinned Rad Pro source tree.'
cp -a radpro/overlay/platform.io/src/. radpro/platform.io/src/
# Header-path regression: the renderer lives in ui/ but the Rider
# physics header lives in extras/. Fail BEFORE the ARM compile if
# the source bundle ever reintroduces the missing-header bug.
test -s radpro/platform.io/src/extras/rider_core.h
grep -Fq '#include "../extras/rider_core.h"' radpro/platform.io/src/ui/rider_render.h
echo 'PASS: firmware renderer header uses extras/rider_core.h via relative include.'
printf '#include "rider_render.h"\n#include "rider_screen.h"\nint main(void) { return 0; }\n' | gcc -std=c11 -Wall -Wextra -Werror -DGC01_RIDER -Iradpro/platform.io/src/ui -x c -fsyntax-only -
gcc -std=c11 -Wall -Wextra -Werror -DGC01_RIDER -fsyntax-only radpro/platform.io/src/ui/rider_render.c
echo 'PASS: installed firmware renderer and screen headers compile with no host include path.'
python3 radpro/rider_ci/apply_expanded_layout.py
python3 radpro/rider_ci/test_expanded_layout.py | tee dist/tests/LAYOUT_75K_TEST.txt
python3 radpro/rider_ci/install_datalog_v28.py | tee dist/tests/DATALOG_INSTALL.txt
cmp radpro/rider_ci/datalog_v28.c radpro/platform.io/src/measurements/datalog.c
(cd radpro/rider_ci && CC=gcc bash tests/run_datalog_v28.sh) | tee dist/tests/DATALOG_GCC.txt
(cd radpro/rider_ci && CC=clang bash tests/run_datalog_v28.sh) | tee dist/tests/DATALOG_CLANG.txt
echo 'PASS: v2.9.1 overlay install and layout checks completed.'

for f in rider_ci/select_size_profile.sh rider_ci/preflight_profile.py rider_ci/tests/test_lossless.c rider_ci/tests/run_lossless.sh rider_ci/README_V22.md; do test -s "radpro/$f"; done

# Verify the compressed immutable asset and the actual C decoder independently.
(cd radpro/rider_ci && python3 tools/check_terrain_delta.py) | tee dist/tests/TERRAIN_ENCODING.txt
for cc in gcc clang; do
  (cd radpro/rider_ci && "$cc" -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -no-pie src/rider_core.c tests/test_terrain_delta.c -o "/tmp/rider_v291_terrain_$cc" && UBSAN_OPTIONS=halt_on_error=1 "/tmp/rider_v291_terrain_$cc") | tee "dist/tests/TERRAIN_${cc}.txt"
done
