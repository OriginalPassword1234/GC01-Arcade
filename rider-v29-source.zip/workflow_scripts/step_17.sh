set -euo pipefail
mkdir -p dist/previews dist/tests
scenes=(referencecurl curlexit referencedrop arc gap risegap highgap moving falling giantsaw sawvalley wall bowl perfect ring lift twosaws twopads timedspikes splitbowl slopeup slopedown openloop score spikes triangle detachedbowl)
{
  gcc -std=c11 -O2 -Wall -Wextra -Werror -fsanitize=address,undefined -no-pie radpro/rider_ci/src/rider_core.c radpro/rider_ci/src/rider_render.c radpro/rider_ci/tests/render_run.c -o /tmp/rider_v18_live_preview
  for scene in "${scenes[@]}"; do
    echo "Rendering $scene"
    ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v18_live_preview "$scene" "$GITHUB_WORKSPACE/dist/previews/$scene.ppm"
  done
} 2>&1 | tee dist/tests/PREVIEW_RESULTS.txt
# Convert raw PPM screenshots to PNG using Python's standard library.
# A pure conversion: no AI-generated or altered screenshots.
python3 - "${scenes[@]}" <<'PYPNG'
import struct, zlib, sys
from pathlib import Path
folder=Path('dist/previews')
scenes=sys.argv[1:]
if len(scenes)!=len(set(scenes)) or not scenes:
    raise RuntimeError(f'Invalid preview scene list: {scenes}')
expected_ppm={f'{scene}.ppm' for scene in scenes}
expected_png={f'{scene}.png' for scene in scenes}
actual_ppm={p.name for p in folder.glob('*.ppm') if p.is_file()}
if actual_ppm!=expected_ppm:
    raise RuntimeError(f'PPM set mismatch: missing={sorted(expected_ppm-actual_ppm)}, extra={sorted(actual_ppm-expected_ppm)}')
def chunk(t, payload):
    return struct.pack('>I',len(payload))+t+payload+struct.pack('>I',zlib.crc32(t+payload)&0xffffffff)
for src in sorted(folder.glob('*.ppm')):
    buf=src.read_bytes()
    hdr=b'P6\n320 240\n255\n'
    if not buf.startswith(hdr): raise RuntimeError(f'Unexpected PPM header: {src}')
    rgb=buf[len(hdr):]
    if len(rgb)!=320*240*3: raise RuntimeError(f'Unexpected frame size: {src}, {len(rgb)} bytes')
    raw=b''.join(b'\x00'+rgb[row*320*3:(row+1)*320*3] for row in range(240))
    png=b'\x89PNG\r\n\x1a\n'
    png+=chunk(b'IHDR',struct.pack('>IIBBBBB',320,240,8,2,0,0,0))
    png+=chunk(b'IDAT',zlib.compress(raw,6))
    png+=chunk(b'IEND',b'')
    src.with_suffix('.png').write_bytes(png)
    src.unlink()
    print('Generated',src.with_suffix('.png'))
actual_png={p.name for p in folder.glob('*.png') if p.is_file() and p.stat().st_size>0}
if actual_png!=expected_png:
    raise RuntimeError(f'PNG set mismatch: missing={sorted(expected_png-actual_png)}, extra={sorted(actual_png-expected_png)}')
print(f'Validated all {len(expected_png)} expected PNG previews.')
PYPNG
