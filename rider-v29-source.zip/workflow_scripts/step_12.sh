set -euo pipefail
cd radpro
export RIDER_V29_MAX_BYTES=76496
printf "%s\n" "$RIDER_V29_MAX_BYTES" > "$GITHUB_WORKSPACE/dist/tests/V29_MAX_BYTES.txt"
bash rider_ci/select_size_profile.sh
raw=platform.io/.pio/build/fnirsi-gc01_apm32f103rb-en/firmware.bin
bytes=$(wc -c < "$raw")
test "$bytes" -le "$RIDER_V29_MAX_BYTES"
printf "Target cap: %s B; v2.9: %s B; spare after CRC: %s B; reduction vs v2.8 best: %s B\n" "$RIDER_V29_MAX_BYTES" "$bytes" "$((76796-bytes))" "$((76836-bytes))" | tee "$GITHUB_WORKSPACE/dist/tests/FLASH_BUDGET.txt"
sha256sum -c "$GITHUB_WORKSPACE/dist/tests/size/SELECTED_BUILD_HASHES.txt"
