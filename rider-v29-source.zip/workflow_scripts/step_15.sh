set -euo pipefail
mkdir -p "$GITHUB_WORKSPACE/dist/tests" "$GITHUB_WORKSPACE/dist/previews"
cd radpro/rider_ci
report="$GITHUB_WORKSPACE/dist/tests"
work=$(mktemp -d /tmp/rider-fast.XXXXXXXX)
gcc_script=$(mktemp tests/.run-fast-gcc.XXXXXXXX.sh)
clang_script=$(mktemp tests/.run-fast-clang.XXXXXXXX.sh)
trap 'rm -f -- "$gcc_script" "$clang_script"; rm -rf -- "$work"' EXIT
mkdir -p "$work/gcc" "$work/clang"
# The original run.sh uses fixed /tmp/rider_* paths. Only redirect those
# filenames in temporary launchers; preserve every compiler flag and test.
sed "s|/tmp/rider_|$work/gcc/rider_|g" tests/run.sh > "$gcc_script"
sed "s|/tmp/rider_|$work/clang/rider_|g" tests/run.sh > "$clang_script"
# Prove the temporary launchers differ only in the location of scratch files.
sed "s|$work/gcc/rider_|/tmp/rider_|g" "$gcc_script" | cmp - tests/run.sh
sed "s|$work/clang/rider_|/tmp/rider_|g" "$clang_script" | cmp - tests/run.sh
(
  set -euo pipefail
  {
    echo 'GCC / AddressSanitizer / UndefinedBehaviorSanitizer / gameplay tests'
    echo "Git commit: $GITHUB_SHA"
    gcc --version | head -n 1
    CC=gcc bash "$gcc_script"
    echo 'GCC host tests: PASS'
  } 2>&1 | tee "$report/GCC_TEST_RESULTS.txt"
  CC=gcc bash tests/run_lossless.sh 2>&1 | tee "$report/LOSSLESS_GCC.txt"
) &
gcc_pid=$!
(
  set -euo pipefail
  {
    echo 'Clang / AddressSanitizer / UndefinedBehaviorSanitizer'
    clang --version | head -n 1
    CC=clang bash "$clang_script"
    echo 'Clang host tests: PASS'
  } 2>&1 | tee "$report/CLANG_TEST_RESULTS.txt"
  CC=clang bash tests/run_lossless.sh 2>&1 | tee "$report/LOSSLESS_CLANG.txt"
  CC=clang bash tests/run_compact_lossless.sh 2>&1 | tee "$report/COMPACT_LOSSLESS_CLANG.txt"
) &
clang_pid=$!
gcc_rc=0; clang_rc=0
wait "$gcc_pid" || gcc_rc=$?
wait "$clang_pid" || clang_rc=$?
printf 'GCC exit=%s; Clang exit=%s\n' "$gcc_rc" "$clang_rc"
if ((gcc_rc != 0 || clang_rc != 0)); then
  echo 'At least one full test suite failed; no firmware will be published.' >&2
  exit 1
fi
