set -euo pipefail
test -s dist/GC01_RIDER_V29_75K_APM32_DO_NOT_FLASH.bin
test -s dist/GC01_RIDER_V29_75K_APM32_DIAGNOSTIC.elf
test -s dist/ADDRESS_AND_MEMORY_AUDIT.txt
test -s dist/source/test_v11.c
test -s dist/source/test_reference_repairs.c
test -s dist/source/test_v12.c
test -s dist/source/test_v13.c
test -s dist/source/test_v14.c
test -s dist/source/test_v15.c
test -s dist/source/test_v16.c
test -s dist/source/test_v17.c
test -s dist/source/test_v18.c
test -s dist/source/test_v19.c
test -s dist/source/test_v20.c
test -s dist/source/test_v21.c
test -s dist/source/test_lcd_extended.c
test -s dist/source/render_timing.c
test -s dist/source/render_run.c
test -s dist/tests/GCC_TEST_RESULTS.txt
test -s dist/tests/CLANG_TEST_RESULTS.txt
test -s dist/tests/PREVIEW_RESULTS.txt
test -s dist/tests/HOST_RENDER_BENCHMARK.txt
test -s dist/tests/LOOP_RENDER_BENCHMARK.txt
test -s dist/tests/PLATFORMIO_BUILD_LOG.txt
test -s dist/tests/SIGNING_LOG.txt
test -s dist/tests/LOSSLESS_GCC.txt
test -s dist/tests/LOSSLESS_CLANG.txt
test -s dist/tests/COMPACT_LOSSLESS_CLANG.txt
test -s dist/tests/size/SIZE_RESULTS.tsv
test -s dist/tests/FLASH_BUDGET.txt
test -s dist/tests/DATALOG_GCC.txt
test -s dist/tests/DATALOG_CLANG.txt
test -s dist/source/datalog_v28.c
test -s dist/tests/size/SELECTED_PROFILE.txt
for scene in referencecurl curlexit referencedrop arc gap risegap highgap moving falling giantsaw sawvalley wall bowl perfect ring lift twosaws twopads timedspikes splitbowl slopeup slopedown openloop score spikes triangle detachedbowl; do test -s "dist/previews/$scene.png"; done
(cd dist && sha256sum -c SHA256SUMS.txt)
echo 'RIDER_V29: All tests, previews and signed firmware present in the same artifact.'
