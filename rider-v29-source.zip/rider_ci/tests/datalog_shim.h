#ifndef DATALOG_TEST_SHIM
#define DATALOG_TEST_SHIM
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#define FLASH_WORD_SIZE 2u
#define FLASH_PAGE_SIZE 1024u
#define DATALOG_BASE 0x08017800u
#define DATALOG_SIZE (34u*1024u)
#define DATALOG_END (DATALOG_BASE+DATALOG_SIZE)
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))
typedef uint16_t menu_size_t;
typedef uint32_t MenuStyle;
typedef uint16_t cstring;
typedef enum{EVENT_KEY_BACK=1,EVENT_KEY_SELECT,EVENT_DRAW} ViewEvent;
typedef void OnViewEvent(ViewEvent);
typedef struct{menu_size_t startIndex,selectedIndex;} MenuState;
typedef struct{cstring title;MenuState *state;menu_size_t itemCount;const char *(*get)(menu_size_t,MenuStyle*);void(*select)(menu_size_t);void(*back)(void);} Menu;
typedef struct{cstring title;void(*showView)(void);} ViewOption;
#define MENUSTYLE_SUBMENU 2
#define STRING_OFF 0
#define STRING_EVERY_HOUR 1
#define STRING_EVERY10_MINUTES 2
#define STRING_EVERY_MINUTE 3
#define STRING_EVERY10_SECONDS 4
#define STRING_EVERY_SECOND 5
#define STRING_LOGGING_MODE 6
#define STRING_RESET 7
#define STRING_NOTIFICATION_DATALOG_RESET_SUCCESS 8
#define STRING_NOTIFICATION_DATALOG_RESET_CONFIRM 9
#define STRING_DATALOG 10
enum{DATALOG_LOGGINGMODE_OFF,DATALOG_LOGGINGMODE_60_MINUTES,DATALOG_LOGGINGMODE_10_MINUTES,DATALOG_LOGGINGMODE_1_MINUTE,DATALOG_LOGGINGMODE_10_SECONDS,DATALOG_LOGGINGMODE_1_SECOND,DATALOG_LOGGINGMODE_NUM};
typedef struct{unsigned loggingMode:3;} Settings;
extern Settings settings;
typedef struct{uint32_t time,pulseCount;} Dose;
typedef struct{bool sessionStart;Dose dose;} DatalogRecord;
const uint8_t *readFlash(uint32_t,uint32_t);bool writeFlash(uint32_t,const uint8_t*,uint32_t);bool eraseFlash(uint32_t);
uint32_t getDeviceTime(void);uint32_t getDeviceTimeFast(void);uint32_t getTubePulseCount(void);
void clearHistory(void);void selectMenuItem(const Menu*,menu_size_t);void showMenu(const Menu*);const char *getString(cstring);void showSettingsMenu(void);void showDatalogMenu(void);void showView(OnViewEvent*);void drawNotification(const char*,const char*);
#endif
