#!/usr/bin/env bash
# Invoked from the radpro checkout. Never change partition sizes, trim output,
# strip program bytes, or disable an existing feature to meet the size limit.
set -euo pipefail
: "${GITHUB_WORKSPACE:?GITHUB_WORKSPACE is required}"
REPORT="$GITHUB_WORKSPACE/dist/tests/size"
mkdir -p "$REPORT"
TARGET=fnirsi-gc01_apm32f103rb-en
INI=platform.io/platformio.ini
BUILD=platform.io/.pio/build/$TARGET
cp "$INI" "$REPORT/platformio-original.ini"
WORK=$(mktemp -d)
# Restore actual C sources even if an optional alternate backend fails.
restore_mixed() {
  if [[ -f "$WORK/original_core.c" ]]; then mv -f "$WORK/original_core.c" platform.io/src/extras/rider_core.c; fi
  if [[ -f "$WORK/original_render.c" ]]; then mv -f "$WORK/original_render.c" platform.io/src/ui/rider_render.c; fi
  if [[ -f "$WORK/mixed_active" ]]; then
    rm -f platform.io/src/extras/rider_mixed_v24.s platform.io/src/extras/rider_abi_v24.c "$WORK/mixed_active"
  fi
}
trap 'restore_mixed; rm -rf "$WORK"' EXIT
printf 'profile\tresult\traw_bytes\tremaining\tnominal_spare_sram\n' > "$REPORT/SIZE_RESULTS.tsv"
apply_flags() {
  python3 - "$INI" "$REPORT/platformio-original.ini" "$1" "$2" <<'PY'
import pathlib,sys
out,base=map(pathlib.Path,sys.argv[1:3]); flags,toolchain=sys.argv[3:5]
s=base.read_text(); marker='[env:fnirsi-gc01_apm32f103rb-en]'
assert s.count(marker)==1
start=s.index(marker); end=s.find('\n[',start+len(marker)); end=len(s) if end<0 else end
block=s[start:end]; anchor='    -DGC01_RIDER\n'
assert block.count(anchor)==1 and '-DFIRMWARE_SIZE=0x12c00' in block
if toolchain:
    assert not any(line.strip().startswith('platform_packages') for line in block.splitlines())
    block=block.replace(marker,marker+'\nplatform_packages = '+toolchain,1)
# PlatformIO commonly injects -Os. Remove that default only in Oz profiles.
# Avoid silently testing an ineffective -Oz option.
if '-Oz' in flags.split():
    assert not any(line.strip().startswith('build_unflags') for line in block.splitlines())
    block=block.replace(marker,marker+'\nbuild_unflags = -Os',1)
if flags: block=block.replace(anchor,anchor+''.join('    '+flag+'\n' for flag in flags.split()),1)
out.write_text(s[:start]+block+s[end:])
PY
}
# Keep actual binary/ELF out of failure diagnostic artifacts. Preserve maps and
# symbol tables for further optimization if no candidate can satisfy all gates.
max_bytes=${RIDER_V29_MAX_BYTES:-76496}
[[ "$max_bytes" =~ ^[0-9]+$ ]] || exit 2
((max_bytes>0)) || exit 2
if ((max_bytes>76496)); then max_bytes=76496; fi
echo "Hard payload limit: $max_bytes B (75 KiB partition, at least 300 bytes free)."
best_size=999999
best_profile=''
run_profile() {
  local name="$1" flags="$2" toolchain="${3:-}" dir="$REPORT/$1" bytes spare result
  mkdir -p "$dir"
  apply_flags "$flags -Wl,-Map=$dir/firmware.map" "$toolchain" || return 2
  cp "$INI" "$dir/platformio.ini" || return 2
  printf '%s\n' "$flags" > "$dir/extra_flags.txt"
  printf "%s\n" "${toolchain:-upstream default}" > "$dir/toolchain.txt"
  echo "=== Size profile $name: ${flags:-pinned defaults}; ${toolchain:-upstream default} ==="
  if ! pio run -d platform.io -e "$TARGET" -t clean > "$dir/clean.log" 2>&1; then
    printf '%s\tclean_failed\t-\t-\t-\n' "$name" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  rm -f -- "$BUILD/firmware.bin" "$BUILD/firmware.elf"
  if ! pio run -v -d platform.io -e "$TARGET" > "$dir/build.log" 2>&1; then
    grep -Ei "error:|fatal error|unrecognized|undefined reference|not found|failed" "$dir/build.log" | tail -n 25 || true
    tail -n 12 "$dir/build.log"
    if [[ "$name" == gcc12_* ]]; then
      find "$BUILD" -type f -name "*.s" -exec cp --parents {} "$dir/" \; 2>/dev/null || true
    fi
    printf '%s\tcompile_failed\t-\t-\t-\n' "$name" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  if ! test -s "$BUILD/firmware.bin" || ! test -s "$BUILD/firmware.elf"; then
    printf '%s\tmissing_output\t-\t-\t-\n' "$name" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  if [[ "$name" == clang_oz_game_* || "$name" == clang_compact_game_* ]]; then
    # A successful build must actually assemble the replacement, not silently
    # ignore the assembly file or link a stale version of the removed C objects.
    if ! grep -Fq 'rider_mixed_v24.s' "$dir/build.log" || ! grep -Fq 'rider_abi_v24.c' "$dir/build.log"; then
      printf '%s\tbackend_not_verified\t-\t-\t-\n' "$name" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
    fi
  fi
  bytes=$(wc -c < "$BUILD/firmware.bin")
  size -A -d "$BUILD/firmware.elf" > "$dir/sections.txt" 2>&1 || true
  nm -S --size-sort --radix=d --defined-only -C "$BUILD/firmware.elf" > "$dir/symbols-by-size.txt" 2>&1 || true
  readelf -W -S -l "$BUILD/firmware.elf" > "$dir/sections-and-segments.txt" 2>&1 || true
  readelf -p .comment "$BUILD/firmware.elf" > "$dir/layout-and-compiler.txt" 2>&1 || true
  if ! test -s "$dir/firmware.map" && test -f "$BUILD/firmware.map"; then cp "$BUILD/firmware.map" "$dir/firmware.map" || return 2; fi
  # Same constants as the independent final CRC audit. Check layout and RAM
  # before signing, not just raw length. Actual stack usage remains unmeasured.
  if ! spare=$(python3 rider_ci/preflight_profile.py "$BUILD/firmware.bin" "$BUILD/firmware.elf" 2> "$dir/preflight.log"); then
    cat "$dir/preflight.log"
    printf '%s\tpreflight_failed\t%s\t%s\t-\n' "$name" "$bytes" "$((76796-bytes))" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  if (( bytes > 76796 )); then result=oversize
  elif (( bytes > max_bytes )); then result=above_target
  elif (( spare < 3328 )); then result=insufficient_sram
  else result=fits; fi
  printf '%s\t%s\t%s\t%s\t%s\n' "$name" "$result" "$bytes" "$((76796-bytes))" "$spare" >> "$REPORT/SIZE_RESULTS.tsv"
  echo "Raw $bytes B; remaining $((76796-bytes)) B; nominal SRAM spare $spare B; $result"
  if [[ "$result" == fits ]] && (( bytes < best_size )); then
    cp "$BUILD/firmware.bin" "$WORK/firmware.bin" || return 2
    cp "$BUILD/firmware.elf" "$WORK/firmware.elf" || return 2
    cp "$INI" "$WORK/platformio.ini" || return 2
    best_size=$bytes; best_profile=$name
  fi
  # Prefer the first less intrusive profile with at least 256 bytes of
  # optional margin. If no such profile exists, use best fitting result.
  return 0
}
try_profile() {
  local rc=0
  run_profile "$1" "$2" "${3:-}" || rc=$?
  if ((rc==2)); then echo 'Internal workflow error; refusing signing.' >&2; exit 1; fi
}
# The original target uses LTO. First try the optimized source with its exact
# default flags, then progressively more size-oriented GCC choices.
try_profile optimized_default ''
if ((best_size>max_bytes-256)); then try_profile default_lto_one '-Os -flto-partition=one'; fi
if ((best_size>max_bytes-256)); then try_profile default_restrained '-Os -fno-inline-functions-called-once -fno-ipa-cp-clone'; fi
if ((best_size>max_bytes-256)); then try_profile default_lto_restrained '-Os -flto-partition=one -fno-inline-functions-called-once -fno-ipa-cp-clone'; fi
if ((best_size>max_bytes-256)); then try_profile default_no_jump_tables '-Os -fno-jump-tables -fno-tree-switch-conversion'; fi
modern='platformio/toolchain-gccarmnoneeabi@1.120301.0'

# Alternate backend ONLY when no normal GCC build fits. Compile the same two
# Rider C sources with Clang for ARM EABI, then let the existing GNU assembler
# and linker build the rest of Rad Pro. No changes to Rad Pro measurement C sources or bootloader.
# All cross-compiler structure offsets must match or the build fails closed.
prepare_mixed() {
  local mode="${1:-standard}" src="$PWD/platform.io/src"
  local stage="$WORK/clang-$mode" dest="$REPORT/clang_backend-$mode"
  mkdir -p "$stage" "$dest"
  test ! -e "$src/extras/rider_mixed_v24.s" && test ! -e "$src/extras/rider_abi_v24.c" || return 1
  command -v clang >/dev/null || { echo 'Clang unavailable; alternate backend skipped.'; return 1; }
  cat > "$stage/string.h" <<'HDR'
#include <stddef.h>
void *memset(void *, int, size_t);
size_t strlen(const char *);
HDR
  if [[ "$mode" == compact ]]; then
    python3 rider_ci/tools/compact_backend.py "$src" "$stage" || return 1
    # ABI assertions use the generated equivalent header, with unchanged layout.
    sed -i "1i #include \"$PWD/rider_ci/tools/check_mixed_abi.c\"" "$stage/combined.c"
  else
    printf '#include "%s"\n#include "%s"\n#include "%s"\n' "$PWD/rider_ci/tools/check_mixed_abi.c" "$src/extras/rider_core.c" "$src/ui/rider_render.c" > "$stage/combined.c"
  fi
  local -a flags=(-std=c11 --target=arm-none-eabi -mcpu=cortex-m3 -mthumb -mfloat-abi=soft -fshort-enums -Oz -ffreestanding -fno-builtin -fno-addrsig -fno-unwind-tables -fno-asynchronous-unwind-tables -ffunction-sections -fdata-sections -I"$stage" -I"$src/extras" -I"$src/ui")
  if [[ "$mode" == compact ]]; then flags+=(-fomit-frame-pointer); fi
  clang --version > "$dest/clang-version.txt"
  printf '%s\n' "${flags[@]}" > "$dest/clang-flags.txt"
  sha256sum "$src/extras/rider_core.c" "$src/ui/rider_render.c" "$src/extras/rider_core.h" "$src/ui/rider_render.h" rider_ci/tools/check_mixed_abi.c > "$dest/input-hashes.txt"
  if ! clang "${flags[@]}" -S "$stage/combined.c" -o "$dest/rider_mixed_v24.s" > "$dest/clang-build.log" 2>&1; then cat "$dest/clang-build.log"; return 1; fi
  # Verify generated assembly is accepted by Clang's ARM assembler before
  # attempting the full GNU assembler/ELF build; the latter is still required.
  if ! clang --target=arm-none-eabi -mcpu=cortex-m3 -mthumb -c "$dest/rider_mixed_v24.s" -o "$stage/check.o" >> "$dest/clang-build.log" 2>&1; then cat "$dest/clang-build.log"; return 1; fi
  readelf -h -A "$stage/check.o" > "$dest/arm-attributes.txt" || return 1
  nm -u "$stage/check.o" > "$dest/undefined-symbols.txt" || return 1
  size "$stage/check.o" > "$dest/arm-object-size.txt" || return 1
  if [[ "$mode" == compact ]]; then
    nm -g --defined-only "$stage/check.o" | awk '$2=="T" {print $3}' | LC_ALL=C sort > "$dest/exports.txt" || return 1
    printf '%s\n' rider_init rider_render_snapshot rider_restart rider_step | diff -u - "$dest/exports.txt" || return 1
  fi
  sha256sum "$dest/rider_mixed_v24.s" > "$dest/assembly-hash.txt"
  touch "$WORK/mixed_active"
  mv "$src/extras/rider_core.c" "$WORK/original_core.c" || return 1
  mv "$src/ui/rider_render.c" "$WORK/original_render.c" || return 1
  cp "$dest/rider_mixed_v24.s" "$src/extras/rider_mixed_v24.s" || return 1
  cp rider_ci/tools/check_mixed_abi.c "$src/extras/rider_abi_v24.c" || return 1
  return 0
}
if [[ -z "$best_profile" ]]; then
  for mode in compact standard; do
    if prepare_mixed "$mode"; then
      if [[ "$mode" == compact ]]; then prefix=clang_compact_game; else prefix=clang_oz_game; fi
      try_profile "${prefix}_default_gcc" ''
      if [[ -z "$best_profile" ]]; then try_profile "${prefix}_gcc12_oz" '-Oz -flto-partition=one' "$modern"; fi
    else
      echo "Alternate $mode backend preparation failed; see diagnostics."
      printf 'clang_%s_backend\tprepare_failed\t-\t-\t-\n' "$mode" >> "$REPORT/SIZE_RESULTS.tsv"
    fi
    restore_mixed
    [[ -z "$best_profile" ]] || break
  done
fi
# GCC 12.3 explicitly supports -Oz, unlike many older ARM GCC releases.
# Keep the original platform/CMSIS framework; override only the toolchain.
if ((best_size>max_bytes)); then try_profile gcc12_os '-Os -save-temps=obj' "$modern"; fi
if ((best_size>max_bytes-256)); then try_profile gcc12_oz '-Oz -fomit-frame-pointer -save-temps=obj' "$modern"; fi
if ((best_size>max_bytes-256)); then try_profile gcc12_oz_lto_one '-Oz -flto-partition=one' "$modern"; fi
if ((best_size>max_bytes-256)); then try_profile gcc12_oz_restrained '-Oz -fno-inline-functions-called-once -fno-ipa-cp-clone' "$modern"; fi
if ((best_size>max_bytes-256)); then try_profile gcc12_oz_noinline '-Oz -fno-inline-functions -fno-inline-small-functions -fno-inline-functions-called-once -fno-partial-inlining' "$modern"; fi
if ((best_size>max_bytes-256)); then try_profile gcc12_oz_layout '-Oz -flto-partition=one -fno-align-functions -fno-align-jumps -fno-align-labels -fno-align-loops' "$modern"; fi
if ((best_size>max_bytes-256)); then try_profile gcc12_oz_ipa '-Oz -flto-partition=one -fipa-pta -fipa-ra' "$modern"; fi
if ((best_size>max_bytes-256)); then try_profile gcc12_oz_no_jump_tables '-Oz -fno-jump-tables -fno-tree-switch-conversion' "$modern"; fi

cat "$REPORT/SIZE_RESULTS.tsv"
if [[ -z "$best_profile" ]]; then
  echo 'NO PROFILE FITS. Upload SIZE_RESULTS.tsv and symbols-by-size.txt to continue optimizing. No binary will be signed.' >&2
  exit 1
fi
# Restore the exact successful paired binary, ELF and configuration; later
# profiles may have overwritten the build tree. Do not rebuild a different one.
cp "$WORK/firmware.bin" "$BUILD/firmware.bin"
cp "$WORK/firmware.elf" "$BUILD/firmware.elf"
cp "$WORK/platformio.ini" "$INI"
cp "$REPORT/$best_profile/build.log" "$GITHUB_WORKSPACE/dist/tests/PLATFORMIO_BUILD_LOG.txt"
cp "$REPORT/$best_profile/build.log" /tmp/rider_expanded_build.log
printf 'Selected %s: raw %s B, remaining %s B. Hardware timing and bootloader still unverified.\n' "$best_profile" "$best_size" "$((76796-best_size))" | tee "$REPORT/SELECTED_PROFILE.txt"
sha256sum "$BUILD/firmware.bin" "$BUILD/firmware.elf" > "$REPORT/SELECTED_BUILD_HASHES.txt"
