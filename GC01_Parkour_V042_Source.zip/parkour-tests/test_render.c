/* 0.4.1 framebuffer equivalence: no ghost sprites, stale attack effects,
 * HUD tearing, missing projectiles, or uncleared pause overlays. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../platform.io/src/ui/parkour_draw.h"
#define W 320
#define H 240
static uint16_t screen[W*H],compare[W*H];
static uint32_t updates,fullUpdates,partialUpdates;
void pg_test_image(int x,int y,int w,int h,const uint16_t *pixels) {
    assert(x>=0 && y>=0 && x+w<=W && y+h<=H);
    for(int r=0;r<h;r++)memcpy(&screen[(y+r)*W+x],pixels+r*w,(size_t)w*2);
    updates++;
}
void pg_test_rect(int x,int y,int w,int h,uint16_t c) {
    assert(x>=0&&y>=0&&x+w<=W&&y+h<=H);
    for(int r=y;r<y+h;r++)for(int col=x;col<x+w;col++)screen[r*W+col]=c;
}
static void compare_frame(const PG_Game *g,const char *stage,int step) {
    /* Incremental rendering to the existing framebuffer vs rebuilding from
       blank; two byte-identical images prove all old pixels were erased. */
    uint32_t start=updates;
    pg_draw(g,false);
    partialUpdates+=updates-start;
    memcpy(compare,screen,sizeof(screen));
    memset(screen,0,sizeof(screen));
    start=updates;
    pg_draw(g,true);
    fullUpdates+=updates-start;
    if(memcmp(compare,screen,sizeof(screen))) {
        fprintf(stderr,"FAIL stale/incorrect pixel: %s at frame %d\n",stage,step);
        assert(0);
    }
}
int main(void) {
    PG_Game g;
    pg_new(&g,45);
    memset(screen,0,sizeof(screen));
    pg_draw(&g,true);
    for(int i=0;i<80;i++) {
        pg_tick(&g,(i%7==0)?(PG_RIGHT|PG_DOWN):
                   (i%4)?PG_RIGHT:PG_UP);
        if(i%9==0)pg_quick_attack(&g);
        if(g.phase==PG_DEAD)pg_quick_attack(&g);
        compare_frame(&g,"motion",i);
    }
    /* Paint of effects as they appear/disappear, enemy deaths, bullets,
       health, theme change, map change, score, and overlays. */
    for(int i=0;i<28;i++) {
        g.x=(int16_t)((10+i*3)*16);
        g.y=(int16_t)((36+i%7)*16);
        g.grounded=(uint8_t)(i%2);
        g.attackTime=(uint8_t)(i%3?10:0);
        g.effectTime=(uint8_t)(i%3?8:0);
        g.chargeTime=(uint8_t)(i%4?20:0);
        g.dashTime=(uint8_t)(i%5?5:0);
        g.invulnerable=(uint8_t)(i%6?0:8);
        g.facing=(uint8_t)(i&1);
        g.steps++;
        g.hp=(uint8_t)(100-i*2);
        g.mana=(uint8_t)(100-i*3);
        if(i%4==0)g.enemies[0].hp=(int8_t)(i&4?0:2);
        g.shots[0].live=(uint8_t)(i&1);
        g.shots[0].x=(int16_t)((g.x+15*16));
        g.shots[0].y=(int16_t)((g.y+5*16));
        if(i==10)g.cells[9*PG_COLS+13]=PG_AIR;
        if(i==15)g.theme=(uint8_t)((g.theme+1)%3);
        if(i==20)g.room++;
        g.score+=(uint32_t)(i%4==0?5:0);
        compare_frame(&g,"effects",i);
    }
    pg_toggle_pause(&g);compare_frame(&g,"pause",0);
    g.menuChoice=1;compare_frame(&g,"pause-select",1);
    pg_toggle_pause(&g);compare_frame(&g,"resume",2);
    g.phase=PG_DEAD;compare_frame(&g,"death",3);
    g.phase=PG_RUN;compare_frame(&g,"restart",4);
    assert(fullUpdates==260u*(80u+28u+5u));
    assert(partialUpdates<fullUpdates); /* Dirty rectangles save work. */
    printf("PASS: 113 exact dirty-vs-full RGB565 frames including 3 themes,\n"
           "      moving sprites, effects, death, pause, hazards, and HUD changes\n"
           "      partial transfers %u vs full transfers %u\n",
           (unsigned)partialUpdates,(unsigned)fullUpdates);
    return 0;
}
