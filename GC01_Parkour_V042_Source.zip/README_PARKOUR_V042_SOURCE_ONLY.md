# FNIRSI GC-01 Parkour Gauntlet 0.4.2 — Flash size recovery

**SOURCE-ONLY. Experimental. This ZIP is NOT installable firmware.**

Target: Gissio Rad Pro 3.1.1, FNIRSI GC-01 APM32F103RB English.
PlatformIO environment: `fnirsi-gc01_apm32f103rb-en`.

## Why this release exists

The GitHub Actions 0.4.1 source compiled to 58,912 bytes, but the strict
application limit is **57,340 bytes** (1,572 bytes over). The linker did
not fail; the post-build memory audit correctly refused the oversized
application. Do not disable or increase the flash limit.

## Size-saving changes (no guessed ARM build size)

- Lossless 4bpp art compression by a dictionary of shared sprite rows:
  1,536 bytes of raw art -> 934 bytes of packed rows and row indices.
  The character and enemy sprite pixels are unchanged.
- Shared clipping and rendering of effect rings replaces duplicated loops.
- Heavy procedural scenery shader is out-of-line rather than duplicated
  into the renderer; moonlit city, factory, and crystal cavern remain.
- Compact, simpler sky/cavern decoration can be used only IF the first
  full-quality build still exceeds 57,340 bytes.
- In that compact build, optional shadow, dash afterimage, and healing
  sparkle are disabled. The sprites, attack effects, player physics,
  health/mana, three visual themes, and gameplay are unchanged.
- More efficient one-way platform landing and fractional collision snap.
- Corrected a generated pit whose second floor row previously covered
  the gap, preventing an intended fall.

**Note:** The estimates are based on portable/native and Clang ARM-object
size comparisons, not a complete final GCC/PlatformIO firmware build.
The matching workflow compiles the full graphics edition first; if its
raw application is oversized, it automatically retries with
`PG_FLASH_COMPACT`, then performs the same strict memory audit. It never
signs or makes a flashable `-install.bin`.

## Developer verification

`bash parkour-tests/run.sh` builds and runs both full and compact variants
using host GCC and Clang with AddressSanitizer and UBSan. The frame tests
reconstruct each incremental draw as a full framebuffer and verify an
identical RGB565 image for 113 frames. These are software-only tests; they
do NOT establish on-device frame rates, physical LCD tearing, firmware
installation safety, or radiation measurement correctness.

## Installation in GitHub (compilation only)

1. Upload `GC01_Parkour_V042_Source.zip` to your GitHub repository root.
   Do not extract the source ZIP.
2. Open the existing `.github/workflows/GC01_Dungeon_Prototype_Build.yml`,
   click Edit, replace its text with the matching v0.4.2 workflow, commit.
   Do **not** delete the only file inside `.github/workflows`.
3. In Actions, start **GC-01 Parkour Gauntlet 0.4.2 - OPTIMIZE AND COMPILE ONLY**
   as a **new run** on `main` (not Re-run jobs).
4. Download the diagnostics artifact if it succeeds or fails. The report
   `results/build-variant.txt` states FULL or COMPACT and the actual size.

**DO NOT FLASH `firmware.bin` from the diagnostics.** Neither build
variant is signed. The GC-01's Geiger counter and alarm functions must
be checked independently before relying on experimental firmware.
