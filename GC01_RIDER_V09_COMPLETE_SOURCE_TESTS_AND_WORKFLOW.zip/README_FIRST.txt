GC01 RIDER v0.9 — complete source, tests and ONE GitHub Actions workflow.
This archive is SOURCE ONLY, NOT FLASHABLE.

To build: Add a new file on GitHub with the path:
.github/workflows/gc01-rider-v09-ONE-ACTION.yml
Paste the full contents of gc01-rider-v09-ONE-ACTION-TESTS-AND-FIRMWARE.yml.
Commit to main, open Actions > GC01 Rider v0.9 Tests and Firmware (ONE ARTIFACT), and click Run workflow (not Re-run jobs).

If every host test, ARM build, signing, and memory audit passes, one artifact will contain a .bin firmware candidate, .elf diagnostic, tests and seven actual renderer previews.

CAUTION: The signed candidate has NOT been tested on hardware, and cannot be considered proven safe for GC01 measurement use. The expanded flash layout has NO migration of old radiation logs/settings. Retain known-good firmware and calibration backup and do not flash on the strength of a green GitHub run alone.
Not an original Rider asset/Box2D port. The 95 original sections and moving platform mechanisms remain incomplete.
