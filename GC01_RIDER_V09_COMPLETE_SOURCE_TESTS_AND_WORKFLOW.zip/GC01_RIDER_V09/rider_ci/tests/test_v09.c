#include "../src/rider_core.h"
#include <assert.h>
#include <stdio.h>
#include <stdint.h>

static void test_vertical_and_bowl_paths(void)
{
    for(uint8_t kind=27u;kind<=28u;kind++){
        RiderState s;rider_init(&s,37u);
        s.track[0].template_id=kind;
        s.track[0].flags=0;
        s.phase=RIDER_RUNNING;
        s.x=65*RIDER_Q;
        s.y=161*RIDER_Q;
        s.vx=4*RIDER_Q;
        s.grounded=1;
        int entered=0,exited=0,miny=99999,maxy=0;
        for(int i=0;i<190;i++){
            rider_step(&s,true);
            assert(s.phase!=RIDER_CRASHED);
            if(s.looping){
                entered=1;
                if(s.y<miny)miny=s.y;
                if(s.y>maxy)maxy=s.y;
            }
            if(entered && !s.looping){exited=1;break;}
        }
        assert(entered && exited);
        if(kind==27u){assert(miny<75*RIDER_Q);assert(!s.grounded);}
        if(kind==28u){assert(maxy>192*RIDER_Q);assert(s.grounded);}
        int32_t a,b,c,d;
        assert(rider_special_point_q(0,kind,0,&a,&b));
        assert(rider_special_point_q(0,kind,4096,&c,&d));
        assert(a==70*RIDER_Q && b==166*RIDER_Q);
        assert(c>a);
    }
}
static void test_flip_at_270_degrees(void)
{
    RiderState s;rider_init(&s,2u);
    s.phase=RIDER_RUNNING;
    s.x=70*RIDER_Q;
    s.y=160*RIDER_Q;
    s.grounded=0;
    s.vy=RIDER_Q;
    s.angle=RIDER_ANGLE_TURN;
    s.angular_speed=0;
    s.air_rotation=3072u;
    rider_step(&s,false);
    assert(s.pending_score==1);
    assert(s.phase==RIDER_RUNNING);
}
static void test_stability_under_bumps(void)
{
    RiderState s;rider_init(&s,7u);
    for(int i=0;i<30;i++)rider_step(&s,true);
    assert(s.grounded);
    s.angle=300;
    for(int i=0;i<12;i++){
        rider_step(&s,true);
        assert(s.phase==RIDER_RUNNING);
        assert(s.grounded);
        assert(s.angle<530 && s.angle>-530);
    }
}
static void test_spike_metadata(void)
{
    RiderState s;rider_init(&s,3u);
    s.track[0].flags|=8u;
    int32_t x0,x1,tip;
    assert(rider_piece_spikes_q(&s,0,&x0,&x1,&tip));
    assert(x0<x1 && tip>166*RIDER_Q);
    s.track[0].flags=0;
    assert(!rider_piece_spikes_q(&s,0,&x0,&x1,&tip));
}
static void test_grouped_gem_pickup(void)
{
    RiderState s;rider_init(&s,1u);
    s.track[0].template_id=28u;
    s.track[0].flags=1;
    s.track[0].gem_mask=7;
    s.phase=RIDER_RUNNING;
    s.grounded=0;
    s.vx=0;s.vy=0;
    for(int i=0;i<3;i++){
        int32_t x,y;
        assert(rider_piece_gem_q(&s,0,(uint8_t)i,&x,&y));
        s.x=x;s.y=y;
        rider_step(&s,false);
        assert(s.diamonds==i+1);
    }
    assert(s.track[0].gem_mask==0u && !(s.track[0].flags&1u));
}
int main(void)
{
    test_vertical_and_bowl_paths();
    test_flip_at_270_degrees();
    test_stability_under_bumps();
    test_spike_metadata();
    test_grouped_gem_pickup();
    puts("v0.9: vertical rail, deep bowl, 270-degree flips, grounded stability, spikes, three individual gems PASS");
}
