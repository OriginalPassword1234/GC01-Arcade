/* GC01 ST7789 update adapter. Bounded 3-row streaming with 3 horizontal
 * changed-region hashes per strip. All memory statically allocated.
 * The first pass hashes all tiles; when exactly one tile differs, compact
 * that rectangle in the renderer's mutable work strip and transfer only it.
 * When more tiles change, send the whole strip in ONE display transaction.
 * No heap, DMA reconfiguration, or changes to Rad Pro interrupt processing.
 */
#if defined(GC01_RIDER)
#include <stdint.h>
#include <string.h>
#include "rider_screen.h"
#include "rider_render.h"
#include "draw.h"

#define ROWS 3
#define WIDTH 320
#define HEIGHT 240
#define STRIPS (HEIGHT/ROWS)
#define TILES 3
static const uint16_t bounds[TILES+1]={0,107,214,320};
static uint16_t previous_hash[STRIPS][TILES]; /* 480 bytes vs old 320 bytes */
static uint8_t cache_valid;

void rider_screen_invalidate(void){cache_valid=0;}

static uint16_t hash_tile(const uint16_t *p,uint16_t begin,uint16_t end)
{
    uint16_t h=0xA17Bu;
    for(int r=0;r<ROWS;r++)
        for(uint16_t x=begin;x<end;x++){
            uint16_t v=p[r*WIDTH+x];
            h=(uint16_t)((h ^ v)*0x9E37u+0x1F7Bu);
            h=(uint16_t)((h<<3)|(h>>13));
        }
    return h;
}
static void send_rows(int top,int rows,const uint16_t *p,void *unused)
{
    (void)unused;
    if(rows!=ROWS || top<0 || top+rows>HEIGHT || top%ROWS!=0)return;
    const unsigned slot=(unsigned)top/ROWS;
    uint16_t next[TILES];
    int changed=-1,count=0;
    for(int j=0;j<TILES;j++){
        next[j]=hash_tile(p,bounds[j],bounds[j+1]);
        if(!cache_valid || next[j]!=previous_hash[slot][j]){
            changed=j;
            ++count;
        }
    }
    if(count==0)return;
    if(count==1){
        const uint16_t start=bounds[changed];
        const uint16_t width=bounds[changed+1]-start;
        /* rider_render passes the mutable static work strip, but advertises
         * a const read-only view. Only compact AFTER all hashes are taken.
         * Source rows are at offsets 0,320,640 and destinations stay below
         * their next unread source row, so this is safe in place. */
        uint16_t *mutable_strip=(uint16_t *)(void *)p;
        for(int r=0;r<ROWS;r++)
            memmove(mutable_strip+r*width,p+r*WIDTH+start,(size_t)width*sizeof(uint16_t));
        const mr_rectangle_t area={(int16_t)start,(int16_t)top,(int16_t)width,ROWS};
        drawImage(&area,mutable_strip);
    }else{
        const mr_rectangle_t area={0,(int16_t)top,WIDTH,ROWS};
        drawImage(&area,p);
    }
    for(int j=0;j<TILES;j++)previous_hash[slot][j]=next[j];
}
void rider_draw_gc01(const RiderState *s,const RiderState *prev,uint8_t alpha)
{
    rider_render(s,prev,alpha,send_rows,0);
    cache_valid=1;
}
#endif
