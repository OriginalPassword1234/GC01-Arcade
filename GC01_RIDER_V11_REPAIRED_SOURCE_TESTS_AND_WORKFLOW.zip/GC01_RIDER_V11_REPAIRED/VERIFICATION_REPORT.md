# GC01 Rider v1.1 — actual-source repair audit

**Evidence**: User-uploaded `GC01_RIDER_V11_SOURCE_TESTS_AND_WORKFLOW(1).zip` was opened and integrity-tested; all source changes were applied to a copy, preserving the uploaded original. Its `README_V10.md` documents the earlier v1.0 lineage. This archive does **not** contain a separate frozen v1.0 source snapshot; claiming a complete v1.0 line-by-line comparison would be inaccurate.

**Rejected branch**: The separate `GC01_RIDER_V11_SOURCE_ONLY_NOT_FLASHABLE.zip` from the earlier failed attempt was NOT used as the base. No source was copied from that rewrite.

**Verified repairs**: Both engine and renderer copies are byte-identical between the `overlay` firmware tree and `rider_ci/src` host test tree. The RGB565 renderer uses one screen transformation for track, bike, saw, spike, gem, and saw radius; 2:3 zoom object-placement test now checks actual rendered pixels. Added a micro-loop; one time-oscillating bridge; a moving saw; a time-switched spike; ramp-following collectible clusters; a flash-only 13-tooth swept saw; per-section green/pink rail coloring; less repetitive dark terrain; original-style HUD. The existing car, physics core, game-menu adapter, journal, measurement integration and LCD streaming design are retained.

## Files compared with the uploaded archive

- Unchanged original members: **47**
- Modified original members: **16**
- Missing original source members: **0**
- Added source/tests/documentation members: **6**

### Changed files

- `PREVIEWS/BOWL.png`
- `PREVIEWS/CONTACT_SHEET.png`
- `PREVIEWS/JUMP.png`
- `PREVIEWS/LOOP.png`
- `PREVIEWS/OPEN.png`
- `PREVIEWS/PAUSE.png`
- `PREVIEWS/SAW.png`
- `PREVIEWS/SCORE.png`
- `PREVIEWS/VWALL.png`
- `overlay/platform.io/src/extras/rider_core.c`
- `overlay/platform.io/src/ui/rider_render.c`
- `rider_ci/README_V11.md`
- `rider_ci/src/rider_core.c`
- `rider_ci/src/rider_render.c`
- `rider_ci/tests/render_scenes.c`
- `rider_ci/tests/run.sh`

### New files

- `PREVIEWS/MINI.png`
- `PREVIEWS/MOVING.png`
- `READ_FIRST_REPAIRED.txt`
- `RENDERED_PREVIEW_ACTUAL_SOURCE.png`
- `gc01-rider-v11-REPAIRED-ONE-ACTION-TESTS-AND-FIRMWARE.yml`
- `rider_ci/tests/test_reference_repairs.c`

## Reproducible checks executed locally

- The original uploaded ZIP passed `testzip`; its workflow-embedded tarball agreed with the uploaded original sources for all comparable members.
- Repaired host regression suite: **PASS**, GCC AddressSanitizer/UndefinedBehaviorSanitizer, with the original user-provided logic/visual/tests and the newly added rendering/geometry/hazard tests.
- **500 deterministic novice runs: 2 crashes**, identical failure count to the source baseline. This is a scripted policy, not proof of human playability.
- **100/100 sampled stunt runs** scored; 1000 emulated journal-save transactions passed.
- Framebuffer reconstruction and tile-cache guards: PASS.
- Renderer static allocation **2965 B** (formerly **3045 B**); two Rider states **472 B**, three-tile LCD checksum cache **480 B**; combined **3917 B**, not counting full Rad Pro runtime/stack.
- Clang ASan/UBSan new regression tests: PASS.
- Embedded workflow payload SHA-256 validates and exactly matches source/overlay files in this ZIP. Workflow YAML parses; original build, signing, CRC, and **>=3072 B nominal spare SRAM** gates remain mandatory.

## Not verified or still incomplete

- No full PlatformIO ARM firmware build, linked SRAM map, stack profiling, or USB flash test was completed in this environment.
- No hardware frame-rate, radiation ISR timing, Geiger accuracy, or retention of existing calibration/history was verified.
- This experimental 68 KiB/2 KiB/1 KiB/41 KiB flash partition layout has no migration for previous settings/calibration/history. Firmware may be rejected by some USB updaters; SWD recovery may be necessary.
- A pixel-based preview is **not** evidence that the original game's physics or every original stage has been reproduced. Art and physics remain original-inspired approximations.

**Do NOT flash this package merely because native tests pass.** GitHub Actions can produce a signed candidate only if all ARM and memory checks succeed; it still cannot certify safe hardware installation.
