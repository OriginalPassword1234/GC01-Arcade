set -euo pipefail
cd radpro/rider_ci
gcc -std=c11 -O2 -Wall -Wextra -Werror src/rider_core.c src/rider_render.c tests/host_render_benchmark.c -o /tmp/rider_v09_host_bench
/tmp/rider_v09_host_bench | tee "$GITHUB_WORKSPACE/dist/tests/HOST_RENDER_BENCHMARK.txt"
gcc -std=c11 -O2 -Wall -Wextra -Werror src/rider_core.c src/rider_render.c tests/bench_loop.c -o /tmp/rider_v09_loop_bench
/tmp/rider_v09_loop_bench | tee "$GITHUB_WORKSPACE/dist/tests/LOOP_RENDER_BENCHMARK.txt"
gcc -std=c11 -O2 -Wall -Wextra -Werror -fsanitize=address,undefined -no-pie src/rider_core.c src/rider_render.c tests/render_audit.c -o /tmp/rider_v17_qa
/tmp/rider_v17_qa | tee "$GITHUB_WORKSPACE/dist/tests/LIVE_300_FRAME_QA.txt"

CC=gcc bash tests/run_bench_compare_v33.sh | tee "$GITHUB_WORKSPACE/dist/tests/MATCHED_INPUT_BENCHMARK.txt"

CC=gcc bash tests/run_bench_structures_v33.sh | tee "$GITHUB_WORKSPACE/dist/tests/STRUCTURE_BENCHMARK.txt"
CC=gcc bash tests/run_bench_fit_v331.sh | tee "$GITHUB_WORKSPACE/dist/tests/LOSSLESS_MATCHED_INPUT_V331.txt"
