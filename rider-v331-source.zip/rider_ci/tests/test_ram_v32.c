#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    const unsigned render_bytes = (unsigned)rider_render_static_ram();
    const unsigned strip_hash_bytes = 120u * sizeof(uint32_t);
    /* Strict guard for v1.0 RAM safety: no change to firmware audit threshold. */
    assert(render_bytes == 3060u);
    assert(strip_hash_bytes == 480u);
    assert(sizeof(RiderRenderPrevious)==24u);
    assert((size_t)render_bytes+sizeof(RiderState)+sizeof(RiderRenderPrevious)+strip_hash_bytes<=3805u);
    printf("RAMFIX: renderer=%u B, state and snapshot=%zu B, dirty hashes=%u B, Rider subtotal=%zu B\n",
           render_bytes, sizeof(RiderState)+sizeof(RiderRenderPrevious), strip_hash_bytes,
           (size_t)render_bytes + sizeof(RiderState)+sizeof(RiderRenderPrevious) + strip_hash_bytes);
    return 0;
}
