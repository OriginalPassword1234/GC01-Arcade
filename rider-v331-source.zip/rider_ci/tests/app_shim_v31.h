#ifndef APP_SHIM_V31_H
#define APP_SHIM_V31_H
#include <stdint.h>
#include <stdbool.h>
typedef enum {EVENT_KEY_GAME_EXIT,EVENT_KEY_GAME_OK,EVENT_KEY_GAME_RIGHT,EVENT_KEY_GAME_UP,EVENT_DRAW,EVENT_HEARTBEAT} ViewEvent;
typedef void OnViewEvent(ViewEvent);
typedef unsigned menu_size_t;
typedef struct {int unused;} MenuState;
typedef enum {MENUSTYLE_SUBMENU} MenuStyle;
typedef struct {int title;MenuState *state;unsigned count;const char *(*option)(menu_size_t,MenuStyle*);void (*select)(menu_size_t);void(*back)(void);} Menu;
enum {STRING_GAME,KEYBOARD_MODE_MENU,KEYBOARD_MODE_GAME,KEY_RIGHT,KEY_UP,KEY_DOWN,ALERTLEVEL_NONE};
extern uint32_t currentTick;
void setKeyboardMode(int); bool isGameKeyHeld(int); bool isKeyboardGameMode(void);
void showMenu(const Menu*);void showSettingsMenu(void);void selectMenuItem(const Menu*,menu_size_t);
void requestViewUpdate(void);void requestBacklightTrigger(void);void showView(OnViewEvent*);bool isCurrentView(OnViewEvent*);
bool isPoweredOn(void);bool isDisplayAwake(void);int getAlertLevel(void);void setMeasurementView(void);
#endif
