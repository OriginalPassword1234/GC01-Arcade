#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
extern void reference_rider_render(const RiderState*,const RiderState*,uint8_t,RiderPixels,void*);
static uint16_t frames[2][320*240];
static void sink(int y,int rows,const uint16_t *p,void *ctx){unsigned n=*(unsigned*)ctx;memcpy(frames[n]+y*320,p,(size_t)rows*320*sizeof(*p));}
static void check(RiderState *s,RiderState *p,uint8_t alpha){unsigned a=0,b=1;rider_render(s,p,alpha,sink,&a);reference_rider_render(s,p,alpha,sink,&b);assert(!memcmp(frames[0],frames[1],sizeof frames[0]));}
int main(void){unsigned total=0;for(unsigned k=0;k<RIDER_TEMPLATE_COUNT;++k){RiderState s;rider_init(&s,7);for(unsigned i=0;i<RIDER_TRACK_SLOTS;++i){s.track[i].template_id=0;s.track[i].start_y=166;s.track[i].flags=0;}s.track[1].template_id=(uint8_t)k;s.track[1].flags=15;s.x=320*256;s.y=161*256;s.phase=RIDER_RUNNING;s.throttle_active=1;
for(unsigned j=0;j<5;++j){s.camera_x=(130+j*43)*256+127;s.camera_y=((int)j*70-100)*256;s.tick_count=j*33;check(&s,NULL,0);++total;}}
for(unsigned seed=1;seed<=3;++seed){RiderState s;rider_init(&s,seed);for(unsigned t=0;t<400;++t){RiderState p=s;rider_step(&s,s.grounded);if(s.phase==RIDER_CRASHED){rider_restart(&s);p=s;}if(!(t%8)){check(&s,&p,(uint8_t)t);++total;}}}printf("PASS: %u pixel-identical full frames against scalar/unculled reference of new visuals\n",total);return 0;}
