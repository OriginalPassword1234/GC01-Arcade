#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
mkdir -p "$work"/{extras,measurements,peripherals,system,ui}
# CI installs actual overlay next to rider_ci; local package same hierarchy.
cp ../overlay/platform.io/src/extras/rider_app.c "$work/extras/"
cp src/rider_core.h rider_saves.h "$work/extras/"
cp rider_screen.h "$work/ui/"
cp tests/app_shim_v31.h "$work/shim.h"
for p in measurements/measurements.h peripherals/keyboard.h system/events.h system/power.h system/settings.h ui/menu.h ui/view.h extras/game.h; do printf '#include "../shim.h"\n' > "$work/$p"; done
"${CC:-gcc}" -std=c11 -O1 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -no-pie -DGC01_RIDER -I"$work" src/rider_core.c tests/test_app_v32.c -o "$work/test"
UBSAN_OPTIONS=halt_on_error=1 "$work/test"
