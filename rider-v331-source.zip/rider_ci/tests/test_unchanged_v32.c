/* Exact geometry comparison against v3.1. Intentional palette, bike and texture changes are not required to match the old image. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
extern void base_rider_init(RiderState*,uint32_t);
extern bool base_rider_surface_q(const RiderState*,int32_t,int32_t*);
static uint16_t frames[2][320*240];
static void sink(int y,int rows,const uint16_t *p,void *ctx){unsigned n=*(unsigned*)ctx;memcpy(frames[n]+y*320,p,(size_t)rows*320*sizeof(*p));}
static void render_compare(const RiderState *s,const RiderState *p,const RiderState *expected,uint8_t alpha){unsigned a=0,b=1;rider_render(s,p,alpha,sink,&a);rider_render(expected,NULL,0,sink,&b);assert(!memcmp(frames[0],frames[1],sizeof frames[0]));}
int main(void){unsigned samples=0;
 for(unsigned k=0;k<RIDER_TEMPLATE_COUNT;k++)for(unsigned h=0;h<3;h++)for(unsigned phase=0;phase<2;phase++){
 RiderState s;base_rider_init(&s,1);for(unsigned i=0;i<12;i++){s.track[i].template_id=0;s.track[i].flags=0;s.track[i].gem_mask=0;s.track[i].start_y=(int16_t)(108+53*h);}
 s.track[1].template_id=(uint8_t)k;s.track[1].flags=phase?128u|16u:0;s.track[1].fall_tick=10;s.tick_count=phase?30:7;
 for(unsigned x=0;x<65536;x+=7){int32_t a=0,b=0;bool p=rider_surface_q(&s,65536+(int32_t)x,&a),q=base_rider_surface_q(&s,65536+(int32_t)x,&b);assert(p==q&&(!p||a==b));samples++;}}
 printf("PASS: %u exact v3.1 surface queries across all templates, elevations and phases\n",samples);
 RiderState s,p,e;rider_init(&s,2);for(unsigned i=0;i<12;i++){s.track[i].template_id=0;s.track[i].flags=0;}
 s.phase=RIDER_RUNNING;s.grounded=1;s.x=80*256;s.y=161*256;s.camera_x=-60*256;s.camera_y=-29*256;s.angle=0;p=s;
 p.grounded=0;p.x-=4*256;p.y-=2*256;p.camera_x-=4*256;p.camera_y-=256;p.angle=4096-128;
 for(unsigned alpha=0;alpha<256;alpha+=17){e=s;int b=(int)(256-alpha);e.x-=4*256*b/256;e.y-=2*256*b/256;e.camera_x-=4*256*b/256;e.camera_y-=256*b/256;e.angle-=128*b/256;render_compare(&s,&p,&e,(uint8_t)alpha);}
 puts("PASS: 16 interpolation phases across airborne-to-ground transition, including angle wrap");return 0;}
