/* Lossless flash-fit regression: actual unmodified v3.3 vs current code. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
extern void base_rider_init(RiderState*,uint32_t);
extern void base_rider_restart(RiderState*);
extern void base_rider_step_controls(RiderState*,bool,bool);
extern bool base_rider_surface_q(const RiderState*,int32_t,int32_t*);
extern bool base_rider_platform_at_q(const RiderState*,uint32_t,unsigned,int32_t*,int32_t*,int32_t*);
extern bool base_rider_piece_gem_q(const RiderState*,uint32_t,uint8_t,int32_t*,int32_t*);
extern bool base_rider_special_point_q(uint32_t,uint8_t,uint16_t,int32_t*,int32_t*);
extern void base_rider_render(const RiderState*,const RiderState*,uint8_t,RiderPixels,void*);
static uint16_t frame[2][320*240];
static void sink(int y,int n,const uint16_t *p,void *ctx){unsigned i=*(unsigned*)ctx;memcpy(frame[i]+y*320,p,(size_t)n*320*sizeof(*p));}
static void compare_frame(const RiderState *s,const RiderState *prev,uint8_t alpha){unsigned a=0,b=1;base_rider_render(s,prev,alpha,sink,&a);rider_render(s,prev,alpha,sink,&b);assert(!memcmp(frame[0],frame[1],sizeof frame[0]));}
static uint32_t rng=0x49d1u;
static uint32_t rnd(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static void fixture(RiderState *s,unsigned k){base_rider_init(s,17);for(unsigned j=0;j<RIDER_TRACK_SLOTS;j++){s->track[j].template_id=0;s->track[j].start_y=166;s->track[j].flags=0;}s->track[1].template_id=(uint8_t)k;s->track[1].flags=15;s->track[1].gem_mask=7;s->phase=RIDER_RUNNING;s->x=320*256;s->y=161*256;}
int main(void){
 unsigned surfaces=0,objects=0,paths=0,frames=0,steps=0;
 for(unsigned k=0;k<RIDER_TEMPLATE_COUNT;k++){
  RiderState s;fixture(&s,k);
  for(unsigned h=0;h<3;h++)for(unsigned f=0;f<8;f++)for(unsigned t=0;t<12;t++){
   s.track[1].start_y=(int16_t)(108+53*h);s.track[1].flags=(uint8_t)(15|((f&1)?16:0)|((f&2)?64:0)|((f&4)?128:0));
   static const uint32_t ticks[]={0,2,3,6,7,21,22,28,29,49,81,65536};s.tick_count=ticks[t];s.track[1].fall_tick=0;
   for(unsigned slot=0;slot<3;slot++){
    int32_t a[3]={-123,-456,-789},b[3]={-123,-456,-789};bool q=base_rider_platform_at_q(&s,1,slot,&a[0],&a[1],&a[2]),v=rider_platform_at_q(&s,1,slot,&b[0],&b[1],&b[2]);assert(q==v&&!memcmp(a,b,sizeof a));objects++;
    q=base_rider_piece_gem_q(&s,1,(uint8_t)slot,&a[0],&a[1]);v=rider_piece_gem_q(&s,1,(uint8_t)slot,&b[0],&b[1]);assert(q==v&&(!q||!memcmp(a,b,sizeof a)));objects++;
   }
   for(unsigned x=0;x<65536;x+=37){int32_t a=0,b=0;bool q=base_rider_surface_q(&s,65536+(int32_t)x,&a),v=rider_surface_q(&s,65536+(int32_t)x,&b);assert(q==v&&(!q||a==b));surfaces++;}
  }
  for(unsigned t=0;t<=4096;t++){int32_t a=0,b=0,c=0,d=0;bool q=base_rider_special_point_q(1,(uint8_t)k,(uint16_t)t,&a,&b),v=rider_special_point_q(1,(uint8_t)k,(uint16_t)t,&c,&d);assert(q==v&&(!q||(a==c&&b==d)));paths++;}
  fixture(&s,k);s.throttle_active=1;for(unsigned t=0;t<5;t++){s.camera_x=(130+(int)t*43)*256+127;s.camera_y=((int)t*70-100)*256;s.tick_count=t*33;s.angle=(int32_t)t*811;compare_frame(&s,NULL,0);frames++;}
 }
 for(unsigned seed=1;seed<=256;seed++){
  RiderState a,b;uint32_t key=seed*0x9e3779b9u;base_rider_init(&a,key);rider_init(&b,key);assert(!memcmp(&a,&b,sizeof a));
  for(unsigned t=0;t<3000;t++){
   RiderState prev=a;uint32_t v=rnd();bool held=(v&15u)<12u,brake=((v>>8)&15u)==0u;base_rider_step_controls(&a,held,brake);rider_step_controls(&b,held,brake);assert(!memcmp(&a,&b,sizeof a));steps++;
   if(a.phase==RIDER_CRASHED){base_rider_restart(&a);rider_restart(&b);assert(!memcmp(&a,&b,sizeof a));prev=a;}
   if(seed<=3u && t%60u==0u){compare_frame(&a,&prev,(uint8_t)v);frames++;}
  }
 }
 printf("PASS: %u exact full states, %u surface queries, %u platform/gem queries, %u path queries, %u pixel-identical full frames\n",steps,surfaces,objects,paths,frames);return 0;
}
