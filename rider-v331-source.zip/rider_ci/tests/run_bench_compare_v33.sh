#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-gcc}
mapfile -t names < <(grep -hE '^(bool|void|int16_t|int32_t|uint8_t|uint32_t) rider_[a-zA-Z0-9_]+\(' baseline_v32/src/*.h | sed -E 's/^[^ ]+ (rider_[a-zA-Z0-9_]+)\(.*/\1/' | sort -u)
rename=(); for n in "${names[@]}" rider_screen_invalidate rider_draw_gc01_snapshot rider_draw_gc01; do rename+=("-D$n=base_$n"); done
flags=(-std=c11 -O2 -Wall -Wextra -Werror -DGC01_RIDER -DRIDER_HOST_TEST -Itests/fake -Isrc -I.)
for name in src/rider_core src/rider_render rider_screen; do "$cc" "${flags[@]}" "${rename[@]}" -Ibaseline_v32/src -c "baseline_v32/$name.c" -o "$work/$(basename "$name").o"; done
"$cc" "${flags[@]}" src/rider_core.c src/rider_render.c rider_screen.c tests/bench_compare_v33.c "$work/"*.o -o "$work/test"
"$work/test"
