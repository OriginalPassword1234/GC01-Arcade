#define _POSIX_C_SOURCE 200809L
#include "../src/rider_render.h"
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>
extern void base_rider_render(const RiderState*,const RiderState*,uint8_t,RiderPixels,void*);
static volatile uint32_t sinkval;
static void sink(int y,int n,const uint16_t *p,void *ctx){(void)ctx;sinkval+=p[(y%n)*320];}
static uint64_t now(void){struct timespec t;assert(!clock_gettime(CLOCK_MONOTONIC,&t));return (uint64_t)t.tv_sec*1000000000u+(uint64_t)t.tv_nsec;}
int main(void){
    puts("template,old_us,new_us,change_pct (CPU-only host, no hardware transfer)");
    const uint8_t kinds[]={0,9,25,27,45,46,54,56,57,58,59,60,65,70,71,72,80,81,82,83};
    for(unsigned j=0;j<sizeof kinds;j++){
        unsigned k=kinds[j];RiderState s;rider_init(&s,1);
        for(unsigned i=0;i<RIDER_TRACK_SLOTS;i++){s.track[i].template_id=0;s.track[i].start_y=166;s.track[i].flags=0;s.track[i].gem_mask=0;}
        s.track[1].template_id=k;s.track[1].flags=15;s.track[1].gem_mask=7;s.x=350*256;s.y=161*256;s.phase=RIDER_RUNNING;s.throttle_active=1;s.vx=1024;s.grounded=1;
        uint64_t time[2]={0,0};
        for(unsigned trial=0;trial<5;trial++)for(unsigned mode0=0;mode0<2;mode0++){
            unsigned mode=(trial&1u)^mode0;uint64_t start=now();
            for(unsigned f=0;f<120;f++){
                s.camera_x=(90+(f%81))*256+127;s.camera_y=(-58+(int)(f%35))*256;s.tick_count=f*3;
                if(mode)rider_render(&s,NULL,0,sink,NULL);else base_rider_render(&s,NULL,0,sink,NULL);
            }time[mode]+=now()-start;
        }
        printf("%u,%.2f,%.2f,%+.2f\n",k,time[0]/600000.0,time[1]/600000.0,100.0*((double)time[1]/time[0]-1.0));
    }return sinkval==0;
}
