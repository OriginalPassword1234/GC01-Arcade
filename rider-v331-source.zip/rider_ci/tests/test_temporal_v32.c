#include <assert.h>
#include <stdio.h>
#include "../src/rider_render.c"
static int background_at(int x,int origin){int t=x+(origin&7),block=t>>3,j=t&7;return backdrop[block]+(backdrop[block+1]-backdrop[block])*j/8;}
int main(void){
 RiderState s;rider_init(&s,1);for(unsigned i=0;i<RIDER_TRACK_SLOTS;++i){s.track[i].template_id=0;s.track[i].start_y=166;s.track[i].flags=0;}
 int previous[W],samples=0,sky_limit,rail_top;
 for(int pos=-24;pos<=540;++pos){
     int32_t cam=pos*384;int origin=screen_x(cam,0);assert(origin==pos);build_caches(&s,cam,-30*256,origin,&sky_limit,&rail_top);
     for(int x=0;x<W;++x){int y=background_at(x,origin);if(pos>-24&&x<W-1){assert(y==previous[x+1]);samples++;}}
     for(int x=0;x<W;++x)previous[x]=background_at(x,origin);
     /* Fractional movement within a screen pixel never shifts rock phase. */
     for(int fraction=1;fraction<384;fraction+=95){assert(screen_x(cam+fraction,0)==origin);build_caches(&s,cam+fraction,-30*256,origin,&sky_limit,&rail_top);for(int x=0;x<W;++x)assert(background_at(x,origin)==previous[x]);}
 }
 /* Body mask anchored to world screen cells, not physical LCD columns. */
 for(int pos=-12;pos<28;++pos){
     build_caches(&s,pos*384,-30*256,pos,&sky_limit,&rail_top);memset(facet,255,sizeof facet);mark_facet(100-pos,180-pos,254,pos);
     for(int x=70-pos;x<210-pos;++x)assert((facet[facet_index(x,pos)]==254)==(x+pos>=100&&x+pos<184));
 }
 assert(rail_palette[7]==rail_palette[0]&&rail_palette[8]!=rail_palette[0]&&rail_palette[31]==0);
 /* Visual wheel centers map to the same +/-8 screen-pixel physical axles.
    Bottom of tire remains close to the 5-world-pixel support distance. */
 assert(bike_pixel(-12,-1)==CAR_DARK&&bike_pixel(12,-1)==CAR_DARK);
 assert(bike_pixel(-12,4)==RGB(235,255,241));assert(bike_pixel(-12,5)==0);
 printf("PASS: %d stable translated backdrop samples, fractional rock phase and facet alignment, thicker rail and aligned wheels\n",samples);return 0;
}
