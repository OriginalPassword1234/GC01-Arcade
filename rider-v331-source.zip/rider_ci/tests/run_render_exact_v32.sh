#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-gcc}
python3 - "$work/ref_render.c" <<'PYREF'
from pathlib import Path
import sys
p=Path('src/rider_render.c').read_text()
a='if(top+STRIP_ROWS>rail_top_limit && top<=lower_rail_limit)'
assert p.count(a)==1
p=p.replace(a,'if(top+STRIP_ROWS>upper_sky_limit)')
p=p.replace('int lower_rail_limit=build_caches(s,camx,camy,origin,&upper_sky_limit,&rail_top_limit);','(void)build_caches(s,camx,camy,origin,&upper_sky_limit,&rail_top_limit);')
a='#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__'
assert p.count(a)==1
p=p.replace(a,'#if 0')
a='        int y0=loop_anchor_y[j]+loop_dy[j][i-1],y1=loop_anchor_y[j]+loop_dy[j][i];\n        if(imax(y0,y1)+9<top || imin(y0,y1)-8>=top+STRIP_ROWS)continue;\n'
assert p.count(a)==1
p=p.replace(a,'')
Path(sys.argv[1]).write_text(p)
PYREF
flags=(-std=c11 -O2 -Wall -Wextra -Werror)
"$cc" "${flags[@]}" -Drider_render=reference_rider_render -Drider_render_snapshot=reference_rider_render_snapshot -Drider_render_static_ram=reference_rider_render_static_ram -Isrc -c "$work/ref_render.c" -o "$work/ref.o"
"$cc" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_render_exact_v32.c "$work/ref.o" -o "$work/test"
"$work/test"
