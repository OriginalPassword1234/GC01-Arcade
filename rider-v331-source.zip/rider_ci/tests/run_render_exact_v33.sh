#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-gcc}
python3 - "$work/ref_render.c" <<'PYREF'
from pathlib import Path
import sys
p=Path('src/rider_render.c').read_text()
a='if(top+STRIP_ROWS>rail_top_limit && top<=lower_rail_limit)'
assert p.count(a)==1
p=p.replace(a,'if(top+STRIP_ROWS>upper_sky_limit)')
a='#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__'
assert p.count(a)==1
p=p.replace(a,'#if 0')
base=Path('baseline_v32/src/rider_render.c').read_text()
# Restore the old exact geometry paths, preserving intentional v3.3 colors.
for start,end in [('static unsigned saw_mask_at(','/* Paint only object bounding boxes'),('static void paint_segment_q2(','/* Same Q4 ring test')]:
    if start.startswith('static void paint_segment'):
        ref_end='static void paint_objects('
    else: ref_end=end
    p=p[:p.index(start)]+base[base.index(start):base.index(ref_end)]+p[p.index(end):]
a='            if(y<174){'
assert p.count(a)==1;p=p.replace(a,'            uniform=0;\n'+a)
a=p.index('static inline unsigned ring_pixel(');b=p.index('static void paint_objects(',a)
p=p[:a]+p[b:]
a=p.index('        if(y0>=y1||x0>=x1)continue;');b=p.index('    int tx=throttle?',a)
x=base.index('        for(int y=y0;y<y1;++y){',base.index('    for(uint8_t i=0;i<saw_n;++i)'));y=base.index('    int tx=throttle?',x)
p=p[:a]+base[x:y]+p[b:]
Path(sys.argv[1]).write_text(p)
PYREF
flags=(-std=c11 -O2 -Wall -Wextra -Werror)
"$cc" "${flags[@]}" -Drider_render=reference_rider_render -Drider_render_snapshot=reference_rider_render_snapshot -Drider_render_static_ram=reference_rider_render_static_ram -Isrc -c "$work/ref_render.c" -o "$work/ref.o"
"$cc" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_render_exact_v33.c "$work/ref.o" -o "$work/test"
"$work/test"
