/* Independent Rider-inspired simulation prototype v2.2 (lossless size optimization of v2.1a).
 * Builds on v0.4 with more section variety, saw/boost piece metadata,
 * small gaps, subpixel track sampling and compact hazard collision checks.
 * Still NOT a Box2D/LiquidFun port and still not full original parity. */
#include "rider_core.h"
#include <limits.h>
#include <string.h>

#define NORMAL_SPEED_CAP_Q 1126 /* v3.0/v3.1 1024; +9.96% */
#define SPIN_CAP 84             /* v3.0 70; v3.1 128 */
#define PIECE_FLAG_GEM   0x01u
#define PIECE_FLAG_SAW   0x02u
#define PIECE_FLAG_BOOST 0x04u
#define PIECE_FLAG_SPIKES 0x08u
#define PIECE_FLAG_FALLING 0x10u
#define PIECE_FLAG_HARD 0x80u

/* Compact synthesized geometry. Template 16 is a real non-heightfield
 * loop PATH, guided by the same model used to draw it. Not original game data. */
static const int8_t heights[][7] = {
    {0,0,0,0,0,0,0},
    {0,-5,-20,-29,-18,-4,0},
    {0,8,24,30,17,3,0},
    {-4,-17,-9,5,0,-12,-3},
    {0,-9,-28,-16,-3,9,0},
    {0,6,18,8,-14,-24,-5},
    {0,-8,-22,-34,-17,-7,0},
    {0,5,14,24,10,-8,0},
    {0,-12,-30,-42,-24,-9,0},
    {0,10,28,38,20,5,0},
    {-2,-10,-5,12,3,-14,-5},
    {0,-4,-12,-18,-10,-4,0},
    {0,-2,-8,-10,-7,-2,0},
    {-6,-21,-32,-35,12,22,8},
    {0,-10,-29,-43,-8,12,1},
    {-5,-14,-25,-34,2,17,5},
    {0,-8,-16,-14,-8,-3,0},
    {0,9,17,10,-10,-17,-4},
    {0,-8,-30,-40,-32,-8,0},
    {0,4,12,7,0,-4,0},
    {-4,-15,-28,-8,18,8,-3},
    {0,-4,-11,-18,-5,4,0},
    {-3,-15,-20,-6,-23,-11,-3},
    {0,5,16,25,-10,-24,-7},
    {-2,-9,-22,-36,-22,-8,0},
    {0,-8,-16,3,15,4,0},
    {0,-18,-45,-58,-31,-5,0},
    {3,16,27,31,17,-8,0},
    {-3,-12,-26,-40,-31,-15,-3},
    {0,0,-11,-30,-35,-17,-1},
    {0,6,23,36,15,0,0},
    {-1,-8,-18,-31,-28,-6,0},
    {0,-3,-15,-28,-10,9,0},
    {0,10,22,13,-12,-29,-5},
    {-3,-10,-12,0,8,15,4},
    {0,0,-7,-16,-25,-15,-3},
    {0,0,-4,-26,29,20,7},
    {0,0,-10,-30,-54,-38,-8},
    {1,9,24,34,29,15,4},
    {0,0,-4,-25,-58,-40,-8},
    {-2,-9,-20,-33,-39,-28,-9},
    {3,25,57,89,57,25,3},
    {-3,-23,-55,-87,-55,-23,-3},
    {8,34,65,81,69,39,12},
    {-4,-23,-48,-75,26,37,19},
    {-8,-30,-55,-70,-35,-10,0},
    {0,-8,-38,-78,-69,-34,-8},
    {0,-8,-13,-13,-13,-8,0},
    {0,-16,-53,-65,-14,22,13},
    {-2,-5,13,49,13,-5,-2},
    {-24,-47,-18,27,47,22,-8},
    {-28,-45,-4,-38,15,-24,-12},
    {12,32,44,30,-12,-46,-24},
    {-8,-30,-10,32,12,-34,-18},
    {-8,-35,-56,-22,32,35,14},
    {8,28,30,0,-32,-34,-10},
    {-8,-24,-6,12,-24,-42,-10},
    {4,23,49,52,36,8,0},
    {-6,-30,-20,50,-20,-30,-6},
    {-4,-10,-12,-12,-12,-10,-4},
    {-5,-28,-52,-22,26,49,27},
    {18,39,16,-25,-48,-20,12},
    {0,-14,-43,-66,16,29,12},
    {-31,-5,-39,-7,-33,-4,-21},
    {0,-18,-52,-71,32,42,22},
    {9,34,66,38,-15,-48,-14},
};
static const uint8_t height_index[RIDER_TEMPLATE_COUNT]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0,16,17,18,19,20,21,22,23,24,25,0,0,26,27,28,29,30,31,0,32,33,34,35,36,37,38,39,40,0,0,0,0,41,42,43,0,44,45,0,46,47,47,48,49,50,51,52,53,0,54,55,56,57,47,47,59,60,61,0,62,63,64,65,47,0,0,0};
#define N_TEMPLATES ((uint32_t)sizeof(height_index))
_Static_assert(N_TEMPLATES == RIDER_TEMPLATE_COUNT, "track table/count mismatch");
/* Exact quarter-wave symmetry: all original 256 values reproduced. */
static const uint8_t sine_quarter[62] = {
    0, 6, 13, 19, 25, 31, 38, 44, 50, 56, 62, 68, 74, 80, 86, 92, 98, 104, 109, 115, 121, 126, 132, 137, 142, 147, 152, 157, 162, 167, 172, 177, 181, 185, 190, 194, 198, 202, 206, 209, 213, 216, 220, 223, 226, 229, 231, 234, 237, 239, 241, 243, 245, 247, 248, 250, 251, 252, 253, 254, 255, 255
};
int16_t rider_sin256(uint8_t angle_index) { unsigned i=angle_index&63u;
    i=(angle_index&64u)?64u-i:i;
    int16_t v=i>=62u?256:sine_quarter[i];
    return (angle_index&128u)?-v:v; }
int16_t rider_sin4096(int32_t angle)
{
    uint32_t a=(uint32_t)angle & (RIDER_ANGLE_TURN-1u);
    uint32_t k=a>>4, f=a&15u;
    int32_t v0=rider_sin256((uint8_t)k), v1=rider_sin256((uint8_t)(k+1u));
    return (int16_t)(v0+(v1-v0)*(int32_t)f/16);
}
/* A full, continuously curved loop with long shallow approach/exit,
 * whose rail is not a heightfield. The large circle follows the visual
 * proportions in the reference frames and retains a rounded entry tangent.
 * Coordinates Q8; no dynamic allocation, no float operations in firmware. */
static bool circular_path(uint32_t pn,int32_t t,int32_t base,int32_t advance,int32_t rx,int32_t ry,int32_t *xq,int32_t *yq)
{
    if(t>4096 || pn>25000u || !xq || !yq)return false;
    *xq=(int32_t)(pn*256u+(uint32_t)base)*RIDER_Q+advance*RIDER_Q*t/4096+rx*rider_sin4096(t);
    *yq=166*RIDER_Q-ry*(RIDER_Q-rider_sin4096(t+1024));
    return true;
}
__attribute__((noinline)) bool rider_loop_point_q(uint32_t pn,uint16_t t,int32_t *xq,int32_t *yq)
{
    return circular_path(pn,t,68,88,78,62,xq,yq);
}
static bool rider_micro_loop_point_q(uint32_t pn,uint16_t t,int32_t *xq,int32_t *yq)
{
    return circular_path(pn,t,68,65,42,32,xq,yq);
}
static const uint8_t wall_xy[][2] = {
    {70,166},{93,164},{113,147},{125,112},{127,78},{140,54},{165,45}
};
/* Open C-shaped curved rail. It launches the bike into the next platform
 * after the lip rather than pretending to be a closed circle or a hill. */
static const uint8_t open_xy[][2] = {
    {70,166},{85,166},{102,153},{112,131},{110,107},{96,86},
    {75,81},{55,92},{49,114},{65,133},{92,134},{119,124},{150,122}
};
static int32_t cubic_axis(int32_t u,int32_t v,int32_t a,int32_t b,int32_t c,int32_t d)
{
    int32_t p=(a*v+b*u)/4,q=(b*v+c*u)/4,r=(c*v+d*u)/4;
    p=(p*v+q*u)/1024;q=(q*v+r*u)/1024;
    return (p*v+q*u)/1024;
}
static __attribute__((noinline)) int32_t hermite(int32_t u,int32_t v0,int32_t v1,int32_t m0,int32_t m1)
{
    int32_t u2=u*u/256,u3=u2*u/256;
    int32_t a=2*u3-3*u2+256,b=-2*u3+3*u2,c=u3-2*u2+u,d=u3-u2;
    return a*v0+b*v1+c*m0+d*m1;
}
bool rider_special_point_q(uint32_t pn,uint8_t kind,uint16_t t,int32_t *xq,int32_t *yq)
{
    if(!xq||!yq||t>4096||pn>25000u)return false;
    if(kind==45u){
        /* Reference 70992: a rising rail curls around an OPEN circle,
         * then launches toward a physically separate lower landing.
         * The 60-degree opening remains a genuine gap. */
        int32_t bx=(int32_t)(pn*256u)*RIDER_Q;
        if(t<1024u){
            int32_t u=(int32_t)t, v=1024-u;
            /* De Casteljau at Q8, smooth tangent into the circular rail. */
            *xq=bx+cubic_axis(u,v,34,65,102,125);
            *yq=cubic_axis(u,v,166,166,141,125);
        }else{
            int32_t a=626-((int32_t)(t-1024u)*3413)/3072;
            *xq=bx+100*RIDER_Q+43*rider_sin4096(a+1024);
            *yq=90*RIDER_Q+43*rider_sin4096(a);
        }
        return true;
    }
    if(kind==16u)return rider_loop_point_q(pn,t,xq,yq);
    if(kind==52u||kind==65u){
        if(!rider_loop_point_q(pn,t,xq,yq))return false;
        if(kind==65u){
            /* Keep the upper three quarters centred over the rotating red
             * ring. Ease the horizontal separation into the lower entry
             * and exit, rather than shearing the entire circle. */
            int32_t u=t<1024u?(int32_t)t/4:t>3072u?(4096-(int32_t)t)/4:256;
            int32_t drift=44*hermite(u,0,1,0,0);
            if(t>3072u)drift=88*RIDER_Q-drift;
            *xq+=drift-88*RIDER_Q*t/4096-12*rider_sin4096(t);
        }
        *yq-=32*RIDER_Q;
        return true;
    }
    if(kind==47u)return rider_micro_loop_point_q(pn,t,xq,yq);
    if(kind==75u){
        /* Two genuinely distinct 2-D rail turns with continuous horizontal
         * tangents at the shared bottom point. One path, no extra state. */
        int32_t u=(int32_t)t*2;
        int32_t bx=48,advance=64,rx=43,ry=36;
        if(t>=2048u){u-=4096;bx=112;advance=78;rx=58;ry=48;}
        return circular_path(pn,u,bx,advance,rx,ry,xq,yq);
    }
    if(kind==54u){
        /* Separate open arc over the crest. Traversal starts at the lower
         * right, then wraps around the top and exits at the lower left.
         * Unlike a closed track loop, the lower opening is not connected
         * to the continuous heightfield under it. */
        int32_t a=448-(int32_t)t*2944/4096;
        *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+130u)*RIDER_Q+48*rider_sin4096(a+1024);
        *yq=50*RIDER_Q+45*rider_sin4096(a);
        return true;
    }
    const uint8_t (*points)[2]=NULL;
    uint32_t segments=6u;
    if(kind==27u)points=wall_xy;
    if(kind==28u){
        *xq=(int32_t)(pn*256u+70u)*RIDER_Q+128*RIDER_Q*t/4096;
        *yq=166*RIDER_Q+27*(RIDER_Q-rider_sin4096(t+1024));
        return true;
    }
    if(kind==46u){points=open_xy;segments=12u;}
    if(!points)return false;
    uint32_t step=(uint32_t)t*segments, k=step/4096u;
    if(k>=segments)k=segments-1u;
    uint32_t frac=step-k*4096u;
    /* Cubic Hermite between authored 2D knots. Straight joining lines
     * made the old open arcs look hexagonal; this shares the exact rail
     * path with collision and uses integer-only fixed point. */
    const int32_t u=(int32_t)(frac>>4); /* [0,256] */
    int32_t mx0=(points[k+1][0]-points[k? k-1u: k][0])/2;
    int32_t my0=(points[k+1][1]-points[k? k-1u: k][1])/2;
    int32_t mx1=(points[(k+2u<=segments)? k+2u:k+1u][0]-points[k][0])/2;
    int32_t my1=(points[(k+2u<=segments)? k+2u:k+1u][1]-points[k][1])/2;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q +
        hermite(u,points[k][0],points[k+1][0],mx0,mx1);
    *yq=hermite(u,points[k][1],points[k+1][1],my0,my1);
    return true;
}
static __attribute__((noinline)) const RiderPiece *piece_at(const RiderState *s,uint32_t pn)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    return pn<s->next_piece && p->number==pn ? p : NULL;
}
bool rider_track_special_q(const RiderState *s,uint32_t pn,uint8_t kind,uint16_t t,int32_t *xq,int32_t *yq)
{
    const RiderPiece *p=piece_at(s,pn);
    if(!p || p->template_id!=kind ||
       !rider_special_point_q(pn,kind,t,xq,yq))return false;
    *yq+=((int32_t)p->start_y-166)*RIDER_Q;
    return true;
}
/* Compact immutable template classification, shared by physics and drawing. */
static const uint8_t template_properties[RIDER_TEMPLATE_COUNT]={
    128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 1, 32, 0, 0, 0, 0, 0, 128, 32, 0, 0, 0, 16, 32, 128, 32, 128, 69, 69, 67, 0, 0, 0, 0, 67, 0, 5, 16, 0, 8, 8, 16, 0, 0, 0, 0, 0, 67, 0, 0, 0, 0, 8, 0, 0, 0, 0, 67, 16, 0, 16, 0, 16, 16, 0, 0
};
uint8_t rider_template_properties(uint8_t k){return k<RIDER_TEMPLATE_COUNT?template_properties[k]:0u;}
static __attribute__((noinline)) bool special_piece(uint8_t k){return (rider_template_properties(k)&RIDER_T_SPECIAL)!=0;}
static __attribute__((noinline)) int32_t angle_from_vector(int32_t dx,int32_t dy)
{
    /* atan2 approximation in 4096 turn units, max error a few degrees. */
    int32_t ax=dx<0?-dx:dx, ay=dy<0?-dy:dy;
    if(!ax && !ay) return 0;
    int32_t oct=(ax>=ay)? (ay*512)/(ax?ax:1) :
                              1024-(ax*512)/ay;
    if(dx<0) oct=2048-oct;
    if(dy<0) oct=-oct;
    return oct;
}

static __attribute__((noinline)) uint32_t next_random(RiderState *s)
{
    uint32_t x = s->random_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    s->random_state = x;
    return x;
}

static __attribute__((noinline)) int32_t clamp_i32(int32_t a,int32_t lo,int32_t hi)
{
    return a<lo ? lo : a>hi ? hi : a;
}
static __attribute__((noinline)) int32_t smooth_q8(int32_t u)
{
    int32_t u2=u*u/256;
    return 3*u2-2*u2*u/256;
}
static __attribute__((noinline)) bool surface_delta(const RiderState *s,int32_t a,int32_t b,int32_t *delta)
{
    int32_t lo,hi;
    if(!rider_surface_q(s,a,&lo)||!rider_surface_q(s,b,&hi))return false;
    *delta=hi-lo;return true;
}
static void free_air(RiderState *s)
{
    s->grounded=0;s->takeoff_angle=s->angle;s->air_rotation=0;
    s->angular_speed=0;s->airborne_ticks=0;
}


/* Each three-piece group is an intentionally designed challenge:
 * an approach, a launch/obstacle, then a suitable runout.  The long flat
 * streaks in v1.0 made almost every run boring and suppressed the score
 * progression needed to unlock later stages.  Difficulty is now also
 * unlocked by distance, so runs with no scored flips don't get stuck
 * in the initial pool forever.  All section data stays in FLASH. */
static __attribute__((noinline)) uint8_t choose_template(RiderState *s, uint32_t pn)
{
    /* Seeded challenge/recovery groups. Ordinary hazards are available from
     * the first challenge; demanding combinations gain weight with score. */
    static const uint8_t ordinary[]={29,36,19,41,31,43,34,14,39,45,46,54,40,57,58,59,60,70,9,10,25,27,28,48,51,53,55,56,65,76,11,12,13,15,21,22,26,30,49,50,1,2,3,4,5,6,7,8,17,18,20,23,24,32,33,37,38,82,83};
    static const uint8_t expert[]={61,62,63,64,66,67,68,69,71,72,73,74,77,78,79,80,81,82,83};
    static const uint8_t easy[]={0,35,42,44};
    uint32_t rnd=next_random(s);
    unsigned difficulty=(unsigned)clamp_i32(s->score,0,400);
    unsigned phase=pn%3u;
    if(phase==1u)return (rnd&1u)?0u:35u; /* flat launch approach */
    if(phase==0u){
        /* Extra compound approaches after a ground-based obstacle; avoid
         * placing a second guided loop or a gap immediately after a launch. */
        static const uint8_t link[]={29,36,39,41,43,60};
        uint8_t prior=s->last_template;
        if(difficulty>=100u && (rnd&511u)<difficulty-80u &&
           (prior==29u||prior==36u||prior==39u||prior==41u||prior==43u||prior==60u))
            return link[(rnd>>16)%sizeof(link)];
        return easy[(rnd>>16)&3u];
    }
    bool flat=s->last_template==0u||s->last_template==35u;
    if(!flat)return easy[(rnd>>16)&3u];
    uint8_t k;
    if(difficulty>=50u && (rnd&511u)<difficulty-40u)
        k=expert[(rnd>>16)%sizeof(expert)];
    else k=ordinary[(rnd>>16)%sizeof(ordinary)];
    if(pn>=3u && k==s->track[(pn-3u)%RIDER_TRACK_SLOTS].template_id)
        k=ordinary[next_random(s)%sizeof(ordinary)];
    return k;
}

/* Bounded continuous elevation changes on ordinary slopes. No extra state.
 * Start/end tangents of the additional smoothstep are zero. */
static __attribute__((noinline)) int32_t piece_end_delta(uint8_t kind,int32_t start_y)
{
    static const int8_t delta[RIDER_TEMPLATE_COUNT]={
        [42]=32,[51]=32,[30]=24,[44]=-32,[34]=-32,[55]=-72,[73]=24,[74]=-24,[79]=-24
    };
    int32_t d=kind<RIDER_TEMPLATE_COUNT?delta[kind]:0;
    return clamp_i32(start_y+d,108,214)-start_y;
}
static void append_piece(RiderState *s)
{
    uint32_t n = s->next_piece++;
    RiderPiece *p = &s->track[n % RIDER_TRACK_SLOTS];
    uint8_t pattern = 0;
    if (n != 0) pattern = choose_template(s,n);
    p->number = n;
    p->template_id = pattern;
    p->start_y = 166;
    if(n){
        const RiderPiece *prev=&s->track[(n-1u)%RIDER_TRACK_SLOTS];
        p->start_y=(int16_t)(prev->start_y+piece_end_delta(prev->template_id,prev->start_y));
    }
    /* Only select the sustained double ascent when there is enough world
     * elevation headroom; otherwise select the independent high gap. */
    if(pattern==55u && p->start_y<164){pattern=56u;p->template_id=pattern;}
    /* Generation metadata, packed into one flash byte per template. */
    static const uint8_t meta[RIDER_TEMPLATE_COUNT]={
        0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 8, 16, 18, 0, 16, 3, 0, 0, 0, 0, 16, 8, 0, 0, 4, 0, 3, 3, 2, 2, 0, 0, 0, 0, 0, 2, 0, 0, 8, 3, 2, 0, 2, 0, 3, 3, 3, 0, 2, 0, 2, 3, 2, 3, 3, 3, 3, 3, 7, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 7, 3, 3, 3, 3, 19, 3, 3, 3, 3, 3, 7, 3
    };
    unsigned m=meta[pattern];
    p->flags=(uint8_t)((m>>1)&14u);
    if(s->score>=100 && (s->random_state&255u)<(unsigned)clamp_i32(s->score-80,0,240))p->flags|=PIECE_FLAG_HARD;
    p->gem_mask=0;
    p->fall_tick=0;
    if(n!=0u && ((n&1u)||(m&1u)) && pattern!=48u){
        p->flags|=PIECE_FLAG_GEM;
        p->gem_mask=(m&2u)?7u:1u;
    }
    s->last_template = pattern;
}

/* Hermite curve with slopes derived from adjacent knots; flat end tangents. */
static int32_t sample_curve_q(uint8_t kind, uint32_t local_x_q)
{
    if (kind >= N_TEMPLATES || !height_index[kind]) return 0;
    uint32_t k = local_x_q / (32u*RIDER_Q);
    if (k >= 8) return 0;
    int32_t t = (int32_t)((local_x_q % (32u*RIDER_Q)) / 32u);
    const int8_t *h=heights[height_index[kind]];
    int32_t v0=k?h[k-1]:0,v1=k<7?h[k]:0;
    int32_t m0=k?(v1-(k>1?h[k-2]:0))/2:0;
    int32_t m1=k<7?((k<6?h[k+1]:0)-v0)/2:0;
    /* Keep the central sharp apex of V/peak templates; their outer
     * transitions are still Hermite and have flat endpoints. */
    if(((kind==49u || kind==50u) && (k==3u || k==4u)) || (kind==62u && k>=1u && k<=6u))
        return v0*(RIDER_Q-t)+v1*t;
    return hermite(t,v0,v1,m0,m1);
}

/* Gap endpoints retain exact Q8 inclusive/exclusive boundaries. */
typedef struct {uint8_t lo,hi,flags;} Gap;
static const uint8_t gap_index[RIDER_TEMPLATE_COUNT]={
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 19, 0, 19, 11, 0, 0, 0, 0, 19, 0, 0, 0, 0, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 3, 14, 12, 0, 0, 0, 0, 11, 17, 0, 15, 16, 10, 10, 9, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 10, 0, 8, 0, 0, 7, 5, 0, 6, 0, 1, 2, 0, 0
};
static const uint8_t gap_offsets[]={0,1,3,5,6,7,8,9,10,13,14,16,17,18,19,20,21,22,23,24,25};
static const Gap gaps[]={{0,0,0},{86,102,2},{176,190,1},{82,96,2},{164,178,1},{34,142,2},{112,174,2},{118,158,0},{124,172,0},{48,190,0},{66,78,2},{116,138,3},{176,188,1},{88,190,0},{86,98,2},{158,170,1},{68,156,0},{68,133,0},{70,220,0},{70,221,0},{116,148,0},{120,158,0},{124,173,0},{102,152,0},{102,154,0} };
static __attribute__((noinline)) bool template_gap(uint8_t kind,uint32_t x)
{
    if(kind>=RIDER_TEMPLATE_COUNT)return false;
    unsigned g=gap_index[kind];
    if(!g)return false;
    for(unsigned i=gap_offsets[g];i<gap_offsets[g+1];i++){
        const Gap *p=&gaps[i];
        uint32_t lo=(uint32_t)p->lo*RIDER_Q+(p->flags&1u);
        uint32_t hi=(uint32_t)p->hi*RIDER_Q-((p->flags>>1)&1u);
        if(x-lo<=hi-lo)return true;
    }
    return false;
}
/* Shared moving/falling surface, with compact per-piece trigger time. The
 * exact timing is an independently tuned approximation, not original data. */
bool rider_platform_at_q(const RiderState *s,uint32_t pn,unsigned slot,int32_t *x0,int32_t *x1,int32_t *y)
{
    const RiderPiece *p=piece_at(s,pn);
    if(!p)return false;
    if(p->template_id==83u){
        if(slot>=2u)return false;
        *x0=(int32_t)(pn*256u+80u+52u*slot)*RIDER_Q;*x1=*x0+46*RIDER_Q;
        *y=((int32_t)p->start_y-4)*RIDER_Q;
        if(p->flags&PIECE_FLAG_FALLING){
            unsigned age=(uint16_t)((uint16_t)s->tick_count-p->fall_tick);
            unsigned delay=((p->flags&PIECE_FLAG_HARD)?3u:7u)+slot*20u;
            if((p->flags&0x40u)||age>=delay+22u)return false;
            if(age>delay){age-=delay;*y+=(int32_t)(age*age*20u);}
        }
        return true;
    }
    if(p->template_id==72u){
        if(slot>=2u)return false;
        *x0=(int32_t)(pn*256u+78u+60u*slot)*RIDER_Q; *x1=*x0+38*RIDER_Q;
        *y=((int32_t)p->start_y-12)*RIDER_Q+((p->flags&PIECE_FLAG_HARD)?9:5)*rider_sin256((uint8_t)(s->tick_count+pn*13u+slot*128u));
        return true;
    }
    if(p->template_id==80u){
        if(slot)return false;
        *x0=(int32_t)(pn*256u+102u)*RIDER_Q; *x1=*x0+74*RIDER_Q;
        *y=((int32_t)p->start_y-34)*RIDER_Q; return true;
    }
    if(slot || (p->template_id!=57u&&p->template_id!=58u&&p->template_id!=70u))return false;
    *x0=(int32_t)(pn*256u+98u)*RIDER_Q; *x1=*x0+60*RIDER_Q;
    *y=((int32_t)p->start_y-13)*RIDER_Q;
    if(p->template_id==57u)*y+=((p->flags&PIECE_FLAG_HARD)?22:15)*rider_sin256((uint8_t)(s->tick_count+pn*13u));
    else if(p->template_id==70u){
        if(p->flags&PIECE_FLAG_FALLING){
            unsigned age=(uint16_t)((uint16_t)s->tick_count-p->fall_tick);
            if(age>=22u || (p->flags&0x40u))*y-=24*RIDER_Q;
            else *y-=24*smooth_q8((int32_t)age*256/22);
        }
    }
    else if(p->flags&PIECE_FLAG_FALLING){
        unsigned age=(uint16_t)((uint16_t)s->tick_count-p->fall_tick);
        if(age>80u || (p->flags&0x40u))return false;
        unsigned delay=(p->flags&PIECE_FLAG_HARD)?2u:6u;
        if(age>delay){age-=delay;if(age>=22u)return false;*y+=(int32_t)(age*age*20u);}
    }
    return true;
}
bool rider_platform_q(const RiderState *s,uint32_t pn,int32_t *x0,int32_t *x1,int32_t *y)
{
    return rider_platform_at_q(s,pn,0u,x0,x1,y);
}
bool rider_surface_q(const RiderState *s, int32_t world_x_q, int32_t *world_y_q)
{
    if (world_x_q < 0) return false;
    uint32_t number = (uint32_t)world_x_q / (RIDER_PIECE_WIDTH*RIDER_Q);
    const RiderPiece *p=piece_at(s,number);
    if (!p) return false;
    uint32_t local_x_q = (uint32_t)world_x_q % (RIDER_PIECE_WIDTH*RIDER_Q);
    if(p->template_id==72u||p->template_id==83u){
        for(unsigned j=0;j<2u;j++){
            int32_t a,b,y;
            if(rider_platform_at_q(s,number,j,&a,&b,&y) && world_x_q>=a && world_x_q<=b){*world_y_q=y;return true;}
        }
    }
    if(p->template_id==83u && local_x_q>=68u*RIDER_Q && local_x_q<=190u*RIDER_Q)return false;
    if(((rider_template_properties(p->template_id)&RIDER_T_PLATFORM)) && local_x_q>=98u*RIDER_Q && local_x_q<=158u*RIDER_Q){
        int32_t a,b;return rider_platform_q(s,number,&a,&b,world_y_q);
    }
    if(p->template_id==48u){
        /* Small gaps around a vertically oscillating suspended bridge.
         * Trigger and visual motion require NO additional state allocation. */
        if((local_x_q>=90u*RIDER_Q && local_x_q<103u*RIDER_Q) ||
           (local_x_q>177u*RIDER_Q && local_x_q<=190u*RIDER_Q))return false;
        if(local_x_q>=103u*RIDER_Q && local_x_q<=177u*RIDER_Q){
            *world_y_q=(int32_t)p->start_y*RIDER_Q +
              18*rider_sin256((uint8_t)(2u*s->tick_count+number*13u));
            return true;
        }
    }
    if (template_gap(p->template_id, local_x_q)) return false;
    if(p->template_id==80u && local_x_q>=102u*RIDER_Q && local_x_q<=176u*RIDER_Q){int32_t a,b;return rider_platform_q(s,number,&a,&b,world_y_q);}
    int32_t offset;
    unsigned k=p->template_id;
    if(k==40u||k==80u||k==81u){
        int32_t u,c;
        unsigned divisor;
        uint32_t numerator;
        if(k==80u && local_x_q<86u*RIDER_Q){
            u=(int32_t)(local_x_q/86u);offset=-36*(u*u/RIDER_Q)*u/RIDER_Q;goto elevation;
        }
        if(k==81u && local_x_q>=82u*RIDER_Q && local_x_q<=164u*RIDER_Q){
            u=(int32_t)((local_x_q-96u*RIDER_Q)/68u);offset=-12*RIDER_Q+16*(4*u*(RIDER_Q-u)/RIDER_Q);goto elevation;
        }
        if(k==40u && local_x_q<112u*RIDER_Q){numerator=local_x_q;divisor=112;c=-25;}
        else if(k==81u && local_x_q<82u*RIDER_Q){numerator=local_x_q;divisor=82;c=-15;}
        else {numerator=256u*RIDER_Q-local_x_q;
            if(k==40u){divisor=82;c=31;}
            else if(k==80u){divisor=66;c=-28;}
            else {divisor=78;c=-8;}
        }
        u=(int32_t)(numerator/divisor);
        offset=c*u*u/RIDER_Q;
    }else if(k==45u && local_x_q>=142u*RIDER_Q){
        int32_t u=(int32_t)((local_x_q-142u*RIDER_Q)/114u);
        offset=18*(RIDER_Q-u*u/RIDER_Q);
    }else if(k==28u && local_x_q>=70u*RIDER_Q && local_x_q<=198u*RIDER_Q){
        int32_t t=(int32_t)((local_x_q-70u*RIDER_Q)/8u);
        offset=27*(RIDER_Q-rider_sin4096(t+1024));
    }else if(k==52u||k==65u){
        int32_t t=local_x_q<68u*RIDER_Q?(int32_t)(local_x_q/68u):
            (int32_t)((256u*RIDER_Q-local_x_q)/100u);
        if(t>RIDER_Q)t=RIDER_Q;
        offset=-32*smooth_q8(t);
    }else offset=sample_curve_q((uint8_t)k,local_x_q);
elevation: ;
    const int32_t u=(int32_t)(local_x_q/RIDER_PIECE_WIDTH);
    int32_t elevation_delta=piece_end_delta(p->template_id,p->start_y);
    if(elevation_delta)offset+=elevation_delta*smooth_q8(u);
    if(p->template_id==55u && local_x_q>148u*RIDER_Q){
        /* A few world pixels of landing clearance compensate for gravity
         * during the gap; the second rail still climbs continuously. */
        int32_t z=(int32_t)((256u*RIDER_Q-local_x_q)/108u);
        offset+=6*smooth_q8(z);
    }
    if(p->template_id==70u && local_x_q>=170u*RIDER_Q){
        int32_t z=(int32_t)((256u*RIDER_Q-local_x_q)/86u);
        offset=-34*smooth_q8(z);
    }else if(((rider_template_properties(p->template_id)&RIDER_T_PLATFORM)) && local_x_q>170u*RIDER_Q){
        int32_t z=(int32_t)((256u*RIDER_Q-local_x_q)/86u);
        offset+=10*z;
    }
    *world_y_q = (int32_t)p->start_y*RIDER_Q + offset;
    return true;
}

/* Opposed red arc segments inside an elevated loop, visible in original Rider.
 * Radius/width/timing are independently tuned. No extra per-piece state. */
__attribute__((noinline)) bool rider_piece_ring_q(const RiderState *s,uint32_t pn,int32_t *x,int32_t *y)
{
    const RiderPiece *p=piece_at(s,pn);
    if(!p||p->template_id!=65u)return false;
    *x=(int32_t)(pn*256u+112u)*RIDER_Q;
    *y=((int32_t)p->start_y-94)*RIDER_Q;
    return true;
}
bool rider_ring_contains_q(int32_t dx,int32_t dy,uint32_t tick,int margin)
{
    /* Q4 geometry, two opposite narrow arc sectors. */
    if(dx<-68*RIDER_Q||dx>68*RIDER_Q||dy<-68*RIDER_Q||dy>68*RIDER_Q)return false;
    int32_t x=dx/16,y=dy/16;
    int32_t d2=x*x+y*y,lo=(35-margin)*16,hi=(42+margin)*16;
    if(d2<lo*lo||d2>hi*hi)return false;
    uint8_t a=(uint8_t)(tick/2u);
    int32_t dot=x*rider_sin256((uint8_t)(a+64u))+y*rider_sin256(a);
    /* |projection| / length >= cos(28 deg), relaxed for wheel radius. */
    int32_t v=dot/256;if(v<0)v=-v;
    int32_t threshold=margin?210:225;
    return v*v >= (d2*threshold/256)*threshold/256;
}

/* Approximate swept contact for the two rotating sectors. Endpoints and
 * quarter steps cover intermediate motion; bounded broad phase avoids work
 * for distant hazards. Not a continuous rigid-body solver. */
static bool ring_swept(int32_t ax,int32_t ay,int32_t bx,int32_t by,uint32_t tick,int margin)
{
    const int32_t r=68*RIDER_Q;
    if((ax<-r&&bx<-r)||(ax>r&&bx>r)||(ay<-r&&by<-r)||(ay>r&&by>r))return false;
    for(int i=0;i<=4;i++){
        int32_t x=ax+(bx-ax)*i/4,y=ay+(by-ay)*i/4;
        if(rider_ring_contains_q(x,y,tick,margin)||
           (i<4 && rider_ring_contains_q(x,y,tick-1u,margin)))return true;
    }
    return false;
}

static bool saw_at_tick(const RiderState *s, uint32_t piece_number, unsigned slot, uint32_t tick, int32_t *cx_q, int32_t *cy_q, int32_t *radius_q)
{
    const RiderPiece *p=piece_at(s,piece_number);
    if (!p || !(p->flags & PIECE_FLAG_SAW)) return false;
    if(p->template_id==71u || p->template_id==82u || p->template_id==60u || p->template_id==25u || p->template_id==9u){
        unsigned k=p->template_id;
        bool pair=k==71u||k==82u;
        if(slot>=(pair?2u:1u))return false;
        *cx_q=(int32_t)(piece_number*256u+(pair?(slot?186u:90u):(k==9u?146u:128u)))*RIDER_Q;
        int32_t surface;
        if(!rider_surface_q(s,*cx_q,&surface))return false;
        *radius_q=(pair?19:24)*RIDER_Q;
        unsigned hard=(p->flags&PIECE_FLAG_HARD)!=0;
        uint8_t phase=(uint8_t)(tick*(hard?2u:1u)+piece_number*13u+slot*(k==82u?32u:48u));
        /* Lowest clearance intersects the actual wheel/body path; highest
         * clearance leaves room for a stopped or accelerating bike. */
        *cy_q=surface-*radius_q-(hard?19:24)*RIDER_Q+(hard?20:21)*rider_sin256(phase);
        return true;
    }
    if(slot)return false;
    if(p->template_id==59u){
        *cx_q=(int32_t)(piece_number*256u+139u)*RIDER_Q;
        *radius_q=56*RIDER_Q;
        *cy_q=((int32_t)p->start_y+34)*RIDER_Q;
        return true;
    }
    uint32_t local_px = (p->template_id == 10u) ? 176u : 146u;
    *cx_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + local_px) * RIDER_Q;
    int32_t yq;
    if (!rider_surface_q(s, *cx_q, &yq)) return false;
    /* Place the full blade above the LOCAL rail. Collisions are computed
     * against the same center/radius used by the renderer. */
    /* Larger original-inspired blade; maintain safe clearance in the
     * pretested novice route despite the late-game horizontal oscillation. */
    *cy_q=yq-62*RIDER_Q;
    *radius_q=42*RIDER_Q;
    return true;
}

__attribute__((noinline)) bool rider_piece_saw_at_q(const RiderState *s,uint32_t pn,unsigned slot,int32_t *x,int32_t *y,int32_t *r)
{
    return saw_at_tick(s,pn,slot,s->tick_count,x,y,r);
}
bool rider_piece_saw_q(const RiderState *s,uint32_t pn,int32_t *x,int32_t *y,int32_t *r)
{
    return rider_piece_saw_at_q(s,pn,0u,x,y,r);
}
bool rider_piece_boost_q(const RiderState *s, uint32_t piece_number, int32_t *x0_q, int32_t *x1_q, int32_t *y_q)
{
    const RiderPiece *p = &s->track[piece_number % RIDER_TRACK_SLOTS];
    if (p->number != piece_number || !(p->flags & PIECE_FLAG_BOOST)) return false;
    *x0_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 92u) * RIDER_Q;
    *x1_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 148u) * RIDER_Q;
    int32_t mid = *x0_q + (*x1_q-*x0_q)/2;
    return rider_surface_q(s, mid, y_q);
}

bool rider_piece_gem_q(const RiderState *s,uint32_t pn,uint8_t slot,int32_t *xq,int32_t *yq)
{
    if(slot>=3u || !xq || !yq)return false;
    const RiderPiece *p=piece_at(s,pn);
    if(!p || !(p->flags&PIECE_FLAG_GEM) || !(p->gem_mask&(1u<<slot)))return false;
    if(special_piece(p->template_id)) {
        static const uint16_t ts[3]={1050,2050,3050};
        uint16_t t=ts[slot];
        if(p->template_id==28u){static const uint16_t bowl[3]={1100,2200,3350};t=bowl[slot];}
        int32_t ax,ay,bx,by;
        if(!rider_track_special_q(s,pn,p->template_id,t,xq,yq) ||
           !rider_track_special_q(s,pn,p->template_id,t-32,&ax,&ay) ||
           !rider_track_special_q(s,pn,p->template_id,t+32,&bx,&by))return false;
        /* Put diamonds on the rider-facing side of the actual 2D path. */
        int32_t a=angle_from_vector(bx-ax,by-ay);
        *xq+=14*rider_sin4096(a);
        *yq-=14*rider_sin4096(a+1024);
        return true;
    }
    if(p->template_id==57u || p->template_id==58u || p->template_id==70u || p->template_id==80u){
        int32_t a,b,y;if(!rider_platform_q(s,pn,&a,&b,&y))return false;
        *xq=a+(12+(int32_t)slot*18)*RIDER_Q;*yq=y-17*RIDER_Q;return true;
    }
    if(p->template_id==40u){
        *xq=(int32_t)(pn*256u+123u+slot*19u)*RIDER_Q;
        *yq=((int32_t)p->start_y-36+(int32_t)slot*5)*RIDER_Q;return true;
    }
    if(p->template_id==59u){
        *xq=(int32_t)(pn*256u+103u+slot*35u)*RIDER_Q;
        *yq=((int32_t)p->start_y-68-(slot==1u?15:0))*RIDER_Q;return true;
    }
    if(p->template_id==72u||p->template_id==83u){
        int32_t a,b,y;
        if(!rider_platform_at_q(s,pn,slot==2u?1u:0u,&a,&b,&y))return false;
        *xq=a+(slot==1u?28:12)*RIDER_Q;*yq=y-17*RIDER_Q;return true;
    }
    if(p->template_id==76u || p->template_id==78u || p->template_id==55u || p->template_id==56u || p->template_id==53u){
        static const uint8_t ends[5][2]={{117,159},{123,173},{115,149},{119,159},{123,174}};
        unsigned idx=p->template_id==76u?0:p->template_id==78u?1:p->template_id==55u?2:p->template_id==56u?3:4;
        int l=ends[idx][0],r=ends[idx][1];
        int32_t base=(int32_t)(pn*256u)*RIDER_Q,yl,yr;
        if(!rider_surface_q(s,base+l*RIDER_Q,&yl)||!rider_surface_q(s,base+r*RIDER_Q,&yr))return false;
        int u=idx==4?7+(int)slot*17:(r-l)*(slot+1)/4;
        *xq=base+(l+u)*RIDER_Q;
        if(idx<2)*yq=(yl<yr?yl:yr)-(16+(slot==1u?6:0))*RIDER_Q;
        else *yq=yl+(yr-yl)*u/(r-l)-((idx==4?26:20)+(slot==1u?(idx==4?12:9):0))*RIDER_Q;
        return true;
    }
    if(p->template_id>=60u){
        unsigned k=p->template_id;
        *xq=(int32_t)(pn*256u+(k==81u?108u+slot*22u:78u+slot*50u))*RIDER_Q;
        if(!rider_surface_q(s,*xq,yq))return false;
        *yq-=(k==81u?16:18)*RIDER_Q;return true;
    }
    int32_t wx=(int32_t)(pn*RIDER_PIECE_WIDTH+128u)*RIDER_Q;
    if(p->template_id==13u || p->template_id==30u || p->template_id==49u || p->template_id==51u || p->template_id==53u)
        wx=(int32_t)(pn*RIDER_PIECE_WIDTH+100u+slot*28u)*RIDER_Q;
    int32_t wy;
    if(((rider_template_properties(p->template_id)&RIDER_T_LAUNCH_GEMS)) && (p->flags&PIECE_FLAG_GEM)){
        wx=(int32_t)(pn*RIDER_PIECE_WIDTH+115u+slot*28u)*RIDER_Q;
        if(!rider_surface_q(s,wx,&wy))
            wy=(int32_t)p->start_y*RIDER_Q;
        /* The middle gem sits higher, forming a three-gem airborne arc. */
        wy-=(20+(slot==1u?8:0))*RIDER_Q;

    } else if(!rider_surface_q(s,wx,&wy)){
        /* Around real gaps the diamonds float over the missing rail. */
        wy=(int32_t)(p->start_y-19)*RIDER_Q;
    }
    *xq=wx;
    *yq=wy-((((rider_template_properties(p->template_id)&RIDER_T_LAUNCH_GEMS)) &&
               (p->flags&PIECE_FLAG_GEM))?0:18*RIDER_Q);
    return true;
}
/* Repeating triangular spike profile in the same Q8 world coordinates
 * as the hazard bounds. A sawtooth is not a filled collision rectangle. */
int32_t rider_spike_profile_q(int32_t local_x_q)
{
    int32_t u=local_x_q%(10*RIDER_Q)-5*RIDER_Q;
    return (u<0?-u:u)*6/5;
}
static bool spikes_at_tick(const RiderState *s,uint32_t pn,uint32_t tick,int32_t *x0q,int32_t *x1q,int32_t *tipyq)
{
    const RiderPiece *p=piece_at(s,pn);
    if(!p || !(p->flags&PIECE_FLAG_SPIKES) || !x0q || !x1q || !tipyq)return false;
    if(p->template_id==15u && ((tick+pn*17u)%120u)<50u)
        return false; /* timed lance retracted: renderer AND physics agree */
    if(p->template_id==76u){
        /* A complete retract/extend cycle. The same translated solid spike
         * geometry is used for drawing and contact, including the warning motion. */
        unsigned t=(tick+pn*17u)%160u;
        int32_t extension=t<40u?0:t<64u?(int32_t)(t-40u)*RIDER_Q/24:t<112u?RIDER_Q:t<136u?(int32_t)(136u-t)*RIDER_Q/24:0;
        if(!extension)return false;
        *x0q=(int32_t)(pn*256u+120u)*RIDER_Q;
        *x1q=(int32_t)(pn*256u+156u)*RIDER_Q;
        *tipyq=(int32_t)(p->start_y+40)*RIDER_Q-30*extension;
        return true;
    }
    *x0q=(int32_t)(pn*RIDER_PIECE_WIDTH+106u)*RIDER_Q;
    *x1q=(int32_t)(pn*RIDER_PIECE_WIDTH+151u)*RIDER_Q;
    *tipyq=(int32_t)(p->start_y+14)*RIDER_Q;
    return true;
}
bool rider_piece_spikes_q(const RiderState *s,uint32_t pn,int32_t *x0q,int32_t *x1q,int32_t *tipyq)
{
    return spikes_at_tick(s,pn,s->tick_count,x0q,x1q,tipyq);
}
void rider_wheel_centers_q(const RiderState *s, int32_t *lx, int32_t *ly,
                           int32_t *rx, int32_t *ry)
{
    int32_t si = rider_sin4096(s->angle), co = rider_sin4096(s->angle+1024);
    int32_t dx = co*12, dy = si*12;
    *lx = s->x-dx; *ly=s->y-dy;
    *rx = s->x+dx; *ry=s->y+dy;
}

void rider_restart(RiderState *s)
{
    uint32_t saved_best = (uint32_t)s->best;
    int32_t saved_diamonds = s->diamonds;
    uint32_t seed = s->random_state ^ 0x9e3779b9u;
    rider_init(s, seed);
    s->best = (int32_t)saved_best;
    s->diamonds = saved_diamonds;
}

void rider_init(RiderState *s, uint32_t seed)
{
    memset(s, 0, sizeof(*s));
    s->random_state = seed ? seed : 0xd88ec19bu;
    s->theme=0u; /* presentation interval not yet measured */
    for (uint32_t i=0; i<RIDER_TRACK_SLOTS; ++i) append_piece(s);
    s->x = 70*RIDER_Q;
    s->y = 161*RIDER_Q;
    s->camera_x = -70*RIDER_Q;
    s->camera_y = -30*RIDER_Q;
    s->phase=RIDER_READY;
    s->grounded=1;
}

static void add_score(RiderState *s,uint16_t n)
{
    if(s->score>INT32_MAX-(int32_t)n)s->score=INT32_MAX;
    else s->score+=n;
    if(s->score>s->best)s->best=s->score;
}
static void commit_pending(RiderState *s)
{
    if(s->pending_score && s->pending_ticks==31u){
        add_score(s,s->pending_score);
        uint32_t n=s->pending_score/(s->perfect_ticks==48u?2u:1u);
        s->flips_landed=UINT32_MAX-s->flips_landed<n?UINT32_MAX:s->flips_landed+n;
        /* HUD lifetime only: points have already been awarded. */
        s->pending_ticks=30u;
    }
}

static void crash(RiderState *s)
{
    s->phase=RIDER_CRASHED;
    s->pending_score=0;
    s->pending_ticks=0;
}

static void maybe_collect_gem(RiderState *s, uint32_t piece_number)
{
    RiderPiece *p=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(p->number!=piece_number || !(p->flags&PIECE_FLAG_GEM))return;
    /* One collision per gem, so a U-shaped cluster awards three diamonds. */
    for(uint8_t j=0;j<3u;++j){
        int32_t gx,gy;
        if(!rider_piece_gem_q(s,piece_number,j,&gx,&gy))continue;
        if(s->x-gx> -13*RIDER_Q && s->x-gx<13*RIDER_Q &&
           s->y-gy> -20*RIDER_Q && s->y-gy<20*RIDER_Q){
            p->gem_mask&=(uint8_t)~(1u<<j);
            if(s->diamonds<INT32_MAX)++s->diamonds;
        }
    }
    if(!p->gem_mask)p->flags&=(uint8_t)~PIECE_FLAG_GEM;
}

/* Continuous segment versus circle in the obstacle's relative frame.
 * Bounding-box rejection is cheap on the MCU; the division runs only when
 * the segment can meet the circle. Coordinates reduced to Q4 with a one-Q4
 * conservative margin, avoiding overflow and 64-bit arithmetic in the hot path. */
bool rider_swept_circle_q(int32_t ax,int32_t ay,int32_t bx,int32_t by,int32_t rr)
{
    if(rr<=0 || rr>64*RIDER_Q)return false;
    if((ax< -rr&&bx< -rr)||(ax>rr&&bx>rr)||(ay< -rr&&by< -rr)||(ay>rr&&by>rr))return false;
    /* Callers supply near-piece coordinates and per-tick displacement < 32 px.
     * Clip the public helper's extreme inputs conservatively to avoid UB. */
    if(ax< -128*RIDER_Q || ax>128*RIDER_Q || ay< -128*RIDER_Q || ay>128*RIDER_Q || bx< -128*RIDER_Q || bx>128*RIDER_Q || by< -128*RIDER_Q || by>128*RIDER_Q)return false;
    ax/=16;ay/=16;bx/=16;by/=16;rr=(rr+15)/16+1;
    int32_t dx=bx-ax,dy=by-ay, len2=dx*dx+dy*dy;
    int32_t dot=-(ax*dx+ay*dy);
    if(dot>=len2){ax=bx;ay=by;}
    else if(dot>0){
        /* Q10 fraction: dot*1024 may exceed 32 bits for artificial inputs. */
        int32_t t;
        if(dot<=INT32_MAX/1024)t=dot*1024/len2;
        else {
            t=0;
            for(unsigned bit=0;bit<10;bit++){
                dot*=2;t*=2;
                if(dot>=len2){dot-=len2;t++;}
            }
        }
        ax+=dx*t/1024;ay+=dy*t/1024;
    }
    return ax*ax+ay*ay<=rr*rr;
}

/* Loop runs are deliberately guided: a small MCU cannot fit Box2D and the
 * original collision graph alongside Rad Pro. The path itself is a true
 * overlapping loop, not a fake x-height hill. This is NOT rigid-body parity. */
static void maybe_collect_gem(RiderState *s,uint32_t piece_number);
static void step_loop(RiderState *s,bool held)
{
    uint32_t pn=s->loop_piece;
    const RiderPiece *gp=&s->track[pn%RIDER_TRACK_SLOTS];
    const uint8_t kind=(gp->number==pn)?gp->template_id:16u;
    int32_t xa0,ya0,xb0,yb0;
    uint16_t ta=s->loop_t>64u?s->loop_t-64u:0u;
    uint16_t tb=s->loop_t<4032u?s->loop_t+64u:4096u;
    if(!rider_track_special_q(s,pn,kind,ta,&xa0,&ya0) ||
       !rider_track_special_q(s,pn,kind,tb,&xb0,&yb0)){crash(s);return;}
    int32_t dx=xb0-xa0,dy=yb0-ya0;
    int32_t ax=dx<0?-dx:dx,ay=dy<0?-dy:dy;
    int32_t length=(ax>ay?ax:ay)+(ax>ay?ay:ax)*3/8;
    if(length<1)length=1;
    int32_t slope=dy*14/length;
    /* Signed velocity on the constrained rail. A released bike can coast,
     * stall, and roll back down an incline instead of dying on an arbitrary
     * minimum-speed threshold. Gravity retains its direction along the rail. */
    int32_t drag=clamp_i32(-s->vx,-5,5);
    int32_t travel=clamp_i32(s->vx+(held?18:drag)+slope,-2*RIDER_Q,4*RIDER_Q);
    /* Compact contact-loss criterion for the inverted portions of a
     * closed rail. The prior model glued even slow bikes to the ceiling.
     * Approximate v^2/R >= inward gravity using Q8 units, then release
     * into ballistic motion along the actual shared tangent. */
    if(dx<0 && (kind==45u||kind==16u||kind==47u||kind==52u||kind==65u||kind==75u)){
        int radius=kind==45u?43:kind==47u?32:(kind==75u?(s->loop_t<2048u?36:48):62);
        int32_t tangent=angle_from_vector(dx,dy);
        int32_t co=rider_sin4096(tangent+1024),si=rider_sin4096(tangent);
        if(co<0 && travel*travel<15*radius*(-co)){
            int32_t xx,yy;
            if(!rider_track_special_q(s,pn,kind,s->loop_t,&xx,&yy)){crash(s);return;}
            s->x=xx+si*5;s->y=yy-co*5;
            s->vx=travel*co/256;s->vy=travel*si/256;
            s->angle=tangent;s->takeoff_angle=tangent;s->angular_speed=0;
            s->looping=0;s->grounded=0;s->airborne_ticks=0;s->air_rotation=0;
            return;
        }
    }
    s->vx=travel;
    int32_t advance=travel*(int32_t)(tb-ta)/length;
    if(!advance && travel)advance=travel>0?1:-1;
    advance=clamp_i32(advance,-180,180);
    int32_t nt=(int32_t)s->loop_t+advance;
    if(nt<=0 && travel<0){
        /* The entrance leads back onto the approach rail. No teleport or
         * automatic score; normal ground contact takes over next step. */
        int32_t ex,ey;
        if(!rider_track_special_q(s,pn,kind,0,&ex,&ey)){crash(s);return;}
        int32_t a=angle_from_vector(dx,dy),sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
        s->x=ex+sn*5-1;s->y=ey-cs*5;s->angle=a;
        s->vx=travel*cs/256;s->vy=0;s->loop_t=0;s->looping=0;
        s->grounded=1;s->angular_speed=0;s->airborne_ticks=0;s->air_rotation=0;
        return;
    }
    if(nt>=RIDER_ANGLE_TURN) {
        s->loop_t=RIDER_ANGLE_TURN;
        s->looping=0;
        if((rider_template_properties(kind)&RIDER_T_AIR_EXIT)){
            /* Open rails exit at the real path tangent and speed. */
            int32_t ex,ey,px,py;
            if(!rider_track_special_q(s,pn,kind,4096u,&ex,&ey) ||
               !rider_track_special_q(s,pn,kind,4032u,&px,&py)){crash(s);return;}
            int32_t a=angle_from_vector(ex-px,ey-py);
            int32_t sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
            s->x=ex+sn*5;s->y=ey-cs*5;
            s->vx=clamp_i32(travel*cs/256,0,4*RIDER_Q);
            s->vy=travel*sn/256;s->angle=a;s->takeoff_angle=a;s->grounded=0;
        }else{
            int32_t ex,ey;
            if(!rider_track_special_q(s,pn,kind,4096u,&ex,&ey)){crash(s);return;}
            s->x=ex;
            s->y=ey-5*RIDER_Q;
            s->angle=(((rider_template_properties(kind)&RIDER_T_CLOSED))?-RIDER_ANGLE_TURN:0);
            s->vy=0;
            s->grounded=1;
        }
        s->angular_speed=0;
        s->airborne_ticks=0;
        s->air_rotation=0;
        maybe_collect_gem(s,pn);
        return;
    }
    s->loop_t=(uint16_t)nt;
    int32_t xx,yy,xb,yb,xa,ya;
    rider_track_special_q(s,pn,kind,s->loop_t,&xx,&yy);
    rider_track_special_q(s,pn,kind,(uint16_t)(s->loop_t>8?s->loop_t-8:0),&xb,&yb);
    rider_track_special_q(s,pn,kind,(uint16_t)(s->loop_t<4088?s->loop_t+8:4096),&xa,&ya);
    int32_t tangent=angle_from_vector(xa-xb,ya-yb);
    int32_t si=rider_sin4096(tangent),co=rider_sin4096(tangent+1024);
    s->x=xx+si*5;
    s->y=yy-co*5;
    /* Continuous 0..4096 rotation around loop. */
    if(s->loop_t>RIDER_ANGLE_TURN/2 && tangent>0)tangent-=RIDER_ANGLE_TURN;
    s->angle=tangent;
    s->grounded=1;
    s->vy=0;
    s->angular_speed=0;
    maybe_collect_gem(s,pn);
}

/* Contact with the inside of a detached rail requires actual proximity,
 * compatible orientation and velocity along the rail. This is a compact
 * rail constraint, not an automatic pickup when crossing its x coordinate.
 * A coarse search followed by fine local refinement uses only stack scalars. */
static bool arch_contact(RiderState *s,uint32_t pn)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(p->number!=pn || p->template_id!=54u || s->grounded)return false;
    int32_t base=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q;
    if(s->x<base+68*RIDER_Q || s->x>base+192*RIDER_Q ||
       s->y>((int32_t)p->start_y-67)*RIDER_Q || s->y<((int32_t)p->start_y-172)*RIDER_Q)return false;
    uint16_t best=0;
    int32_t best_d=INT32_MAX,best_x=0,best_y=0,best_a=0;
    for(unsigned pass=0;pass<2u;++pass){
        unsigned begin=pass?(best>128u?best-128u:0u):0u;
        unsigned end=pass?(best<3968u?best+128u:4096u):4096u;
        unsigned step=pass?16u:128u;
        for(unsigned t=begin;t<=end;t+=step){
            int32_t x,y,ax,ay,bx,by;
            uint16_t ta=(uint16_t)(t>32u?t-32u:0u),tb=(uint16_t)(t<4064u?t+32u:4096u);
            if(!rider_track_special_q(s,pn,54u,(uint16_t)t,&x,&y) ||
               !rider_track_special_q(s,pn,54u,ta,&ax,&ay) ||
               !rider_track_special_q(s,pn,54u,tb,&bx,&by))continue;
            int32_t a=angle_from_vector(bx-ax,by-ay);
            x+=5*rider_sin4096(a);y-=5*rider_sin4096(a+1024);
            int32_t dx=(s->x-x)/16,dy=(s->y-y)/16;
            int32_t d=dx*dx+dy*dy;
            if(d<best_d){best_d=d;best=(uint16_t)t;best_x=x;best_y=y;best_a=a;}
        }
    }
    if(best_d>80*80 || best>3968u)return false; /* five world pixels, not a magnetic snap */
    int32_t speed=(s->vx*rider_sin4096(best_a+1024)+s->vy*rider_sin4096(best_a))/256;
    int32_t angle_error=((s->angle-best_a+2048)&4095)-2048;
    if(speed<2*RIDER_Q || angle_error< -720 || angle_error>720)return false;
    s->looping=1;s->loop_piece=pn;s->loop_t=best;s->x=best_x;s->y=best_y;
    s->vx=clamp_i32(speed,0,4*RIDER_Q);s->vy=0;s->angle=best_a;
    s->grounded=1;s->angular_speed=0;s->air_rotation=0;s->airborne_ticks=0;
    maybe_collect_gem(s,pn);
    return true;
}

static void update_camera(RiderState *s)
{
    int32_t tx=s->x-140*RIDER_Q;
    int32_t ty=s->y-190*RIDER_Q;
    /* Resist 1px snaps as the vehicle crosses changing slopes. */
    s->camera_x += clamp_i32((tx-s->camera_x)/5,-7*RIDER_Q,7*RIDER_Q);
    s->camera_y += clamp_i32((ty-s->camera_y)/10,-3*RIDER_Q,3*RIDER_Q);
}

static bool spike_hit(int32_t x,int32_t y,int32_t x0,int32_t x1,int32_t tip)
{
    return x>=x0 && x<=x1 && y<=tip+12*RIDER_Q &&
           y+5*RIDER_Q>=tip+rider_spike_profile_q(x-x0);
}
static bool spike_swept(int32_t ax,int32_t ay,int32_t bx,int32_t by,int32_t x0,int32_t x1,int32_t oldtip,int32_t tip)
{
    if((ax<x0&&bx<x0)||(ax>x1&&bx>x1))return false;
    for(int i=0;i<=4;i++){
        int32_t x=ax+(bx-ax)*i/4,y=ay+(by-ay)*i/4,t=oldtip+(tip-oldtip)*i/4;
        if(spike_hit(x,y,x0,x1,t))return true;
    }
    return false;
}
static __attribute__((noinline)) void step_motion(RiderState *s, bool held)
{
    if (s->phase==RIDER_CRASHED) {
        if (s->crash_ticks<UINT16_MAX) ++s->crash_ticks;
        return;
    }
    if (s->phase==RIDER_READY) {
        if (!held) return;
        s->phase=RIDER_RUNNING;
    }
    s->throttle_active=held?1u:0u;
    ++s->tick_count;
    if(s->perfect_ticks) --s->perfect_ticks;
    if(s->pending_ticks && --s->pending_ticks==0u)s->pending_score=0;
    if(s->boost_ticks) --s->boost_ticks;
    if(s->looping) {
        step_loop(s,held);
        update_camera(s);
        return;
    }
    const bool was_grounded=s->grounded!=0;
    const int32_t old_x=s->x;
    if(was_grounded && s->x>=0){
        uint32_t pn=(uint32_t)s->x/(256u*RIDER_Q);
        int32_t a,b,y,prev_y;
        for(unsigned j=0;j<2u;j++){
            if(!rider_platform_at_q(s,pn,j,&a,&b,&y)||s->x<a||s->x>b)continue;
            --s->tick_count;
            bool ok=rider_platform_at_q(s,pn,j,&a,&b,&prev_y);
            ++s->tick_count;
            if(ok && s->y>=prev_y-8*RIDER_Q && s->y<=prev_y+2*RIDER_Q){s->y+=y-prev_y;s->vy=0;}
            break;
        }
    }
    int32_t prev_lx,prev_ly,prev_rx,prev_ry;
    rider_wheel_centers_q(s,&prev_lx,&prev_ly,&prev_rx,&prev_ry);
    if(was_grounded) {
        int32_t diff,slope_drive=0;
        if(surface_delta(s,s->x-12*RIDER_Q,s->x+12*RIDER_Q,&diff))
            slope_drive=clamp_i32(diff/384,-12,12);
        const int32_t cap=s->boost_ticks?6*RIDER_Q:NORMAL_SPEED_CAP_Q+clamp_i32(s->score,0,400)/2;
        int32_t brake=20-clamp_i32(s->score,0,400)/50;
        if(s->vx<0){
            int32_t delta=(held?17:brake)+slope_drive;
            s->vx=clamp_i32(s->vx+delta,-2*RIDER_Q,cap);
        }else {
            int32_t delta=(held?17:-brake)+slope_drive;
            if(!held && delta> -3)delta=-3;
            s->vx=clamp_i32(s->vx+delta,0,cap);
        }
        s->angular_speed=0;
    } else {
        if(s->airborne_ticks<UINT16_MAX) ++s->airborne_ticks;
        s->vy=clamp_i32(s->vy+15,-7*RIDER_Q,8*RIDER_Q);
        /* The original one-button control should not spin the bike wildly
         * after a short accidental press. Accelerate rotation gradually. */
        if(held && s->airborne_ticks>=6) {
            /* Average 7.5 units/tick acceleration, exactly 25% below v3.1.
             * Cap is 443 deg/s at 60 Hz, 20% above v3.0. */
            s->angular_speed=clamp_i32(s->angular_speed+7+(int32_t)(s->tick_count&1u),0,SPIN_CAP);
        } else {
            s->angular_speed=(s->angular_speed*212)/256;
        }
        if(s->angle< -65536 || s->angle>65536)
            s->angle=(int32_t)(((uint32_t)s->angle+2048u)&4095u)-2048;
        s->angle-=s->angular_speed;
        s->air_rotation+=(uint32_t)s->angular_speed;
        if(s->air_rotation>16u*RIDER_ANGLE_TURN)s->air_rotation=16u*RIDER_ANGLE_TURN;
    }
    /* A raised landing is a wall until the lift reaches its level. Do not
     * snap the chassis upward through that wall. Holding lets the lift
     * finish its travel before the player drives off. */
    if(was_grounded && s->x>=0){
        uint32_t pn=(uint32_t)s->x/65536u;
        const RiderPiece *p=piece_at(s,pn);
        int32_t edge=(int32_t)(pn*256u+148u)*RIDER_Q;
        if(p && p->template_id==70u && s->x<=edge && s->x+s->vx>edge){
            int32_t a,b,y;
            if(rider_platform_q(s,pn,&a,&b,&y) && y>((int32_t)p->start_y-31)*RIDER_Q){
                s->x=edge;s->vx=0;
            }
        }
    }
    s->x+=s->vx;
    s->y+=s->vy;
    uint32_t piece_number=(uint32_t)(s->x/(RIDER_PIECE_WIDTH*RIDER_Q));
    if(piece_number+7>=s->next_piece)append_piece(s);

    /* Enter a closed loop only on the leading rail and at adequate speed. */
    const RiderPiece *piece=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(piece->number==piece_number && special_piece(piece->template_id) && piece->template_id!=54u && piece->template_id!=28u) {
        int32_t entrance=(int32_t)(piece_number*RIDER_PIECE_WIDTH+(piece->template_id==45u?34u:piece->template_id==75u?48u:((piece->template_id==16u||piece->template_id==47u||piece->template_id==52u||piece->template_id==65u)?68u:70u)))*RIDER_Q;
        if(old_x<entrance && s->x>=entrance && s->vx>2*RIDER_Q) {
            int32_t ex,ey;
            if(!rider_track_special_q(s,piece_number,piece->template_id,0,&ex,&ey)){crash(s);return;}
            int32_t near=s->y-(ey-5*RIDER_Q);
            int32_t facing=(int32_t)(((uint32_t)s->angle+2048u)&4095u)-2048;
            /* The front wheel can pass the seam before the centre does. A
             * recent, close, forward-facing contact is eligible; a remote
             * airborne vehicle or a stunt rotation must never be captured. */
            bool near_lip=((rider_template_properties(piece->template_id)&RIDER_T_NEAR_LIP)) &&
                s->airborne_ticks<=6u && near>=-6*RIDER_Q && near<=3*RIDER_Q &&
                facing>=-400 && facing<=400 && s->air_rotation==0;
            if(was_grounded||near_lip){
            s->looping=1;
            s->loop_piece=piece_number;
            s->loop_t=0;
            s->x=ex;
            s->y=ey-5*RIDER_Q;
            s->angle=0;
            s->angular_speed=0;
            step_loop(s,held);
            update_camera(s);
            return;
            }
        }
    }
    if(!was_grounded && arch_contact(s,piece_number)){update_camera(s);return;}
    /* At the end of the first rising lip, preserve its tangent momentum.
     * The ordinary one-wheel support path used to zero vertical speed at
     * a missing centre rail, causing the bike to fall through the higher
     * landing even when it was launched at full speed. */
    if(was_grounded && ((rider_template_properties(piece->template_id)&RIDER_T_LIP))){
        int32_t here,old,back;
        if(!rider_surface_q(s,s->x,&here) && rider_surface_q(s,old_x,&old) &&
           rider_surface_q(s,old_x-8*RIDER_Q,&back)){
            s->vy=clamp_i32((old-back)*s->vx/(8*RIDER_Q),-3*RIDER_Q,2*RIDER_Q);
            s->y=old-5*RIDER_Q+s->vy;
            free_air(s);
            maybe_collect_gem(s,piece_number);
            update_camera(s);return;
        }
    }
    int32_t yl=0,yr=0,xl,xr,wl,wr;
    rider_wheel_centers_q(s,&xl,&wl,&xr,&wr);
    bool left=rider_surface_q(s,xl,&yl),right=rider_surface_q(s,xr,&yr);
    int32_t dl=left?wl+5*RIDER_Q-yl:INT32_MIN/4;
    int32_t dr=right?wr+5*RIDER_Q-yr:INT32_MIN/4;
    /* Independent wheel-contact probes: a wheel well above the rail is not
     * a supporting contact merely because its x coordinate has a surface.
     * This avoids snapping the whole bike to a remote slope when only one
     * wheel is actually on the ground. */
    bool l_support=left && dl>=-RIDER_Q && dl<=9*RIDER_Q;
    bool r_support=right && dr>=-RIDER_Q && dr<=9*RIDER_Q;
    /* Swept vertical crossing: a fast fall can travel farther than the
     * nine-pixel static support window in one tick. Test the old wheel
     * against its old rail, and the new wheel against the new rail. */
    if(!was_grounded){
        int32_t py;
        if(left && dl>=0 && rider_surface_q(s,prev_lx,&py) && prev_ly+5*RIDER_Q<=py)l_support=true;
        if(right && dr>=0 && rider_surface_q(s,prev_rx,&py) && prev_ry+5*RIDER_Q<=py)r_support=true;
    }
    bool contact=l_support||r_support;
    if(!was_grounded && !contact && rider_sin4096(s->angle+1024)<-96){
        int32_t roof_x=s->x+8*rider_sin4096(s->angle),roof_y=s->y-8*rider_sin4096(s->angle+1024),rail;
        if(rider_surface_q(s,roof_x,&rail) && roof_y>=rail && roof_y<=rail+12*RIDER_Q && s->vy>0){crash(s);return;}
    }
    /* A badly penetrated wheel is still rescued if the bike was already
     * grounded, rather than tunnelling through the rail on a long frame. */
    if(was_grounded && !contact){
        contact=(left&&dl>=0)||(right&&dr>=0);
        int32_t cy,oy;
        /* A continuous descending rail must not be mistaken for a gap
         * because both wheels briefly sit above its next contact point.
         * Preserve contact only when the old centre was actually near the
         * rail and the next centre stays on the same continuous surface. */
        if(!contact && rider_surface_q(s,old_x,&oy) && rider_surface_q(s,s->x,&cy) &&
           cy-oy<8*RIDER_Q && oy-cy<8*RIDER_Q && s->y-s->vy>=oy-10*RIDER_Q && s->y-s->vy<=oy+2*RIDER_Q)
            contact=true;
    }
    /* At a genuinely convex launch lip, keep momentum and leave the
     * rail instead of following the falling slope. Flat terrain and
     * tiny bumps never activate this. */
    if(was_grounded && contact && s->vx>2*RIDER_Q){
        int32_t before,here,after;
        if(rider_surface_q(s,s->x-20*RIDER_Q,&before) &&
           rider_surface_q(s,s->x,&here) &&
           rider_surface_q(s,s->x+20*RIDER_Q,&after) &&
           here-before< -5*RIDER_Q && after-here>5*RIDER_Q){
            s->vy=clamp_i32((here-before)/4,-3*RIDER_Q,-2*RIDER_Q);
            free_air(s);
            maybe_collect_gem(s,piece_number);
            update_camera(s);
            return;
        }
    }
    /* Landing is descending relative to the rail, not necessarily relative
     * to the world. A bike can meet a rising landing while still moving up. */
    bool approaching=s->vy>=0;
    if(!was_grounded && !approaching && s->airborne_ticks>2u && contact){
        int32_t diff;
        if(surface_delta(s,s->x,s->x+8*RIDER_Q,&diff))
            approaching=s->vy >= diff*s->vx/(8*RIDER_Q);
    }
    if(contact && (was_grounded || approaching)) {
        /* Ground angle must not collapse to zero merely because only one
         * wheel is inside the narrow impact-contact window. */
        int32_t tangent=0;
        if(was_grounded){
            int32_t diff;
            if(surface_delta(s,s->x-9*RIDER_Q,s->x+9*RIDER_Q,&diff)&&diff<35*RIDER_Q&&diff> -35*RIDER_Q)
                tangent=clamp_i32(angle_from_vector(18*RIDER_Q,diff),-700,700);
            else if(l_support||r_support){
                int32_t at=l_support?xl:xr;
                if(surface_delta(s,at-2*RIDER_Q,at+2*RIDER_Q,&diff))
                    tangent=clamp_i32(angle_from_vector(4*RIDER_Q,diff),-700,700);
                else tangent=(int32_t)(((uint32_t)s->angle+2048u)&4095u)-2048;
            }
        } else if(l_support&&r_support) {
            int32_t difference=yr-yl;
            tangent=clamp_i32((difference*652)/(24*RIDER_Q),-390,390);
        } else if(l_support||r_support) {
            int32_t at=l_support?xl:xr,diff;
            if(surface_delta(s,at-2*RIDER_Q,at+2*RIDER_Q,&diff))
                tangent=clamp_i32(angle_from_vector(4*RIDER_Q,diff),-390,390);
        }
        int32_t phase=((s->angle-tangent+2048)&4095)-2048;
        int32_t impact= s->vy;
        /* Small slopes don't kill the car. Serious upside-down impact does. */
        int32_t landing_limit=1000-clamp_i32(s->score,0,400)/2;
        if((!was_grounded && s->airborne_ticks>=8u && (phase>landing_limit||phase< -landing_limit)) ||
           (phase>1580||phase<-1580) ||
           ((phase>1380||phase<-1380)&&impact>4*RIDER_Q)) {
            crash(s); return;
        }
        if(!was_grounded) {
            /* Count only complete airborne turns followed by a safe landing. */
            /* Count complete turns relative to the takeoff/landing slopes.
             * Small angular error is allowed, but no 3/4-turn credit.
             * Bound slope correction so changing road angle alone is not a stunt. */
            int32_t slope_change=(int32_t)(((uint32_t)tangent-(uint32_t)s->takeoff_angle+2048u)&4095u)-2048;
            int32_t corrected=(int32_t)s->air_rotation+clamp_i32(slope_change,-512,512);
            uint32_t n=(uint32_t)clamp_i32(corrected+256,0,16*RIDER_ANGLE_TURN)/RIDER_ANGLE_TURN;
            if(s->air_rotation+512u<n*RIDER_ANGLE_TURN && n)n--;
            if(n>8)n=8;
            if(n) {

                bool perfect=l_support&&r_support && dl-dr<2*RIDER_Q && dr-dl<2*RIDER_Q && phase<128 && phase>-128;
                s->pending_score=(uint16_t)(n*(perfect?2u:1u));
                s->pending_ticks=31; /* this successful landing tick consumes one */
                s->perfect_ticks=perfect?48:0;
                if(perfect){s->boost_ticks=18;s->vx=clamp_i32(s->vx+RIDER_Q/2,0,5*RIDER_Q);}
            }
        }
        int32_t lp=(was_grounded?left:l_support)?dl:INT32_MIN/4;
        int32_t rp=(was_grounded?right:r_support)?dr:INT32_MIN/4;
        int32_t penetration=lp>rp?lp:rp;
        if(penetration>0)s->y-=penetration;
        if(was_grounded){
            int32_t road_y;
            if(rider_surface_q(s,s->x,&road_y)){
                /* Wheel orientation must not turn positional correction into
                 * a fake jump. Project to the road while already grounded;
                 * intentional cliffs and missing rail still release it. */
                s->y=road_y-5*RIDER_Q;
            }
        }
        /* Never convert a ground-position correction into an upward kick. */
        /* A ground projection is not a bounce impulse. Retain only a
         * bounded upward takeoff velocity on an actual rising ramp. */
        if(!was_grounded) s->vy=0;
        else if(left && right && yr-yl<32*RIDER_Q && yl-yr<32*RIDER_Q) {
            /* Launch velocity follows the *road tangent*, not the amount of
             * penetration resolved this frame. Thus no phantom bounce. */
            int32_t motion=(yr-yl)*s->vx/(24*RIDER_Q);
            s->vy=clamp_i32(motion,-3*RIDER_Q,2*RIDER_Q);
        } else s->vy=0;
        int32_t nearest=(s->angle & ~4095)+tangent;
        if(nearest-s->angle>2048)nearest-=4096;
        if(s->angle-nearest>2048)nearest+=4096;
        int32_t d=nearest-s->angle;
        /* While grounded there is no angular input: wheel suspension aligns
         * the bike gently with the road. This prevents phantom tip-overs. */
        if(was_grounded) {
            /* A bump cannot accumulate a rollover while in grounded mode. */
            s->angle+=clamp_i32(d*3/4,-220,220);
            /* Resolve the oriented wheelbase, not the old flat chassis.
             * On continuous rail the vertical circle clearance grows with
             * slope. Clamp to avoid attaching across a gap or ledge. */
            int32_t cx_y,al,ar,wx0,wy0,wx1,wy1;
            if(rider_surface_q(s,s->x,&cx_y)){
                rider_wheel_centers_q(s,&wx0,&wy0,&wx1,&wy1);
                if(rider_surface_q(s,wx0,&al)&&rider_surface_q(s,wx1,&ar)&&ar-al<32*RIDER_Q&&al-ar<32*RIDER_Q){
                    int32_t c=rider_sin4096(s->angle+1024);
                    if(c>=128){
                        int32_t clearance=5*RIDER_Q*256/c;
                        int32_t y0=al-(wy0-s->y)-clearance,y1=ar-(wy1-s->y)-clearance;
                        int32_t target=y0<y1?y0:y1;
                        s->y=clamp_i32(target,cx_y-8*RIDER_Q,cx_y-4*RIDER_Q);
                    }
                }
            }
        } else s->angle+=clamp_i32(d/3,-75,75);
        s->grounded=1;
        s->airborne_ticks=0;
        s->air_rotation=0;
    } else {
        if(was_grounded) {
            s->takeoff_angle=s->angle;
            s->air_rotation=0;
            s->airborne_ticks=0;
        }
        s->grounded=0;
    }
    /* Boost pads only trigger with the bike in ground contact and along the
     * underlying curved surface. They provide an obvious temporary effect. */
    if(s->grounded) {
        int32_t bx0,bx1,by;
        if(rider_piece_boost_q(s,piece_number,&bx0,&bx1,&by) &&
           s->x>=bx0 && s->x<=bx1) {
            if(s->boost_ticks<5)s->vx=clamp_i32(s->vx+125,0,6*RIDER_Q);
            s->boost_ticks=26;
        }
    }
    update_camera(s);
    if(s->x>INT32_MAX-150000 || s->y>410*RIDER_Q) crash(s);
}

/* Every movement path, including guided/open rails and gap-launch early
 * returns, now shares hazards, collectibles, landing score and world bounds. */
void rider_step(RiderState *s,bool held)
{
    if(s->paused)return;
    if(s->phase==RIDER_CRASHED || (s->phase==RIDER_READY && !held)){step_motion(s,held);return;}
    if(s->phase==RIDER_RUNNING && (s->x<0 || s->x>24990*256*RIDER_Q || s->y>410*RIDER_Q)){crash(s);return;}
    /* Centre, left wheel, right wheel: identical collision order for each hazard. */
    
    int32_t ox[3]={s->x},oy[3]={s->y};
    rider_wheel_centers_q(s,&ox[1],&oy[1],&ox[2],&oy[2]);
    step_motion(s,held);
    if(s->phase!=RIDER_RUNNING)return;
    if(s->x<0 || s->x>24990*256*RIDER_Q || s->y>410*RIDER_Q){crash(s);return;}
    uint32_t piece_number=(uint32_t)s->x/(256u*RIDER_Q);
    for(unsigned i=0;i<RIDER_TRACK_SLOTS;i++){
        RiderPiece *p=&s->track[i];
        if((p->template_id==58u||p->template_id==70u||p->template_id==83u) && (p->flags&PIECE_FLAG_FALLING) && (uint16_t)((uint16_t)s->tick_count-p->fall_tick)>80u)
            p->flags|=0x40u; /* permanently spent or raised, even after tick wrap */
    }
    RiderPiece *p=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(s->grounded && p->number==piece_number && (p->template_id==58u||p->template_id==70u||p->template_id==83u) && !(p->flags&PIECE_FLAG_FALLING)){
        int32_t a,b,y;
        for(unsigned slot=0;slot<(p->template_id==83u?2u:1u);++slot){
            if(rider_platform_at_q(s,piece_number,slot,&a,&b,&y) && s->x>=a && s->x<=b && s->y>=y-8*RIDER_Q && s->y<=y+2*RIDER_Q){
                p->flags|=PIECE_FLAG_FALLING;p->fall_tick=(uint16_t)(s->tick_count-slot*20u);break;
            }
        }
    }
    /* Recalculate wheel positions AFTER penetration correction. */
    int32_t nx[3]={s->x},ny[3]={s->y};
    rider_wheel_centers_q(s,&nx[1],&ny[1],&nx[2],&ny[2]);
    uint32_t first=piece_number?piece_number-1u:0u;
    for(uint32_t pn=first;pn<=piece_number+1u;++pn) {
        int32_t cx,cy,r;
        if(rider_piece_ring_q(s,pn,&cx,&cy)){
            for(unsigned i=0;i<3u;i++)
                if(ring_swept(ox[i]-cx,oy[i]-cy,nx[i]-cx,ny[i]-cy,s->tick_count,i?3:4)){crash(s);return;}
        }
        for(unsigned j=0;j<2u;j++){
            if(!rider_piece_saw_at_q(s,pn,j,&cx,&cy,&r))break;
            int32_t pcx=cx,pcy=cy,pr;
            if(!saw_at_tick(s,pn,j,s->tick_count-1u,&pcx,&pcy,&pr)){pcx=cx;pcy=cy;}
            for(unsigned i=0;i<3u;i++)
                if(rider_swept_circle_q(ox[i]-pcx,oy[i]-pcy,nx[i]-cx,ny[i]-cy,r+(i?4:6)*RIDER_Q)){crash(s);return;}
        }
    }
    for(uint32_t pn=first;pn<=piece_number+1u;++pn){
        int32_t x0,x1,tip;
        if(!rider_piece_spikes_q(s,pn,&x0,&x1,&tip))continue;
        int32_t a,b,oldtip;
        if(!spikes_at_tick(s,pn,s->tick_count-1u,&a,&b,&oldtip))oldtip=tip;
        for(unsigned i=0;i<3u;i++)
            if(spike_swept(ox[i],oy[i],nx[i],ny[i],x0,x1,oldtip,tip)){crash(s);return;}
    }
    for(uint32_t pn=piece_number?piece_number-1u:0u;pn<=piece_number+1u;++pn)
        if(pn<s->next_piece)maybe_collect_gem(s,pn);

    /* Confirm stunt points only AFTER this tick's collision checks. */
    if(s->grounded && !s->looping)commit_pending(s);

}

uint32_t rider_hash(const RiderState *s)
{
    uint32_t x=2166136261u;
#define HASH(v) do { x^=(uint32_t)(v); x*=16777619u; } while(0)
    HASH(s->flips_landed); HASH(s->random_state); HASH(s->next_piece); HASH(s->x); HASH(s->y);
    HASH(s->vx);HASH(s->vy);HASH(s->angle);HASH(s->phase);HASH(s->score);HASH(s->tick_count);HASH(s->air_rotation);HASH(s->loop_t);HASH(s->looping);HASH(s->boost_ticks); HASH(s->throttle_active); HASH(s->theme);
    for (uint32_t i=0;i<RIDER_TRACK_SLOTS;i++) {
        HASH(s->track[i].number);HASH(s->track[i].start_y);HASH(s->track[i].template_id);HASH(s->track[i].flags);HASH(s->track[i].gem_mask); HASH(s->track[i].fall_tick);
    }
#undef HASH
    return x;
}
