#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "rider_core.h"

static uint32_t rand32(uint32_t *s){uint32_t x=*s;x^=x<<13;x^=x>>17;x^=x<<5;return *s=x;}
static void check(const RiderGame *r){
    assert(r->used<=RDR_SEGMENTS);
    assert(r->generatedEnd>0);
    int32_t last=-1;
    for(unsigned i=0;i<r->used;++i) {
        const RiderSegment *s=riderSegmentAt(r,i);
        assert(s&&s->x1>s->x0&&s->x0>last);
        assert(s->y0>=66&&s->y0<=204&&s->y1>=66&&s->y1<=204);
        if(i)assert(last+1==s->x0);
        last=s->x1-1;
    }
}
int main(void) {
    for(unsigned seed=1;seed<=2500;++seed){
        RiderGame a,b;
        riderInit(&a,seed);riderInit(&b,seed);
        assert(!memcmp(&a,&b,sizeof(a)));
        riderStart(&a);riderStart(&b);
        uint32_t rng=seed*1113u;
        for(int i=0;i<1100;i++) {
            bool held=(rand32(&rng)%13)<8;
            riderStep(&a,held);riderStep(&b,held);
            assert(memcmp(&a,&b,sizeof(a))==0);
            check(&a);
            if(a.phase==RDR_CRASHED)break;
        }
        assert(a.phase==RDR_CRASHED || a.phase==RDR_RUNNING);
    }
    /* One-button input must accelerate and initial runway must be stable. */
    RiderGame t;riderInit(&t,17);riderStart(&t);
    for(int i=0;i<20;i++){riderStep(&t,true);assert(t.phase==RDR_RUNNING);}
    assert(t.vx>0&&t.distance>0);
    riderPause(&t);assert(t.phase==RDR_PAUSED);
    int32_t x=t.x;riderStep(&t,true);assert(t.x==x);
    riderPause(&t);assert(t.phase==RDR_RUNNING);
    puts("PASS: 2500 deterministic generated runs; boundaries, pause, runway, input");
    return 0;
}
