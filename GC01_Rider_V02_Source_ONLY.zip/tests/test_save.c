#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "rider_save.h"
static uint8_t mem[2048];
static int writes=0;
static bool rd(void *c,uint32_t a,void *dst,uint32_t n){(void)c;a-=RIDER_SAVE_PAGE_A;if(a+n>2048)return false;memcpy(dst,mem+a,n);return true;}
static bool pr(void *c,uint32_t a,const void *src,uint32_t n){(void)c;a-=RIDER_SAVE_PAGE_A;if(a+n>2048)return false;const uint8_t *p=src;for(uint32_t i=0;i<n;i++)mem[a+i]&=p[i];writes++;return true;}
static bool er(void *c,uint32_t a){(void)c;a-=RIDER_SAVE_PAGE_A;if(a+1024>2048||a%1024)return false;memset(mem+a,0xff,1024);return true;}
int main(void) {
    memset(mem,0xff,sizeof(mem));
    RiderFlashOps f={0,rd,pr,er};RiderRecord r={0},s={0};
    assert(riderLoadRecord(&f,&s)&&s.bestScore==0&&s.soundEnabled);
    for(int i=1;i<=160;i++){
        r.bestScore=i*13;r.diamonds=i;r.bestDistance=i*120;r.soundEnabled=(i%2)==0;
        assert(riderSaveRecord(&f,&r));
        assert(riderLoadRecord(&f,&s));
        assert(s.bestScore==r.bestScore && s.diamonds==r.diamonds && s.soundEnabled==r.soundEnabled);
    }
    /* Simulate a partially programmed future record: newest remains valid. */
    uint32_t best=s.bestScore;
    /* Current page A has 16 records (145..160); interrupt programming slot 16. */
    uint32_t torn=0x31524452u;
    assert(pr(0,RIDER_SAVE_PAGE_A+16*28,&torn,4));
    assert(riderLoadRecord(&f,&s)&&s.bestScore==best);
    /* A later save must skip the dirty, interrupted slot and remain readable. */
    r.bestScore=best+19;
    assert(riderSaveRecord(&f,&r));
    assert(riderLoadRecord(&f,&s)&&s.bestScore==r.bestScore);
    printf("PASS: 161 persistent updates, page rollover, interrupted record recovery; %d flash writes\n",writes);
    return 0;
}
