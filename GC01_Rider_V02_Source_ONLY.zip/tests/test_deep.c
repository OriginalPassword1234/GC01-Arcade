/* Repeated seeds, event/reward coverage, long-run invariants, and loop geometry. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "rider_core.h"
static uint32_t next(uint32_t *s){uint32_t x=*s;x^=x<<13;x^=x>>17;x^=x<<5;return *s=x;}
int main(void){
 uint32_t counts[7]={0};unsigned seeds=10000,nontrivial=0;
 for(unsigned seed=1;seed<=seeds;seed++){
  RiderGame r;riderInit(&r,seed);riderStart(&r);
  uint32_t random=seed+0x2e485332u,prevScore=0,prevDiamonds=0;
  for(unsigned tick=0;tick<2400;tick++){
   bool held=(seed&3)==0?true:(next(&random)&7u)<6u;
   riderStep(&r,held);
   assert(r.phase==RDR_CRASHED||r.phase==RDR_RUNNING);
   assert(r.used>0&&r.used<=RDR_SEGMENTS);
   assert(r.score>=prevScore&&r.diamonds>=prevDiamonds);
   assert(r.generatedEnd>0&&r.x>=0&&r.x<=0x7fffffff);
   assert(r.loopProgress<256);
   int32_t prev=-1;
   for(unsigned i=0;i<r.used;i++){
    const RiderSegment *s=riderSegmentAt(&r,i);
    assert(s->x1>s->x0&&s->y0>=82&&s->y0<=204&&s->y1>=82&&s->y1<=204);
    assert(s->kind<=RDR_WHEEL);
    if(i)assert(s->x0==prev);
    prev=s->x1;
   }
   if(r.event<=RDR_EVENT_CRASH)counts[r.event]++;
   prevScore=r.score;prevDiamonds=r.diamonds;
   if(r.distance>1000)nontrivial++;
   if(r.phase==RDR_CRASHED)break;
  }
 }
 assert(counts[RDR_EVENT_LOOP]>0&&counts[RDR_EVENT_WHEEL]>0&&counts[RDR_EVENT_DIAMOND]>0);
 assert(nontrivial>0);
 for(int a=0;a<256;a++)assert(riderSine((uint8_t)a)>=-64&&riderSine((uint8_t)a)<=64);
 printf("PASS: %u generated seeds; %u loop events, %u wheel events, %u diamonds, %u flips\n",seeds,counts[RDR_EVENT_LOOP],counts[RDR_EVENT_WHEEL],counts[RDR_EVENT_DIAMOND],counts[RDR_EVENT_FLIP]);
}
