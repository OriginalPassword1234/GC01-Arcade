#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
cc="${CC:-cc}"
flags='-std=c11 -O2 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -Isrc'
"$cc" $flags src/rider_core.c tests/test_rider.c -o /tmp/gc01-rider-test
/tmp/gc01-rider-test
"$cc" $flags src/rider_core.c tests/test_deep.c -o /tmp/gc01-rider-deep
/tmp/gc01-rider-deep
"$cc" $flags src/rider_save.c tests/test_save.c -o /tmp/gc01-rider-save
/tmp/gc01-rider-save
"$cc" -std=c11 -O2 -Wall -Wextra -Werror -Isrc src/rider_core.c src/rider_neon.c tests/render_preview.c -o /tmp/gc01-rider-render
/tmp/gc01-rider-render

"$cc" $flags -DGC01_RIDER -DDISPLAY_320X240 -DDISPLAY_COLOR \
  -Iplatform.io/src/ui -Iplatform.io/lib/mcu-renderer \
  src/rider_core.c src/rider_neon.c platform.io/src/ui/rider.c \
  tests/test_ui_stream.c -o /tmp/gc01-rider-ui-test
/tmp/gc01-rider-ui-test
