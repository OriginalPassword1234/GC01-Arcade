#include <stdio.h>
#include <stdint.h>
#include "rider_core.h"
#include "rider_neon.h"
static uint16_t framebuffer[240][320];
static void rect(void *ctx,int x,int y,int w,int h,uint16_t c){(void)ctx;for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++)framebuffer[yy][xx]=c;}
static void line(void *ctx,int x0,int y0,int x1,int y1,int width,uint16_t c){
    (void)ctx;int dx=x1-x0,dy=y1-y0;
    int steps=dx>0?dx:-dx, ady=dy>0?dy:-dy;if(ady>steps)steps=ady;
    if(steps==0)steps=1;
    for(int i=0;i<=steps;i++){
        int x=x0+dx*i/steps,y=y0+dy*i/steps;
        for(int yy=y-width/2; yy<=y+width/2;yy++)for(int xx=x-width/2;xx<=x+width/2;xx++)
            if(xx>=0&&xx<320&&yy>=0&&yy<240)framebuffer[yy][xx]=c;
    }
}
static void circle(void *ctx,int x,int y,int radius,uint16_t c){
    (void)ctx;int lastx=radius,lasty=0;
    for(int i=1;i<=48;i++){
        static const int8_t cs[13]={64,62,55,45,32,17,0,-17,-32,-45,-55,-62,-64};
        int j=i%48, quadrant=j/12,ind=j%12;
        int cx=quadrant==0?cs[ind]:quadrant==1?cs[12-ind]:quadrant==2?-cs[ind]:-cs[12-ind];
        int cy=quadrant==0?cs[12-ind]:quadrant==1?cs[ind]:quadrant==2?-cs[12-ind]:-cs[ind];
        int nx=cx*radius/64,ny=cy*radius/64;
        line(ctx,x+lastx,y+lasty,x+nx,y+ny,1,c);lastx=nx;lasty=ny;
    }
}
int main(void){
    RiderGame g;riderInit(&g,23);riderStart(&g);
    for(int i=0;i<78;i++)riderStep(&g,i%33<27);
    RiderCanvas c={0,rect,line,circle};riderDrawNeon(&g,&c);
    FILE *f=fopen("rider_preview.ppm","wb");if(!f)return 2;
    fputs("P6\n320 240\n255\n",f);
    for(int y=0;y<240;y++)for(int x=0;x<320;x++){
        uint16_t v=framebuffer[y][x];
        uint8_t rgb[3]={(uint8_t)(((v>>11)&31)*255/31),
                        (uint8_t)(((v>>5)&63)*255/63),
                        (uint8_t)((v&31)*255/31)};
        fwrite(rgb,1,3,f);
    }
    fclose(f);puts("Rendered prototype preview");return 0;
}
