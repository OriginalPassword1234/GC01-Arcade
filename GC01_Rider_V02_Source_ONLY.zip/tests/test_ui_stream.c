/* Native mock of Rad Pro image transfer: test clipped four-row RGB565 renderer. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "rider.h"
#include "draw.h"
static uint16_t display[240][320];
static unsigned strips=0;
void drawImage(const mr_rectangle_t *r,const mr_color_t *pixels){
    assert(r && pixels && r->x==0 && r->width==320 && r->height==4);
    assert(r->y>=0 && r->y+4<=240 && (r->y&3)==0);
    memcpy(&display[r->y][0],pixels,320*4*sizeof(uint16_t));
    strips++;
}
int main(void){
    RiderRecord rec={0};rec.bestScore=300;rec.soundEnabled=true;
    for(unsigned seed=1;seed<=30;seed++){
        RiderGame r;riderInit(&r,seed);riderStart(&r);
        for(int i=0;i<120;i++)riderStep(&r,(i+seed)%11<8);
        drawRider(&r,&rec);
        assert(strips==seed*60);
        unsigned colored=0;for(int y=25;y<240;y++)for(int x=0;x<320;x++)if(display[y][x]!=display[25][0])colored++;
        assert(colored>100);
    }
    puts("PASS: 30 full 320x240 streamed render tests (1800 checked strips)");
}
