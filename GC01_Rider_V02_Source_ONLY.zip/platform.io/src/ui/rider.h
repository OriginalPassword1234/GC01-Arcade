#ifndef GC01_RIDER_UI_H
#define GC01_RIDER_UI_H
#include "../extras/rider_core.h"
#include "../extras/rider_save.h"
void drawRider(const RiderGame *r,const RiderRecord *records);
#endif
