/* Four-row RGB565 streaming renderer: 2560-byte framebuffer, no whole-screen RAM.
 * Geometry is identical to rider_neon.c's reference canvas callbacks. MIT. */
#if defined(GC01_RIDER)
#include <stdint.h>
#include <string.h>
#include "draw.h"
#include "rider.h"
#include "../extras/rider_neon.h"
#define ROWS 4
#define W 320
#define H 240
#define RGB(r,g,b) (uint16_t)((((r)&31)<<11)|(((g)&63)<<5)|((b)&31))
typedef struct {int top;uint16_t pix[ROWS*W];} Scan;
static Scan scan;
static void rect(void *ctx,int x,int y,int w,int h,uint16_t color){
 Scan*s=ctx;if(w<=0||h<=0)return;
 int x0=x<0?0:x,x1=x+w>W?W:x+w;
 int y0=y<s->top?s->top:y,y1=y+h>s->top+ROWS?s->top+ROWS:y+h;
 if(x0>=x1||y0>=y1)return;
 for(int j=y0;j<y1;j++){uint16_t*row=s->pix+(j-s->top)*W;
  for(int i=x0;i<x1;i++)row[i]=color;}
}
static void plot(Scan*s,int x,int y,int thick,uint16_t color){
 int half=thick/2;rect(s,x-half,y-half,thick,thick,color);
}
static void line(void *ctx,int x0,int y0,int x1,int y1,int thick,uint16_t color){
 Scan*s=ctx;int dx=x1-x0,dy=y1-y0,ax=dx<0?-dx:dx,ay=dy<0?-dy:dy;
 /* Reject an entire line well outside the strip; avoid large raster loops. */
 int minY=y0<y1?y0:y1,maxY=y0>y1?y0:y1;
 if(maxY+thick<s->top || minY-thick>=s->top+ROWS)return;
 int n=ax>ay?ax:ay;if(n>1200)return;
 if(n==0){plot(s,x0,y0,thick,color);return;}
 for(int i=0;i<=n;i++){
  int x=x0+(int)((int64_t)dx*i/n),y=y0+(int)((int64_t)dy*i/n);
  if(y+thick>=s->top && y-thick<s->top+ROWS)plot(s,x,y,thick,color);
 }
}
static void circle(void *ctx,int cx,int cy,int radius,uint16_t color){
 Scan*s=ctx;if(radius<=0||cy+radius<s->top||cy-radius>=s->top+ROWS)return;
 int x=radius,y=0,err=1-radius;
 while(x>=y){
  plot(s,cx+x,cy+y,2,color);plot(s,cx+y,cy+x,2,color);
  plot(s,cx-x,cy+y,2,color);plot(s,cx-y,cy+x,2,color);
  plot(s,cx+x,cy-y,2,color);plot(s,cx+y,cy-x,2,color);
  plot(s,cx-x,cy-y,2,color);plot(s,cx-y,cy-x,2,color);
  y++;if(err<0)err+=2*y+1;else{x--;err+=2*(y-x)+1;}
 }
}
static const uint16_t digits[10]={0x7b6f,0x2c97,0x73e7,0x73cf,0x5bc9,0x79cf,0x79ef,0x7292,0x7bef,0x7bcf};
static const uint16_t letters[26]={0x2bed,0x6bae,0x3923,0x6b6e,0x79a7,0x79a4,0x396b,0x5bed,0x7497,0x126a,0x5bad,0x4927,0x5fed,0x5ffd,0x2b6a,0x6ba4,0x2b7b,0x6bad,0x388e,0x7492,0x5b6f,0x5b6a,0x5bfd,0x5aad,0x5a92,0x72a7};
static void tiny(const char *str,int x,int y,int scale,uint16_t fg){
 for(;*str;str++,x+=scale*4){uint16_t bits=0;
  if(*str>='0'&&*str<='9')bits=digits[*str-'0'];
  else if(*str>='A'&&*str<='Z')bits=letters[*str-'A'];
  for(int row=0;row<5;row++)for(int col=0;col<3;col++)
   if(bits&(1u<<(14-row*3-col)))rect(&scan,x+col*scale,y+row*scale,scale,scale,fg);
 }
}
static void number(uint32_t v,int x,int y,int scale,uint16_t fg){
 char b[12];int i=0;do{b[i++]=(char)('0'+(v%10));v/=10;}while(v&&i<11);
 int n=i;for(int k=0;k<n/2;k++){char t=b[k];b[k]=b[n-1-k];b[n-1-k]=t;}b[n]=0;tiny(b,x,y,scale,fg);
}
void drawRider(const RiderGame*r,const RiderRecord*rec){
 RiderCanvas c={&scan,rect,line,circle};
 for(int top=0;top<H;top+=ROWS){
  scan.top=top;
  riderDrawNeon(r,&c);
  const uint16_t white=RGB(27,61,30),gold=RGB(31,48,10),muted=RGB(13,29,28);
  tiny("SCORE",7,6,2,muted);number(r->score,58,6,2,white);
  tiny("BEST",156,6,2,muted);
  number(r->score>rec->bestScore?r->score:rec->bestScore,203,6,2,gold);
  tiny("D",286,6,2,gold);number(r->diamonds,300,6,2,white);
  if(r->phase==RDR_PAUSED){
   tiny("PAUSED",112,84,3,white);tiny("OK RESUME",88,124,2,gold);
   tiny("LEFT EXIT",88,141,2,white);tiny(rec->soundEnabled?"DOWN SOUND ON":"DOWN SOUND OFF",58,160,2,muted);
  }else if(r->phase==RDR_CRASHED){
   tiny("CRASH",123,84,3,gold);tiny("OK RETRY",102,127,2,white);
  }
  drawImage(&(mr_rectangle_t){0,(int16_t)top,W,ROWS},scan.pix);
 }
}
#endif
