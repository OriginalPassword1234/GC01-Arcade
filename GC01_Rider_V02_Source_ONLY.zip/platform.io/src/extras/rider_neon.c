/* Original compact geometry-only neon renderer. MIT license.
 * This reference draws the full scene; real GC-01 needs measured dirty rendering. */
#include "rider_neon.h"

#define RGB565(r,g,b) (uint16_t)((((r)&31)<<11)|(((g)&63)<<5)|((b)&31))
#define BG RGB565(1,1,4)
#define GRID RGB565(2,5,11)
#define PURPLE RGB565(29,6,28)
#define MAGENTA RGB565(31,19,30)
#define CYAN RGB565(3,58,31)
#define LIGHT RGB565(26,63,31)
#define GOLD RGB565(31,52,9)
#define RED RGB565(31,6,10)
#define RED_GLOW RGB565(13,2,5)
#define DARKBLUE RGB565(1,8,17)
static void rect(const RiderCanvas *c,int x,int y,int w,int h,uint16_t color) {
    if(w<=0||h<=0)return;
    if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}
    if(x+w>320)w=320-x;
    if(y+h>240)h=240-y;
    if(w>0&&h>0)c->rect(c->ctx,x,y,w,h,color);
}
static void line(const RiderCanvas *c,int x0,int y0,int x1,int y1,int width,uint16_t color) {
    c->line(c->ctx,x0,y0,x1,y1,width,color);
}
static void ring(const RiderCanvas *c,int x,int y,int radius,uint16_t color) {
    c->circle(c->ctx,x,y,radius,color);
}
void riderDrawNeon(const RiderGame *r,const RiderCanvas *c) {
    if(!r||!c||!c->rect||!c->line||!c->circle)return;
    rect(c,0,0,320,240,BG);
    const int32_t camera=(r->x>>8)-86;
    /* inexpensive distant grid; moves slower than the track */
    int scroll=(int)((camera/5)%36);if(scroll<0)scroll+=36;
    for(int x=-36+scroll;x<320;x+=36)rect(c,x,26,1,214,GRID);
    for(int y=42;y<240;y+=35)rect(c,0,y,320,1,GRID);
    for(int i=0;i<22;i++) {
        int x=(int)((i*113+17-(camera/12)%320)%320);if(x<0)x+=320;
        int y=31+(i*61)%175;
        rect(c,x,y,(i&3)==0?2:1,1,(i&1)?GRID:DARKBLUE);
    }
    /* The track is generated from parameterized segments, never stored bitmaps. */
    for(unsigned i=0;i<r->used;++i) {
        const RiderSegment *s=riderSegmentAt(r,i);
        int x0=(int)(s->x0-camera),x1=(int)(s->x1-camera);
        if(x1<-10||x0>331)continue;
        if(s->kind!=RDR_GAP) {
            uint16_t glow=(s->kind==RDR_BOOST)?RGB565(9,18,5):PURPLE;
            uint16_t core=(s->kind==RDR_BOOST)?GOLD:(i&1)?MAGENTA:CYAN;
            int y0=riderTrackHeight(s,s->x0,r->frames);
            int y1=riderTrackHeight(s,s->x1,r->frames);
            if(s->kind==RDR_LOOP){
                int cx=(int)(s->x0+40-camera),cy=s->y0-24;
                line(c,x0,s->y0,cx,s->y0,9,glow);
                line(c,x0,s->y0,cx,s->y0,3,core);
                ring(c,cx,cy,27,glow);ring(c,cx,cy,24,core);ring(c,cx,cy,23,LIGHT);
                line(c,cx,s->y0,x1,s->y1,9,glow);
                line(c,cx,s->y0,x1,s->y1,3,core);
            }else{
                line(c,x0,y0,x1,y1,9,glow);
                line(c,x0,y0,x1,y1,4,core);
                line(c,x0,y0,x1,y1,1,LIGHT);
            }
            if(s->kind==RDR_BOOST) {
                for(int j=16;j<s->x1-s->x0;j+=18) {
                    int py=s->y0+(int)((int64_t)j*(s->y1-s->y0)/(s->x1-s->x0));
                    line(c,x0+j,py-3,x0+j+6,py-3,1,GOLD);
                }
            }
        }
        if((s->special&1u)&&!(s->special&2u)) {
            int mx=(x0+x1)/2,my=(s->y0+s->y1)/2-20;
            line(c,mx,my-9,mx+6,my,2,GOLD);
            line(c,mx+6,my,mx,my+9,2,GOLD);
            line(c,mx,my+9,mx-6,my,2,GOLD);
            line(c,mx-6,my,mx,my-9,2,GOLD);
            rect(c,mx-1,my-2,3,4,LIGHT);
        }
        if(s->kind==RDR_SAW || s->kind==RDR_WHEEL) {
            /* A visual placeholder for the future timed red gripping wheel.
             * Not yet a simulated collidable hazard. */
            int mx=(x0+x1)/2,my=(s->y0+s->y1)/2-(s->kind==RDR_WHEEL?12:28);
            ring(c,mx,my,s->kind==RDR_WHEEL?16:13,RED_GLOW);ring(c,mx,my,11,RED);
            for(int a=0;a<8;++a) {
                uint8_t angle=(uint8_t)(a*32+r->frames*(s->kind==RDR_WHEEL?5:3));
                int ux=(int)riderSine(angle+64),uy=(int)riderSine(angle);
                line(c,mx+ux*9/64,my+uy*9/64,mx+ux*15/64,my+uy*15/64,2,RED);
            }
            ring(c,mx,my,3,MAGENTA);
        }
    }
    /* Rider icon: narrow triangular bike body, neon rims and turning wheels. */
    int bx=86,by=r->y>>8;
    uint8_t angle=(uint8_t)(r->turns&255);
    int cs=riderSine((uint8_t)(angle+64)),sn=riderSine(angle);
    int ax=bx-(11*cs)/64,ay=by-(11*sn)/64;
    int zx=bx+(11*cs)/64,zy=by+(11*sn)/64;
    int mx=bx+(6*sn)/64,my=by-(6*cs)/64;
    ring(c,ax,ay,6,PURPLE);ring(c,zx,zy,6,PURPLE);
    ring(c,ax,ay,4,LIGHT);ring(c,zx,zy,4,LIGHT);
    line(c,ax,ay,mx,my,3,GOLD);
    line(c,mx,my,zx,zy,3,GOLD);
    line(c,ax,ay,zx,zy,1,LIGHT);
    line(c,mx,my,mx+(4*cs)/64,my+(4*sn)/64,2,MAGENTA);
    /* Minimal HUD, device firmware can use its existing font renderer. */
    rect(c,0,0,320,24,DARKBLUE);
    rect(c,0,23,320,1,PURPLE);
    if(r->phase==RDR_CRASHED){rect(c,0,0,320,2,RED);}
}
