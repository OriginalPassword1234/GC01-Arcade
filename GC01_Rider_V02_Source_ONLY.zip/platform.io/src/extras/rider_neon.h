/* Palette-based neon drawing backend (rendering reference; not a hardware driver). */
#ifndef GC01_RIDER_NEON_H
#define GC01_RIDER_NEON_H
#include "rider_core.h"
#include <stdint.h>
typedef struct {
    void *ctx;
    void (*rect)(void *,int,int,int,int,uint16_t);
    void (*line)(void *,int,int,int,int,int,uint16_t);
    void (*circle)(void *,int,int,int,uint16_t);
} RiderCanvas;
void riderDrawNeon(const RiderGame *game,const RiderCanvas *canvas);
#endif
