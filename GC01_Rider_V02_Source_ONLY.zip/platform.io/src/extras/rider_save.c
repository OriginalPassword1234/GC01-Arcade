/* Two-page append-only flash journal, original code, MIT. */
#include "rider_save.h"
#include <string.h>
#define MAGIC 0x31524452u /* "RDR1" in little-endian */

typedef struct {
    uint32_t magic, serial, bestScore, diamonds, bestDistance, flags, checksum;
} Raw;
_Static_assert(sizeof(Raw)==RIDER_SAVE_RECORD_SIZE,"flash record must stay 28 bytes");
static const uint32_t page[2]={RIDER_SAVE_PAGE_A,RIDER_SAVE_PAGE_B};
static uint32_t checksum(const Raw *a) {
    uint32_t h=2166136261u;
    const uint32_t *words=(const uint32_t *)a;
    for(unsigned j=0;j<6;++j){uint32_t t=words[j];for(unsigned i=0;i<4;i++){h^=(uint8_t)t;h*=16777619u;t>>=8;}}
    return h;
}
static bool rawValid(const Raw *r) {
    return r->magic==MAGIC && r->checksum==checksum(r) &&
        (r->flags&0xffff0000u)==0x738a0000u;
}
static bool isEmpty(const Raw *r) {
    const uint32_t *p=(const uint32_t *)r;
    for(unsigned i=0;i<7;++i)if(p[i]!=0xffffffffu)return false;
    return true;
}
static bool newer(uint32_t a,uint32_t b){return (int32_t)(a-b)>0;}
static bool findLatest(const RiderFlashOps *f,Raw *best,int *bestPage,int *nextSlot) {
    bool found=false;
    *bestPage=-1;
    *nextSlot=0;
    for(int p=0;p<2;p++){
        for(unsigned i=0;i<RIDER_SAVE_SLOTS_PER_PAGE;i++){
            Raw v;
            if(!f->read(f->ctx,page[p]+i*sizeof(v),&v,sizeof(v)))return false;
            if(rawValid(&v) && (!found||newer(v.serial,best->serial))) {
                *best=v;*bestPage=p;found=true;
            }
        }
    }
    if(!found)return true;
    /* Next record follows the newest entry, skipping interrupted records. */
    int p=*bestPage;
    bool seenBest=false;
    for(unsigned i=0;i<RIDER_SAVE_SLOTS_PER_PAGE;i++){
        Raw v;
        if(!f->read(f->ctx,page[p]+i*sizeof(v),&v,sizeof(v)))return false;
        if(v.serial==best->serial&&rawValid(&v))seenBest=true;
        if(seenBest&&isEmpty(&v)) {*nextSlot=(int)i;return true;}
    }
    *nextSlot=RIDER_SAVE_SLOTS_PER_PAGE;
    return true;
}
bool riderLoadRecord(const RiderFlashOps *f,RiderRecord *out) {
    Raw a={0};int pageIdx=-1,slot=0;
    if(!f||!out||!f->read||!findLatest(f,&a,&pageIdx,&slot))return false;
    if(pageIdx<0) {
        memset(out,0,sizeof(*out));
        out->soundEnabled=true;
        return true;
    }
    out->serial=a.serial;
    out->bestScore=a.bestScore;
    out->diamonds=a.diamonds;
    out->bestDistance=a.bestDistance;
    out->soundEnabled=(a.flags&1u)!=0;
    return true;
}
bool riderSaveRecord(const RiderFlashOps *f,const RiderRecord *record) {
    Raw previous={0},v;int p=-1,slot=0;
    if(!f||!record||!f->read||!f->program||!f->erase||
       !findLatest(f,&previous,&p,&slot))return false;
    int targetPage=p;
    if(p<0){targetPage=0;slot=0;}
    else if(slot>=(int)RIDER_SAVE_SLOTS_PER_PAGE){targetPage=1-p;slot=0;}
    /* First save or page rollover: erase only page not holding newest valid entry. */
    if(slot==0 && !f->erase(f->ctx,page[targetPage]))return false;
    v.magic=MAGIC;
    v.serial=(p>=0)?previous.serial+1u:1u;
    v.bestScore=record->bestScore;
    v.diamonds=record->diamonds;
    v.bestDistance=record->bestDistance;
    v.flags=0x738a0000u|(record->soundEnabled?1u:0u);
    v.checksum=checksum(&v);
    uint32_t addr=page[targetPage]+(uint32_t)slot*sizeof(Raw);
    /* On most hardware, 4-byte-aligned writes are legal; an interrupted write
       cannot become valid unless the checksum was programmed successfully. */
    if(!f->program(f->ctx,addr,&v,sizeof(v)))return false;
    Raw check;
    return f->read(f->ctx,addr,&check,sizeof(check))&&rawValid(&check)&&check.serial==v.serial;
}
