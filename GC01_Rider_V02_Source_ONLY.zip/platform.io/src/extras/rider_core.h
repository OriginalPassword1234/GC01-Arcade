/* GC-01 Rider independent deterministic gameplay. MIT. */
#ifndef GC01_RIDER_CORE_H
#define GC01_RIDER_CORE_H
#include <stdint.h>
#include <stdbool.h>
#define RDR_FP 256
#define RDR_SEGMENTS 30
/* Only a few bytes per segment; generated/recycled as player advances. */
typedef enum {RDR_ROAD=0,RDR_GAP,RDR_BOOST,RDR_SAW,RDR_LOOP,RDR_MOVING,RDR_WHEEL} RiderKind;
typedef enum {RDR_READY=0,RDR_RUNNING,RDR_CRASHED,RDR_PAUSED} RiderPhase;
typedef enum {RDR_EVENT_NONE=0,RDR_EVENT_DIAMOND,RDR_EVENT_FLIP,RDR_EVENT_LOOP,RDR_EVENT_WHEEL,RDR_EVENT_CRASH} RiderEvent;
typedef struct {
 int32_t x0,x1;
 int16_t y0,y1;
 uint8_t kind,special;
} RiderSegment;
typedef struct {
 int32_t x,y,vx,vy,turns,lastGroundTurns;
 uint32_t score,distance,diamonds,seed,frames;
 uint32_t lastAwardBucket;
 uint16_t combo,bestCombo,loopProgress;
 int32_t loopWorldX;
 int16_t loopBaseY;
 uint8_t phase,airborne,loopActive,event,eventSeq;
 uint8_t recent[4],recentAt,head,used;
 int32_t generatedEnd;
 int16_t generatedHeight;
 RiderSegment segments[RDR_SEGMENTS];
} RiderGame;
void riderInit(RiderGame *r,uint32_t seed);
void riderStart(RiderGame *r);
void riderStep(RiderGame *r,bool upHeld);
void riderPause(RiderGame *r);
const RiderSegment *riderSegmentAt(const RiderGame *r,unsigned index);
const RiderSegment *riderFindTrack(const RiderGame *r,int32_t x);
int riderTrackHeight(const RiderSegment *s,int32_t x,uint32_t frame);
int riderSine(uint8_t angle); /* scaled to +/-64 */
#endif
