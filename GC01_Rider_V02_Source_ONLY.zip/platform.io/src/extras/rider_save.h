/* Wear-levelled, crash-resistant two-page record journal.
 * Requires two dedicated, independently erasable 1-KiB flash pages.
 * Does not touch Rad Pro settings or measurement logs. MIT. */
#ifndef GC01_RIDER_SAVE_H
#define GC01_RIDER_SAVE_H
#include <stdint.h>
#include <stdbool.h>
#define RIDER_SAVE_PAGE_SIZE 1024u
#define RIDER_SAVE_RECORD_SIZE 28u
#define RIDER_SAVE_SLOTS_PER_PAGE (RIDER_SAVE_PAGE_SIZE/RIDER_SAVE_RECORD_SIZE)
#define RIDER_SAVE_PAGE_A 0x08015000u
#define RIDER_SAVE_PAGE_B 0x08015400u

typedef struct {
    uint32_t serial;
    uint32_t bestScore;
    uint32_t diamonds;
    uint32_t bestDistance;
    bool soundEnabled;
} RiderRecord;

typedef struct {
    void *ctx;
    bool (*read)(void *ctx,uint32_t addr,void *dst,uint32_t bytes);
    bool (*program)(void *ctx,uint32_t addr,const void *data,uint32_t bytes);
    bool (*erase)(void *ctx,uint32_t addr);
} RiderFlashOps;
bool riderLoadRecord(const RiderFlashOps *f,RiderRecord *out);
bool riderSaveRecord(const RiderFlashOps *f,const RiderRecord *record);
#endif
