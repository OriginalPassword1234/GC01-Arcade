/* GC-01 Rider v0.2: integer-only physics, geometry, deterministic generation. MIT.
 * No heap, no file I/O, no writes to measurement/config flash. */
#include "rider_core.h"
#include <string.h>
#define MAX_X 0x006fffff
static uint32_t rng(RiderGame *r){uint32_t x=r->seed; x^=x<<13;x^=x>>17;x^=x<<5;return r->seed=x?x:0x7352a93du;}
static int32_t clamp(int32_t v,int32_t lo,int32_t hi){return v<lo?lo:v>hi?hi:v;}
static int32_t absi(int32_t v){return v<0?-v:v;}
static const uint8_t sinq[17]={0,6,12,18,24,30,36,41,45,50,53,56,59,61,63,64,64};
int riderSine(uint8_t ang){uint8_t q=ang>>6,i=(ang&63)>>2;int v=(q&1)?sinq[16-i]:sinq[i];return q>=2?-v:v;}
static void notify(RiderGame *r,uint8_t ev){r->event=ev;r->eventSeq++;}
static bool emit(RiderGame *r,int w,int y,uint8_t kind,uint8_t flags){
 if(w<12||r->used>=RDR_SEGMENTS||r->generatedEnd>MAX_X-w)return false;
 RiderSegment *s=&r->segments[(r->head+r->used)%RDR_SEGMENTS];
 s->x0=r->generatedEnd;s->x1=s->x0+w;
 s->y0=r->generatedHeight;s->y1=(int16_t)clamp(y,82,204);
 s->kind=kind;s->special=flags;
 r->generatedEnd=s->x1;r->generatedHeight=s->y1;r->used++;return true;
}
const RiderSegment *riderSegmentAt(const RiderGame *r,unsigned i){return i<r->used?&r->segments[(r->head+i)%RDR_SEGMENTS]:0;}
const RiderSegment *riderFindTrack(const RiderGame *r,int32_t x){
 for(unsigned i=0;i<r->used;++i){const RiderSegment*s=riderSegmentAt(r,i);if(x>=s->x0&&x<s->x1)return s;}return 0;
}
static int movingOffset(const RiderSegment *s,uint32_t frame){
 uint32_t t=(frame/3+(uint32_t)(s->x0&31))%48;
 int val=(int)(t<24?t:48-t)-12;
 return val/2; /* within +/-6 pixels */
}
int riderTrackHeight(const RiderSegment *s,int32_t x,uint32_t frame){
 if(!s||s->x1<=s->x0)return 180;
 int32_t dx=clamp(x-s->x0,0,s->x1-s->x0);
 int y=s->y0+(int)((dx*(s->y1-s->y0))/(s->x1-s->x0));
 if(s->kind==RDR_MOVING)y+=movingOffset(s,frame);
 return y;
}
static bool recent(const RiderGame *r,int k){for(int i=0;i<4;i++)if(r->recent[i]==k+1)return true;return false;}
static void generate(RiderGame *r){
 unsigned tries=0;
 while(r->used<RDR_SEGMENTS-3 && r->generatedEnd<(r->x/RDR_FP)+530 && tries++<40){
  uint32_t u=rng(r);int kind=(int)(u%11u);if(recent(r,kind))kind=(kind+5)%11;
  int y=r->generatedHeight;int w=0;
  switch(kind){
   case 0: w=80+(int)(u%60);emit(r,w,y,RDR_ROAD,0);break;
   case 1: emit(r,55,y-20,RDR_ROAD,0);emit(r,60,y-6,RDR_ROAD,0);break;
   case 2: emit(r,65,y+22,RDR_ROAD,0);emit(r,55,y+12,RDR_ROAD,0);break;
   case 3: /* Launch + gap + safe landing: fixed small gap; optional risk remains. */
    emit(r,48,y-20,RDR_BOOST,0);emit(r,22+(int)(u%11),y-20,RDR_GAP,0);
    emit(r,92,y-2,RDR_ROAD,0);break;
   case 4: emit(r,100,y-7,RDR_BOOST,0);break;
   case 5: emit(r,45,y+20,RDR_ROAD,0);emit(r,55,y-8,RDR_ROAD,0);break;
   case 6: emit(r,95+(int)(u%25),y,RDR_ROAD,1);break;
   case 7: emit(r,116,y+3,RDR_SAW,0);break;
   case 8: /* A circular physics path with straight entrance and exit, not just art. */
    emit(r,150,y,RDR_LOOP,0);break;
   case 9: emit(r,106,y,RDR_MOVING,0);break;
   default: emit(r,114,y,RDR_WHEEL,0);break;
  }
  r->recent[r->recentAt++&3]=(uint8_t)(kind+1);
 }
}
static void retire(RiderGame *r){
 while(r->used>1&&r->segments[r->head].x1<(r->x/RDR_FP)-145){r->head=(uint8_t)((r->head+1)%RDR_SEGMENTS);r->used--;}
}
void riderInit(RiderGame *r,uint32_t seed){
 memset(r,0,sizeof(*r));r->seed=seed?seed:0x8ab39d71u;
 r->generatedHeight=184;r->x=36*RDR_FP;r->y=(184-8)*RDR_FP;
 r->phase=RDR_READY;emit(r,196,184,RDR_ROAD,0);generate(r);
}
void riderStart(RiderGame*r){if(r->phase==RDR_READY)r->phase=RDR_RUNNING;}
void riderPause(RiderGame*r){if(r->phase==RDR_RUNNING)r->phase=RDR_PAUSED;else if(r->phase==RDR_PAUSED)r->phase=RDR_RUNNING;}
static void awardDistance(RiderGame*r){
 int32_t px=r->x/RDR_FP;
 if(px>36){uint32_t d=(uint32_t)(px-36);if(d>r->distance)r->distance=d;
 uint32_t bucket=d/64;if(bucket>r->lastAwardBucket){r->score+=bucket-r->lastAwardBucket;r->lastAwardBucket=bucket;}}
}
static void crash(RiderGame*r){r->phase=RDR_CRASHED;notify(r,RDR_EVENT_CRASH);}
static void loopStep(RiderGame*r){
 /* Guided circular contact constraint: the wheel follows a physical circle.
  * The approach must have enough speed; the loop can be ridden in either
  * view without a y(x) approximation, which would be geometrically impossible. */
 int32_t step=7+r->vx/(RDR_FP*2);if(step>19)step=19;
 uint32_t progress=(uint32_t)r->loopProgress+(uint32_t)step;
 if(progress>=256){
  r->loopActive=0;r->loopProgress=0;
  r->x=(r->loopWorldX+42)*RDR_FP;
  r->y=(r->loopBaseY-8)*RDR_FP;
  r->turns=-256;r->lastGroundTurns=-256;
  r->airborne=0;r->vy=0;r->score+=3;
  notify(r,RDR_EVENT_LOOP);return;
 }
 r->loopProgress=(uint16_t)progress;
 uint8_t a=(uint8_t)progress;
 int sn=riderSine(a),cs=riderSine((uint8_t)(a+64));
 /* Start at bottom of ring. Treat car center as inner radius 24-8. */
 r->x=(r->loopWorldX-sn*24/64)*RDR_FP;
 r->y=(r->loopBaseY-24+cs*16/64)*RDR_FP;
 r->turns=-(int32_t)progress;
}
void riderStep(RiderGame *r,bool held){
 if(r->phase!=RDR_RUNNING)return;
 r->frames++;r->event=RDR_EVENT_NONE;
 if(r->loopActive){loopStep(r);awardDistance(r);return;}
 if(!r->airborne){
  if(held)r->vx+=27;else if(r->vx>0)r->vx-=r->vx>4?4:r->vx;
  r->vx=clamp(r->vx,0,8*RDR_FP);
 } else {
  if(held)r->turns+=7;
  r->vy=clamp(r->vy+38,-8*RDR_FP,9*RDR_FP);
 }
 int32_t oldPx=r->x/RDR_FP;
 if(r->x>MAX_X*RDR_FP-r->vx){crash(r);return;}
 r->x+=r->vx;r->y+=r->vy;
 retire(r);generate(r);
 int32_t px=r->x/RDR_FP;
 const RiderSegment*s=riderFindTrack(r,px);
 if(s && s->kind==RDR_LOOP && !r->airborne && r->vx>=3*RDR_FP && px>=s->x0+35 && px<s->x0+43){
  r->loopActive=1;r->loopWorldX=s->x0+40;r->loopBaseY=s->y0;
  r->loopProgress=0;loopStep(r);awardDistance(r);return;
 }
 if(!s || s->kind==RDR_GAP){
  if(!r->airborne){
   const RiderSegment*prev=riderFindTrack(r,oldPx);
   if(prev&&prev->kind!=RDR_GAP){
    int slope=(prev->y1-prev->y0);
    int width=prev->x1-prev->x0;
    r->vy=(int32_t)(((int64_t)slope*r->vx)/(width?width:1));
    if(r->vy>-420)r->vy=-420;
   }
  }
  r->airborne=1;
 } else {
  int32_t height=(riderTrackHeight(s,px,r->frames)-8)*RDR_FP;
  if(r->airborne){
   if(r->vy>=0 && r->y>=height){
    int32_t angle=r->turns&255;int32_t off=angle<128?angle:256-angle;
    if(off>32){crash(r);return;}
    int32_t rotated=absi(r->turns-r->lastGroundTurns);
    int flips=(int)(rotated/256);
    if(flips>0){if(flips>4)flips=4;
     r->combo=(uint16_t)(r->combo<4?r->combo+1:4);
     r->score+=(uint32_t)(2*flips*r->combo);
     if(r->combo>r->bestCombo)r->bestCombo=r->combo;
     notify(r,RDR_EVENT_FLIP);
    }else r->combo=0;
    r->airborne=0;r->lastGroundTurns=r->turns;r->vy=0;r->y=height;
   }
  } else {r->y=height;r->vy=0;}
  if(s->kind==RDR_BOOST && !r->airborne)r->vx=clamp(r->vx+16,0,8*RDR_FP);
  if(s->kind==RDR_SAW){
   int32_t cx=(s->x0+s->x1)/2,cy=(s->y0+s->y1)/2-28;
   if(absi(px-cx)<13 && absi(r->y/RDR_FP-cy)<15){crash(r);return;}
  }
  if(s->kind==RDR_WHEEL && !(s->special&4)){
   int32_t cx=(s->x0+s->x1)/2;
   if(absi(px-cx)<11 && !r->airborne){
    /* Red gripping wheel imparts a short impulse; deterministic contact. */
    r->vx=clamp(r->vx+RDR_FP,0,8*RDR_FP);
    r->vy=-500;r->airborne=1;
    ((RiderSegment*)s)->special|=4;
    r->score+=2;notify(r,RDR_EVENT_WHEEL);
   }
  }
 }
 awardDistance(r);
 if(s && (s->special&1) && !(s->special&2)){
  int32_t mx=(s->x0+s->x1)/2;
  if(absi(px-mx)<12 && absi(r->y/RDR_FP-(riderTrackHeight(s,mx,r->frames)-8))<26){
   ((RiderSegment*)s)->special|=2;r->diamonds++;r->score++;
   notify(r,RDR_EVENT_DIAMOND);
  }
 }
 if(r->y/RDR_FP>310 || r->y/RDR_FP<-130)crash(r);
}
