# GC-01 Rider v0.2 — experimental Rad Pro integration (SOURCE ONLY)

**DO NOT FLASH ANY GENERATED BINARY FROM THIS PACKAGE.** This is a testable source overlay, not a verified or signed GC-01 update.

Target: **FNIRSI GC-01, APM32F103RBT6 English variant**, based on Gissio Rad Pro **3.1.1**.

This package starts from the exact v0.1 Rider kernel (`GC01_Rider_Development_V01_SOURCE_ONLY.zip`) available in the project. It does **not** contain Parkour Gauntlet or the old four-game arcade program. The overlay replaces the normal `showGameMenu()` application for this one target with Rider.

## Changes since v0.1

- Added rotating-circle guided loop physics with corresponding neon circular track geometry (the original had no loop mechanics).
- Added red rotating gripping wheels, animated red saw hazards, and moving road segments with collision geometry.
- Corrected several bounded procedural-generation and long-run score-counter issues.
- Expanded native tests to 10,000 seeded runs and event/hazard coverage; added 30 full 320x240 streamed-render tests (1,800 strips checked).
- Added a 4-row RGB565 scanline renderer using only 2,560 bytes of static pixel buffering (rather than a 153,600-byte framebuffer).
- Connected Rider `resetGame` / `showGameMenu` / `updateGame` to Rad Pro 3.1.1 on the target variant.
- Uses held Up for throttle/airborne rotation; short OK pauses/resumes/retries; when paused, short Left exits and Down toggles sound. Long OK power-off remains handled by upstream Rad Pro.
- Adds optional 16 ms buzzer feedback through Rad Pro's existing scheduling, gated by the game's sound setting and alarm priority.
- Implements and loads a two-page checksummed record journal for high scores, diamonds and sound choice. **Hardware flash writes are deliberately disabled by default** pending flash/bootloader and radiation-timing validation. Compile with `-DRIDER_ENABLE_FLASH_SAVES` only after those checks.
- Preserves radiation measurement, alarms, graph and logging source modules. Firmware partition and view/keyboard integration **are modified**, therefore their behavior on hardware remains to be verified.

## Known limitations — important

1. **Not a finished, polished Rider release.** Rendering at 20 FPS is a *target* pending LCD profiling, not a verified physical frame rate. No device was flashed with this version. Realistic wheel suspension and complete physical contact for rotating platforms have not yet been validated. Loops use a deterministic guided circular-contact constraint rather than a full rigid-body motorcycle model.
2. **Not all procedurally generated transitions are formally proved reachable.** Generation uses conservative templates, bounded dimensions, deterministic seeds, and runtime fallbacks. Automated random testing does not guarantee every combination is playable.
3. **Sound and flash journal code are prepared, but saving to live flash is disabled** until we verify erase/write timing under radiation measurement and alarms.
4. `platform.io/platformio.ini` reserves 68 KiB executable application (`FIRMWARE_SIZE=0x11000`); two 1 KiB journal pages at `0x08015000` and `0x08015400`; Rad Pro settings at `0x08015800`; logging at `0x08015c00` (41 KiB). The original 16 KiB bootloader is unchanged in the proposed map. These are **proposed layout addresses, not yet hardware-tested**.
5. No ARM GCC/PlatformIO build is available locally in this environment. The GitHub workflow compiles, tests, measures binary and uploads **RAW DIAGNOSTICS ONLY**. It does not sign or publish flash-ready firmware.
6. The static codebase uses Rad Pro's power and radiation event priorities; timing tests on real GC-01 hardware are essential before use.

## Source overlay usage (GitHub Actions)

1. Upload this ZIP **unchanged** at repository root, named `GC01_Rider_V02_Source_ONLY.zip`.
2. Upload the separate workflow file `GC01_Rider_V02_Build.yml` as `.github/workflows/rider-v02-build.yml` in your repository.
3. Run **GC-01 Rider V0.2 — native tests and ARM diagnostics ONLY** from Actions > Run workflow.
4. Check all tests, the raw linked size (`<= 69,628 bytes`) and log/pointer bounds in diagnostics. The artifact is deliberately labeled **DO NOT FLASH**.
5. Independently verify SWD backups, bootloader installer behavior, migration of prior settings/logs and radiation pulse/alarm timing before preparing any installable firmware.

## Native tests

Run these after extracting the overlay over an untouched Rad Pro 3.1.1 source tree (the UI streaming test needs Rad Pro's `draw.h` and `mcu-renderer.h`):

```bash
bash tests/run_native.sh
```

## Storage protection

The Rider code is constrained to flash pages `0x08015000–0x080157ff` for journal records. Firmware CRC stays at the end of the 68 KiB application region. Static assertions verify these boundaries, including Rad Pro settings and history. `RIDER_ENABLE_FLASH_SAVES` is **not enabled** in the workflow.

The existing GC-01 bootloader and saved radiation calibration must not be modified or erased. Readout protection must **not** be disabled just to perform a backup, because that may mass-erase protected flash. Always prepare a recovery image through authorized, validated means.

## Technical origin

The previous v0.1 kernel, Rad Pro 3.1.1 source and archived earlier GC-01 arcade modification were inspected locally. The project is an original C game inspired by the classic one-button neon motorcycle stunt genre; it does not include game assets from third parties.
