/* Renderer-regression guard for Rider-like bright pink loop and emerald gems.
 * Counts actual RGB565 output pixels; does not compare simulated screenshots. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static int bright_loop,green_bowl;
static int mode;
static void pixel_sink(int top,int rows,const uint16_t *p,void *unused)
{
    (void)unused;
    assert(rows==3);
    for(int r=0;r<rows;++r)for(int x=0;x<320;++x){
        const int y=top+r;
        const uint16_t c=p[r*320+x];
        const int red=(int)((c>>11)&31u)*255/31;
        const int green=(int)((c>>5)&63u)*255/63;
        const int blue=(int)(c&31u)*255/31;
        if(mode==1 && y>=50 && y<155 && x>=25 && x<200 && red>200 && green>150 && blue>170) ++bright_loop;
        if(mode==2 && y>=120 && y<230 && x>=40 && x<240 && green>205 && red<180 && blue>70) ++green_bowl;
    }
}
static void prepare_special(RiderState *s,uint8_t templ,int ticks)
{
    rider_init(s,0x2727u);s->theme=0;
    s->track[0].template_id=templ;
    if(templ==28u){s->track[0].flags|=1u;s->track[0].gem_mask=7u;}
    s->phase=RIDER_RUNNING;
    s->vx=4*RIDER_Q;
    s->x=65*RIDER_Q;
    s->y=161*RIDER_Q;
    s->grounded=1;
    for(int i=0;i<ticks;++i)rider_step(s,true);
    s->camera_x=-5*RIDER_Q;
    s->camera_y=-4*RIDER_Q;
}
int main(void)
{
    RiderState s;
    /* Use the same deterministic loop entry as the preview generator. */
    rider_init(&s,0x4444u);s.theme=0;
    s.track[0].template_id=16u;
    s.phase=RIDER_RUNNING;
    s.vx=4*RIDER_Q;
    s.x=65*RIDER_Q;
    s.y=161*RIDER_Q;
    s.grounded=1;
    for(int t=0;t<50;++t){rider_step(&s,true);if(s.looping&&s.loop_t>1300u)break;}
    assert(s.looping);
    s.camera_x=-6*RIDER_Q;
    s.camera_y=-4*RIDER_Q;
    mode=1;rider_render(&s,NULL,0,pixel_sink,NULL);
    assert(bright_loop>650); /* narrower core than v0.9; detailed width test in v1.3 */
    prepare_special(&s,28u,20);
    mode=2;rider_render(&s,NULL,0,pixel_sink,NULL);
    assert(green_bowl>100); /* smaller emerald diamonds in blue theme */
    printf("v0.9 actual renderer: %d bright loop pixels, %d green valley pixels PASS\n",bright_loop,green_bowl);
}
