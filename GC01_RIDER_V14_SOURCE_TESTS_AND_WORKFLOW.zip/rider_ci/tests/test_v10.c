#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>

static uint32_t checksum;
static void capture(int top,int rows,const uint16_t *pixels,void *ctx)
{
    (void)ctx;
    assert(top%3==0 && rows==3);
    for(int i=0;i<rows*320;++i)
        checksum=checksum*16777619u ^ pixels[i];
}

static void test_authored_approaches(void)
{
    uint32_t flat=0,total=0;
    for(uint32_t seed=1;seed<=100u;++seed){
        RiderState s; rider_init(&s,seed);
        for(uint32_t j=1;j<RIDER_TRACK_SLOTS;++j){
            uint8_t id=s.track[j].template_id;
            if(id==0u || id==35u)flat++;
            /* The first difficulty pool must not show the infamous
             * little oscillating two-hill templates or the deep bowl. */
            assert(id!=3u && id!=10u && id!=20u && id!=23u && id!=28u);
            total++;
        }
    }
    assert(flat*100u>=10u*total && flat*100u<=35u*total);
    printf("v1.1 varied approaches: %u/%u flat/smooth early pieces\n",flat,total);
}
static void test_controlled_air_rotation(void)
{
    RiderState s;rider_init(&s,19u);
    s.phase=RIDER_RUNNING;
    s.grounded=0;
    s.x=70*RIDER_Q;
    s.y=-200*RIDER_Q;
    s.vx=0;s.vy=0;
    int32_t last_angle=s.angle;
    for(int i=0;i<30;++i){
        rider_step(&s,true);
        assert(s.angular_speed<=70 && s.angular_speed>=0);
        assert(s.angle>=last_angle);
        last_angle=s.angle;
    }
    int32_t released=s.angular_speed;
    for(int i=0;i<12;++i)rider_step(&s,false);
    assert(s.angular_speed<released/4);
    /* A long enough deliberate hold still makes a stunt. */
    assert(s.air_rotation>800);
}
static void test_open_loop_release(void)
{
    RiderState s;rider_init(&s,0x1111u);
    s.track[0].template_id=46u;
    s.track[0].flags=0u;
    s.phase=RIDER_RUNNING;
    s.vx=3*RIDER_Q;
    s.x=65*RIDER_Q;
    s.y=161*RIDER_Q;
    s.grounded=1u;
    int entered=0,exited=0,miny=100000;
    int32_t prev_x=s.x;
    int reversed=0;
    for(int i=0;i<260;++i){
        rider_step(&s,true);
        assert(s.phase!=RIDER_CRASHED);
        if(s.looping){
            entered=1;
            if(s.y<miny)miny=s.y;
            if(s.x<prev_x)reversed=1;
        }
        if(entered && !s.looping){exited=1;break;}
        prev_x=s.x;
    }
    assert(entered && exited && reversed);
    assert(miny<100*RIDER_Q);
    assert(!s.grounded && s.y<145*RIDER_Q);
    int32_t x0,y0,x1,y1;
    assert(rider_special_point_q(0,46u,0,&x0,&y0));
    assert(rider_special_point_q(0,46u,4096u,&x1,&y1));
    assert(x1>x0 && y1<y0);
}
static void test_subframe_scrolling(void)
{
    RiderState s;rider_init(&s,17u);
    s.phase=RIDER_RUNNING;
    RiderState p=s;
    for(int i=0;i<125;++i){
        p=s;
        rider_step(&s,true);
        if(s.phase==RIDER_CRASHED)break;
    }
    /* Render interpolation is visual only and must never modify physics. */
    RiderState snapshot=s;
    checksum=2166136261u;
    rider_render(&s,&p,0u,capture,NULL);
    uint32_t before=checksum;
    checksum=2166136261u;
    rider_render(&s,&p,255u,capture,NULL);
    uint32_t after=checksum;
    assert(s.x==snapshot.x && s.y==snapshot.y &&
           s.camera_x==snapshot.camera_x && s.random_state==snapshot.random_state);
    /* A camera movement between physics ticks should have visible
     * in-between states, not repeat the previous delayed frame. */
    assert(before!=after);
}
int main(void)
{
    test_authored_approaches();
    test_controlled_air_rotation();
    test_open_loop_release();
    test_subframe_scrolling();
    puts("v1.0: track distribution, air control, open-loop flight, fractional scrolling PASS");
}
