/* New tests of the actual fixed-point core and RGB565 renderer. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>

static void elevation_and_seams(void)
{
    unsigned shifted=0;
    for(unsigned seed=1;seed<=100;++seed){
        RiderState s;rider_init(&s,seed);
        for(unsigned n=1;n<RIDER_TRACK_SLOTS;++n){
            int32_t a,b;
            assert(rider_surface_q(&s,n*256*256-1,&a));
            assert(rider_surface_q(&s,n*256*256,&b));
            assert(a-b<RIDER_Q && b-a<RIDER_Q);
            if(s.track[n].start_y!=166)++shifted;
            assert(s.track[n].start_y>=108 && s.track[n].start_y<=214);
        }
    }
    assert(shifted>500);
    printf("v1.2 elevation: %u shifted pieces across 100 starts, all seams continuous\n",shifted);
}
static void special_path_and_gems(void)
{
    const uint8_t kinds[]={16,27,28,46,47};
    for(unsigned i=0;i<sizeof(kinds);++i){
        RiderState s;rider_init(&s,7);
        RiderPiece *p=&s.track[0];
        p->template_id=kinds[i];p->flags=1;p->gem_mask=7;p->start_y=208;
        int32_t ax,ay,bx,by;
        assert(rider_special_point_q(0,kinds[i],2048,&ax,&ay));
        assert(rider_track_special_q(&s,0,kinds[i],2048,&bx,&by));
        assert(ax==bx && by-ay==42*RIDER_Q);
        for(unsigned j=0;j<3;++j){
            assert(rider_piece_gem_q(&s,0,j,&ax,&ay));
            p->start_y=166;
            assert(rider_piece_gem_q(&s,0,j,&bx,&by));
            assert(ax==bx && ay-by==42*RIDER_Q);
            p->start_y=208;
        }
        assert(rider_piece_gem_q(&s,0,2,&ax,&ay));
        p->gem_mask=4;
        assert(rider_piece_gem_q(&s,0,2,&bx,&by));
        assert(ax==bx && ay==by);
    }
    puts("v1.2 translated special paths and stable diamond coordinates PASS");
}
static void release_does_not_force_loop(void)
{
    RiderState s;rider_init(&s,1);
    s.track[0].template_id=16;s.track[0].flags=0;
    s.phase=RIDER_RUNNING;s.looping=1;s.loop_piece=0;s.loop_t=900;
    s.vx=RIDER_Q/2;s.grounded=1;
    rider_step(&s,false);
    assert(s.phase==RIDER_CRASHED); /* slow upward traversal cannot be motor-forced */
    puts("v1.2 slow released-loop failure PASS (guided approximation)");
}
static unsigned bright[2];
static int target_x[2],target_y[2];
static void pixel_sink(int top,int rows,const uint16_t *p,void *ctx)
{
    (void)ctx;
    for(int y=0;y<rows;++y)for(int x=0;x<320;++x){
        unsigned c=p[y*320+x];
        unsigned r=(c>>11)&31u,g=(c>>5)&63u,b=c&31u;
        for(int j=0;j<2;++j)if(x>=target_x[j]-5&&x<=target_x[j]+5&&
          top+y>=target_y[j]-5&&top+y<=target_y[j]+5&&r>24&&g>40&&b>22)++bright[j];
    }
}
static void both_paths_drawn(void)
{
    RiderState s;rider_init(&s,2);
    s.camera_x=0;s.camera_y=0;s.track[0].template_id=16;s.track[0].start_y=166;
    s.track[1].template_id=47;s.track[1].start_y=205;
    s.track[0].flags=s.track[1].flags=0;
    for(int j=0;j<2;++j){
        int32_t x,y;
        assert(rider_track_special_q(&s,j,s.track[j].template_id,2048,&x,&y));
        target_x[j]=x/384;target_y[j]=y/384;
    }
    rider_render(&s,0,0,pixel_sink,0);
    assert(bright[0]>3 && bright[1]>3);
    printf("v1.2 both visible 2D paths rendered: %u / %u core pixels\n",bright[0],bright[1]);
}
int main(void){elevation_and_seams();special_path_and_gems();release_does_not_force_loop();both_paths_drawn();return 0;}
