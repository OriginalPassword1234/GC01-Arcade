/* Actual procedural playthrough snapshots: no state or camera editing. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static FILE *out;
static void sink(int y,int rows,const uint16_t *p,void *ctx){(void)y;(void)ctx;for(int i=0;i<rows*320;i++){unsigned c=p[i];unsigned char rgb[]={((c>>11)&31)*255/31,((c>>5)&63)*255/63,(c&31)*255/31};assert(fwrite(rgb,1,3,out)==3);}}
int main(int argc,char **argv){
 if(argc!=3)return 2;
 const char *names[]={"jump","crest","arc","gap","saw","valley","wall","score","risegap","highgap","spikes","v"};
 unsigned mode=0;while(mode<12&&strcmp(argv[1],names[mode]))mode++;if(mode==12)return 2;
 for(unsigned seed=1;seed<=600;seed++){
  RiderState s,prev;rider_init(&s,seed);
  for(unsigned t=0;t<11000;t++){
   prev=s;rider_step(&s,s.grounded||((mode==7||mode>=8)&&s.score==0&&s.airborne_ticks<55));
   if(s.phase==RIDER_CRASHED)break;
   unsigned pn=(unsigned)s.x/(256*RIDER_Q),k=s.track[pn%12].template_id,l=(unsigned)(s.x/RIDER_Q)%256;
   int yes=0;
   switch(mode){
    case 0: yes=!s.grounded&&s.airborne_ticks>=25&&l>=40&&l<=210&&pn>=2&&pn<8;break;
    case 1: yes=s.looping&&k==52&&s.loop_t>1350&&s.loop_t<1700;break;
    case 2: yes=k==54&&l>=95&&l<=120;break;
    case 3: yes=k==53&&l>=135&&l<=160&&!s.grounded;break;
    case 4: yes=k==9&&l>=80&&l<=110;break;
    case 5: yes=(k==49||k==51)&&l>=100&&l<=125&&pn>12;break;
    case 6: yes=k==27&&s.looping&&s.loop_t>1400&&s.loop_t<2200;break;
    case 7: yes=s.score>=1&&s.grounded&&pn>=4&&l>=80&&l<=180;break;
    case 8: yes=k==55&&l>=118&&l<=145&&!s.grounded;break;
    case 9: yes=k==56&&l>=128&&l<=156&&!s.grounded;break;
    case 10: yes=k==13&&l>=90&&l<=125;break;
    case 11: yes=k==49&&l>=118&&l<=136;break;
   }
   if(!yes)continue;
   out=fopen(argv[2],"wb");assert(out);fprintf(out,"P6\n320 240\n255\n");rider_render(&s,&prev,255,sink,NULL);fclose(out);
   printf("%s seed=%u tick=%u piece=%u template=%u local=%u score=%d diamonds=%d guided=%u camera=(%d,%d)\n",argv[1],seed,t+1,pn,k,l,s.score,s.diamonds,s.looping,s.camera_x,s.camera_y);return 0;
  }
 }
 fprintf(stderr,"No live frame found for %s\n",argv[1]);return 1;
}
