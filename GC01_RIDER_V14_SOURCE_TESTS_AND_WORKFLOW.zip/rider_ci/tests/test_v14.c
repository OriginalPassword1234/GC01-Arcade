/* v1.4: fixed palette, real gap traversal, new geometry and shared spikes.
 * All measurements use the actual game core and RGB565 renderer. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static uint16_t frame[320*240]; /* host test only; never linked into firmware */
static void capture(int top,int rows,const uint16_t *p,void *ctx){
    (void)ctx;memcpy(frame+top*320,p,(size_t)rows*320*sizeof(*p));
}
static uint32_t checksum(void){
    uint32_t h=2166136261u;
    for(unsigned i=0;i<320*240;i++)h=(h^frame[i])*16777619u;
    return h;
}
static void fixed_palette(void){
    RiderState s;rider_init(&s,1);
    s.track[0].template_id=52;s.track[0].flags=1;s.track[0].gem_mask=7;
    s.camera_x=0;s.camera_y=-60*RIDER_Q;
    rider_render(&s,0,0,capture,0);uint32_t h=checksum();
    const uint8_t themes[]={1,2,3,127,255};
    for(unsigned i=0;i<sizeof(themes);++i){s.theme=themes[i];rider_render(&s,0,0,capture,0);assert(checksum()==h);}
    for(unsigned seed=1;seed<=1000;++seed){rider_init(&s,seed);assert(s.theme==0);rider_restart(&s);assert(s.theme==0);}
    puts("v1.4 fixed single palette: all pixels identical across legacy theme values; 1000 starts/restarts PASS");
}
static void gap_geometry(void){
    RiderState s;rider_init(&s,7);s.track[0].start_y=204;s.track[0].flags=1;s.track[0].gem_mask=7;
    for(unsigned k=55;k<=56;k++){
        s.track[0].template_id=(uint8_t)k;
        int l=k==55?115:119,r=k==55?149:159;
        int32_t a,b,c,d;
        assert(rider_surface_q(&s,(l-12)*RIDER_Q,&a));
        assert(rider_surface_q(&s,l*RIDER_Q,&b));assert(b<a);
        assert(!rider_surface_q(&s,132*RIDER_Q,&a));
        assert(rider_surface_q(&s,r*RIDER_Q,&c));
        assert(rider_surface_q(&s,(r+12)*RIDER_Q,&d));
        if(k==55){assert(d<c);assert(c<b);}else assert(d>c);
        for(unsigned i=0;i<3;i++){
            assert(rider_piece_gem_q(&s,0,i,&a,&d));
            assert(a>l*RIDER_Q&&a<r*RIDER_Q);
            assert(d<b+(c-b)*(a-l*RIDER_Q)/((r-l)*RIDER_Q));
        }
        s.camera_x=s.camera_y=0;s.x=20*RIDER_Q;s.y=195*RIDER_Q;
        rider_render(&s,0,0,capture,0);
        /* No bright bridge across gap center (gems excluded by y). */
        int mid=(l+r)/3;int chord=(b+c)/768;unsigned white=0;
        for(int y=chord-5;y<=chord+5;y++){
            uint16_t p=frame[y*320+mid];if((p>>11)>22 && (p&31)>23)white++;
        }
        assert(white==0);
    }
    puts("v1.4 two new rail forms: actual gaps, rising/descending landings, aerial gems, no drawn bridge PASS");
}
static void live_crossing(void){
    RiderState s;rider_init(&s,1);
    unsigned launched=0,relative_landing=0,high_gap=0,cleared=0;
    for(unsigned t=0;t<2200;t++){
        RiderState prev=s;
        rider_step(&s,s.grounded||(s.score==0&&s.airborne_ticks<55));
        assert(s.phase!=RIDER_CRASHED);
        unsigned pn=(unsigned)s.x/(256*RIDER_Q),k=s.track[pn%12].template_id;
        unsigned local=(unsigned)(s.x/RIDER_Q)%256;
        if(k==55&&local>=116&&local<149&&!s.grounded&&s.vy<0)launched++;
        if(k==55&&local>=149&&local<220&&!prev.grounded&&prev.vy<0&&s.grounded)relative_landing++;
        if(k==56&&local>=120&&local<159&&!s.grounded)high_gap++;
        if(high_gap&&pn>=15&&s.grounded)cleared++;
        if(launched&&relative_landing&&high_gap&&cleared)break;
    }
    assert(launched&&relative_landing&&high_gap&&cleared);
    printf("v1.4 unmodified generated run: ascent launch ticks=%u, upward relative landing=%u, high gap airborne=%u, cleared=%u PASS\n",launched,relative_landing,high_gap,cleared);
}
static void spikes(void){
    assert(rider_spike_profile_q(0)==6*RIDER_Q);
    assert(rider_spike_profile_q(5*RIDER_Q)==0);
    assert(rider_spike_profile_q(10*RIDER_Q)==6*RIDER_Q);
    assert(rider_spike_profile_q(15*RIDER_Q)==0);
    puts("v1.4 spike triangle profile shared by collision and rasterizer PASS");
}
int main(void){fixed_palette();gap_geometry();live_crossing();spikes();return 0;}
