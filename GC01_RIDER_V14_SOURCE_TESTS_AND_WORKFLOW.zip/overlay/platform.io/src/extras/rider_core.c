/* Independent Rider-inspired simulation prototype v1.0.
 * Builds on v0.4 with more section variety, saw/boost piece metadata,
 * small gaps, subpixel track sampling and compact hazard collision checks.
 * Still NOT a Box2D/LiquidFun port and still not full original parity. */
#include "rider_core.h"
#include <limits.h>
#include <string.h>

#define PIECE_FLAG_GEM   0x01u
#define PIECE_FLAG_SAW   0x02u
#define PIECE_FLAG_BOOST 0x04u
#define PIECE_FLAG_SPIKES 0x08u

/* Compact synthesized geometry. Template 16 is a real non-heightfield
 * loop PATH, guided by the same model used to draw it. Not original game data. */
static const int8_t heights[][RIDER_TRACK_NODES] = {
  {0, 0, 0, 0, 0, 0, 0, 0, 0},
  {0, 0, -5, -20, -29, -18, -4, 0, 0},
  {0, 0, 8, 24, 30, 17, 3, 0, 0},
  {0, -4, -17, -9, 5, 0, -12, -3, 0},
  {0, 0, -9, -28, -16, -3, 9, 0, 0},
  {0, 0, 6, 18, 8, -14, -24, -5, 0},
  {0, 0, -8, -22, -34, -17, -7, 0, 0},
  {0, 0, 5, 14, 24, 10, -8, 0, 0},
  {0, 0, -12, -30, -42, -24, -9, 0, 0},
  {0, 0, 10, 28, 38, 20, 5, 0, 0},
  {0, -2, -10, -5, 12, 3, -14, -5, 0},
  {0, 0, -4, -12, -18, -10, -4, 0, 0},
  {0, 0, -2, -8, -10, -7, -2, 0, 0},
  {0, -6, -21, -32, -35, 12, 22, 8, 0}, /* split ramp and descending landing */
  {0, 0, -10, -29, -43, -8, 12, 1, 0}, /* tall ejector and drop */
  {0, -5, -14, -25, -34, 2, 17, 5, 0}, /* lip to landing gap */
  {0, 0, 0, 0, 0, 0, 0, 0, 0},  /* closed loop */
  {0, 0, -8, -16, -14, -8, -3, 0, 0}, /* gentle two-step rise */
  {0, 0, 9, 17, 10, -10, -17, -4, 0}, /* shallow valley and up */
  {0, 0, -8, -30, -40, -32, -8, 0, 0}, /* long flight ramp */
  {0, 0, 4, 12, 7, 0, -4, 0, 0}, /* small rolling dip */
  {0, -4, -15, -28, -8, 18, 8, -3, 0}, /* cliff and landing */
  {0, 0, -4, -11, -18, -5, 4, 0, 0}, /* undulating boost */
  {0, -3, -15, -20, -6, -23, -11, -3, 0}, /* twin crests */
  {0, 0, 5, 16, 25, -10, -24, -7, 0}, /* downhill to ejector */
  {0, -2, -9, -22, -36, -22, -8, 0, 0}, /* steep saw approach */
  {0, 0, -8, -16, 3, 15, 4, 0, 0}, /* descending landing */
  {0,0,0,0,0,0,0,0,0},             /* 27: true rising wall */
  {0,0,0,0,0,0,0,0,0},             /* 28: true deep bowl */
  {0,0,-18,-45,-58,-31,-5,0,0},  /* 29: tall ejector */
  {0,3,16,27,31,17,-8,0,0},      /* 30: smooth downhill valley */
  {0,-3,-12,-26,-40,-31,-15,-3,0}, /* 31: long approach and launch */
  {0,0,0,-11,-30,-35,-17,-1,0},  /* 32: late lip */
  {0,0,6,23,36,15,0,0,0},        /* 33: deep valley */
  {0,-1,-8,-18,-31,-28,-6,0,0},  /* 34: rising arch */
  {0,0,0,0,0,0,0,0,0},            /* 35: long flat run */
  {0,0,-3,-15,-28,-10,9,0,0},    /* 36: tall leap */
  {0,0,10,22,13,-12,-29,-5,0},  /* 37: valley into ramp */
  {0,-3,-10,-12,0,8,15,4,0},     /* 38: undulating approach */
  {0,0,0,-7,-16,-25,-15,-3,0},   /* 39: boost rise */
  {0,0,0,0,0,0,0,0,0},           /* 40: reserved flat */
  {0,0,0,-10,-30,-54,-38,-8,0},/* 41: clean rising ramp (open lip) */
  {0,1,9,24,34,29,15,4,0},      /* 42: descending runout */
  {0,0,0,-4,-25,-58,-40,-8,0},/* 43: longer high launch */
  {0,-2,-9,-20,-33,-39,-28,-9,0},/* 44: progressive incline */
  {0,0,0,0,0,0,0,0,0},            /* 45: reserved flat */
  {0,0,0,0,0,0,0,0,0},            /* 46: open loop, 2D path */
  {0,0,0,0,0,0,0,0,0},            /* 47: compact circular micro-loop */
  {0,0,0,0,0,0,0,0,0},            /* 48: legacy oscillating detached bridge */
  {0,3,25,57,89,57,25,3,0},      /* 49: steep V valley, reference 70359 */
  {0,-3,-23,-55,-87,-55,-23,-3,0}, /* 50: angular peak, reference 71004 */
  {0,8,34,65,81,69,39,12,0},      /* 51: asymmetric broad U, ref 71012 */
  {0,0,0,0,0,0,0,0,0},            /* 52: loop integrated into an elevated crest, ref 71002 */
  {0,-4,-23,-48,-75,26,37,19,0},  /* 53: split rising lip and lower detached landing, ref 70980 */
  {0,-8,-30,-55,-70,-35,-10,0,0}, /* 54: climb beneath independent open arc, ref 71002 */
  {0,0,0,0,0,0,0,0,0}, /* 55: two rising lips on a sustained incline, reference 70353 */
  {0,0,-8,-38,-78,-69,-34,-8,0}  /* 56: steep launch, separated curved landing, ref 71040 */
};
#define N_TEMPLATES ((uint32_t)(sizeof(heights)/sizeof(heights[0])))
static const int16_t sine256[256] = {
       0,    6,   13,   19,   25,   31,   38,   44,   50,   56,   62,   68,   74,   80,   86,   92,
      98,  104,  109,  115,  121,  126,  132,  137,  142,  147,  152,  157,  162,  167,  172,  177,
     181,  185,  190,  194,  198,  202,  206,  209,  213,  216,  220,  223,  226,  229,  231,  234,
     237,  239,  241,  243,  245,  247,  248,  250,  251,  252,  253,  254,  255,  255,  256,  256,
     256,  256,  256,  255,  255,  254,  253,  252,  251,  250,  248,  247,  245,  243,  241,  239,
     237,  234,  231,  229,  226,  223,  220,  216,  213,  209,  206,  202,  198,  194,  190,  185,
     181,  177,  172,  167,  162,  157,  152,  147,  142,  137,  132,  126,  121,  115,  109,  104,
      98,   92,   86,   80,   74,   68,   62,   56,   50,   44,   38,   31,   25,   19,   13,    6,
       0,   -6,  -13,  -19,  -25,  -31,  -38,  -44,  -50,  -56,  -62,  -68,  -74,  -80,  -86,  -92,
     -98, -104, -109, -115, -121, -126, -132, -137, -142, -147, -152, -157, -162, -167, -172, -177,
    -181, -185, -190, -194, -198, -202, -206, -209, -213, -216, -220, -223, -226, -229, -231, -234,
    -237, -239, -241, -243, -245, -247, -248, -250, -251, -252, -253, -254, -255, -255, -256, -256,
    -256, -256, -256, -255, -255, -254, -253, -252, -251, -250, -248, -247, -245, -243, -241, -239,
    -237, -234, -231, -229, -226, -223, -220, -216, -213, -209, -206, -202, -198, -194, -190, -185,
    -181, -177, -172, -167, -162, -157, -152, -147, -142, -137, -132, -126, -121, -115, -109, -104,
     -98,  -92,  -86,  -80,  -74,  -68,  -62,  -56,  -50,  -44,  -38,  -31,  -25,  -19,  -13,   -6,
};
int16_t rider_sin256(uint8_t angle_index) { return sine256[angle_index]; }
int16_t rider_sin4096(int32_t angle)
{
    uint32_t a=(uint32_t)angle & (RIDER_ANGLE_TURN-1u);
    uint32_t k=a>>4, f=a&15u;
    int32_t v0=sine256[k], v1=sine256[(k+1u)&255u];
    return (int16_t)(v0+(v1-v0)*(int32_t)f/16);
}
/* A full, continuously curved loop with long shallow approach/exit,
 * whose rail is not a heightfield. The large circle follows the visual
 * proportions in the reference frames and retains a rounded entry tangent.
 * Coordinates Q8; no dynamic allocation, no float operations in firmware. */
bool rider_loop_point_q(uint32_t pn, uint16_t t, int32_t *xq, int32_t *yq)
{
    if (t>RIDER_ANGLE_TURN || pn>25000u || !xq || !yq) return false;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+68u)*RIDER_Q +
        ((int32_t)88*RIDER_Q*t)/RIDER_ANGLE_TURN + 78*rider_sin4096(t);
    *yq=166*RIDER_Q-62*(RIDER_Q-rider_sin4096((int32_t)t+1024));
    return true;
}
/* Flash-only two-dimensional rail templates: the vertical wall and deep U
 * cannot be represented by a 1D heightfield. The control points are compact,
 * and evaluated only for the visible path or while traversing one structure.
 * These are hand-recreated from gameplay references, not original game data. */
/* Small closed loop attached to a short approach and runout. Reuses the
 * original fixed-point sine LUT; no vertex heap, extra state or float. */
static bool rider_micro_loop_point_q(uint32_t pn,uint16_t t,int32_t *xq,int32_t *yq)
{
    if(t>4096u || pn>25000u || !xq || !yq)return false;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+68u)*RIDER_Q+
         ((int32_t)65*RIDER_Q*t)/4096+42*rider_sin4096(t);
    *yq=166*RIDER_Q-32*(RIDER_Q-rider_sin4096((int32_t)t+1024));
    return true;
}
static const int16_t wall_xy[][2] = {
    {70,166},{93,164},{113,147},{125,112},{127,78},{140,54},{165,45}
};
static const int16_t bowl_xy[][2] = {
    {70,166},{89,183},{103,206},{126,220},{148,220},{173,194},{198,166}
};
/* Open C-shaped curved rail. It launches the bike into the next platform
 * after the lip rather than pretending to be a closed circle or a hill. */
static const int16_t open_xy[][2] = {
    {70,166},{85,166},{102,153},{112,131},{110,107},{96,86},
    {75,81},{55,92},{49,114},{65,133},{92,134},{119,124},{150,122}
};
bool rider_special_point_q(uint32_t pn,uint8_t kind,uint16_t t,int32_t *xq,int32_t *yq)
{
    if(!xq||!yq||t>4096||pn>25000u)return false;
    if(kind==16u)return rider_loop_point_q(pn,t,xq,yq);
    if(kind==52u){
        if(!rider_loop_point_q(pn,t,xq,yq))return false;
        *yq-=32*RIDER_Q;
        return true;
    }
    if(kind==47u)return rider_micro_loop_point_q(pn,t,xq,yq);
    if(kind==54u){
        /* Separate open arc over the crest. Traversal starts at the lower
         * right, then wraps around the top and exits at the lower left.
         * Unlike a closed track loop, the lower opening is not connected
         * to the continuous heightfield under it. */
        int32_t a=448-(int32_t)t*2944/4096;
        *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+130u)*RIDER_Q+48*rider_sin4096(a+1024);
        *yq=50*RIDER_Q+45*rider_sin4096(a);
        return true;
    }
    const int16_t (*points)[2]=NULL;
    uint32_t segments=6u;
    if(kind==27u)points=wall_xy;
    if(kind==28u)points=bowl_xy;
    if(kind==46u){points=open_xy;segments=12u;}
    if(!points)return false;
    uint32_t step=(uint32_t)t*segments, k=step/4096u;
    if(k>=segments)k=segments-1u;
    uint32_t frac=step-k*4096u;
    /* Cubic Hermite between authored 2D knots. Straight joining lines
     * made the old open arcs look hexagonal; this shares the exact rail
     * path with collision and uses integer-only fixed point. */
    const int32_t u=(int32_t)(frac>>4); /* [0,256] */
    const int32_t u2=u*u/256, u3=u2*u/256;
    const int32_t h00=2*u3-3*u2+256;
    const int32_t h01=-2*u3+3*u2;
    const int32_t h10=u3-2*u2+u;
    const int32_t h11=u3-u2;
    int32_t mx0=(points[k+1][0]-points[k? k-1u: k][0])/2;
    int32_t my0=(points[k+1][1]-points[k? k-1u: k][1])/2;
    int32_t mx1=(points[(k+2u<=segments)? k+2u:k+1u][0]-points[k][0])/2;
    int32_t my1=(points[(k+2u<=segments)? k+2u:k+1u][1]-points[k][1])/2;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q +
        h00*points[k][0]+h01*points[k+1][0]+h10*mx0+h11*mx1;
    *yq=h00*points[k][1]+h01*points[k+1][1]+h10*my0+h11*my1;
    return true;
}
bool rider_track_special_q(const RiderState *s,uint32_t pn,uint8_t kind,uint16_t t,int32_t *xq,int32_t *yq)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(p->number!=pn || pn>=s->next_piece || p->template_id!=kind ||
       !rider_special_point_q(pn,kind,t,xq,yq))return false;
    *yq+=((int32_t)p->start_y-166)*RIDER_Q;
    return true;
}
static bool special_piece(uint8_t k){return k==16u||k==27u||k==28u||k==46u||k==47u||k==52u||k==54u;}
static int32_t angle_from_vector(int32_t dx,int32_t dy)
{
    /* atan2 approximation in 4096 turn units, max error a few degrees. */
    int32_t ax=dx<0?-dx:dx, ay=dy<0?-dy:dy;
    if(!ax && !ay) return 0;
    int32_t oct=(ax>=ay)? (ay*512)/(ax?ax:1) :
                              1024-(ax*512)/ay;
    if(dx<0) oct=2048-oct;
    if(dy<0) oct=-oct;
    return oct;
}

static uint32_t next_random(RiderState *s)
{
    uint32_t x = s->random_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    s->random_state = x;
    return x;
}

static int32_t clamp_i32(int32_t a,int32_t lo,int32_t hi)
{
    return a<lo ? lo : a>hi ? hi : a;
}

/* Each three-piece group is an intentionally designed challenge:
 * an approach, a launch/obstacle, then a suitable runout.  The long flat
 * streaks in v1.0 made almost every run boring and suppressed the score
 * progression needed to unlock later stages.  Difficulty is now also
 * unlocked by distance, so runs with no scored flips don't get stuck
 * in the initial pool forever.  All section data stays in FLASH. */
static uint8_t choose_template(RiderState *s, uint32_t pn)
{
    static const uint8_t novice_challenges[]={
        29,36,19,41,31,43,34,14,39,36,29,19,41,43
    };
    static const uint8_t mid_challenges[]={
        29,36,41,31,43,39,52,27,46,47,14,9,19,34,13,55,56,9
    };
    static const uint8_t expert_challenges[]={
        29,36,41,43,52,27,46,47,13,9,28,39,14,19,34,44,53,54,55,56
    };
    static const uint8_t recoveries[]={0,35,42,26,51,44,30,42};
    /* Intentionally predictable first few structures.  The first ramp
     * teaches a controlled jump; the following runout allows landing. */
    if(pn==1u) return 31u;
    if(pn==2u) return 29u;
    if(pn==3u) return 42u;
    if(pn==4u) return 39u; /* boost in the first ten seconds */
    if(pn==5u) return 36u;
    if(pn==6u) return 51u;
    if(pn==7u) return 35u;
    if(pn==8u) return 52u; /* recognizable closed-loop section early */
    /* Legacy oscillating bridge is no longer selected in endless mode. */
    /* Two to three distinct structures per eight pieces, with breathing
     * room, but never an indefinite chain of empty 256px straights. */
    if(pn%3u==0u) {
        uint8_t r=recoveries[next_random(s)%sizeof(recoveries)];
        if(pn>=15u && (r==26u || r==30u))r=(r==26u?49u:51u);
        return r;
    }
    if(pn%3u==1u) {
        static const uint8_t approaches[]={0,35,42,44,34,31,49,26};
        uint8_t a=approaches[next_random(s)%sizeof(approaches)];
        if(pn>=16u && a==31u)a=50u;
        return a;
    }
    uint32_t progression=pn*2u;
    if(s->score>=75 || progression>=75)progression=75;
    else if(s->score>=40 || progression>=40)progression=40;
    else if(s->score>=15 || progression>=15)progression=15;
    else progression=0;
    const uint8_t *pool=novice_challenges;
    uint32_t len=sizeof(novice_challenges);
    if(progression>=40){pool=expert_challenges;len=sizeof(expert_challenges);}
    else if(progression>=15){pool=mid_challenges;len=sizeof(mid_challenges);}
    uint8_t chosen=pool[next_random(s)%len];
    if(chosen==s->last_template)chosen=pool[next_random(s)%len];
    if(special_piece(chosen) && s->last_template!=0u && s->last_template!=35u && chosen!=52u && chosen!=54u)chosen=42u;
    if(chosen==25u && s->last_template==50u)chosen=42u;
    if(chosen==9u && (s->last_template==26u || s->last_template==44u || s->last_template==31u || s->last_template==34u))chosen=51u;
    return chosen;
}

/* Bounded continuous elevation changes on ordinary slopes. No extra state.
 * Start/end tangents of the additional smoothstep are zero. */
static int32_t piece_end_delta(uint8_t kind,int32_t start_y)
{
    int32_t d=0;
    if(kind==42u || kind==51u) d=32;
    if(kind==30u) d=24;
    if(kind==44u || kind==34u) d=-32;
    if(kind==55u) d=-72;
    return clamp_i32(start_y+d,108,214)-start_y;
}
static void append_piece(RiderState *s)
{
    uint32_t n = s->next_piece++;
    RiderPiece *p = &s->track[n % RIDER_TRACK_SLOTS];
    uint8_t pattern = 0;
    if (n != 0) pattern = choose_template(s,n);
    p->number = n;
    p->template_id = pattern;
    p->start_y = 166;
    if(n){
        const RiderPiece *prev=&s->track[(n-1u)%RIDER_TRACK_SLOTS];
        p->start_y=(int16_t)(prev->start_y+piece_end_delta(prev->template_id,prev->start_y));
    }
    /* Only select the sustained double ascent when there is enough world
     * elevation headroom; otherwise select the independent high gap. */
    if(pattern==55u && p->start_y<164){pattern=56u;p->template_id=pattern;}
    p->flags = 0;
    p->gem_mask=0;
    if (n != 0u && ((n & 1u) || special_piece(pattern) || pattern==55u || pattern==56u) && pattern!=48u) {
        p->flags |= PIECE_FLAG_GEM;
        p->gem_mask = (special_piece(pattern) || pattern==13u || pattern==30u ||
                       pattern==29u || pattern==36u || pattern==41u || pattern==43u ||
                       pattern==49u || pattern==51u || pattern==53u || pattern==55u || pattern==56u)?7u:1u;
    }
    /* No disconnected floating saws. Later saws belong only to explicit
     * hazard sections with nearby rail geometry. */
    if (pattern == 9u || pattern == 10u || pattern == 25u)
        p->flags |= PIECE_FLAG_SAW;
    if (pattern == 11u || pattern == 22u || pattern==39u) p->flags |= PIECE_FLAG_BOOST;
    if(pattern==12u || pattern==13u || pattern==15u || pattern==21u) p->flags |= PIECE_FLAG_SPIKES;
    s->last_template = pattern;
}

/* Hermite curve with slopes derived from adjacent knots; flat end tangents. */
static int32_t sample_curve_q(uint8_t kind, uint32_t local_x_q)
{
    if (kind >= N_TEMPLATES) return 0;
    uint32_t k = local_x_q / (32u*RIDER_Q);
    if (k >= 8) return 0;
    int32_t t = (int32_t)((local_x_q % (32u*RIDER_Q)) / 32u);
    int32_t t2 = t * t / RIDER_Q, t3 = t2 * t / RIDER_Q;
    int32_t a = 2*t3-3*t2+RIDER_Q, b=-2*t3+3*t2;
    int32_t c = t3-2*t2+t, d=t3-t2;
    int32_t v0 = heights[kind][k];
    int32_t v1 = heights[kind][k+1];
    int32_t m0 = k ? ((int32_t)heights[kind][k+1]-heights[kind][k-1])/2 : 0;
    int32_t m1 = k+1<8 ? ((int32_t)heights[kind][k+2]-heights[kind][k])/2 : 0;
    /* Keep the central sharp apex of V/peak templates; their outer
     * transitions are still Hermite and have flat endpoints. */
    if((kind==49u || kind==50u) && (k==3u || k==4u))
        return v0*(RIDER_Q-t)+v1*t;
    return a*v0 + b*v1 + c*m0 + d*m1;
}

static bool template_gap(uint8_t kind, uint32_t local_x_q)
{
    if (kind == 16u || kind == 52u) return local_x_q>=68u*RIDER_Q && local_x_q<=156u*RIDER_Q;
    if (kind == 47u) return local_x_q>=68u*RIDER_Q && local_x_q<=133u*RIDER_Q;
    if (kind == 27u) return local_x_q>=70u*RIDER_Q && local_x_q<=220u*RIDER_Q;
    if (kind == 28u) return local_x_q>=70u*RIDER_Q && local_x_q<=198u*RIDER_Q;
    if (kind == 46u) return local_x_q>=70u*RIDER_Q && local_x_q<=221u*RIDER_Q;
    if (kind == 55u) return local_x_q>=116u*RIDER_Q && local_x_q<=148u*RIDER_Q;
    if (kind == 56u) return local_x_q>=120u*RIDER_Q && local_x_q<=158u*RIDER_Q;
    if (kind == 53u) return local_x_q>=124u*RIDER_Q && local_x_q<=173u*RIDER_Q;
    if (kind == 12u) return local_x_q >= 102u*RIDER_Q && local_x_q <= 152u*RIDER_Q;
    if (kind == 13u || kind == 15u || kind == 21u) return local_x_q >= 102u*RIDER_Q && local_x_q <= 154u*RIDER_Q;
    return false;
}

bool rider_surface_q(const RiderState *s, int32_t world_x_q, int32_t *world_y_q)
{
    if (world_x_q < 0) return false;
    uint32_t number = (uint32_t)world_x_q / (RIDER_PIECE_WIDTH*RIDER_Q);
    const RiderPiece *p = &s->track[number % RIDER_TRACK_SLOTS];
    if (p->number != number || number >= s->next_piece) return false;
    uint32_t local_x_q = (uint32_t)world_x_q % (RIDER_PIECE_WIDTH*RIDER_Q);
    if(p->template_id==48u){
        /* Small gaps around a vertically oscillating suspended bridge.
         * Trigger and visual motion require NO additional state allocation. */
        if((local_x_q>=90u*RIDER_Q && local_x_q<103u*RIDER_Q) ||
           (local_x_q>177u*RIDER_Q && local_x_q<=190u*RIDER_Q))return false;
        if(local_x_q>=103u*RIDER_Q && local_x_q<=177u*RIDER_Q){
            *world_y_q=(int32_t)p->start_y*RIDER_Q +
              18*rider_sin256((uint8_t)(2u*s->tick_count+number*13u));
            return true;
        }
    }
    if (template_gap(p->template_id, local_x_q)) return false;
    int32_t offset = sample_curve_q(p->template_id, local_x_q);
    if(p->template_id==52u){
        /* Same elevated tangent as the 2D path at x=68 and x=156.
         * Smooth approach, no invisible rail under the loop. */
        int32_t t=local_x_q<68u*RIDER_Q?(int32_t)(local_x_q/68u):
            (int32_t)((256u*RIDER_Q-local_x_q)/100u);
        if(t>RIDER_Q)t=RIDER_Q;
        int32_t t2=t*t/RIDER_Q;
        offset=-32*(3*t2-2*t2*t/RIDER_Q);
    }
    const int32_t u=(int32_t)(local_x_q/RIDER_PIECE_WIDTH);
    const int32_t u2=u*u/RIDER_Q;
    offset+=piece_end_delta(p->template_id,p->start_y)*(3*u2-2*u2*u/RIDER_Q);
    if(p->template_id==55u && local_x_q>148u*RIDER_Q){
        /* A few world pixels of landing clearance compensate for gravity
         * during the gap; the second rail still climbs continuously. */
        int32_t z=(int32_t)((256u*RIDER_Q-local_x_q)/108u);
        int32_t z2=z*z/RIDER_Q;
        offset+=6*(3*z2-2*z2*z/RIDER_Q);
    }
    *world_y_q = (int32_t)p->start_y*RIDER_Q + offset;
    return true;
}

bool rider_piece_saw_q(const RiderState *s, uint32_t piece_number, int32_t *cx_q, int32_t *cy_q, int32_t *radius_q)
{
    const RiderPiece *p = &s->track[piece_number % RIDER_TRACK_SLOTS];
    if (p->number != piece_number || !(p->flags & PIECE_FLAG_SAW)) return false;
    uint32_t local_px = (p->template_id == 10u) ? 176u : 146u;
    *cx_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + local_px) * RIDER_Q;
    if(p->template_id==25u) {
        const uint8_t phase=(uint8_t)(2u*s->tick_count+piece_number*13u);
        *cx_q += 13*rider_sin256(phase); /* +/-13 world pixels, no RAM */
    }
    int32_t yq;
    if (!rider_surface_q(s, *cx_q, &yq)) return false;
    /* Place the full blade above the LOCAL rail. Collisions are computed
     * against the same center/radius used by the renderer. */
    /* Larger original-inspired blade; maintain safe clearance in the
     * pretested novice route despite the late-game horizontal oscillation. */
    *cy_q=yq-(p->template_id==25u?96:87)*RIDER_Q;
    *radius_q = (p->template_id==25u?33:42) * RIDER_Q;
    return true;
}

bool rider_piece_boost_q(const RiderState *s, uint32_t piece_number, int32_t *x0_q, int32_t *x1_q, int32_t *y_q)
{
    const RiderPiece *p = &s->track[piece_number % RIDER_TRACK_SLOTS];
    if (p->number != piece_number || !(p->flags & PIECE_FLAG_BOOST)) return false;
    *x0_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 92u) * RIDER_Q;
    *x1_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 148u) * RIDER_Q;
    int32_t mid = (*x0_q + *x1_q) / 2;
    return rider_surface_q(s, mid, y_q);
}

bool rider_piece_gem_q(const RiderState *s,uint32_t pn,uint8_t slot,int32_t *xq,int32_t *yq)
{
    if(slot>=3u || !xq || !yq)return false;
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(p->number!=pn || !(p->flags&PIECE_FLAG_GEM) || !(p->gem_mask&(1u<<slot)))return false;
    if(special_piece(p->template_id)) {
        static const uint16_t ts[3]={1050,2050,3050};
        uint16_t t=ts[slot];
        if(p->template_id==28u){static const uint16_t bowl[3]={1100,2200,3350};t=bowl[slot];}
        int32_t ax,ay,bx,by;
        if(!rider_track_special_q(s,pn,p->template_id,t,xq,yq) ||
           !rider_track_special_q(s,pn,p->template_id,t-32,&ax,&ay) ||
           !rider_track_special_q(s,pn,p->template_id,t+32,&bx,&by))return false;
        /* Put diamonds on the rider-facing side of the actual 2D path. */
        int32_t a=angle_from_vector(bx-ax,by-ay);
        *xq+=14*rider_sin4096(a);
        *yq-=14*rider_sin4096(a+1024);
        return true;
    }
    if(p->template_id==55u || p->template_id==56u){
        /* Airborne diamond path follows the actual two lips, not the base
         * elevation. It is drawn and collected using this same function. */
        int32_t start=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q, yl,yr;
        int l=p->template_id==55u?115:119, r=p->template_id==55u?149:159;
        if(!rider_surface_q(s,start+l*RIDER_Q,&yl) ||
           !rider_surface_q(s,start+r*RIDER_Q,&yr))return false;
        int u=(r-l)*(slot+1)/4;
        *xq=start+(l+u)*RIDER_Q;
        *yq=yl+(yr-yl)*u/(r-l)-(20+(slot==1u?9:0))*RIDER_Q;
        return true;
    }
    if(p->template_id==53u){
        int32_t start=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q, yl,yr;
        if(!rider_surface_q(s,start+123*RIDER_Q,&yl) ||
           !rider_surface_q(s,start+174*RIDER_Q,&yr))return false;
        *xq=start+(130+(int32_t)slot*17)*RIDER_Q;
        *yq=yl+(yr-yl)*(7+(int32_t)slot*17)/51-(26+(slot==1u?12:0))*RIDER_Q;
        return true;
    }
    int32_t wx=(int32_t)(pn*RIDER_PIECE_WIDTH+128u)*RIDER_Q;
    if(p->template_id==13u || p->template_id==30u || p->template_id==49u || p->template_id==51u || p->template_id==53u)
        wx=(int32_t)(pn*RIDER_PIECE_WIDTH+100u+slot*28u)*RIDER_Q;
    int32_t wy;
    if((p->template_id==29u || p->template_id==36u ||
        p->template_id==41u || p->template_id==43u) && (p->flags&PIECE_FLAG_GEM)){
        wx=(int32_t)(pn*RIDER_PIECE_WIDTH+115u+slot*28u)*RIDER_Q;
        if(!rider_surface_q(s,wx,&wy))
            wy=(int32_t)p->start_y*RIDER_Q;
        /* The middle gem sits higher, forming a three-gem airborne arc. */
        wy-=(20+(slot==1u?8:0))*RIDER_Q;

    } else if(!rider_surface_q(s,wx,&wy)){
        /* Around real gaps the diamonds float over the missing rail. */
        wy=(int32_t)(p->start_y-19)*RIDER_Q;
    }
    *xq=wx;
    *yq=wy-(((p->template_id==29u||p->template_id==36u||
               p->template_id==41u||p->template_id==43u) &&
               (p->flags&PIECE_FLAG_GEM))?0:18*RIDER_Q);
    return true;
}
/* Repeating triangular spike profile in the same Q8 world coordinates
 * as the hazard bounds. A sawtooth is not a filled collision rectangle. */
int32_t rider_spike_profile_q(int32_t local_x_q)
{
    int32_t u=local_x_q%(10*RIDER_Q)-5*RIDER_Q;
    return (u<0?-u:u)*6/5;
}
bool rider_piece_spikes_q(const RiderState *s,uint32_t pn,int32_t *x0q,int32_t *x1q,int32_t *tipyq)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(p->number!=pn || !(p->flags&PIECE_FLAG_SPIKES) || !x0q || !x1q || !tipyq)return false;
    if(p->template_id==15u && ((s->tick_count+pn*17u)%120u)<50u)
        return false; /* timed lance retracted: renderer AND physics agree */
    *x0q=(int32_t)(pn*RIDER_PIECE_WIDTH+106u)*RIDER_Q;
    *x1q=(int32_t)(pn*RIDER_PIECE_WIDTH+151u)*RIDER_Q;
    *tipyq=(int32_t)(p->start_y+14)*RIDER_Q;
    return true;
}
void rider_wheel_centers_q(const RiderState *s, int32_t *lx, int32_t *ly,
                           int32_t *rx, int32_t *ry)
{
    int32_t si = rider_sin4096(s->angle), co = rider_sin4096(s->angle+1024);
    int32_t dx = co*12, dy = si*12;
    *lx = s->x-dx; *ly=s->y-dy;
    *rx = s->x+dx; *ry=s->y+dy;
}

void rider_restart(RiderState *s)
{
    uint32_t saved_best = (uint32_t)s->best;
    int32_t saved_diamonds = s->diamonds;
    uint32_t seed = s->random_state ^ 0x9e3779b9u;
    rider_init(s, seed);
    s->best = (int32_t)saved_best;
    s->diamonds = saved_diamonds;
}

void rider_init(RiderState *s, uint32_t seed)
{
    memset(s, 0, sizeof(*s));
    s->random_state = seed ? seed : 0xd88ec19bu;
    s->theme=0u; /* fixed classic blue world / pink rail */
    for (uint32_t i=0; i<RIDER_TRACK_SLOTS; ++i) append_piece(s);
    s->x = 70*RIDER_Q;
    s->y = 161*RIDER_Q;
    s->camera_x = -70*RIDER_Q;
    s->camera_y = -30*RIDER_Q;
    s->phase=RIDER_READY;
    s->grounded=1;
}

static void commit_pending(RiderState *s)
{
    if (s->pending_ticks) {
        --s->pending_ticks;
        if (!s->pending_ticks) {
            s->score+=s->pending_score;
            if(s->score>s->best) s->best=s->score;
            s->pending_score=0;
        }
    }
}

static void crash(RiderState *s)
{
    s->phase=RIDER_CRASHED;
    s->pending_score=0;
    s->pending_ticks=0;
}

static void maybe_collect_gem(RiderState *s, uint32_t piece_number)
{
    RiderPiece *p=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(p->number!=piece_number || !(p->flags&PIECE_FLAG_GEM))return;
    /* One collision per gem, so a U-shaped cluster awards three diamonds. */
    for(uint8_t j=0;j<3u;++j){
        int32_t gx,gy;
        if(!rider_piece_gem_q(s,piece_number,j,&gx,&gy))continue;
        if(s->x-gx> -13*RIDER_Q && s->x-gx<13*RIDER_Q &&
           s->y-gy> -20*RIDER_Q && s->y-gy<20*RIDER_Q){
            p->gem_mask&=(uint8_t)~(1u<<j);
            if(s->diamonds<INT32_MAX)++s->diamonds;
        }
    }
    if(!p->gem_mask)p->flags&=(uint8_t)~PIECE_FLAG_GEM;
}

static bool saw_hit_q(int32_t px, int32_t py, int32_t cx, int32_t cy, int32_t rr)
{
    int64_t dx = (int64_t)px - cx;
    int64_t dy = (int64_t)py - cy;
    return dx*dx + dy*dy <= (int64_t)rr*rr;
}

/* Loop runs are deliberately guided: a small MCU cannot fit Box2D and the
 * original collision graph alongside Rad Pro. The path itself is a true
 * overlapping loop, not a fake x-height hill. This is NOT rigid-body parity. */
static void maybe_collect_gem(RiderState *s,uint32_t piece_number);
static void step_loop(RiderState *s,bool held)
{
    uint32_t pn=s->loop_piece;
    const RiderPiece *gp=&s->track[pn%RIDER_TRACK_SLOTS];
    const uint8_t kind=(gp->number==pn)?gp->template_id:16u;
    int32_t xa0,ya0,xb0,yb0;
    uint16_t ta=s->loop_t>64u?s->loop_t-64u:0u;
    uint16_t tb=s->loop_t<4032u?s->loop_t+64u:4096u;
    if(!rider_track_special_q(s,pn,kind,ta,&xa0,&ya0) ||
       !rider_track_special_q(s,pn,kind,tb,&xb0,&yb0)){crash(s);return;}
    int32_t dx=xb0-xa0,dy=yb0-ya0;
    int32_t ax=dx<0?-dx:dx,ay=dy<0?-dy:dy;
    int32_t length=(ax>ay?ax:ay)+(ax>ay?ay:ax)*3/8;
    if(length<1)length=1;
    int32_t slope=dy*14/length;
    int32_t travel=clamp_i32(s->vx+(held?18:-5)+slope,0,4*RIDER_Q);
    if(travel<RIDER_Q/2){crash(s);return;} /* no automatic minimum-speed ride */
    s->vx=travel;
    uint32_t advance=(uint32_t)(travel*(tb-ta)/length);
    if(advance<1u)advance=1u;
    if(advance>180u)advance=180u;
    uint32_t nt=(uint32_t)s->loop_t+advance;
    if(nt>=RIDER_ANGLE_TURN) {
        s->loop_t=RIDER_ANGLE_TURN;
        s->looping=0;
        if(kind==54u||kind==46u||kind==27u){
            /* Open rails exit at the real path tangent and speed. */
            int32_t ex,ey,px,py;
            if(!rider_track_special_q(s,pn,kind,4096u,&ex,&ey) ||
               !rider_track_special_q(s,pn,kind,4032u,&px,&py)){crash(s);return;}
            int32_t a=angle_from_vector(ex-px,ey-py);
            int32_t sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
            s->x=ex+sn*5;s->y=ey-cs*5;
            s->vx=clamp_i32(travel*cs/256,0,4*RIDER_Q);
            s->vy=travel*sn/256;s->angle=a;s->grounded=0;
        }else{
            int32_t ex,ey;
            if(!rider_track_special_q(s,pn,kind,4096u,&ex,&ey)){crash(s);return;}
            s->x=ex;
            s->y=ey-5*RIDER_Q;
            s->angle=((kind==16u || kind==47u || kind==52u)?-RIDER_ANGLE_TURN:0);
            s->vy=0;
            s->grounded=1;
        }
        s->angular_speed=0;
        s->airborne_ticks=0;
        s->air_rotation=0;
        maybe_collect_gem(s,pn);
        return;
    }
    s->loop_t=(uint16_t)nt;
    int32_t xx,yy,xb,yb,xa,ya;
    rider_track_special_q(s,pn,kind,s->loop_t,&xx,&yy);
    rider_track_special_q(s,pn,kind,(uint16_t)(s->loop_t>8?s->loop_t-8:0),&xb,&yb);
    rider_track_special_q(s,pn,kind,(uint16_t)(s->loop_t<4088?s->loop_t+8:4096),&xa,&ya);
    int32_t tangent=angle_from_vector(xa-xb,ya-yb);
    int32_t si=rider_sin4096(tangent),co=rider_sin4096(tangent+1024);
    s->x=xx+si*5;
    s->y=yy-co*5;
    /* Continuous 0..4096 rotation around loop. */
    if(s->loop_t>RIDER_ANGLE_TURN/2 && tangent>0)tangent-=RIDER_ANGLE_TURN;
    s->angle=tangent;
    s->grounded=1;
    s->vy=0;
    s->angular_speed=0;
    maybe_collect_gem(s,pn);
}

/* Contact with the inside of a detached rail requires actual proximity,
 * compatible orientation and velocity along the rail. This is a compact
 * rail constraint, not an automatic pickup when crossing its x coordinate.
 * A coarse search followed by fine local refinement uses only stack scalars. */
static bool arch_contact(RiderState *s,uint32_t pn)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(p->number!=pn || p->template_id!=54u || s->grounded)return false;
    int32_t base=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q;
    if(s->x<base+68*RIDER_Q || s->x>base+192*RIDER_Q ||
       s->y>((int32_t)p->start_y-67)*RIDER_Q || s->y<((int32_t)p->start_y-172)*RIDER_Q)return false;
    uint16_t best=0;
    int32_t best_d=INT32_MAX,best_x=0,best_y=0,best_a=0;
    for(unsigned pass=0;pass<2u;++pass){
        unsigned begin=pass?(best>128u?best-128u:0u):0u;
        unsigned end=pass?(best<3968u?best+128u:4096u):4096u;
        unsigned step=pass?16u:128u;
        for(unsigned t=begin;t<=end;t+=step){
            int32_t x,y,ax,ay,bx,by;
            uint16_t ta=(uint16_t)(t>32u?t-32u:0u),tb=(uint16_t)(t<4064u?t+32u:4096u);
            if(!rider_track_special_q(s,pn,54u,(uint16_t)t,&x,&y) ||
               !rider_track_special_q(s,pn,54u,ta,&ax,&ay) ||
               !rider_track_special_q(s,pn,54u,tb,&bx,&by))continue;
            int32_t a=angle_from_vector(bx-ax,by-ay);
            x+=5*rider_sin4096(a);y-=5*rider_sin4096(a+1024);
            int32_t dx=(s->x-x)/16,dy=(s->y-y)/16;
            int32_t d=dx*dx+dy*dy;
            if(d<best_d){best_d=d;best=(uint16_t)t;best_x=x;best_y=y;best_a=a;}
        }
    }
    if(best_d>80*80 || best>3968u)return false; /* five world pixels, not a magnetic snap */
    int32_t speed=(s->vx*rider_sin4096(best_a+1024)+s->vy*rider_sin4096(best_a))/256;
    int32_t angle_error=((s->angle-best_a+2048)&4095)-2048;
    if(speed<2*RIDER_Q || angle_error< -720 || angle_error>720)return false;
    s->looping=1;s->loop_piece=pn;s->loop_t=best;s->x=best_x;s->y=best_y;
    s->vx=clamp_i32(speed,0,4*RIDER_Q);s->vy=0;s->angle=best_a;
    s->grounded=1;s->angular_speed=0;s->air_rotation=0;s->airborne_ticks=0;
    maybe_collect_gem(s,pn);
    return true;
}

static void update_camera(RiderState *s)
{
    int32_t tx=s->x-140*RIDER_Q;
    int32_t ty=s->y-190*RIDER_Q;
    /* Resist 1px snaps as the vehicle crosses changing slopes. */
    s->camera_x += clamp_i32((tx-s->camera_x)/5,-7*RIDER_Q,7*RIDER_Q);
    s->camera_y += clamp_i32((ty-s->camera_y)/10,-3*RIDER_Q,3*RIDER_Q);
}

static bool spike_hit(int32_t x,int32_t y,int32_t x0,int32_t x1,int32_t tip)
{
    return x>=x0 && x<=x1 && y<=tip+12*RIDER_Q &&
           y+5*RIDER_Q>=tip+rider_spike_profile_q(x-x0);
}
void rider_step(RiderState *s, bool held)
{
    if (s->phase==RIDER_CRASHED) {
        if (s->crash_ticks<UINT16_MAX) ++s->crash_ticks;
        return;
    }
    if (s->phase==RIDER_READY) {
        if (!held) return;
        s->phase=RIDER_RUNNING;
    }
    s->throttle_active=held?1u:0u;
    commit_pending(s);
    ++s->tick_count;
    if(s->perfect_ticks) --s->perfect_ticks;
    if(s->boost_ticks) --s->boost_ticks;
    if(s->looping) {
        step_loop(s,held);
        update_camera(s);
        return;
    }
    const bool was_grounded=s->grounded!=0;
    const int32_t old_x=s->x;
    if(was_grounded) {
        int32_t ahead,behind,slope_drive=0;
        if(rider_surface_q(s,s->x+12*RIDER_Q,&ahead) &&
           rider_surface_q(s,s->x-12*RIDER_Q,&behind))
            slope_drive=clamp_i32((ahead-behind)/384,-12,12);
        const int32_t cap=s->boost_ticks?6*RIDER_Q:4*RIDER_Q;
        s->vx=clamp_i32(s->vx+(held?16:-6)+slope_drive,0,cap);
        s->angular_speed=0;
    } else {
        if(s->airborne_ticks<UINT16_MAX) ++s->airborne_ticks;
        s->vy=clamp_i32(s->vy+15,-7*RIDER_Q,8*RIDER_Q);
        /* The original one-button control should not spin the bike wildly
         * after a short accidental press. Accelerate rotation gradually. */
        if(held && s->airborne_ticks>=6) {
            /* About 365 deg/s maximum at 60 Hz, versus v0.9's >570.
             * The release decay is much stronger for precise landing. */
            s->angular_speed=clamp_i32(s->angular_speed+7,0,70);
        } else {
            s->angular_speed=(s->angular_speed*212)/256;
        }
        s->angle+=s->angular_speed;
        s->air_rotation+=(uint32_t)s->angular_speed;
        if(s->air_rotation>16u*RIDER_ANGLE_TURN)s->air_rotation=16u*RIDER_ANGLE_TURN;
    }
    s->x+=s->vx;
    s->y+=s->vy;
    uint32_t piece_number=(uint32_t)(s->x/(RIDER_PIECE_WIDTH*RIDER_Q));
    if(piece_number+7>=s->next_piece)append_piece(s);

    /* Enter a closed loop only on the leading rail and at adequate speed. */
    const RiderPiece *piece=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(was_grounded && piece->number==piece_number && special_piece(piece->template_id) && piece->template_id!=54u) {
        int32_t entrance=(int32_t)(piece_number*RIDER_PIECE_WIDTH+((piece->template_id==16u||piece->template_id==47u||piece->template_id==52u)?68u:70u))*RIDER_Q;
        if(old_x<entrance && s->x>=entrance && s->vx>2*RIDER_Q) {
            s->looping=1;
            s->loop_piece=piece_number;
            s->loop_t=0;
            int32_t ex,ey;
            if(!rider_track_special_q(s,piece_number,piece->template_id,0,&ex,&ey)){crash(s);return;}
            s->x=ex;
            s->y=ey-5*RIDER_Q;
            s->angle=0;
            s->angular_speed=0;
            step_loop(s,held);
            update_camera(s);
            return;
        }
    }
    if(!was_grounded && arch_contact(s,piece_number)){update_camera(s);return;}
    /* At the end of the first rising lip, preserve its tangent momentum.
     * The ordinary one-wheel support path used to zero vertical speed at
     * a missing centre rail, causing the bike to fall through the higher
     * landing even when it was launched at full speed. */
    if(was_grounded && piece->template_id==55u){
        int32_t here,old,back;
        if(!rider_surface_q(s,s->x,&here) && rider_surface_q(s,old_x,&old) &&
           rider_surface_q(s,old_x-8*RIDER_Q,&back)){
            s->vy=clamp_i32((old-back)*s->vx/(8*RIDER_Q),-3*RIDER_Q,2*RIDER_Q);
            s->y=old-5*RIDER_Q+s->vy;
            s->grounded=0;s->takeoff_angle=s->angle;s->air_rotation=0;
            s->angular_speed=0;s->airborne_ticks=0;
            maybe_collect_gem(s,piece_number);
            update_camera(s);return;
        }
    }
    int32_t yl=0,yr=0,xl,xr,wl,wr;
    rider_wheel_centers_q(s,&xl,&wl,&xr,&wr);
    bool left=rider_surface_q(s,xl,&yl),right=rider_surface_q(s,xr,&yr);
    int32_t dl=left?wl+5*RIDER_Q-yl:INT32_MIN/4;
    int32_t dr=right?wr+5*RIDER_Q-yr:INT32_MIN/4;
    /* Independent wheel-contact probes: a wheel well above the rail is not
     * a supporting contact merely because its x coordinate has a surface.
     * This avoids snapping the whole bike to a remote slope when only one
     * wheel is actually on the ground. */
    bool l_support=left && dl>=-RIDER_Q && dl<=9*RIDER_Q;
    bool r_support=right && dr>=-RIDER_Q && dr<=9*RIDER_Q;
    bool contact=l_support||r_support;
    /* A badly penetrated wheel is still rescued if the bike was already
     * grounded, rather than tunnelling through the rail on a long frame. */
    if(was_grounded && !contact)
        contact=(left&&dl>=0)||(right&&dr>=0);
    /* At a genuinely convex launch lip, keep momentum and leave the
     * rail instead of following the falling slope. Flat terrain and
     * tiny bumps never activate this. */
    if(was_grounded && contact && s->vx>2*RIDER_Q){
        int32_t before,here,after;
        if(rider_surface_q(s,s->x-20*RIDER_Q,&before) &&
           rider_surface_q(s,s->x,&here) &&
           rider_surface_q(s,s->x+20*RIDER_Q,&after) &&
           here-before< -5*RIDER_Q && after-here>5*RIDER_Q){
            s->grounded=0;
            s->vy=clamp_i32((here-before)/4,-3*RIDER_Q,-2*RIDER_Q);
            s->air_rotation=0;
            s->angular_speed=0;
            s->airborne_ticks=0;
            s->takeoff_angle=s->angle;
            maybe_collect_gem(s,piece_number);
            update_camera(s);
            return;
        }
    }
    /* Landing is descending relative to the rail, not necessarily relative
     * to the world. A bike can meet a rising landing while still moving up. */
    bool approaching=s->vy>=0;
    if(!was_grounded && !approaching && s->airborne_ticks>2u && contact){
        int32_t a,b;
        if(rider_surface_q(s,s->x,&a) && rider_surface_q(s,s->x+8*RIDER_Q,&b))
            approaching=s->vy >= (b-a)*s->vx/(8*RIDER_Q);
    }
    if(contact && (was_grounded || approaching)) {
        int32_t tangent=0;
        if(l_support&&r_support) {
            int32_t difference=yr-yl;
            tangent=clamp_i32((difference*652)/(24*RIDER_Q),-390,390);
        }
        int32_t phase=((s->angle-tangent+2048)&4095)-2048;
        int32_t impact= s->vy;
        /* Small slopes don't kill the car. Serious upside-down impact does. */
        if((phase>1580||phase<-1580) ||
           ((phase>1380||phase<-1380)&&impact>4*RIDER_Q)) {
            crash(s); return;
        }
        if(!was_grounded) {
            /* The original's firstFlipDegreesAmount is 270 degrees, not
             * our older 349-degree threshold. Further full turns each count. */
            uint32_t n=s->air_rotation>=3072u ?
               1u+(s->air_rotation-3072u)/RIDER_ANGLE_TURN:0u;
            if(n>8)n=8;
            if(n) {
                if(s->pending_ticks) {
                    s->score+=s->pending_score;
                    if(s->score>s->best)s->best=s->score;
                    s->pending_score=0;
                }
                s->pending_score=(uint16_t)n;
                s->pending_ticks=30;
                s->perfect_ticks=(l_support&&r_support &&
                    dl-dr<3*RIDER_Q && dr-dl<3*RIDER_Q)?48:0;
            }
        }
        int32_t penetration=(left?dl:INT32_MIN/4) > (right?dr:INT32_MIN/4)?dl:dr;
        if(penetration>0)s->y-=penetration;
        if(was_grounded){
            int32_t road_y;
            if(rider_surface_q(s,s->x,&road_y)){
                /* Wheel orientation must not turn positional correction into
                 * a fake jump. Project to the road while already grounded;
                 * intentional cliffs and missing rail still release it. */
                s->y=road_y-5*RIDER_Q;
            }
        }
        /* Never convert a ground-position correction into an upward kick. */
        /* A ground projection is not a bounce impulse. Retain only a
         * bounded upward takeoff velocity on an actual rising ramp. */
        if(!was_grounded) s->vy=0;
        else if(l_support && r_support) {
            /* Launch velocity follows the *road tangent*, not the amount of
             * penetration resolved this frame. Thus no phantom bounce. */
            int64_t motion=(int64_t)(yr-yl)*s->vx/(24*RIDER_Q);
            s->vy=clamp_i32((int32_t)motion,-3*RIDER_Q,2*RIDER_Q);
        } else s->vy=0;
        int32_t nearest=(s->angle & ~4095)+tangent;
        if(nearest-s->angle>2048)nearest-=4096;
        if(s->angle-nearest>2048)nearest+=4096;
        int32_t d=nearest-s->angle;
        /* While grounded there is no angular input: wheel suspension aligns
         * the bike gently with the road. This prevents phantom tip-overs. */
        if(was_grounded) {
            /* A bump cannot accumulate a rollover while in grounded mode. */
            s->angle+=clamp_i32(d/2,-75,75);
            int32_t remain=nearest-s->angle;
            if(remain>255)s->angle=nearest-255;
            if(remain< -255)s->angle=nearest+255;
        } else s->angle+=clamp_i32(d/3,-75,75);
        s->grounded=1;
        s->airborne_ticks=0;
        s->air_rotation=0;
    } else {
        if(was_grounded) {
            s->takeoff_angle=s->angle;
            s->air_rotation=0;
            s->airborne_ticks=0;
        }
        s->grounded=0;
    }
    /* Boost pads only trigger with the bike in ground contact and along the
     * underlying curved surface. They provide an obvious temporary effect. */
    if(s->grounded) {
        int32_t bx0,bx1,by;
        if(rider_piece_boost_q(s,piece_number,&bx0,&bx1,&by) &&
           s->x>=bx0 && s->x<=bx1) {
            if(s->boost_ticks<5)s->vx=clamp_i32(s->vx+125,0,6*RIDER_Q);
            s->boost_ticks=26;
        }
    }
    /* Recalculate wheel positions AFTER penetration correction. */
    rider_wheel_centers_q(s,&xl,&wl,&xr,&wr);
    for(uint32_t pn=piece_number?piece_number-1u:0u;pn<=piece_number+1u;++pn) {
        int32_t cx,cy,r;
        if(!rider_piece_saw_q(s,pn,&cx,&cy,&r))continue;
        if(saw_hit_q(s->x,s->y,cx,cy,r+6*RIDER_Q) ||
           saw_hit_q(xl,wl,cx,cy,r+4*RIDER_Q) ||
           saw_hit_q(xr,wr,cx,cy,r+4*RIDER_Q)) {crash(s);return;}
    }
    for(uint32_t pn=piece_number?piece_number-1u:0u;pn<=piece_number+1u;++pn){
        int32_t x0,x1,tip;
        if(!rider_piece_spikes_q(s,pn,&x0,&x1,&tip))continue;
        /* The spikes sit below the normal rail, within intentional gaps. */
        if(spike_hit(s->x,s->y,x0,x1,tip) || spike_hit(xl,wl,x0,x1,tip) ||
           spike_hit(xr,wr,x0,x1,tip)){crash(s);return;}
    }
    maybe_collect_gem(s,piece_number);
    if(piece_number+1u<s->next_piece)maybe_collect_gem(s,piece_number+1u);
    update_camera(s);
    if(s->x>INT32_MAX-150000 || s->y>410*RIDER_Q) crash(s);
}

uint32_t rider_hash(const RiderState *s)
{
    uint32_t x=2166136261u;
#define HASH(v) do { x^=(uint32_t)(v); x*=16777619u; } while(0)
    HASH(s->random_state); HASH(s->next_piece); HASH(s->x); HASH(s->y);
    HASH(s->vx);HASH(s->vy);HASH(s->angle);HASH(s->phase);HASH(s->score);HASH(s->tick_count);HASH(s->air_rotation);HASH(s->loop_t);HASH(s->looping);HASH(s->boost_ticks); HASH(s->throttle_active); HASH(s->theme);
    for (uint32_t i=0;i<RIDER_TRACK_SLOTS;i++) {
        HASH(s->track[i].number);HASH(s->track[i].start_y);HASH(s->track[i].template_id);HASH(s->track[i].flags);HASH(s->track[i].gem_mask);
    }
#undef HASH
    return x;
}
