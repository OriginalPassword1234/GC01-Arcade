# GC-01 Parkour Gauntlet 0.4.1 — physics & graphics stabilization

SOURCE-ONLY EXPERIMENT. NOT FLASHABLE FIRMWARE.

Target: FNIRSI GC-01 APM32F103RB (English), Gissio Rad Pro 3.1.1,
PlatformIO environment `fnirsi-gc01_apm32f103rb-en`.

This overlay keeps the previously optimized Rad Pro base and updates the
0.4 parkour module. The original radiation measurement, USB, tube, and
power modules are not directly changed by this ZIP. This is a source
preservation statement, NOT a hardware-safety or alarm-reliability claim.

## Changes since 0.4

- Corrected fractional-pixel hitbox rounding and contact resolution so the
  player settles exactly on floors and doesn't jitter a fraction of a pixel
  into solids. Bound movement to <=1 logical pixel collision substeps.
- Added genuine one-way platforms: jump through from beneath and land from
  above; floor-mounted bounce pads now trigger on approach and landing.
- Fixed the gap template's hidden lower floor so gaps can actually kill;
  prevent dash invulnerability from negating falling out of the world.
- Charged strikes only spend mana when a valid, currently in-range target
  is present at button release. Normal long Right runs don't spend mana.
- Lower CPU cost: precompute static scenery hashes per tile, rasterize only
  enemy/player sprites intersecting a tile, improve dirty rectangle bounds.
- Avoid full HUD clears for every changing HP/mana reading; pace rendering
  to 40-ms deadlines, with frames skipped if the display is late rather than
  slowing measurement/alarm handling to catch up.
- Improved graphic details: anchored character shadows, dash afterimages,
  brighter projectiles, healing sparkles and platform rivets.
- Removed duplicated 260-byte previous-cell array from static RAM.
- Added more demanding physics and framebuffer comparison regressions.

## Tests performed during source preparation

- GCC and Clang `-O1 -Wall -Wextra -Werror` with ASan and UBSan passed.
- 400 seeded simulations x 520 steps per compiler (208,000 simulation
  steps/compiler), plus deterministic physics scenarios (jump, landing,
  platforms, walls, dash, bounce, pit, resources, pause and restart).
- 113 consecutive 320x240 RGB565 software-rendered frames per compiler
  matched full redraw byte-for-byte, including HP/mana, moving projectiles,
  3 scene palettes, effects, pauses, and deaths.
- In that rendering test, 2,726 updated 16x16 tile transfers were needed
  vs 29,380 for redrawing all 260 tiles in each frame (~91% fewer).
  This is NOT a measured hardware FPS improvement.
- Clang targeting ARM Cortex-M3 compiled standalone logic and a test-mode
  renderer, but this is NOT the full linked target firmware.

## Input scheme (unchanged)

- Left/right move; Up jumps/wall-jumps; Down dashes/slides.
- Middle short release attacks; medium release opens/resumes menu; long hold
  turns off device (existing original critical power handling retained).
- Hold Right near a valid target to charge; release for mana-costed strike.
- Hold Left while blocked near a wall/left edge to accelerate HP recovery.
  Normal leftward movement away from walls should not spend mana.

## Build and limitations

1. Upload `GC01_Parkour_V041_Source.zip` to the GitHub repository root.
   Do NOT unzip it, rename it, or delete the older source ZIP.
2. Open `.github/workflows/GC01_Dungeon_Prototype_Build.yml` and EDIT its
   contents with the matching supplied workflow. Never delete that file.
3. Actions -> `GC-01 Parkour Gauntlet 0.4.1 - TEST AND COMPILE ONLY` ->
   Run workflow (new run, not Re-run old jobs).
4. Upload the resulting diagnostic ZIP if any step fails or succeeds.

**No signed -install.bin is produced. DO NOT FLASH the raw firmware.bin.**

The 57,340-byte application limit remains strict. The new game has not yet
been linked against the real APM32F103RB target in this environment, so
fit in flash/RAM and actual responsiveness are NOT confirmed. Correct
software-framebuffer comparisons cannot guarantee no LCD tearing or
jitter on real hardware; hardware testing is still mandatory. Do not depend
on experimental firmware for radiation protection or alarm decisions.
