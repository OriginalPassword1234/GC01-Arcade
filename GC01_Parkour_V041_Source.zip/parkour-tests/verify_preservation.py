#!/usr/bin/env python3
"""Fail if the Parkour 0.4.1 overlay alters files beyond the explicitly reviewed set.

Compare an overlaid Rad Pro 3.1.1 tree against the pristine GitHub 3.1.1 tree.
"""
from pathlib import Path
import sys

ALLOWED_CHANGED = {
    'platform.io/platformio.ini',
    'platform.io/src/extras/game.c',
    'platform.io/src/extras/rng.c',
    'platform.io/src/peripherals/keyboard.c',
    'platform.io/src/peripherals/keyboard.h',
    'platform.io/src/ui/game.c',
    'platform.io/src/ui/view.c',
    'platform.io/src/ui/view.h',
    'platform.io/src/system/settings.c',
    'platform.io/src/ui/statistics.c',
}
ALLOWED_ADDED = {
    'README_PARKOUR_V041_SOURCE_ONLY.md',
    'parkour-tests/run.sh',
    'parkour-tests/test_logic.c',
    'parkour-tests/test_render.c',
    'parkour-tests/verify_firmware.py',
    'parkour-tests/verify_preservation.py',
    'platform.io/src/extras/arcade.c',
    'platform.io/src/extras/parkour_logic.c',
    'platform.io/src/extras/parkour_logic.h',
    'platform.io/src/ui/parkour_draw.c',
    'platform.io/src/ui/parkour_draw.h',
    'platform.io/src/ui/parkour_art.h',
}
PROTECTED = (
    'platform.io/src/measurements/',
    'platform.io/src/stm32/',
    'platform.io/src/peripherals/tube',
    'platform.io/src/peripherals/comm',
    'platform.io/src/system/power',
    'platform.io/src/system/events',
    'platform.io/scripts/',
)


def source_files(root):
    """Exclude generated build products, never exclude protected source folders."""
    return {
        p.relative_to(root).as_posix(): p
        for p in root.rglob('*')
        if p.is_file() and not any(x in {'.pio', '.git', '__pycache__'}
                                    for x in p.relative_to(root).parts)
    }


def main():
    if len(sys.argv) != 2:
        raise SystemExit('Usage: verify_preservation.py /clean/radpro-3.1.1')
    current = Path.cwd().resolve()
    original = Path(sys.argv[1]).resolve()
    if current == original or not (original / 'platform.io/platformio.ini').is_file():
        raise SystemExit('Pristine, separate Rad Pro reference tree required')
    old = source_files(original)
    new = source_files(current)
    missing = sorted(old.keys() - new.keys())
    added = new.keys() - old.keys()
    unexpected_added = sorted(added - ALLOWED_ADDED)
    missing_added = sorted(ALLOWED_ADDED - added)
    changed = {p for p in old.keys() & new.keys()
               if old[p].read_bytes() != new[p].read_bytes()}
    unexpected_changed = sorted(changed - ALLOWED_CHANGED)
    protected = sorted(p for p in changed if p.startswith(PROTECTED))
    if missing or unexpected_added or missing_added or unexpected_changed or protected:
        raise SystemExit('FAIL: missing_original=' + repr(missing[:12]) +
                         ' unexpected_added=' + repr(unexpected_added[:12]) +
                         ' missing_overlay=' + repr(missing_added[:12]) +
                         ' unauthorized_modified=' + repr(unexpected_changed[:12]) +
                         ' protected_modified=' + repr(protected[:12]))
    print(f'PASS: {len(old)} original files retained; {len(changed)} reviewed original files modified; '
          f'{len(added)} allowlisted new files.')
    print('PASS: original radiation, USB, power, flash scripts and measurement modules unchanged.')


if __name__ == '__main__':
    main()
