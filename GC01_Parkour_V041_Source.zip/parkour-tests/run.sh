#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
pass=0
for cc in gcc clang; do
  if ! command -v "$cc" >/dev/null 2>&1; then continue; fi
  for test in logic render; do
    sources=(platform.io/src/extras/parkour_logic.c "parkour-tests/test_${test}.c")
    if [ "$test" = render ]; then
      sources=(platform.io/src/extras/parkour_logic.c platform.io/src/ui/parkour_draw.c parkour-tests/test_render.c)
    fi
    "$cc" -std=c11 -O1 -g -Wall -Wextra -Werror -DPG_DRAW_TEST \
      -fsanitize=address,undefined -fno-omit-frame-pointer \
      "${sources[@]}" -o "$TMP/$test-$cc"
    ASAN_OPTIONS=detect_leaks=0 "$TMP/$test-$cc"
    pass=$((pass+1))
  done
done
if [ "$pass" -eq 0 ];then echo 'No host compiler available';exit 1;fi
