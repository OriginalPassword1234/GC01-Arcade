/* Parkour Gauntlet 0.4.1: deterministic fixed-step gameplay regression. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../platform.io/src/extras/parkour_logic.h"
#define FP 16

static void empty_room(PG_Game *g) {
    pg_new(g,0x12345678u);
    memset(g->cells,PG_AIR,sizeof(g->cells));
    for(int x=0;x<PG_COLS;x++) {
        g->cells[11*PG_COLS+x]=PG_STONE;
        g->cells[12*PG_COLS+x]=PG_STONE;
    }
    memset(g->enemies,0,sizeof(g->enemies));
    memset(g->shots,0,sizeof(g->shots));
    g->enemyCount=0;
    g->x=20*FP;g->y=74*FP;
    g->vx=0;g->vy=0;g->grounded=1;
    g->previousInput=0;g->invulnerable=0;
}
static void physics(void) {
    PG_Game g;
    empty_room(&g);
    pg_tick(&g,PG_UP);
    assert(g.vy<0 && !g.grounded);
    for(int i=0;i<65;i++)pg_tick(&g,0);
    assert(g.grounded && g.y==74*FP);
    assert(g.vy==0);

    /* A one-way platform may be jumped through from below, then landed on. */
    empty_room(&g);
    for(int col=2;col<=4;col++)g.cells[8*PG_COLS+col]=PG_PLATFORM;
    pg_tick(&g,PG_UP);
    for(int i=0;i<10;i++)pg_tick(&g,PG_UP);
    assert(g.y<50*FP); /* Passed upward through platform at y=64. */
    for(int i=0;i<70;i++)pg_tick(&g,0);
    assert(g.grounded && g.y==50*FP); /* 64 (platform top) - 14 (height). */

    /* Fast dash cannot pass straight through a solid wall. */
    empty_room(&g);
    for(int row=4;row<=10;row++)g.cells[row*PG_COLS+10]=PG_STONE;
    for(int i=0;i<20;i++)pg_tick(&g,PG_RIGHT | (i==0?PG_DOWN:0));
    assert(g.x+PG_PLAYER_W*FP<=80*FP);
    assert(g.x>=0);

    /* Floor-mounted jump pad should launch the player when run across. */
    empty_room(&g);
    g.cells[10*PG_COLS+6]=PG_BOUNCE;
    g.x=36*FP;
    for(int i=0;i<15;i++)pg_tick(&g,PG_RIGHT);
    assert(g.y<74*FP); /* Earlier bounce sent character upwards. */

    /* A real gap is lethal regardless of dash invulnerability. */
    empty_room(&g);
    for(int col=6;col<=8;col++) {
        g.cells[11*PG_COLS+col]=PG_AIR;
        g.cells[12*PG_COLS+col]=PG_AIR;
    }
    g.x=51*FP;g.y=74*FP;g.grounded=0;
    g.invulnerable=20;
    for(int i=0;i<80 && g.phase==PG_RUN;i++)pg_tick(&g,0);
    assert(g.phase==PG_DEAD && g.hp==0);

    /* Coyote time allows a buffered jump a few steps after an edge. */
    empty_room(&g);
    g.grounded=0;g.coyote=4;g.x=51*FP;
    pg_tick(&g,PG_UP);
    assert(g.vy<0);

    /* No unwanted mana loss from simply holding Right in an empty room. */
    empty_room(&g);
    g.mana=80;
    for(int i=0;i<120;i++)pg_tick(&g,PG_RIGHT);
    assert(g.mana>=80);
    assert(g.chargeTime==0);

    /* Hold Right near a real target, then release: a charged attack must
     * damage the target exactly once and consume mana. */
    empty_room(&g);
    g.enemyCount=1;
    g.enemies[0].kind=PG_SHOOTER;
    g.enemies[0].x=66*FP;g.enemies[0].y=72*FP;
    g.enemies[0].hp=6;g.enemies[0].cooldown=250;
    for(int i=0;i<65;i++)pg_tick(&g,PG_RIGHT);
    assert(g.chargeTime>=25 && g.mana==100);
    pg_tick(&g,0);
    assert(g.chargeTime==0 && g.mana==75 && g.enemies[0].hp==3);

    /* Long Left heals faster at a wall, but only while injured and using
     * mana; ordinary movement is independent of that resource. */
    empty_room(&g);
    g.x=3*FP;g.hp=40;g.mana=100;g.hurtClock=0;
    for(int i=0;i<65;i++)pg_tick(&g,PG_LEFT);
    assert(g.hp>40 && g.mana<100);

    /* Pause prevents simulation changes, including regeneration. */
    empty_room(&g);
    g.hp=40;g.hurtClock=0;g.steps=0;g.mana=0;
    for(int i=0;i<74;i++)pg_tick(&g,0);
    assert(g.hp==40);
    for(int i=0;i<40;i++)pg_tick(&g,0);
    assert(g.hp>40 && g.mana>0);
    pg_toggle_pause(&g);
    assert(g.phase==PG_PAUSE);
    PG_Game copy=g;
    for(int i=0;i<8;i++)pg_tick(&g,PG_RIGHT);
    assert(!memcmp(&g,&copy,sizeof(g)));
    pg_toggle_pause(&g);
    assert(g.phase==PG_RUN);
    g.hp=0;g.phase=PG_DEAD;
    pg_quick_attack(&g);
    assert(g.phase==PG_RUN && g.hp==100);
    puts("PASS: jump/landing, one-way platforms, wall collision, bounce, pit, coyote, attacks, healing, pause and regeneration");
}
static void fuzz(void) {
    uint32_t checksum=0;
    for(uint32_t seed=1;seed<=400;seed++) {
        PG_Game g;
        pg_new(&g,seed*4567u);
        for(unsigned i=0;i<520;i++) {
            uint8_t held=(uint8_t)(((i+seed)&7)==0?PG_RIGHT:
                          ((i+seed)&7)==1?PG_LEFT:
                          ((i+seed)&7)==2?PG_UP:
                          ((i+seed)&7)==3?(PG_RIGHT|PG_DOWN):
                          ((i+seed)&7)==4?(PG_LEFT|PG_UP):
                          ((i+seed)&7)==5?PG_DOWN:
                          ((i+seed)&7)==6?(PG_RIGHT|PG_UP):0);
            pg_tick(&g,held);
            if(i%19==0)pg_quick_attack(&g);
            if(g.phase==PG_DEAD)pg_quick_attack(&g);
            assert(g.hp<=100 && g.mana<=100);
            assert(g.enemyCount<=PG_ENEMIES);
            assert(g.theme<3);
            assert(g.x>=0 && g.x<=PG_W*FP);
            assert(g.y>=0 && g.y<=PG_H*FP);
        }
        checksum^=g.rng+(uint32_t)g.hp*17u+g.score;
    }
    assert(checksum);
    puts("PASS: 400 deterministic randomized 520-step simulations");
}
int main(void) {physics();fuzz();return 0;}
