/* Parkour Gauntlet 0.4: fixed-step integer platformer. MIT license. */
#include "parkour_logic.h"
#include <string.h>

#define FP 16
#define PLAYER_SPEED 24    /* 1.5 logical pixels per 20 ms */
#define DASH_SPEED 64
#define JUMP_SPEED (-68)
#define GRAVITY 5
#define FALL_LIMIT 72

static uint32_t rnd(PG_Game *g) {
    uint32_t x=g->rng;
    x^=x<<13; x^=x>>17; x^=x<<5;
    return g->rng=x?x:0x9e3779b9u;
}
uint8_t pg_detail(uint16_t tile,uint8_t salt) {
    uint32_t x=(uint32_t)tile*0x45d9f3bu+(uint32_t)salt*0x119de1f3u;
    x^=x>>16; x*=0x45d9f3bu;
    return (uint8_t)(x>>24);
}
static uint8_t tile(const PG_Game *g,int x,int y) {
    if(x<0||x>=PG_W||y<0) return PG_STONE;
    if(y>=PG_H) return PG_AIR; /* Bottomless pits: falling exits the playfield. */
    return g->cells[(y>>3)*PG_COLS+(x>>3)];
}
static uint8_t solid(uint8_t t) {
    /* Thin platforms and jump pads are one-way, not solid side walls. */
    return t==PG_STONE||t==PG_BREAK;
}
/* Positions are nonnegative while alive; reject outside walls explicitly.
 * Full blocks collide on every axis, but never block jumping up through
 * platforms. Fixed-point coordinates avoid movement-dependent rounding. */
static uint8_t collides(const PG_Game *g,int16_t xf,int16_t yf) {
    if(xf<0 || xf>(PG_W-PG_PLAYER_W)*FP || yf<0)return 1;
    int x=xf/FP,y=yf/FP;
    int xr=((int32_t)xf+PG_PLAYER_W*FP-1)/FP;
    int yb=((int32_t)yf+PG_PLAYER_H*FP-1)/FP;
    return solid(tile(g,x,y))||solid(tile(g,xr,y)) ||
           solid(tile(g,x,yb))||solid(tile(g,xr,yb));
}
static uint8_t one_way_landing(const PG_Game *g,int16_t oldY,int16_t newY,
                               int16_t *surfaceY,uint8_t *bounce) {
    if(newY<=oldY)return 0;
    int32_t oldBottom=(int32_t)oldY+PG_PLAYER_H*FP;
    int32_t newBottom=(int32_t)newY+PG_PLAYER_H*FP;
    int firstX=g->x/FP, lastX=(g->x+PG_PLAYER_W*FP-1)/FP;
    /* Every 8-pixel grid boundary crossed this substep is a candidate. */
    for(int top=((int)oldBottom/(8*FP))*(8*FP);top<=newBottom;top+=8*FP) {
        if(top<oldBottom || top>=PG_H*FP)continue;
        if(newBottom<=top)continue;
        for(int tx=firstX>>3;tx<=lastX>>3;tx++) {
            uint8_t t=tile(g,tx*8,top/FP);
            if(t==PG_PLATFORM||t==PG_BOUNCE) {
                *surfaceY=(int16_t)(top-PG_PLAYER_H*FP);
                *bounce=t==PG_BOUNCE;
                return 1;
            }
        }
    }
    return 0;
}
static uint8_t in_range(const PG_Game *g,int ex,int ey,int reach,uint8_t side) {
    int px=g->x/FP+PG_PLAYER_W/2,py=g->y/FP+PG_PLAYER_H/2;
    int dx=ex-px,dy=ey-py;
    return (dy>-20&&dy<20 && ((side && dx>=-3 && dx<reach) ||
                               (!side && dx<=3 && dx>-reach)));
}
static void make_room(PG_Game *g) {
    memset(g->cells,0,sizeof(g->cells));
    memset(g->enemies,0,sizeof(g->enemies));
    memset(g->shots,0,sizeof(g->shots));
    g->theme=(uint8_t)((g->room/2u)%3u);
    uint8_t variant=(uint8_t)(rnd(g)%6u);
    /* A guaranteed floor near the entry/exit. Other shapes are intentional,
     * short, bounded templates rather than arbitrary, possibly impossible maps. */
    for(int x=0;x<PG_COLS;x++) {
        g->cells[11*PG_COLS+x]=PG_STONE;
        g->cells[12*PG_COLS+x]=PG_STONE;
    }
    if(variant==0||variant==3) {
        for(int x=6;x<=8;x++)g->cells[11*PG_COLS+x]=PG_AIR;
        g->cells[8*PG_COLS+7]=PG_PLATFORM;
        g->cells[8*PG_COLS+8]=PG_PLATFORM;
    }
    if(variant==1||variant==4) {
        for(int x=5;x<=7;x++)g->cells[7*PG_COLS+x]=PG_PLATFORM;
        for(int x=11;x<=13;x++)g->cells[7*PG_COLS+x]=PG_PLATFORM;
        g->cells[10*PG_COLS+9]=PG_SPIKE;
    }
    if(variant==2||variant==5) {
        g->cells[10*PG_COLS+6]=PG_BOUNCE; /* One-way pad above the floor. */
        for(int x=9;x<=12;x++)g->cells[7*PG_COLS+x]=PG_PLATFORM;
        g->cells[10*PG_COLS+15]=PG_SPIKE;
    }
    if(variant==4) {
        g->cells[10*PG_COLS+13]=PG_BREAK;
        g->cells[9*PG_COLS+13]=PG_BREAK;
    }
    if(variant==3) for(int x=13;x<16;x++)g->cells[9*PG_COLS+x]=PG_PLATFORM;
    g->cells[10*PG_COLS+19]=PG_EXIT;
    g->enemyCount=(uint8_t)(1+(g->room>2)+(g->room>6));
    if(g->enemyCount>PG_ENEMIES)g->enemyCount=PG_ENEMIES;
    for(uint8_t i=0;i<g->enemyCount;i++) {
        PG_Enemy *e=&g->enemies[i];
        e->kind=(int8_t)((g->room%6==5 && i==0)?PG_BOSS:
                           (rnd(g)%3u));
        e->hp=(int8_t)(e->kind==PG_BOSS?6:e->kind==PG_FLYER?1:2);
        e->x=(int16_t)((87+i*22)*FP);
        e->y=(int16_t)((e->kind==PG_FLYER?58:72)*FP);
        e->cooldown=(uint8_t)(25+i*20);
    }
    g->x=12*FP;g->y=74*FP;g->vx=0;g->vy=0;
    g->grounded=0;g->dashReady=1;g->dashTime=0;
    g->coyote=0;g->jumpBuffer=0;g->previousInput=0;
    g->leftHold=0;g->rightHold=0;g->chargeTime=0;
    g->effectTime=0;g->attackTime=0;
}
void pg_new(PG_Game *g,uint32_t seed) {
    memset(g,0,sizeof(*g));
    g->rng=seed?seed:0x4deca77bu;
    g->hp=100;g->mana=100;g->phase=PG_RUN;
    g->facing=1;
    make_room(g);
}
void pg_toggle_pause(PG_Game *g) {
    if(g->phase==PG_PAUSE)g->phase=PG_RUN;
    else if(g->phase==PG_RUN){g->phase=PG_PAUSE;g->menuChoice=0;}
}
static void attack(PG_Game *g,int power,int reach) {
    if(g->phase!=PG_RUN)return;
    int hit=0;
    for(uint8_t i=0;i<g->enemyCount;i++) {
        PG_Enemy *e=&g->enemies[i];
        if(e->hp<=0)continue;
        int ex=e->x/FP+6,ey=e->y/FP+6;
        if(in_range(g,ex,ey,reach,g->facing)) {
            e->hp=(int8_t)(e->hp-power);
            hit=1;
            if(e->hp<=0) {g->score+=20;g->mana=g->mana<=95?g->mana+5:100;}
            else {
                int move=g->facing?4:-4;
                int newX=e->x+move*FP;
                if(newX>=0&&newX<=148*FP)e->x=(int16_t)newX;
            }
        }
    }
    if(power>1) {
        int cx=g->x/FP+PG_PLAYER_W/2+(g->facing?10:-10);
        int cy=g->y/FP+PG_PLAYER_H/2;
        if(cx>=0&&cx<PG_W&&cy>=0&&cy<PG_H) {
            int ti=(cy>>3)*PG_COLS+(cx>>3);
            if(g->cells[ti]==PG_BREAK){g->cells[ti]=PG_AIR;g->score+=5;hit=1;}
        }
    }
    g->attackTime=(uint8_t)(power>1?11:6);
    g->effectTime=(uint8_t)(power>1?13:7);
    g->effectX=(uint8_t)(g->x/FP+PG_PLAYER_W/2);
    g->effectY=(uint8_t)(g->y/FP+PG_PLAYER_H/2);
    (void)hit;
}
void pg_quick_attack(PG_Game *g) {
    if(g->phase==PG_DEAD){pg_new(g,g->rng^0x8c67a0d5u);return;}
    if(g->phase==PG_PAUSE){g->phase=PG_RUN;return;}
    if(g->attackTime<4)attack(g,1,21);
}
static void hit_player(PG_Game *g,uint8_t damage) {
    if(g->invulnerable||g->phase!=PG_RUN)return;
    if(g->dashTime) {
        if(!g->dashPerfect) {
            g->dashPerfect=1;
            g->score+=5;
            g->mana=g->mana<=94?(uint8_t)(g->mana+6):100;
        }
        return;
    }
    g->hp=g->hp>damage?(uint8_t)(g->hp-damage):0;
    g->hurtClock=0;g->invulnerable=25;g->effectTime=10;
    if(g->hp==0)g->phase=PG_DEAD;
}
static void move_axis(PG_Game *g,int16_t amount,uint8_t vertical) {
    int16_t remaining=amount;
    while(remaining) {
        /* One logical pixel maximum per substep prevents tunnelling through
         * 8px walls even with maximum dash or fall speed. */
        int16_t d=remaining>FP?FP:remaining< -FP?-FP:remaining;
        remaining=(int16_t)(remaining-d);
        int16_t oldX=g->x,oldY=g->y;
        int16_t nx=(int16_t)(oldX+(vertical?0:d));
        int16_t ny=(int16_t)(oldY+(vertical?d:0));
        int16_t surfaceY=0;
        uint8_t bounce=0;
        if(vertical && one_way_landing(g,oldY,ny,&surfaceY,&bounce)) {
            g->y=surfaceY;
            g->grounded=(uint8_t)!bounce;
            g->dashReady=1;
            g->vy=bounce?-83:0;
            return;
        }
        if(!collides(g,nx,ny)) {
            g->x=nx;g->y=ny;
        } else {
            /* Advance as far as possible within this 1px substep. This
             * eliminates visible sticking/jitter against tile boundaries. */
            int direction=d>0?1:-1,lo=0,hi=d>0?d:-d;
            while(lo<hi) {
                int mid=(lo+hi+1)/2;
                int16_t tx=(int16_t)(oldX+(vertical?0:direction*mid));
                int16_t ty=(int16_t)(oldY+(vertical?direction*mid:0));
                if(collides(g,tx,ty))hi=mid-1;
                else lo=mid;
            }
            if(vertical) {
                g->y=(int16_t)(oldY+direction*lo);
                if(d>0){g->grounded=1;g->dashReady=1;}
                g->vy=0;
            } else {
                g->x=(int16_t)(oldX+direction*lo);
                g->vx=0;
            }
            return;
        }
    }
}
static void player_step(PG_Game *g,uint8_t held) {
    uint8_t pressed=(uint8_t)(held&~g->previousInput);
    g->previousInput=held;
    if(pressed&PG_UP)g->jumpBuffer=6;
    if(g->jumpBuffer)g->jumpBuffer--;
    if(g->grounded)g->coyote=5;
    else if(g->coyote)g->coyote--;
    if((held&PG_LEFT) && !(held&PG_RIGHT))g->leftHold=g->leftHold<250?g->leftHold+1:250;
    else g->leftHold=0;
    if((held&PG_RIGHT)&&!(held&PG_LEFT))g->rightHold=g->rightHold<250?g->rightHold+1:250;
    else {
        /* Release charged strike only when an eligible target is actually near.
         * Ordinary runs across empty rooms never spend mana. */
        if(g->chargeTime>=25 && g->mana>=25) {
            uint8_t valid=0;
            for(uint8_t i=0;i<g->enemyCount;i++) {
                PG_Enemy *e=&g->enemies[i];
                if(e->hp>0 && in_range(g,e->x/FP+6,e->y/FP+6,38,1))valid=1;
            }
            if(tile(g,g->x/FP+PG_PLAYER_W+6,g->y/FP+PG_PLAYER_H/2)==PG_BREAK)valid=1;
            if(valid){g->facing=1;g->mana-=25;attack(g,3,38);}
        }
        g->chargeTime=0;
        g->rightHold=0;
    }
    if(g->jumpBuffer && (g->grounded||g->coyote)) {
        g->vy=JUMP_SPEED;
        g->grounded=0;g->coyote=0;g->jumpBuffer=0;
    } else if(g->jumpBuffer && !g->grounded) {
        int touchLeft=(held&PG_LEFT)&&collides(g,(int16_t)(g->x-16),g->y);
        int touchRight=(held&PG_RIGHT)&&collides(g,(int16_t)(g->x+16),g->y);
        if(touchLeft||touchRight) {
            g->vy=JUMP_SPEED;
            g->vx=(int16_t)(touchLeft?45:-45);
            g->wallLock=5;g->jumpBuffer=0;g->coyote=0;
            g->dashReady=1;
        }
    }
    if((pressed&PG_DOWN) && g->dashReady) {
        g->dashTime=7;
        g->dashReady=0;g->dashPerfect=0;
        if(held&PG_LEFT)g->facing=0;
        else if(held&PG_RIGHT)g->facing=1;
    }
    /* Charge only with a nearby enemy or destructible wall on the right.
     * While charging, movement slows; otherwise holding Right remains Run. */
    uint8_t hasTarget=0;
    if(g->rightHold>15 && g->mana>=25) {
        for(uint8_t i=0;i<g->enemyCount;i++) {
            PG_Enemy *e=&g->enemies[i];
            if(e->hp>0 && in_range(g,e->x/FP+6,e->y/FP+6,38,1))hasTarget=1;
        }
        int cx=g->x/FP+PG_PLAYER_W+6,cy=g->y/FP+PG_PLAYER_H/2;
        if(tile(g,cx,cy)==PG_BREAK)hasTarget=1;
    }
    if(hasTarget) {if(g->chargeTime<85)g->chargeTime++;}
    else g->chargeTime=0;
    if(g->dashTime) {
        g->dashTime--;
        g->vx=(int16_t)(g->facing?DASH_SPEED:-DASH_SPEED);
    } else if(g->wallLock) {
        g->wallLock--;
    } else {
        int target=0;
        if((held&PG_LEFT)&&!(held&PG_RIGHT))target=-PLAYER_SPEED;
        if((held&PG_RIGHT)&&!(held&PG_LEFT))target=hasTarget?4:PLAYER_SPEED;
        if(target==0)g->vx=(int16_t)(g->vx/2);
        else g->vx=(int16_t)(g->vx+(target>g->vx?5:-5));
        if(target && ((g->vx>0&&target>0)||(g->vx<0&&target<0))) {
            if(target>0&&g->vx>target)g->vx=(int16_t)target;
            if(target<0&&g->vx<target)g->vx=(int16_t)target;
        }
        if(target<0)g->facing=0;
        else if(target>0)g->facing=1;
    }
    /* Holding Jump slightly reduces early ascent gravity: variable jump. */
    if(!(held&PG_UP)&&g->vy< -30)g->vy=(int16_t)(g->vy+10);
    g->vy=(int16_t)(g->vy+GRAVITY);
    if(!g->grounded && g->vy>22 &&
       (((held&PG_LEFT)&&collides(g,(int16_t)(g->x-16),g->y)) ||
        ((held&PG_RIGHT)&&collides(g,(int16_t)(g->x+16),g->y))))
        g->vy=22; /* wall slide */
    if(g->vy>FALL_LIMIT)g->vy=FALL_LIMIT;
    g->grounded=0;
    move_axis(g,g->vx,0);
    move_axis(g,g->vy,1);
    /* A floor-mounted pad also works when approached by running along the
     * floor: the character's feet overlap its decorated upper tile. */
    int footX=g->x/FP+PG_PLAYER_W/2;
    int footY=g->y/FP+PG_PLAYER_H-1;
    if(g->vy>=0 && tile(g,footX,footY)==PG_BOUNCE) {
        g->vy=-83;g->grounded=0;g->dashReady=1;
    }
    uint8_t hurt=0;
    for(int dx=1;dx<PG_PLAYER_W-1;dx+=6) {
        if(tile(g,g->x/FP+dx,g->y/FP+PG_PLAYER_H-1)==PG_SPIKE)hurt=1;
    }
    if(hurt)hit_player(g,18);
    if(g->y>(PG_H-PG_PLAYER_H+2)*FP) {
        /* Pit death must not be cancelled by dash invulnerability. */
        g->hp=0;g->phase=PG_DEAD;return;
    }
    if(g->x>=147*FP && g->grounded) {
        g->score+=100;g->room++;make_room(g);
    }
}
static void enemy_step(PG_Game *g) {
    for(uint8_t i=0;i<g->enemyCount;i++) {
        PG_Enemy *e=&g->enemies[i];
        if(e->hp<=0)continue;
        if(e->cooldown)e->cooldown--;
        if(e->kind==PG_WALKER||e->kind==PG_BOSS) {
            if(!(g->steps&3)) {
                int newX=e->x+(e->x>g->x?-8:8);
                int x=newX/FP,y=e->y/FP+12;
                if(x>32&&x<145&&tile(g,x+5,y+2)==PG_STONE)e->x=(int16_t)newX;
            }
        } else if(e->kind==PG_FLYER) {
            if(!(g->steps&3))e->x=(int16_t)(e->x+(e->x>g->x?-11:11));
            e->y=(int16_t)((57+((g->steps/9+i)%4)*2)*FP);
        } else if(e->kind==PG_SHOOTER&&!e->cooldown) {
            for(uint8_t j=0;j<PG_PROJECTILES;j++)if(!g->shots[j].live) {
                PG_Bullet *b=&g->shots[j];
                b->x=e->x;b->y=(int16_t)(e->y+7*FP);
                b->vx=(int16_t)(g->x<e->x?-23:23);
                b->live=1;e->cooldown=65;break;
            }
        }
        int dx=e->x/FP-g->x/FP,dy=e->y/FP-g->y/FP;
        if(dx>-9&&dx<10&&dy>-11&&dy<14)hit_player(g,12);
    }
    for(uint8_t j=0;j<PG_PROJECTILES;j++) {
        PG_Bullet *b=&g->shots[j];
        if(!b->live)continue;
        b->x=(int16_t)(b->x+b->vx);
        if(b->x<=0||b->x>=PG_W*FP||solid(tile(g,b->x/FP,b->y/FP))) {
            b->live=0;continue;
        }
        int dx=b->x/FP-g->x/FP,dy=b->y/FP-g->y/FP;
        if(dx>=0&&dx<PG_PLAYER_W&&dy>=0&&dy<PG_PLAYER_H) {
            hit_player(g,10);b->live=0;
        }
    }
}
void pg_tick(PG_Game *g,uint8_t held) {
    if(g->phase!=PG_RUN)return;
    g->steps++;
    if(g->invulnerable)g->invulnerable--;
    if(g->attackTime)g->attackTime--;
    if(g->effectTime)g->effectTime--;
    player_step(g,held);
    if(g->phase!=PG_RUN)return;
    enemy_step(g);
    /* Fast but delayed natural regeneration: 8 HP/s after 1.5 s safe. */
    if(g->hurtClock<250)g->hurtClock++;
    if(g->hurtClock>=75&&g->hp<100 && g->steps%6==0)g->hp++;
    /* Manual healing: stand near a wall while holding Left; prevents routine
     * leftward traversal from consuming mana by accident. */
    if(g->leftHold>=40 && (g->x<18*FP || !g->vx) &&
       g->hp<100 && g->mana && (g->steps%2==0)) {
        g->hp++;
        if(!(g->healClock++&1))g->mana--;
    }
    if(g->steps%10==0 && g->mana<100)g->mana++;
}
