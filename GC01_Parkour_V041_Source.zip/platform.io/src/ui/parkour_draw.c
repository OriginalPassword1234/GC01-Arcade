/* Parkour Gauntlet 0.4: 4bpp sprites composited in a 512-byte RGB565 tile.
 * No full-screen framebuffer. One drawImage transfer per changed tile.
 * MIT license. */
#if defined(GC01_PARKOUR) || defined(PG_DRAW_TEST)
#include <string.h>
#include "parkour_draw.h"
#include "parkour_art.h"
#if defined(PG_DRAW_TEST)
#include <stdint.h>
typedef uint16_t mr_color_t;
#define RGB(x) ((uint16_t)(((((x)>>19)&31u)<<11) | ((((x)>>10)&63u)<<5) | (((x)>>3)&31u)))
extern void pg_test_image(int x,int y,int w,int h,const mr_color_t *pixels);
extern void pg_test_rect(int x,int y,int w,int h,mr_color_t color);
#else
#include "draw.h"
#define RGB(x) mr_get_color(x)
extern mr_t mr;
#endif
#define SCREEN_TOP 32
#define PHYS_TILE 16
#define PIXELS 256

typedef struct {
    mr_color_t sky, sky2, distant, wall, edge, platform, shade;
    mr_color_t hazard, bounce, breakable, accent, hud;
} Theme;
static const Theme themes[3]={
 {RGB(0x142740),RGB(0x304a6b),RGB(0x253450),RGB(0x515d76),RGB(0x839db3),RGB(0x8d9da8),RGB(0x25384e),RGB(0xff675e),RGB(0x59e0c5),RGB(0xd9aa77),RGB(0xffd17d),RGB(0x0b172a)},
 {RGB(0x2c2537),RGB(0x49364a),RGB(0x383143),RGB(0x66555c),RGB(0xba9985),RGB(0xa48b71),RGB(0x372b36),RGB(0xffac4f),RGB(0x85e2d4),RGB(0xe9c08a),RGB(0xffd87b),RGB(0x221c2c)},
 {RGB(0x101f34),RGB(0x22354f),RGB(0x152944),RGB(0x334868),RGB(0x568aa4),RGB(0x6396ad),RGB(0x15293e),RGB(0xeb5f9b),RGB(0x65ddee),RGB(0xc68ee4),RGB(0xb5f7ff),RGB(0x0a1a2e)},
};
/* Dark outline, cape, armor, skin, hair, visor, energy, etc. */
static const mr_color_t spriteColor[16]={
  RGB(0x000000),RGB(0x101828),RGB(0x532f58),RGB(0x31799e),
  RGB(0x70d5df),RGB(0xedbc91),RGB(0x292841),RGB(0x202a3b),
  RGB(0xffcc63),RGB(0xf9f0d6),RGB(0x83eff0),RGB(0xb56c7a),
  RGB(0xef778b),RGB(0x718e9f),RGB(0xecb16e),RGB(0xd4f4fc)
};
static mr_color_t buffer[PIXELS]; /* 512 bytes SRAM */
static uint8_t dirty[PG_TILES];
static PG_Game previous; /* snapshot for dirty-object tracking; ~400 bytes */
static uint8_t valid, overlayVisible, previousTheme;
static void rect(int x,int y,int w,int h,mr_color_t color) {
    if(x<0||y<0||w<=0||h<=0||x+w>320||y+h>240)return;
#if defined(PG_DRAW_TEST)
    pg_test_rect(x,y,w,h,color);
#else
    mr_set_fill_color(&mr,color);
    drawRectangle(&(mr_rectangle_t){(int16_t)x,(int16_t)y,(int16_t)w,(int16_t)h});
#endif
}
static mr_color_t scenery(const PG_Game *g,int x,int y,uint8_t v,uint8_t band) {
    const Theme *t=&themes[g->theme];
    int tx=x/8,ty=y/8,rx=x&7,ry=y&7;
    uint8_t tile=g->cells[ty*PG_COLS+tx];
    if(tile==PG_AIR||tile==PG_EXIT||tile==PG_SPIKE||tile==PG_BOUNCE) {
        mr_color_t bg=y<24?t->sky:(y<57?t->sky2:t->distant);
        if(g->theme==0) {
            /* Rooftops: tiny stars, glowing moon, and multiple city layers. */
            int dx=x-121,dy=y-17,d2=dx*dx+dy*dy;
            if(d2<130)bg=(dx+dy>2)?RGB(0xc1d9d9):RGB(0xf2d6aa);
            if(d2<70 && dx>0&&dy<0)bg=RGB(0xffedc0);
            if(d2>=135&&d2<160)bg=RGB(0x6f9aaf);
            if(y<45 && (((unsigned)x*37u ^ (unsigned)y*83u ^
                         (unsigned)(x*y)*3u)&127u)==0u)
                bg=t->accent; /* Stable star field; no per-pixel hash call. */
            int skyline=40+(band%25);
            if(y>=skyline) {
                bg=y==skyline?t->edge:t->distant;
                if((x%7==2||x%7==4) && (y%8==2||y%8==3))
                    bg=(band&1)?RGB(0xf1b974):RGB(0x73c6cf);
            }
            if(y>=66+(v&7))bg=t->shade;
        } else if(g->theme==1) {
            /* Factory: illuminated ventilation stacks and hot-smoke skyline. */
            if(y<31 && (pg_detail((uint16_t)(x/13),3)&3)==0 && (x%13<7))
                bg=RGB(0x62445a);
            if(y>=34+(band%20) && (x%15)<7) {
                bg=y%14==0?t->edge:t->distant;
                if(x%15==2)bg=t->wall;
                if(y%13==6 && x%15==5)bg=t->accent;
            }
            if(y>=67+(v&7))bg=t->shade;
        } else {
            /* Crystal cavern: dark ceiling teeth and luminous mineral veins. */
            int teeth=3+(band&15);
            if(y<teeth && x%11<8)bg=t->wall;
            if(y<teeth && x%11==4)bg=t->edge;
            if(y>=41+(band%17) && (x%17)<4)bg=t->shade;
            if(((x+2*y)%23)==0 && y<77)bg=t->bounce;
            if(y>43 && (x%17==2||x%17==3) && (y%17>9))bg=t->accent;
        }
        if(tile==PG_SPIKE && ry>2) {
            int mid=rx&3;
            if(ry>=7-(mid<=1?mid:3-mid)*2)bg=t->hazard;
        }
        if(tile==PG_BOUNCE && ry>=5)
            bg=(ry==5||rx==1||rx==6)?t->accent:t->bounce;
        if(tile==PG_EXIT && (rx==2||rx==5 ||ry==1||ry==6))bg=t->accent;
        return bg;
    }
    if(tile==PG_PLATFORM) {
        if(ry==0)return t->accent;
        if(ry==1)return t->edge;
        if((rx==0||rx==7)&&ry<5)return t->shade;
        if(ry==3 && (rx==2||rx==5))return t->edge; /* Tiny metal rivets. */
        return ry<4?t->platform:t->shade;
    }
    mr_color_t c=t->wall;
    if(ry==0)c=t->edge;
    else if((rx==0&&((tx^ty)&1))||(ry==5 && rx<4))c=t->shade;
    else if((v&7)==0 && rx==3 && ry==3)c=t->accent;
    if(tile==PG_BREAK&&(rx==4||((rx==3||rx==5)&&ry==4)))c=t->breakable;
    return c;
}
static uint8_t asset_pixel(uint8_t index,int sx,int sy,uint8_t mirror) {
    if(sx<0||sx>=12||sy<0||sy>=16)return 0;
    if(mirror)sx=11-sx;
    uint8_t data=pg_art[index][sy*6+(sx>>1)];
    return (uint8_t)((sx&1)?data&15u:data>>4);
}
/* Opaque background first, then draw *only* sprites intersecting this 8x8
 * logical tile. The 0.4 compositor tested every enemy and projectile on
 * every pixel, even for tiles nowhere near an entity; that caused expensive
 * transfers and could make motion look uneven on the MCU. */
static void put_pixel(int tx,int ty,int x,int y,mr_color_t c) {
    int dx=x-tx,dy=y-ty;
    if((unsigned)dx>=8u || (unsigned)dy>=8u)return;
    int i=dy*32+dx*2;
    buffer[i]=c;buffer[i+1]=c;
    buffer[i+16]=c;buffer[i+17]=c;
}
static void sprite(int tx,int ty,int px,int py,uint8_t frame,uint8_t mirror,
                   uint8_t shade) {
    int xs=tx>px?tx-px:0;
    int ys=ty>py?ty-py:0;
    int xe=tx+8-px<12?tx+8-px:12;
    int ye=ty+8-py<16?ty+8-py:16;
    for(int sy=ys;sy<ye;sy++)for(int sx=xs;sx<xe;sx++) {
        uint8_t idx=asset_pixel(frame,sx,sy,mirror);
        if(idx) {
            if(shade && idx!=1)idx=(uint8_t)((idx==9||idx==8)?10:3);
            put_pixel(tx,ty,px+sx,py+sy,spriteColor[idx]);
        }
    }
}
static void render_tile(const PG_Game *g,int tx,int ty) {
    int lx=tx*8,ly=ty*8;
    /* Tile decorations are constant across the 8x8 square; calculate the
     * expensive hash once per tile instead of 64 times. */
    uint8_t detail=pg_detail((uint16_t)(tx+ty*PG_COLS),0);
    uint8_t bands[8];
    for(int x=0;x<8;x++)
        bands[x]=pg_detail((uint16_t)((lx+x)/11+23),1);
    for(int y=0;y<8;y++)for(int x=0;x<8;x++) {
        mr_color_t c=scenery(g,lx+x,ly+y,detail,bands[x]);
        int i=y*32+x*2;
        buffer[i]=c;buffer[i+1]=c;
        buffer[i+16]=c;buffer[i+17]=c;
    }
    /* Short contact shadow grounds the character and gives a little more
     * depth without requiring another bitmap or a large alpha buffer. */
    if(g->grounded) {
        int footX=g->x/16+PG_PLAYER_W/2;
        int footY=g->y/16+PG_PLAYER_H;
        for(int dx=-5;dx<=5;dx++)
            if(dx*dx<25)
                put_pixel(lx,ly,footX+dx,footY,
                          themes[g->theme].shade);
    }
    for(uint8_t i=0;i<g->enemyCount;i++) {
        const PG_Enemy *e=&g->enemies[i];
        if(e->hp<=0 || (unsigned)e->kind>PG_BOSS)continue;
        int px=e->x/16,py=e->y/16-3;
        if(px>=lx+8||px+12<=lx||py>=ly+8||py+16<=ly)continue;
        sprite(lx,ly,px,py,(uint8_t)(8+e->kind*2+((g->steps/10)&1)),0,0);
    }
    for(uint8_t i=0;i<PG_PROJECTILES;i++) {
        const PG_Bullet *b=&g->shots[i];
        if(!b->live)continue;
        int cx=b->x/16,cy=b->y/16;
        if(cx+1<lx||cx-1>=lx+8||cy+1<ly||cy-1>=ly+8)continue;
        for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++)
            put_pixel(lx,ly,cx+x,cy+y,spriteColor[(x==0&&y==0)?15:10]);
    }
    if(g->effectTime && g->attackTime) {
        int ex=g->x/16+(g->facing?15:-4);
        int ey=g->y/16+5;
        if(ex+7>=lx&&ex-7<lx+8&&ey+7>=ly&&ey-7<ly+8)
        for(int y=0;y<8;y++)for(int x=0;x<8;x++) {
            int dx=lx+x-ex,dy=ly+y-ey,d2=dx*dx+dy*dy;
            if(d2>=18&&d2<55)
                put_pixel(lx,ly,lx+x,ly+y,
                          spriteColor[(g->effectTime&2)?8:9]);
        }
    }
    uint8_t animation=0;
    if(g->chargeTime)animation=6;
    else if(g->attackTime)animation=5;
    else if(g->dashTime)animation=7;
    else if(!g->grounded)animation=g->vy<0?3:4;
    else if(g->vx>5||g->vx< -5)animation=(uint8_t)(1+(g->steps/5)%2);
    int px=g->x/16-1,py=g->y/16-2;
    /* Subdued afterimage when dashing: reuses the existing animation. */
    if(g->dashTime) {
        int shadowX=px+(g->facing?-6:6);
        if(shadowX<lx+8&&shadowX+12>lx&&py<ly+8&&py+16>ly)
            sprite(lx,ly,shadowX,py,7,(uint8_t)!g->facing,1);
    }
    if(!(g->invulnerable&&(g->steps&2)) &&
       px<lx+8&&px+12>lx&&py<ly+8&&py+16>ly)
        sprite(lx,ly,px,py,animation,(uint8_t)!g->facing,0);
    if(g->leftHold>=40 && g->hp<100 && g->mana &&
       (g->x<18*16 || !g->vx)) {
        /* Spare animation for active, mana-assisted healing. */
        int cx=g->x/16+5,cy=g->y/16+7;
        if(cx+9>=lx&&cx-9<lx+8&&cy+9>=ly&&cy-9<ly+8)
        for(int y=0;y<8;y++)for(int x=0;x<8;x++) {
            int dx=lx+x-cx,dy=ly+y-cy,d2=dx*dx+dy*dy;
            if(d2>=65&&d2<82 && ((lx+x+ly+y+g->steps/3)&3)==0)
                put_pixel(lx,ly,lx+x,ly+y,spriteColor[4]);
        }
    }
    if(g->chargeTime && (g->steps&3)<3) {
        int cx=g->x/16+5,cy=g->y/16+7;
        if(cx+13>=lx&&cx-13<lx+8&&cy+13>=ly&&cy-13<ly+8)
        for(int y=0;y<8;y++)for(int x=0;x<8;x++) {
            int dx=lx+x-cx,dy=ly+y-cy,d2=dx*dx+dy*dy;
            if(d2>=125&&d2<148)
                put_pixel(lx,ly,lx+x,ly+y,spriteColor[(g->steps&2)?8:10]);
        }
    }
#if defined(PG_DRAW_TEST)
    pg_test_image(lx*2,ly*2+SCREEN_TOP,16,16,buffer);
#else
    drawImage(&(mr_rectangle_t){(int16_t)(lx*2),(int16_t)(ly*2+SCREEN_TOP),16,16},buffer);
#endif
}
static void mark_rect(int x,int y,int w,int h) {
    if(x<0){w+=x;x=0;}
    if(y<0){h+=y;y=0;}
    if(x>=PG_W||y>=PG_H||w<=0||h<=0)return;
    if(x+w>PG_W)w=PG_W-x;
    if(y+h>PG_H)h=PG_H-y;
    int left=x/8,top=y/8,right=(x+w-1)/8,bottom=(y+h-1)/8;
    for(int a=top;a<=bottom;a++)for(int b=left;b<=right;b++)dirty[a*PG_COLS+b]=1;
}
static void mark_entities(const PG_Game *g) {
    /* Invalidate exact old/new sprite footprints, including effects. The
     * former fixed 31x28 player box needlessly repainted dozens of tiles. */
    mark_rect(g->x/16-1,g->y/16-2,12,16);
    if(g->grounded)
        mark_rect(g->x/16,g->y/16+PG_PLAYER_H,PG_PLAYER_W,1);
    if(g->dashTime)
        mark_rect(g->x/16+(g->facing?-7:5),g->y/16-2,12,16);
    if(g->effectTime && g->attackTime) {
        int ex=g->x/16+(g->facing?15:-4),ey=g->y/16+5;
        mark_rect(ex-7,ey-7,15,15);
    }
    if(g->chargeTime) {
        int cx=g->x/16+5,cy=g->y/16+7;
        mark_rect(cx-13,cy-13,27,27);
    }
    if(g->leftHold>=40 && g->hp<100 && g->mana &&
       (g->x<18*16 || !g->vx)) {
        int cx=g->x/16+5,cy=g->y/16+7;
        mark_rect(cx-9,cy-9,19,19);
    }
    for(uint8_t i=0;i<g->enemyCount;i++) {
        const PG_Enemy *e=&g->enemies[i];
        if(e->hp>0)mark_rect(e->x/16,e->y/16-3,12,16);
    }
    for(uint8_t i=0;i<PG_PROJECTILES;i++) {
        const PG_Bullet *b=&g->shots[i];
        if(b->live)mark_rect(b->x/16-1,b->y/16-1,3,3);
    }
}
static void bar(int x,int y,uint8_t value,mr_color_t fill,mr_color_t shadow) {
    rect(x,y,108,12,RGB(0x040d19));
    rect(x+2,y+2,104,8,shadow);
    int width=(int)value*104/100;
    if(width)rect(x+2,y+2,width,8,fill);
    if(width>1)rect(x+2,y+2,width,2,RGB(0xf4f8f0));
}
static const uint16_t nums[10]={0x7b6f,0x2c97,0x73e7,0x73cf,0x5bc9,0x79cf,0x79ef,0x7292,0x7bef,0x7bcf};
static const uint16_t word[26]={0x2bed,0x6bae,0x3923,0x6b6e,0x79a7,0x79a4,0x396b,0x5bed,0x7497,0x126a,0x5bad,0x4927,0x5fed,0x5ffd,0x2b6a,0x6ba4,0x2b7b,0x6bad,0x388e,0x7492,0x5b6f,0x5b6a,0x5bfd,0x5aad,0x5a92,0x72a7};
static void text(const char *s,int x,int y,int scale,mr_color_t c) {
    for(;*s;s++,x+=4*scale){
        uint16_t p=(*s>='0'&&*s<='9')?nums[*s-'0']:
                   (*s>='A'&&*s<='Z')?word[*s-'A']:0;
        for(int row=0;row<5;row++)for(int col=0;col<3;col++)
            if(p&(1u<<(14-row*3-col)))rect(x+col*scale,y+row*scale,scale,scale,c);
    }
}
static void number(uint32_t value,int x,int y,mr_color_t c) {
    char out[12];int n=0;
    do {out[n++]=(char)('0'+value%10u);value/=10u;}while(value&&n<11);
    for(int i=0;i<n/2;i++){char tmp=out[i];out[i]=out[n-1-i];out[n-1-i]=tmp;}
    out[n]=0;text(out,x,y,2,c);
}
static void hud_stats(const PG_Game *g) {
    const Theme *t=&themes[g->theme];
    rect(232,1,88,29,t->hud);
    text("R",237,5,2,t->accent);number(g->room+1u,251,5,RGB(0xf7e4c5));
    number(g->score,237,18,RGB(0xf7e4c5));
}
static void hud(const PG_Game *g) {
    const Theme *t=&themes[g->theme];
    rect(0,0,320,SCREEN_TOP,t->hud);
    rect(0,SCREEN_TOP-2,320,2,t->edge);
    rect(5,6,7,7,RGB(0xf14e65));rect(7,12,3,3,RGB(0xf14e65));
    rect(5,19,7,7,RGB(0x3b8eff));rect(7,17,3,3,RGB(0x7adcf7));
    bar(17,4,g->hp,RGB(0xf05a6b),RGB(0x511d32));
    bar(17,18,g->mana,RGB(0x4baff3),RGB(0x19375f));
    hud_stats(g);
}
static void overlay(const PG_Game *g) {
    const Theme *t=&themes[g->theme];
    rect(42,77,236,100,t->hud);
    rect(42,77,236,3,t->accent);
    if(g->phase==PG_PAUSE) {
        text("PAUSED",75,93,4,RGB(0xf2e5d4));
        text("RESUME",85,132,2,g->menuChoice==0?t->accent:RGB(0x8c9ba8));
        text("EXIT",85,153,2,g->menuChoice==1?t->accent:RGB(0x8c9ba8));
    } else {
        text("GAME OVER",56,93,3,RGB(0xff738a));
        text("TAP RESTART",69,140,2,t->accent);
    }
}
void pg_draw(const PG_Game *g,bool force) {
    if(!g)return;
    if(!valid||previousTheme!=g->theme||previous.room!=g->room||
       (overlayVisible&&g->phase==PG_RUN))force=true;
    memset(dirty,force?1:0,sizeof(dirty));
    if(!force){
        for(unsigned i=0;i<PG_TILES;i++)if(previous.cells[i]!=g->cells[i])dirty[i]=1;
        mark_entities(&previous);
        mark_entities(g);
    }
    for(int ty=0;ty<PG_ROWS;ty++)for(int tx=0;tx<PG_COLS;tx++)
        if(dirty[ty*PG_COLS+tx])render_tile(g,tx,ty);
    if(force)hud(g);
    else {
        if(previous.hp!=g->hp)
            bar(17,4,g->hp,RGB(0xf05a6b),RGB(0x511d32));
        if(previous.mana!=g->mana)
            bar(17,18,g->mana,RGB(0x4baff3),RGB(0x19375f));
        if(previous.score!=g->score||previous.room!=g->room)
            hud_stats(g);
    }
    if(g->phase!=PG_RUN && (force||!overlayVisible||previous.phase!=g->phase||previous.menuChoice!=g->menuChoice))overlay(g);
    overlayVisible=g->phase!=PG_RUN;
    valid=1;previousTheme=g->theme;
    memcpy(&previous,g,sizeof(previous));
}
#endif
