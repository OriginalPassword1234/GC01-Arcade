set -euo pipefail
cd radpro
RAW=platform.io/.pio/build/fnirsi-gc01_apm32f103rb-en/firmware.bin
ELF=platform.io/.pio/build/fnirsi-gc01_apm32f103rb-en/firmware.elf
SIGNED=fnirsi-gc01_apm32f103rb/firmware/radpro-fnirsi-gc01_apm32f103rb-en-3.1.1.bin
test -s "$SIGNED" || { echo "ERROR: expected signed image missing: $SIGNED" >&2; exit 1; }
python3 rider_ci/verify_expanded.py "$RAW" "$ELF" "$SIGNED" 2>&1 | tee /tmp/rider_expanded_audit.log
mkdir -p ../dist/source
cp rider_ci/src/rider_core.c rider_ci/src/rider_core.h rider_ci/src/rider_render.c rider_ci/src/rider_render.h ../dist/source/
cp rider_ci/README_V19.md rider_ci/README_V20.md rider_ci/README_V21.md ../dist/source/
printf 'ARM nominal headroom must be >= 3328 bytes; renderer arrays are 3064 B and hash cache 480 B.\n' > ../dist/tests/V17_RAM_NOTES.txt
cp rider_ci/rider_saves.c rider_ci/rider_saves.h overlay/platform.io/src/extras/rider_app.c ../dist/source/
cp rider_ci/README_V25.md ../dist/source/README_V25.md
cp rider_ci/README_V26.md ../dist/source/README_V26.md
cp rider_ci/README_V29.md ../dist/source/README_V29.md
cp rider_ci/README_V33.md ../dist/source/README.md
mkdir -p ../dist/source/texture_reference
cp rider_ci/tests/test_terrain_delta.c rider_ci/tools/check_terrain_delta.py ../dist/source/
cp rider_ci/tests/texture_reference/v29_terrain.h ../dist/source/texture_reference/
cp rider_ci/README_V28.md ../dist/source/README_V28.md
cp -a rider_ci/local_verification ../dist/source/
cp rider_ci/datalog_v28.c rider_ci/tests/test_datalog_v27.c rider_ci/tests/test_minute_v28.c rider_ci/tests/test_fault_v28.c rider_ci/tests/test_datalog_storage.c rider_ci/tests/datalog_shim.h rider_ci/tests/run_datalog_v28.sh rider_ci/install_datalog_v28.py rider_ci/apply_expanded_layout.py rider_ci/test_expanded_layout.py rider_ci/verify_expanded.py rider_ci/rider_screen.c ../dist/source/
cp rider_ci/tools/check_mixed_abi.c rider_ci/tools/compact_backend.py rider_ci/tests/run_compact_lossless.sh ../dist/source/
cp rider_ci/tests/test_lossless.c rider_ci/tests/run_lossless.sh rider_ci/select_size_profile.sh rider_ci/preflight_profile.py ../dist/source/
cp -a rider_ci/tests/reference_v21a ../dist/source/
cp rider_ci/tests/test_v11.c ../dist/source/test_v11.c
cp rider_ci/tests/test_reference_repairs.c rider_ci/tests/test_v12.c rider_ci/tests/test_v13.c rider_ci/tests/test_v14.c rider_ci/tests/test_v15.c rider_ci/tests/test_v16.c rider_ci/tests/test_v17.c rider_ci/tests/test_v18.c rider_ci/tests/test_v19.c rider_ci/tests/test_v20.c rider_ci/tests/render_timing.c rider_ci/tests/render_audit.c rider_ci/tests/render_run.c ../dist/source/
cp rider_ci/tests/test_v21.c rider_ci/tests/test_lcd_extended.c ../dist/source/
cp rider_ci/tests/test_v31.c rider_ci/tests/test_unchanged_v31.c rider_ci/tests/run_v31.sh rider_ci/tests/render_fixture_v31.c rider_ci/tests/run_unchanged_v31.sh rider_ci/tests/test_app_v31.c rider_ci/tests/run_app_v31.sh rider_ci/tests/app_shim_v31.h rider_ci/tests/bench_compare_v31.c rider_ci/tests/run_bench_compare_v31.sh ../dist/source/
cp rider_ci/tests/*v32.c rider_ci/tests/*v32.sh rider_ci/tests/*v33.c rider_ci/tests/*v33.sh ../dist/source/
cp rider_ci/README_V31.md ../dist/source/README_V31.md
cp -a rider_ci/baseline_v31 rider_ci/baseline_v32 ../dist/source/
cp "$SIGNED" ../dist/GC01_RIDER_V33_76K_APM32_DO_NOT_FLASH.bin
cp "$ELF" ../dist/GC01_RIDER_V33_76K_APM32_DIAGNOSTIC.elf
cp /tmp/rider_expanded_audit.log ../dist/ADDRESS_AND_MEMORY_AUDIT.txt
cat > ../dist/READ_BEFORE_FLASHING.txt <<'TXT'
EXPERIMENTAL GC01 APM32 FLASH IMAGE; DO NOT FLASH. NOT HARDWARE VALIDATED.
16 KiB original bootloader / 76 KiB firmware / 2 KiB game score journal
/ 1 KiB moved settings / 33 KiB moved radiation log.

33 KiB physical log (two pages smaller than v2.8). Adaptive minute-page format and legacy short-interval packing. Export before downgrading. Up to three pending minutes (or three one-second/two ten-second samples) may be lost on sudden power loss. Closed minute pages use CRC16; open pages are not fully CRC-protected. Physical torn writes remain unverified. Logging fault stops writer until reboot; export can end at rollover.
Renderer uses 3-row RGB565 strips with 3064 B static arrays, plus
a 480 B adaptive full/split-strip 32-bit checksum cache. Full frame requires at most 80 transfers. ST7789 uses a parallel GPIO bus on
the GC01, not SPI. Skips unchanged strips; periodic refresh repairs stale pixels.
On-device frame rate is UNMEASURED for v3.3; pause screen now shows a measured interval-derived FPS estimate.
Layout is unchanged from v3.2. This build does NOT migrate data from earlier incompatible layouts.
Old settings, cumulative readings, radiation records and Rider saves MAY BE LOST.
A successful CRC, ELF check or GitHub build CANNOT prove the USB bootloader
accepts the expanded layout. Some APM32 GC01 devices fail normal 3.x USB
updates. If flashing fails, SWD recovery may be required.
This package has NOT been run on an actual GC01. Preserve a known-good
firmware and your instrument settings before considering installation.
Gameplay physics are an approximation, not original Box2D. A true
non-monotonic loop is drawn and traversed using a guided model.
Moving and contact-triggered falling platforms are independently approximated.
New dynamic platforms and giant saws occur in ordinary generation; full original hazard library remains incomplete.
Hand-built open-loop, vertical, bowl and jump pieces do not reproduce original game data. Four disputed closed-loop IDs are excluded from random generation. The ring path is reworked and its timed hazard retuned.
v2.1 retains the 2/3 world projection and fixed blue/pink palette, adds
two reference-inspired deck structures, low-speed rail rollback and stronger LCD caching.
v3.3 retains the v2.8 codec; physics tuning and visuals deliberately changed; requires at least 32 B spare after CRC, with 76 KiB application partition.
Lossless texture delta coding preserves the original scanlines; adds frame-local scratch (72 bytes of arrays).
Physical stack high-water and rendering time remain unverified.
Optional mixed backend uses Clang -Oz; compact mode internalizes host-only APIs and omits the frame pointer.
Compiler choice and LCD transfer bandwidth may affect timing.
Compiler settings can affect timing; perceived smoothness and texture flicker must be judged on hardware. World-aligned fractional texture phase, frame deadlines and optimized obstacle rendering are tested on host. Physical LCD tearing remains unverified.
The larger car body is a visual adjustment; physical wheelbase and collision geometry are unchanged. Normal speed cap 1092 Q8; unchanged 84 spin cap; Down brakes, release coasts. Boost lasts 54 ticks (perfect flip) or 78 ticks (pad exit).
The game is NOT proven bug-free; actual hardware and radiation pulse timing still require measurement.
Persistent Rider best/diamonds journal uses the reserved 2KiB save pages;
writes only on explicit game exit (abrupt power loss may lose records); flash-write impact on
pulse interrupts is NOT hardware-validated.
Do not rely on this experimental build for radiation safety decisions.
TXT
cat > ../dist/BUILD_AND_TEST_SUMMARY.txt <<'TXT'
One workflow run produces both firmware candidate and all host test results.
The signed candidate binary is GC01_RIDER_V33_76K_APM32_DO_NOT_FLASH.bin.
The tests/ folder contains GCC, Clang, sanitizers, preview, compile and signing logs.
Includes SOURCE-LEVEL collision and 2:3 visual-alignment regressions.
The previews/ folder contains 29 diagnostic fixture PNG files drawn by the actual C renderer, not real playthroughs.
PASS criteria: both host test suites, build, sign, address/CRC/memory audit.
SOURCE in source/ is the exact engine and renderer tested and compiled.
NOTE: hardware FPS, bootloader behavior, calibration migration and radiation
safety cannot be certified by GitHub Actions tests. See READ_BEFORE_FLASHING.txt.
TXT
(cd ../dist && sha256sum *.bin *.elf previews/*.png source/*.c source/*.h > SHA256SUMS.txt)
