set -euo pipefail
mkdir -p "$GITHUB_WORKSPACE/dist/tests" "$GITHUB_WORKSPACE/dist/previews"
cd radpro/rider_ci
report="$GITHUB_WORKSPACE/dist/tests"
# The old test fixtures intentionally assert the old fixed opening route and
# 270-degree scoring. They remain in source for history; this gate runs the
# new release tests and exact differential tests on unchanged output.
CC=gcc bash tests/run_v33.sh 2>&1 | tee "$report/GCC_TEST_RESULTS.txt" &
gcc_pid=$!
CC=clang bash tests/run_v33.sh 2>&1 | tee "$report/CLANG_TEST_RESULTS.txt" &
clang_pid=$!
gcc_rc=0; clang_rc=0
wait "$gcc_pid" || gcc_rc=$?
wait "$clang_pid" || clang_rc=$?
printf 'GCC exit=%s; Clang exit=%s\n' "$gcc_rc" "$clang_rc"
((gcc_rc==0 && clang_rc==0))
