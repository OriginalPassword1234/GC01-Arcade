#include "rider_render.h"
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define W 320
#define H 240
#define STRIP_ROWS 3
#define RGB(r,g,b) ((((r)>>3)<<11)|(((g)>>2)<<5)|((b)>>3))

static uint16_t strip[W*STRIP_ROWS];
static int16_t surface[W];
/* Distant silhouette has no fine detail: cache in four-pixel columns.
 * 240 bytes RAM reclaimed and 75% fewer background hash calculations. */
static uint8_t backdrop[W/4];
/* Terrain faceting does not contain details finer than two display pixels.
 * Cache one value per pixel pair: saves 160 B of scarce GC01 SRAM and
 * halves costly per-column metadata hashing without losing the rail or
 * object resolution (both remain 320 pixels wide). */
static uint8_t facet[W/2];
static int16_t gemx[10], gemy[10];
static uint8_t gem_n;
static int16_t sawx[4], sawy[4], sawr[4];
static uint8_t saw_n;
/* Boost y is obtained from the surface when painting; no unused cache. */
static int16_t boostx0[4], boostx1[4];
static uint8_t boost_n;
static int16_t spikex0[4],spikex1[4],spikey[4];
static uint8_t spike_n;
/* One loop path cached in FLASH geometry + compact RAM screen offsets. */
static uint8_t loop_dx[65];
static int8_t loop_dy[65];
static int16_t loop_anchor_x,loop_anchor_y;
static uint8_t loop_n;
static int16_t upper_sky_limit;

#define WHITE RGB(250,251,255)
#define TRACK_CORE RGB(253,246,255)
#define TRACK_EDGE RGB(252,171,240)
#define TRACK_GLOW RGB(121,29,137)
#define TRACK_FAR RGB(55,17,75)
#define TRACK_UNDER_EDGE RGB(19,12,44)
#define TRACK_BOOST RGB(255,180,35)
#define TRACK_BOOST2 RGB(255,249,161)
#define SPIKE_RED RGB(253,72,80)
#define SPIKE_GLOW RGB(172,37,67)
#define PINK_HOT RGB(223,90,207)
#define SHADOW_BG RGB(3,9,26)
#define VIOLET_FILL RGB(7,13,29)
#define VIOLET_FACET1 RGB(16,28,57)
#define VIOLET_FACET2 RGB(11,23,49)
#define VIOLET_FACET3 RGB(9,18,39)
#define CAR_GREEN RGB(78,254,126)
#define CAR_GREEN2 RGB(44,198,100)
#define CAR_HALO RGB(130,255,172)
#define CAR_DARK RGB(5,39,32)
#define WHEEL_HALO RGB(106,255,174)
#define GEM_WHITE RGB(244,255,252)
#define GEM_MID RGB(91,255,183)
#define GEM_BLOOM RGB(28,235,135)
#define GEM_OUTER RGB(13,89,66)
#define SAW_RED RGB(255,65,82)
#define SAW_DARK RGB(124,15,24)
#define SAW_CORE RGB(255,210,214)

/* World-to-screen camera zoom: 2/3. More stage is visible on the small
 * GC01 display, and a faster car does not make the terrain jump 12+ screen
 * pixels between two physical LCD updates. Geometry/physics stay in Q8. */
#define VIEW_NUM 2
#define VIEW_DEN 3
static int screen_x(int32_t wx,int32_t camx)
{
    return (wx-camx)/(VIEW_DEN*RIDER_Q/VIEW_NUM);
}
static int screen_y(int32_t wy,int32_t camy)
{
    return (wy-camy)/(VIEW_DEN*RIDER_Q/VIEW_NUM);
}
static int32_t view_world_x(int32_t camx,int pixel_x)
{
    return camx + pixel_x*(VIEW_DEN*RIDER_Q/VIEW_NUM);
}
static uint32_t hash32(uint32_t x)
{
    x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;
    return x;
}
static int absolute(int n) {return n<0?-n:n;}
static uint16_t sky_color(int y)
{
    /* Dark blue/purple gradient, brighter toward the horizon as in
     * Rider 2017. Single integer expression per scan line. */
    int r=4 + y/82;
    int g=9 + y/24;
    int b=49 + y/11;
    if(b>89)b=89;
    return RGB(r,g,b);
}
static uint8_t facet_metadata(int world_x)
{
    uint32_t xx=(uint32_t)(world_x+16384);
    uint32_t block=xx/64;
    uint32_t rnd=hash32(block ^ 0xa5643b62u);
    int triangle=(int)(xx%64);
    int peak=10+(int)((rnd>>11)%43u);
    int edge=absolute(triangle-peak);
    int depth=17+edge/2+(int)((rnd>>7)&7u);
    if(depth>127)depth=127;
    return (uint8_t)(depth|((triangle<peak?1u:0u)<<7));
}
static uint16_t ground_color(int depth,int x)
{
    uint8_t m=facet[x>>1];
    int facet_edge=(int)(m&127);
    int side=(m&0x80u)!=0;
    if(depth<facet_edge) return VIOLET_FILL;
    if(depth<facet_edge+21) return side?VIOLET_FACET1:VIOLET_FACET2;
    if(depth<facet_edge+62) return side?VIOLET_FACET2:VIOLET_FACET3;
    return VIOLET_FILL;
}
static int far_peak(int wx)
{
    uint32_t xx=(uint32_t)(wx+32768);
    uint32_t block=xx/91;
    int t=(int)(xx%91);
    int a=222-(int)(hash32(block+0x91u)%19u);
    int b=222-(int)(hash32(block+0x92u)%19u);
    int highest=188-(int)(hash32(block+0x94u)%26u);
    if(t<38)return a+(highest-a)*t/38;
    return highest+(b-highest)*(t-38)/53;
}
static void build_caches(const RiderState *s,int32_t camx,int32_t camy)
{
    int ox=camx/RIDER_Q;
    int min_h=H,min_bg=H;
    /* Sample the gently curved heightfield at half horizontal resolution,
     * retaining full-resolution pixels and all 2D loop vertices. Odd samples
     * are interpolated only between two nearby valid rail heights; never
     * bridge a gap or a steep discontinuity. Saves ~half the Hermite work. */
    for(int x=0;x<W;x+=2){
        int32_t h;
        surface[x]=rider_surface_q(s,view_world_x(camx,x),&h)
            ?(int16_t)screen_y(h,camy):INT16_MAX;
        facet[x>>1]=facet_metadata(ox+x*VIEW_DEN/VIEW_NUM);
        if((x&3)==0)backdrop[x>>2]=(uint8_t)far_peak((x*VIEW_DEN/VIEW_NUM+ox)/3);
    }
    for(int x=1;x<W;x+=2){
        int16_t a=surface[x-1];
        int16_t b=x+1<W?surface[x+1]:INT16_MAX;
        if(a!=INT16_MAX && b!=INT16_MAX && absolute((int)b-(int)a)<=12)
            surface[x]=(int16_t)(((int)a+(int)b)/2);
        else {
            int32_t h;
            surface[x]=rider_surface_q(s,view_world_x(camx,x),&h)
               ?(int16_t)screen_y(h,camy):INT16_MAX;
        }
    }
    for(int x=0;x<W;++x){
        if(surface[x]!=INT16_MAX && surface[x]<min_h)min_h=surface[x];
        if(backdrop[x>>2]<min_bg)min_bg=backdrop[x>>2];
    }
    upper_sky_limit=(int16_t)(min_h-16<min_bg?min_h-16:min_bg);
    if(upper_sky_limit<0)upper_sky_limit=0;
    gem_n=0; saw_n=0; boost_n=0; spike_n=0; loop_n=0;
    uint32_t begin=camx>0?(uint32_t)(camx/(256*RIDER_Q)):0u;
    for(uint32_t k=begin;k<begin+4;++k){
        const RiderPiece *p=&s->track[k%RIDER_TRACK_SLOTS];
        if(p->number!=k) continue;
        if(!loop_n && (p->template_id==16u||p->template_id==27u||p->template_id==28u||p->template_id==46u)){
            /* Cache the closed 2D loop once per FRAME, not per raster strip. */
            int32_t bx=(int32_t)(k*RIDER_PIECE_WIDTH)*RIDER_Q;
            loop_anchor_x=(int16_t)screen_x(bx,camx);
            loop_anchor_y=(int16_t)screen_y(166*RIDER_Q,camy);
            for(unsigned i=0;i<=64u;++i){
                int32_t px,py;
                uint16_t t=(uint16_t)(i*64u);
                if(!rider_special_point_q(k,p->template_id,t,&px,&py))break;
                loop_dx[i]=(uint8_t)screen_x(px,bx);
                loop_dy[i]=(int8_t)screen_y(py,166*RIDER_Q);
                loop_n=(uint8_t)(i+1u);
            }
        }
        if(p->template_id==27u || p->template_id==28u){
            /* Fill the dark hillside under a genuine 2-D rail once per
             * frame, rather than leaving it visually floating in space. */
            for(unsigned t=32;t<=4096u;t+=32u){
                int32_t ax,ay,bx,by;
                if(!rider_special_point_q(k,p->template_id,(uint16_t)(t-32u),&ax,&ay) ||
                   !rider_special_point_q(k,p->template_id,(uint16_t)t,&bx,&by))continue;
                int xa=screen_x(ax,camx), xb=screen_x(bx,camx);
                int ya=screen_y(ay,camy), yb=screen_y(by,camy);
                if(xa>xb){int tmp=xa;xa=xb;xb=tmp;tmp=ya;ya=yb;yb=tmp;}
                int range=xb-xa;
                for(int x=(xa<0?0:xa);x<=(xb>=W?W-1:xb);++x){
                    int fy=range ? ya+(yb-ya)*(x-xa)/range:(ya<yb?ya:yb);
                    if(surface[x]==INT16_MAX || fy<surface[x])surface[x]=(int16_t)fy;
                }
            }
        }
        for(uint8_t j=0;j<3u && gem_n<10u;++j){
            int32_t wx,wy;
            if(rider_piece_gem_q(s,k,j,&wx,&wy)){
                int xx=screen_x(wx,camx);
                if(xx>=-11&&xx<=W+11){
                    gemx[gem_n]=(int16_t)xx;
                    gemy[gem_n]=(int16_t)((wy-camy)/RIDER_Q);
                    ++gem_n;
                }
            }
        }
        if(saw_n<4){
            int32_t sx,sy,sr;
            if(rider_piece_saw_q(s,k,&sx,&sy,&sr)){
                int xx=screen_x(sx,camx);
                if(xx>=-30 && xx<=W+30){
                    sawx[saw_n]=(int16_t)xx;
                    sawy[saw_n]=(int16_t)((sy-camy)/RIDER_Q);
                    sawr[saw_n]=(int16_t)(sr/RIDER_Q);
                    ++saw_n;
                }
            }
        }
        if(spike_n<4){
            int32_t x0,x1,tip;
            if(rider_piece_spikes_q(s,k,&x0,&x1,&tip)){
                int px0=screen_x(x0,camx);
                int px1=screen_x(x1,camx);
                if(px1>=0&&px0<W){
                    spikex0[spike_n]=(int16_t)px0;
                    spikex1[spike_n]=(int16_t)px1;
                    spikey[spike_n]=(int16_t)((tip-camy)/RIDER_Q);
                    ++spike_n;
                }
            }
        }
        if(boost_n<4){
            int32_t x0,x1,yq;
            if(rider_piece_boost_q(s,k,&x0,&x1,&yq)){
                int xx0=screen_x(x0,camx);
                int xx1=screen_x(x1,camx);
                if(xx1>=-12 && xx0<=W+12){
                    boostx0[boost_n]=(int16_t)xx0;
                    boostx1[boost_n]=(int16_t)xx1;
                    (void)yq; /* boost position comes from cached rail */
                    ++boost_n;
                }
            }
        }
    }
    /* Refine sky-only fast path to include the tall wall and deep bowl. */
    for(int x=0;x<W;++x){
        if(surface[x]!=INT16_MAX && surface[x]<upper_sky_limit+16)
            upper_sky_limit=(int16_t)(surface[x]-16);
    }
    if(upper_sky_limit<0)upper_sky_limit=0;
}

static const uint8_t SCORE_FONT[11][11]={
  {0x1e,0x21,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x22,0x1c},
  {0x0c,0x14,0x24,0x04,0x04,0x04,0x04,0x04,0x04,0x04,0x04},
  {0x3e,0x41,0x01,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x7f},
  {0x3e,0x41,0x01,0x01,0x0e,0x02,0x01,0x01,0x01,0x41,0x3e},
  {0x04,0x0c,0x14,0x24,0x44,0x7f,0x04,0x04,0x04,0x04,0x04},
  {0x7f,0x40,0x40,0x40,0x7e,0x01,0x01,0x01,0x01,0x41,0x3e},
  {0x1e,0x20,0x40,0x40,0x7e,0x41,0x41,0x41,0x41,0x21,0x1e},
  {0x7f,0x01,0x02,0x02,0x04,0x08,0x08,0x10,0x10,0x20,0x20},
  {0x3e,0x41,0x41,0x41,0x22,0x1c,0x22,0x41,0x41,0x41,0x3e},
  {0x3e,0x41,0x41,0x41,0x41,0x3f,0x01,0x01,0x01,0x02,0x3c},
  {0x00,0x00,0x00,0x08,0x08,0x3e,0x08,0x08,0x00,0x00,0x00}
};

static void number(char *out,uint32_t n)
{
    char rev[12];unsigned count=0;
    if(n>99999999u)n=99999999u;
    do{rev[count++]=(char)('0'+n%10u);n/=10u;}while(n&&count<11);
    for(unsigned i=0;i<count;++i)out[i]=rev[count-i-1];
    out[count]='\0';
}
static int glyph_index(char ch)
{
    if(ch>='0'&&ch<='9')return ch-'0';
    return ch=='+'?10:-1;
}
static void put(int x,int y,int top,uint16_t c)
{
    if(x>=0&&x<W&&y>=top&&y<top+STRIP_ROWS)
        strip[(y-top)*W+x]=c;
}
static void draw_digits(const char *txt,int xx,int yy,int scale,int top,uint16_t c)
{
    for(int i=0;txt[i];++i){
        int idx=glyph_index(txt[i]);
        if(idx<0)continue;
        for(int row=0;row<11;++row){
            int py=yy+row*scale;
            if(py>=top+STRIP_ROWS || py+scale<=top) continue;
            uint8_t b=SCORE_FONT[idx][row];
            for(int col=0;col<7;++col)if(b&(1u<<(6-col)))
                for(int ry=0;ry<scale;++ry)
                    for(int rx=0;rx<scale;++rx)
                        put(xx+i*scale*9+col*scale+rx,yy+row*scale+ry,top,c);
        }
    }
}
/* Compact letterforms for a real high-score label and pause overlay.
 * Rendered as bitmap glyphs to preserve an angular, legible HUD on 320x240. */
static const uint8_t label_font[][7]={
  /* B */ {30,17,17,30,17,17,30},
  /* E */ {31,16,16,30,16,16,31},
  /* S */ {15,16,16,14,1,1,30},
  /* T */ {31,4,4,4,4,4,4},
  /* P */ {30,17,17,30,16,16,16},
  /* A */ {14,17,17,31,17,17,17},
  /* U */ {17,17,17,17,17,17,14},
  /* H */ {17,17,17,31,17,17,17},
  /* I */ {31,4,4,4,4,4,31},
  /* space */ {0,0,0,0,0,0,0}
};
static int label_index(char ch)
{
    const char *letters="BESTPAUHI ";
    for(int i=0;letters[i];++i)if(letters[i]==ch)return i;
    return 9;
}
static void draw_label(const char *txt,int x,int y,int scale,int top,uint16_t color)
{
    for(unsigned i=0;txt[i];++i){
        const uint8_t *glyph=label_font[label_index(txt[i])];
        for(int row=0;row<7;++row){
            const int py=y+row*scale;
            if(py>=top+STRIP_ROWS || py+scale<=top)continue;
            for(int col=0;col<5;++col)if(glyph[row] & (1u<<(4-col)))
                for(int dy=0;dy<scale;++dy)
                    for(int dx=0;dx<scale;++dx)
                        put(x+(int)i*6*scale+col*scale+dx,py+dy,top,color);
        }
    }
}

static uint16_t bike_pixel(int x,int y)
{
    int a=(x+14)*(x+14)+(y-1)*(y-1);
    int b=(x-14)*(x-14)+(y-1)*(y-1);
    int r=a<b?a:b;
    if(r<=48){
        if(r<=8)return WHITE;
        if(r<=20)return CAR_DARK;
        if(r<=34)return WHITE;
        return WHEEL_HALO;
    }
    /* slimmer, more Rider-like luminous wedge */
    if(x>=-24 && x<=24){
        int top,bottom=-1;
        if(x< -16) top=-6-(x+24)/3;
        else if(x< -4) top=-10-(x+16)/6;
        else if(x<10) top=-13;
        else if(x<20) top=-12+(x-10)/3;
        else top=-9+(x-20)/2;
        if(x>18) bottom=-2-(x-18)/3;
        if(y>=top && y<=bottom){
            if(y==top || y==bottom || x==24 || x==-24)return WHITE;
            if(y==top+1)return CAR_HALO;
            if(x>=-2 && x<=9 && y>=top+2 && y<=top+5)return CAR_DARK;
            if(x>=6 && x<=16 && y==top+5)return CAR_HALO;
            if(y>bottom-2 && x>=-10&&x<20)return CAR_DARK;
            if(x< -12 && y<bottom-1)return CAR_GREEN2;
            return CAR_GREEN;
        }
    }
    if(x>=-24&&x< -9 && y==-6)return CAR_HALO;
    return 0;
}
static uint16_t bike_and_trail(int px,int py,int cx,int cy,int sn,int cs,int throttle,uint32_t tick)
{
    int dx=px-cx,dy=py-cy;
    if(dx< -48||dx>39||dy< -42||dy>42)return 0;
    int lx=(dx*cs+dy*sn)/256;
    int ly=(-dx*sn+dy*cs)/256;
    /* The screenshot bike is slimmer than the early 48px sprite. Scale
     * geometry by 0.83 without keeping an additional RAM image. */
    int sx=(lx*6)/5, sy=(ly*6)/5;
    if(sx>=-26&&sx<=26&&sy>=-20&&sy<=10){
        uint16_t hit=bike_pixel(sx,sy);
        if(hit)return hit;
    }
    if(!throttle || sx>=-24 || sx< -67 || sy< -18 || sy>12)return 0;
    /* Three short fading particles instead of disconnected exhaust lines.
     * Each point remains attached to the rear in bike-local coordinates. */
    const int phase=(int)((tick/3u)%7u);
    for(int i=0;i<3;++i){
        const int tx=-27-10*i-phase;
        const int ty=-4+((i*5+phase)%7)-3;
        const int dd=(sx-tx)*(sx-tx)+(sy-ty)*(sy-ty);
        if(dd<= (i==0?6:3))return i==0?CAR_HALO:(i==1?CAR_GREEN2:RGB(16,93,63));
    }
    return 0;
}
static uint16_t gem_pixel(int dx,int dy)
{
    int x=absolute(dx),y=absolute(dy);
    if(x>10||y>12)return 0;
    int rank=x*12+y*10;
    if(rank<=20)return GEM_WHITE;
    if(rank<=56)return GEM_MID;
    if(rank<=83)return GEM_BLOOM;
    if(rank<=104)return GEM_OUTER;
    return 0;
}
static uint16_t saw_pixel(int dx,int dy,int radius,int sin_rot,int cos_rot)
{
    int r2=dx*dx+dy*dy;
    int r=radius;
    if(r2>(r+6)*(r+6)) return 0;
    if(r2<15) return SAW_CORE;
    if(r2<39) return SAW_DARK;
    if(r2<=(r-4)*(r-4)) return SAW_RED;
    if(r2<=r*r) return SAW_RED;
    /* Rotate the teeth as the physics ticks advance; collision uses the
     * encompassing circle, so tooth animation cannot change reachability. */
    int rx=(dx*cos_rot+dy*sin_rot)/256;
    int ry=(-dx*sin_rot+dy*cos_rot)/256;
    int mx=absolute(rx), my=absolute(ry);
    if((mx>=r-2 && mx<=r+6 && my<5) ||
       (my>=r-2 && my<=r+6 && mx<5))return SAW_RED;
    /* Eight alternating radial points, rigidly rotating with the blade. */
    if(mx+my>=r+4 && mx+my<=r+11 && mx>=r/2 && my>=r/2 &&
       absolute(mx-my)<5) return SAW_RED;
    return 0;
}
/* Paint only object bounding boxes after the background. The old renderer
 * tested up to 15 objects for every one of the 76,800 screen pixels, which
 * wasted most cycles on empty sky and terrain. Layer order is unchanged. */
static int imin(int a,int b) { return a<b ? a:b; }
static int imax(int a,int b) { return a>b ? a:b; }

static void plot_loop_point(int top,int x,int y)
{
    if(x<-7||x>=W+7 || y<top-6||y>=top+STRIP_ROWS+6)return;
    /* Flash-resident 7-entry L1 radial neon brush. Only visit pixels whose
     * Manhattan radius has a real contribution, not the whole 11x11 box.
     * Inner cores use a max blend so intersecting loops never go dark. */
    static const uint16_t brush[7] = {
        TRACK_CORE,TRACK_CORE,TRACK_EDGE,PINK_HOT,
        TRACK_GLOW,TRACK_FAR,TRACK_FAR
    };
    for(int dy=-5;dy<=5;++dy){
        const int py=y+dy;
        if(py<top || py>=top+STRIP_ROWS)continue;
        uint16_t *dst=strip+(py-top)*W;
        const int ay=absolute(dy);
        for(int dx=-(6-ay);dx<=6-ay;++dx){
            const int px=x+dx;
            if(px<0||px>=W)continue;
            uint16_t c=brush[absolute(dx)+ay];
            if(c>dst[px])dst[px]=c;
        }
    }
}

static void paint_loop(int top)
{
    /* Crucial GC01 optimization: only rasterize line segments whose padded
     * y range actually intersects this strip. V0.7 redrew almost the ENTIRE
     * 65-segment loop eighty times per frame (once per 3-row transfer). */
    for(unsigned i=1;i<loop_n;++i){
        int x=loop_anchor_x+loop_dx[i],y=loop_anchor_y+loop_dy[i];
        int px=loop_anchor_x+loop_dx[i-1],py=loop_anchor_y+loop_dy[i-1];
        if(imax(y,py)+7<top || imin(y,py)-7>=top+STRIP_ROWS ||
           imax(x,px)+7<0 || imin(x,px)-7>=W) continue;
        int dx=x-px,dy=y-py;
        int n=imax(absolute(dx),absolute(dy));
        if(n<1)n=1;
        for(int u=0;u<=n;++u)
            plot_loop_point(top,px+(dx*u)/n,py+(dy*u)/n);
    }
}
static void paint_objects(int top, int cx, int cy, int sn, int cs, int sin_rot, int cos_rot, int throttle, uint32_t tick)
{
    const int bottom=top+STRIP_ROWS;
    paint_loop(top);
    /* Four tiny luminous chevrons; never a solid cyan line. */
    for(uint8_t i=0;i<boost_n;++i){
        for(int k=0;k<4;++k){
            int center=boostx0[i]+7+k*9;
            if(center>boostx1[i]-2)break;
            for(int dx=-4;dx<=4;++dx){
                int px=center+dx;
                if(px<0||px>=W||surface[px]==INT16_MAX)continue;
                int py=surface[px]-7+absolute(dx);
                if(py>=top && py<bottom)strip[(py-top)*W+px]=TRACK_BOOST2;
                if(py+1>=top && py+1<bottom)strip[(py+1-top)*W+px]=TRACK_BOOST;
                if(py-1>=top && py-1<bottom)strip[(py-1-top)*W+px]=TRACK_BOOST;
            }
        }
    }
    /* Saw-style hazard platforms, but embedded BELOW the intentional gap
     * rather than in the rail or at an impossible random height. */
    for(uint8_t i=0;i<spike_n;++i){
        const int xa=imax(0,spikex0[i]);
        const int xb=imin(W,spikex1[i]+1);
        for(int y=imax(top,spikey[i]-2);y<imin(bottom,spikey[i]+13);++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=xa;x<xb;++x){
                const int sub=(x-spikex0[i])%10;
                const int tip=spikey[i]+absolute(sub-5)*2;
                if(y>=tip && y<=spikey[i]+12)
                    dst[x]=y==tip?RGB(255,159,158):SPIKE_RED;
                else if(y>=tip-2 && y<tip)dst[x]=SPIKE_GLOW;
            }
        }
    }
    for(uint8_t i=0;i<saw_n;++i){
        const int halo=sawr[i]+7;
        const int y0=imax(top,sawy[i]-halo);
        const int y1=imin(bottom,sawy[i]+halo+1);
        const int x0=imax(0,sawx[i]-halo);
        const int x1=imin(W,sawx[i]+halo+1);
        for(int y=y0;y<y1;++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=x0;x<x1;++x){
                const uint16_t c=saw_pixel(x-sawx[i],y-sawy[i],sawr[i],sin_rot,cos_rot);
                if(c)dst[x]=c;
            }
        }
    }
    for(int y=imax(top,cy-42);y<imin(bottom,cy+43);++y){
        uint16_t *dst=strip+(y-top)*W;
        for(int x=imax(0,cx-48);x<imin(W,cx+40);++x){
            const uint16_t c=bike_and_trail(x,y,cx,cy,sn,cs,throttle,tick);
            if(c)dst[x]=c;
        }
    }
    for(uint8_t i=0;i<gem_n;++i){
        for(int y=imax(top,gemy[i]-12);y<imin(bottom,gemy[i]+13);++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=imax(0,gemx[i]-10);x<imin(W,gemx[i]+11);++x){
                const uint16_t c=gem_pixel(x-gemx[i],y-gemy[i]);
                if(c)dst[x]=c;
            }
        }
    }
}

uint32_t rider_render_static_ram(void)
{
    return (uint32_t)(sizeof(strip)+sizeof(surface)+sizeof(backdrop)+sizeof(facet)+
                      sizeof(gemx)+sizeof(gemy)+sizeof(gem_n)+sizeof(sawx)+
                      sizeof(sawy)+sizeof(sawr)+sizeof(saw_n)+sizeof(boostx0)+
                      sizeof(boostx1)+sizeof(boost_n)+
                      sizeof(spikex0)+sizeof(spikex1)+sizeof(spikey)+sizeof(spike_n)+
                      sizeof(loop_dx)+sizeof(loop_dy)+sizeof(loop_anchor_x)+sizeof(loop_anchor_y)+sizeof(loop_n)+sizeof(upper_sky_limit));
}
void rider_render(const RiderState *s,const RiderState *prev,uint8_t alpha,
                  RiderPixels out,void *context)
{
    if(!s||!out)return;
    int32_t camx=s->camera_x,camy=s->camera_y;
    int32_t xx=s->x,yy=s->y,a=s->angle;
    if(prev && !s->paused && s->phase==RIDER_RUNNING &&
       prev->phase==RIDER_RUNNING && s->looping==prev->looping){
        /* Predict fractional time after the last *completed* physics step.
         * v0.9 interpolated from PREVIOUS to CURRENT using accumulator alpha,
         * producing a variable whole-tick visual delay and chunky scrolling.
         * Extrapolate only bounded camera/vehicle motion. This is visual-only:
         * no collision, scoring or radiation state is modified. */
        int32_t dcx=camx-prev->camera_x;
        int32_t dcy=camy-prev->camera_y;
        int32_t dx=xx-prev->x;
        int32_t dy=yy-prev->y;
        if(absolute(dcx)<=8*RIDER_Q && absolute(dcy)<=5*RIDER_Q &&
           absolute(dx)<=7*RIDER_Q && absolute(dy)<=9*RIDER_Q){
            camx+=dcx*alpha/256;
            camy+=dcy*alpha/256;
            xx+=dx*alpha/256;
            yy+=dy*alpha/256;
            int32_t da=a-prev->angle;
            if(absolute(da)<=200) a+=da*alpha/256;
        }
    }
    build_caches(s,camx,camy);
    uint8_t ai=(uint8_t)(((uint32_t)a>>4)&255u);
    int sn=rider_sin256(ai),cs=rider_sin256((uint8_t)(ai+64));
    /* Slower, softer decorative motion. The blade remains dangerous even while
     * stationary; animation must never alter the collision geometry. */
    uint8_t saw_ai=(uint8_t)(s->tick_count/3u);
    int sin_rot=rider_sin256(saw_ai), cos_rot=rider_sin256((uint8_t)(saw_ai+64));
    int cx=screen_x(xx,camx),cy=screen_y(yy,camy);
    char score[16];number(score,(uint32_t)(s->score>0?s->score:0));
    char high[16];number(high,(uint32_t)(s->best>0?s->best:0));
    if(s->pending_score){
        int n=(int)strlen(score);
        score[n++]='+';
        number(score+n,s->pending_score);
    }
    int score_size=(int)strlen(score)*18-4;
    char bonus[16];bonus[0]='+';number(bonus+1,s->pending_score);
    for(int top=0;top<H;top+=STRIP_ROWS){
        for(int row=0;row<STRIP_ROWS;++row){
            int y=top+row;
            uint16_t bg=sky_color(y);
            uint16_t *dst=&strip[row*W];
            if(y<upper_sky_limit){
                /* Upper rows are uniform sky for this frame. This removes
                 * most geometry/texture conditionals from blank pixels. */
                for(int x=0;x<W;++x)dst[x]=bg;
                continue;
            }
            for(int x=0;x<W;++x){
                int h=surface[x],d=y-h;
                uint16_t c=bg;
                if(y>=backdrop[x>>2])c=SHADOW_BG;
                if(h!=INT16_MAX && d>=0)c=ground_color(d,x);
                if(h!=INT16_MAX){
                    int ad=absolute(d);
                    if(ad==0)c=TRACK_CORE;
                    else if(ad<=2)c=TRACK_EDGE;
                    else if(ad<=3)c=PINK_HOT;
                    else if(ad<=5)c=TRACK_GLOW;
                    else if(ad<=8)c=TRACK_FAR;
                    else if(d>=9 && d<=11)c=TRACK_UNDER_EDGE;
                }
                dst[x]=c;
            }
        }
        paint_objects(top,cx,cy,sn,cs,sin_rot,cos_rot,s->throttle_active,s->tick_count);
        draw_digits(score,(W-score_size)/2,25,2,top,WHITE);
        /* The persistent high score is drawn during play; the separate save
         * journal is managed by the Rad Pro game adapter. */
        draw_label("BEST",8,34,1,top,WHITE);
        draw_digits(high,8,44,1,top,WHITE);
        /* Diamonds now have visible feedback, even without garage mode. */
        char diamond_count[16];
        number(diamond_count,(uint32_t)(s->diamonds>0?s->diamonds:0));
        int diamond_len=(int)strlen(diamond_count);
        draw_digits(diamond_count,W-11-diamond_len*9,10,1,top,GEM_WHITE);
        for(int dy=-4;dy<=4;++dy){
            for(int dx=-4;dx<=4;++dx){
                int rank=absolute(dx)+absolute(dy);
                if(rank<=4)put(W-16-diamond_len*9+dx,15+dy,top,rank<3?GEM_WHITE:GEM_BLOOM);
            }
        }
        if(s->pending_score){
            int bonus_x=cx-15;
            if(bonus_x<3)bonus_x=3;
            if(bonus_x>W-55)bonus_x=W-55;
            draw_digits(bonus,bonus_x,cy-47,1,top,WHITE);
        }
        if(s->paused){
            /* A play triangle replaces the pause bars when gameplay stops. */
            for(int x=8;x<19;++x)
                for(int y=8;y<20;++y)
                    if(x>=8 && x<=18 && absolute(y-14)<=((x-8)/2))
                        put(x,y,top,WHITE);
            draw_label("PAUSE",115,92,2,top,WHITE);
        }else{
            for(int y=8;y<20;++y){
                for(int x=8;x<11;++x)put(x,y,top,GEM_BLOOM);
                for(int x=15;x<18;++x)put(x,y,top,GEM_BLOOM);
            }
        }
        if(s->phase==RIDER_CRASHED){
            for(int y=73;y<75;++y)for(int x=130;x<190;++x)put(x,y,top,WHITE);
        }
        out(top,STRIP_ROWS,strip,context);
    }
}
