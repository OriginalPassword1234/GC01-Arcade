# GC01 Rider v1.1 — experimental track and scrolling repair

This revision addresses the user-confirmed v1.0 overcorrection: approximately 73% long flat pieces, a low 180 world px/s cap, little potential airtime, and choppy 20-FPS display movement. These are handcrafted, Rider-inspired pieces, **not** extracted original Rider assets or Box2D physics.

## Changes from v1.0

- Early track cadence uses designed approach/challenge/runout sections with 257 jump/ramp sections, 449 flat sections, 105 boost sections and 100 guaranteed early loops in the 1100-piece seeded initial-window test. A guaranteed ramp at piece 2, boost at piece 4, and closed loop at piece 8 make features visible early; fewer repetitive long straights and no reintroduction of the v0.9 small rolling hills.
- Further advanced geometry (open arcs/vertical walls) and some saws become available by distance as well as earned score. In 100 simulated unscored runs through the first 49 pieces, 84 special sections and 28 saws were still present in their final 12-piece world windows. Original Rider's selection pools were score-based; distance fallback is **our** accessibility change, not a claim of original parity.
- Ground acceleration 16 vs 11 Q8 units/tick; normal cap 240 vs 180 world px/s, temporary boost cap 360 vs 300. Intentional crests produce stronger launch velocity and falling acceleration is slightly reduced to make flips possible at the slower, more controllable airborne angular rate retained from v1.0.
- Screen camera projection is 2/3 world scale at render time (no change to collision coordinates). With 240 world px/s at 20 output FPS, steady camera displacement is ~8 display pixels/frame rather than 12 at full scale. More world is visible, but the camera cannot create intermediate LCD refreshes. This trades some art/vehicle apparent scale for lower scrolling jumps; verify aesthetics and actual FPS on hardware.
- Saw geometry was raised higher above the rail on the difficult piece to avoid unavoidable collisions after a jump. Blade appearance stays bright red; this is not original Rider saw-placement data.
- No added global RAM buffers; renderer still reports 3045 B. No new flash writes, USB/recovery changes, or Rad Pro radiation ISR edits. All existing tests plus v1.1 cadence/projection/progression tests pass on GCC with sanitizers. **Not ARM or hardware verified**.

## Local host verification (2026-11-22)

- 498/500 deterministic novice auto-drive runs reached 35 pieces without crashing; this does not validate all manually driven routes.
- 100/100 scripted novice runs landed a scored stunt using the same button physics. This is not a measured human-control success rate.
- 1000 simulated score-save transactions, original v0.9 and v1.0 physics/renderer tests, framebuffer reconstruction for dirty strip updates, and v1.1 progression/projection tests passed.
- 2/3 scrolling in a 240-world-px/s flat test yields 8 display pixels per 50ms (ideal 20Hz). **Actual GC01 FPS and the display BUS timing remain unmeasured**. The GC01 panel uses a parallel GPIO bus; RAM budget and frame-transfer time are independent issues.

## Critical hardware caution

The same 68-KiB firmware, 2-KiB Rider saves, 1-KiB settings, 41-KiB radiation history experimental partition layout is retained. **No migration** of prior calibration/settings/history. USB updater acceptance and radiation pulse integrity are not tested. Do not flash without preserving your known-good firmware/settings and a recovery plan; experimental GC01 firmware should not be used for radiation safety decisions.

The complete original 95-stage library, true independent articulated wheel joints, moving-platform physics, original textures, and the original game's full Box2D behavior are still missing. Do not describe this revision as a one-to-one copy. Save writes happen only on game exit; if power dies beforehand the new best may be lost.
