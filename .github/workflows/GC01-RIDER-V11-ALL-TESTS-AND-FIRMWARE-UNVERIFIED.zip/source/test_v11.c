/* Rider v1.1: challenge cadence, distance-unlocked variety, screen pacing.
 * These tests check the real engine data, not an independent mock generator.
 */
#include "../src/rider_core.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>

static int is_jump(uint8_t k)
{
    return k==29u || k==36u || k==19u || k==41u || k==43u ||
           k==31u || k==34u || k==14u || k==44u;
}
static void early_variety(void)
{
    unsigned ramps=0, flats=0, boosts=0;
    for(uint32_t seed=1;seed<=100;seed++) {
        RiderState s;rider_init(&s,seed);
        assert(s.track[2].template_id==29u);
        assert(s.track[4].template_id==39u);
        assert(s.track[5].template_id==36u);
        assert(s.track[8].template_id==16u); /* early loop challenge */
        for(uint32_t i=1;i<12;++i){
            const uint8_t k=s.track[i].template_id;
            if(is_jump(k))++ramps;
            if(k==0u||k==35u)++flats;
            if(s.track[i].flags&4u)++boosts;
        }
    }
    assert(ramps>=250 && boosts>=100);
    assert(flats>=200 && flats<=650);
    printf("v1.1 early distribution: %u jump/ramp, %u flat, %u boost (of 1100 pieces)\n",ramps,flats,boosts);
}
static void later_variety_without_scores(void)
{
    unsigned special=0, saws=0, pieces=0;
    for(uint32_t seed=1;seed<=100;seed++){
        RiderState s;rider_init(&s,seed);
        for(int t=0;t<7500;++t){
            rider_step(&s,s.grounded!=0);
            if(s.phase==RIDER_CRASHED)break;
            uint32_t pn=(uint32_t)(s.x/(256*256));
            if(pn>=49)break;
        }
        for(uint32_t i=0;i<RIDER_TRACK_SLOTS;++i){
            RiderPiece *p=&s.track[i];
            if(p->number>=20u){
                ++pieces;
                if(p->template_id==16u||p->template_id==27u||p->template_id==46u)++special;
                if(p->flags&2u)++saws;
            }
        }
    }
    assert(pieces>=800);
    assert(special>0 && saws>0);
    printf("v1.1 advanced sections reached without scoring: %u loops/walls, %u saws\n",special,saws);
}
static void screen_displacement(void)
{
    RiderState s;rider_init(&s,31);
    for(int i=0;i<12;i++) {s.track[i].template_id=0u;s.track[i].flags=0u;}
    s.phase=RIDER_RUNNING;
    for(int i=0;i<100;++i) rider_step(&s,true);
    assert(s.grounded && s.phase==RIDER_RUNNING);
    /* In the current renderer, each 1 screen pixel represents 1.5 world
     * pixels. The car is faster than v1.0, but its rail shouldn't jump
     * more than 9 LCD pixels across 3 ideal 60Hz physics steps.  Actual
     * LCD frame duration must still be measured on device. */
    for(int i=0;i<30;++i){
        int32_t camera=s.camera_x;
        for(int j=0;j<3;++j)rider_step(&s,true);
        int32_t dx=s.camera_x-camera;
        assert(dx>=0);
        assert(dx*2/(3*RIDER_Q)<=9);
    }
    assert(s.vx==4*RIDER_Q);
    printf("v1.1 projected scrolling: 8px / 50ms at 240 world px/s on flat rail\n");
}
int main(void)
{
    early_variety();
    later_variety_without_scores();
    screen_displacement();
    puts("v1.1: authored cadence, progression, and 2/3 world projection PASS");
    return 0;
}
