/* Rad Pro's ST7789 streaming path: 320 x 4 RGB565 pixels per transfer. */
#if defined(GC01_RIDER)
#include <stdint.h>
#include "rider_screen.h"
#include "rider_render.h"
#include "draw.h"
static void send_rows(int top,int rows,const uint16_t *pixels,void *unused)
{
    (void)unused;
    const mr_rectangle_t area={0,(int16_t)top,320,(int16_t)rows};
    drawImage(&area,pixels);
}
void rider_draw_gc01(const RiderState *state,const RiderState *prev,uint8_t alpha)
{
    rider_render(state,prev,alpha,send_rows,0);
}
#endif
