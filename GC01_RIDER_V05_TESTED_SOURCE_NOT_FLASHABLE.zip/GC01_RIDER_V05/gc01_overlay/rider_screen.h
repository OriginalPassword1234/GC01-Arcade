#ifndef RIDER_SCREEN_H
#define RIDER_SCREEN_H
#include "../extras/rider_core.h"
void rider_draw_gc01(const RiderState *state, const RiderState *prev,
                     uint8_t interpolation_256);
#endif
