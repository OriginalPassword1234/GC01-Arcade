# Changes in v0.5

## Gameplay / core
- Added deterministic track-piece pools with more section variety.
- Added compact per-piece flags for gem, saw, and boost content.
- Added short gap support in the surface sampler for cliff/jump-style pieces.
- Added saw collision checks.
- Added boost-strip speed increase when grounded on marked sections.
- Moved diamonds to nearly every other section.

## Graphics
- Refined the vehicle silhouette and trail.
- Added red saw rendering.
- Added cyan boost-strip rendering.
- Retained the purple/white track style and angular violet terrain.

## Tests
- Updated restart test to preserve current totals.
- Reframed reachability test to verify the early/mid non-saw content.
- Added a saw metadata test.
- Verified renderer static RAM remains under 4 KiB.

## Still missing versus the real game
- True loops/overhangs.
- Full original section library and frequency tables.
- Moving physics structures.
- Original-quality vehicle sprite fidelity.
- On-device ARM timing and flash-layout validation.
