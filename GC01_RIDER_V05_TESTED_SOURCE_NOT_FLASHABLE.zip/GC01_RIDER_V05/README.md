# GC01 Rider v0.5 (tested source only, not flashable)

This package contains the next development iteration of the compact Rider-inspired engine for the GC01 project.

## What improved from v0.4

- More track piece variety with deterministic difficulty progression.
- New compact piece metadata for **red saw hazards** and **boost strips**.
- Short **gap/cliff-style** section support in the core surface query.
- Better vehicle silhouette and trail rendering.
- Purple/white neon track retained, with boost-pad drawing and saw rendering.
- Hazard collision checks added for saws.
- Diamond placement increased to approximately every other section.
- Core and render tests updated.

## Verified in this package

- Deterministic core simulation.
- 500/500 seeded runs through the early and mid non-saw content under a simple grounded-driving policy.
- Random-input crash/restart testing.
- Renderer stress test across multiple seeds.
- Static renderer RAM: 3915 bytes.

## Important limitations

This is still **not** a full original Rider port.

- The track model is still fundamentally a compact single-surface representation, so it cannot produce true closed loops.
- The physics are still a hand-tuned fixed-point approximation rather than a LiquidFun/Box2D reconstruction.
- The vehicle sprite remains vector-drawn rather than a perfect copy of the original car.
- Moving platforms, trapdoors, rotating platforms, and complete original endless-section data are not yet integrated.
- This package is **source only**. It is not a flashable GC01 firmware image.

## Files

- `src/` — core gameplay and renderer.
- `tests/` — host-side tests and preview generators.
- `tests/frame.png` — gameplay preview rendered by the actual C renderer.
- `tests/staged.png` — staged airborne bonus preview rendered by the actual C renderer.
- `tests/saw.png` — preview showing the new saw hazard.
- `gc01_overlay/` — integration scaffolding for the Rad Pro firmware tree.
