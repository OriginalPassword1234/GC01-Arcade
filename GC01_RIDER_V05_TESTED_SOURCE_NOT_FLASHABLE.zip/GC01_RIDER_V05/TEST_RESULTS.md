# Test results for v0.5

## Core tests
- 500/500 deterministic tracks pass a grounded-only policy through early/mid pieces.
- Determinism test: passed.
- Restart preservation test: passed.
- Random input survival/recovery test: passed.
- Saw metadata helper test: passed.
- Stunt landing score test: passed.

## Render tests
- Renderer stress test (7 seeds × 800 ticks): passed.
- Single-frame render test: passed.
- Staged preview render test: passed.

## Static renderer RAM
- `3915 bytes`

## Notes
The new hazard content is intentionally treated as later content; the simple automated reachability policy is only asserted through the earlier non-saw track range. This keeps the tests honest about what has and has not been validated.
