# Rider GC01 visual / gameplay iteration v0.4 — 20 November 2026

**SOURCE-ONLY prototype; NOT firmware; DO NOT FLASH.**

## Changes since v0.3

- Purple/lavender-pink rail instead of the incorrectly green rail. The brightest two-pixel band is nearly white, followed by violet-pink layered glow. References are original 2017 Rider gameplay images, not the archived third-party Unity clone.
- Dark cobalt backdrop and purple low-poly shaded terrain underneath, rather than the teal/green theme.
- Replaced pink block vehicle with a compact green neon wedge with dark cockpit and two glowing white-rimmed wheels. It is deliberately VECTOR-DRAWN from scratch rather than a copied game sprite; its silhouette still differs from the original and needs measurement against original footage.
- Main white score is centered near the top, while the `+N` bonus is a *separate* label beside the bike (not joined to the total score).
- Purple glowing gem graphics and less visually prominent pause lines.
- `rider_surface_q` now samples fixed-point subpixel terrain rather than quantizing all surface reads to whole pixels, avoiding discrete one-pixel physics steps.
- Corrected start-ground contact (the older version initially had a one-pixel gap) to prevent a phantom jump after the first button press.
- Land/follow tangent with slope-derived momentum, and retain that momentum upon losing contact instead of adding an artificial jump impulse. Slope gravity also affects forward speed.
- Kept bounded fixed 60 Hz simulation, no dynamic memory, 320x4 RGB565 scanline output, and previously tested GC01 integration adapter.

## Test status

- GCC: deterministic regression tests, 500 generated seeds × 12,000 steps, simulated random inputs/restarts, initial contact, pending flip award.
- GCC AddressSanitizer + UndefinedBehaviorSanitizer: core and renderer exercised; no reported errors.
- Clang with UndefinedBehaviorSanitizer: core and renderer exercised; no reported errors.
- Renderer: 7 seeds × 800 simulation ticks with periodic full-frame strips; no out-of-bounds reports.
- `sizeof(RiderState)` = 168 bytes; two state instances plus renderer's 3,865-byte static scratch buffer = **4,201 bytes** before any other GC01 firmware RAM, stack, menu, display driver or ISR usage.
- Native `-Os` object code sizes: ~3.0 KiB core and ~3.4 KiB renderer, **not** ARM output or complete firmware size; linker, integration, startup and library footprint unknown.

## Current limitations that MUST NOT be hidden

- This is **not** the original Rider's accurate collision engine. The original uses LiquidFun/Box2D with separate wheels/joints and moving bodies. This code still uses a simplified single-body contact model. The new slope model is only a partial improvement.
- Still has *eight* preliminary smooth heightfield templates. These are not the original 95 endless pieces, so the visual/physical gameplay cannot yet be called faithful. Single-valued heightfields **cannot model true loops or vertical overhangs**. The track representation must be replaced before full fidelity is possible.
- No implemented original saw collision, moving platforms, boost pads, dropping surfaces, geometry-matched collision for loops, or original destruction animation.
- No measured frame timing on GC01; native sanitizer passes do not establish glitch-free or 30 FPS target hardware behavior. The display currently redraws the whole image in 60 strips per frame.
- No original sprite/font extraction; the car and HUD are vector approximations. A precise side-by-side comparison with identical game states is still needed.
- No persistent save flash writes, no 25% radiation-log partition change, and no integrated datalog compressor in this package. USB bootloader and memory layout safety remain UNVERIFIED.
- The optimized late-era Rad Pro/Rider firmware source is not in the uploaded archive. The separate GC01 adapter must be reviewed before applying to any new firmware. No ARM firmware has been built or flashed.

## Screenshots

- `tests/frame.png`: direct host-rendered frame after actual simulation using the original renderer API.
- `tests/staged.png`: **staged** rendering test with score 17, pending +2, and the vehicle airborne, to exercise visual elements (NOT proof of a reachable real run state).

Original reference screenshots and independent documentation: <https://www.youtube.com/watch?v=5_yiVYxrcII>, <https://www.appbrain.com/appstore/rider-stunt-bike-racing/ios-1229618961>, <https://github.com/Mason363/NumPlay/blob/main/games/rider/README.md>. The repository's descriptions are third-party claims, not source-code certification.
