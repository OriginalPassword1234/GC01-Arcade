#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
static FILE *f;
static unsigned lines;
static void rgb565(int top,int rows,const uint16_t *pixels,void *context)
{
    (void)context;
    assert(top==(int)lines&&rows==4);
    for(int i=0;i<rows*320;++i) {
        uint16_t v=pixels[i];
        uint8_t rgb[3]={ (uint8_t)(((v>>11)&31)*255/31),
                         (uint8_t)(((v>>5)&63)*255/63),
                         (uint8_t)((v&31)*255/31) };
        assert(fwrite(rgb,1,3,f)==3);
    }
    lines+=4;
}
int main(int argc,char **argv)
{
    RiderState s;rider_init(&s,1u);
    for(int i=0;i<3888;i++) rider_step(&s,s.grounded!=0);
    f=fopen(argc>1?argv[1]:"saw.ppm","wb");assert(f);
    assert(fprintf(f,"P6\n320 240\n255\n")>0);
    rider_render(&s,NULL,0,rgb565,NULL);
    assert(lines==240);assert(fclose(f)==0);
    return 0;
}
