#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
cc -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer src/rider_core.c tests/test_core.c -o tests/test_core
ASAN_OPTIONS=detect_leaks=1 ./tests/test_core
