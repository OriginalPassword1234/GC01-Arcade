#!/usr/bin/env python3
"""Apply new engine to extracted 2026-11-07 legacy Arcade Rad Pro source.

This is a source overlay, never a flashed image. The exact optimized v0.6
source was not supplied; refuse anything else rather than overwriting it.
"""
import pathlib
import shutil
import sys

SELF = pathlib.Path(__file__).resolve().parents[1]
OLD = ("src/extras/arcade.c", "src/extras/arcade_logic.c", "src/extras/arcade_logic.h",
       "src/ui/arcade.c", "src/ui/arcade.h")
GUARDS = ("src/extras/game.c", "src/ui/game.c", "src/ui/view.c", "src/ui/view.h",
          "src/peripherals/keyboard.c", "src/peripherals/keyboard.h")

def apply(base: pathlib.Path):
    p = base / "platform.io"
    ini = p / "platformio.ini"
    if not ini.exists():
        raise RuntimeError("Pass the root of the extracted legacy Rad Pro source")
    txt = ini.read_text()
    if txt.count("-DGC01_ARCADE") != 1:
        raise RuntimeError("Unexpected source; refusing to overwrite incompatible firmware")
    for path in OLD + GUARDS:
        if not (p / path).exists():
            raise RuntimeError("Legacy file absent: " + path)
    for path in OLD:
        (p / path).unlink()
    for path in GUARDS:
        f = p / path
        t = f.read_text().replace("GC01_ARCADE", "GC01_RIDER")
        f.write_text(t)
    ini.write_text(txt.replace("-DGC01_ARCADE", "-DGC01_RIDER"))
    for name in ("rider_core.c", "rider_core.h"):
        shutil.copyfile(SELF / "src" / name, p / "src/extras" / name)
    for name in ("rider_render.c", "rider_render.h"):
        content = (SELF / "src" / name).read_text().replace('"rider_core.h"',
                                                                  '"../extras/rider_core.h"')
        (p / "src/ui" / name).write_text(content)
    for name in ("rider_app.c",):
        shutil.copyfile(SELF / "gc01_overlay" / name, p / "src/extras" / name)
    for name in ("rider_screen.c", "rider_screen.h"):
        shutil.copyfile(SELF / "gc01_overlay" / name, p / "src/ui" / name)
    print("Applied Rider foundation to legacy Rad Pro source. Not yet a verified ARM build.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: apply_to_legacy_arcade.py /path/to/radpro-3.1.1")
    apply(pathlib.Path(sys.argv[1]))
