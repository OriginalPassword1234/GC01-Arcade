set -euo pipefail
python3 -m pip install platformio pyelftools freetype-py bdflib
