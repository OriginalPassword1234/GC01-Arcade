set -euo pipefail
commit=$(git -C radpro rev-parse HEAD)
font_key=$(
  {
    echo "$commit"
    python3 --version
    python3 -c 'import importlib.metadata as m; import freetype; print(m.version("freetype-py"),m.version("bdflib"),freetype.version())'
    find radpro/fonts radpro/tools radpro/platform.io/src/system/strings -type f ! -name '*.pyc' ! -path '*/__pycache__/*' -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
  } | sha256sum | cut -d' ' -f1
)
pio_key=$(
  { echo "$commit"; python3 -m platformio --version; sha256sum radpro/platform.io/platformio.ini; } | sha256sum | cut -d' ' -f1
)
old_pio_key=$(
  { echo "$commit"; python3 -m platformio --version; printf '%s  radpro/platform.io/platformio.ini\n' "$(sed 's/-DFIRMWARE_SIZE=0x13000/-DFIRMWARE_SIZE=0x12c00/' radpro/platform.io/platformio.ini | sha256sum | cut -d' ' -f1)"; } | sha256sum | cut -d' ' -f1
)
printf 'font=%s\npio=%s\nold_pio=%s\n' "$font_key" "$pio_key" "$old_pio_key" >> "$GITHUB_OUTPUT"
