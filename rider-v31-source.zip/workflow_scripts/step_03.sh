set -euo pipefail
if test -d radpro/.git; then
  if ! git -C radpro rev-parse --verify 'a9d0f19^{commit}' >/dev/null 2>&1; then
    rm -rf -- radpro
  fi
fi
if ! test -d radpro/.git; then
  ok=0
  for attempt in 1 2 3; do
    echo "Rad Pro download attempt $attempt/3"
    if git -c http.version=HTTP/1.1 clone --no-checkout --progress https://github.com/Gissio/radpro.git radpro; then
      ok=1; break
    fi
    rm -rf -- radpro
    sleep "$((attempt*3))"
  done
  test "$ok" = 1
fi
git -C radpro checkout --force --detach a9d0f19
git -C radpro reset --hard a9d0f19
git -C radpro clean -ffdx
expected=$(git -C radpro rev-parse 'a9d0f19^{commit}')
test "$(git -C radpro rev-parse HEAD)" = "$expected"
test -f radpro/tools/sign.py
echo "Verified pinned Rad Pro commit: $expected"
