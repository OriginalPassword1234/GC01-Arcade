set -euo pipefail
test -f radpro/fonts/RadPro-Symbols.ttf
fontdir=radpro/platform.io/src/ui/fonts
manifest=radpro/.rider-fonts.sha256
write_manifest() {
  find "$fontdir" -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
}
if test -s "$manifest" && test -s "$fontdir/font_small_en_color_21.h" && test -s "$fontdir/font_medium_en_color_32.h" && cmp -s "$manifest" <(write_manifest); then
  echo 'FONT CACHE HIT: all cached font bytes match the manifest.'
else
  echo 'FONT CACHE MISS: generating the unmodified original Rad Pro fonts.'
  (cd radpro/tools && python3 build-fonts.py)
  write_manifest > "$manifest"
fi
test -s "$fontdir/font_small_en_color_21.h"
test -s "$fontdir/font_medium_en_color_32.h"
test -s "$manifest"
sha256sum -c "$manifest" > dist/tests/FONT_INTEGRITY.txt
