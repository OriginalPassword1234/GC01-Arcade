set -euo pipefail
report=dist/tests/size/SIZE_RESULTS.tsv
if test -s "$report" && awk -F '\t' '$2=="fits" || $2=="oversize" || $2=="insufficient_sram" || $2=="above_target" {ok=1} END {exit !ok}' "$report" && test -d "$HOME/.platformio/packages" && test -d "$HOME/.platformio/platforms"; then
  echo 'ok=true' >> "$GITHUB_OUTPUT"
else
  echo 'ok=false' >> "$GITHUB_OUTPUT"
fi
