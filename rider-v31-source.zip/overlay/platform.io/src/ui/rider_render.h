#ifndef RIDER_RENDER_H
#define RIDER_RENDER_H
#include <stdint.h>
#include "../extras/rider_core.h"

/* Output rows are synchronous: callback must finish consuming pixels before
 * returning. RGB565 words, 320 pixels per row. Max chunk 3 rows = 1920 B. */
typedef void (*RiderPixels)(int top, int rows, const uint16_t *pixels, void *context);
void rider_render(const RiderState *state, const RiderState *previous,
                  uint8_t interpolation_256, RiderPixels output, void *context);
void rider_render_snapshot(const RiderState *,const RiderRenderPrevious *,uint8_t,RiderPixels,void *);
uint32_t rider_render_static_ram(void);
#endif
