#ifndef RIDER_SCREEN_H
#define RIDER_SCREEN_H
#if defined(RIDER_HOST_TEST)
#include "rider_core.h"
#else
#include "../extras/rider_core.h"
#endif
void rider_screen_invalidate(void);
void rider_draw_gc01_snapshot(const RiderState *, const RiderRenderPrevious *, uint8_t);
#if defined(RIDER_HOST_TEST)
void rider_draw_gc01(const RiderState *state, const RiderState *prev,
                     uint8_t interpolation_256);
#endif
#endif
