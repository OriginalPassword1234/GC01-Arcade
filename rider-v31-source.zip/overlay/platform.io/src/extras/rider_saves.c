/* Rider record journal, two 1-KiB pages, append only, CRC, commit marker last.
 * The last known-good record is never erased until a newer one is committed.
 * No radiation settings or history pages are touched.
 * Requires verified GC01 75/2/1/34 KiB partition map.
 */
#if defined(GC01_RIDER) && defined(GC01)
#include "rider_saves.h"
#include "../peripherals/flash.h"
#include <stdint.h>
#include <stdbool.h>

#define SAVE_MAGIC 0x52494438u /* RID8 */
#define SAVE_COMMIT 0xA55Au
#define RECORD_SIZE 20u
#define RECORDS_PER_PAGE (FLASH_PAGE_SIZE/RECORD_SIZE)
#define SAVE_PAGES 2u

typedef struct {
    uint32_t magic;
    uint32_t seq;
    uint32_t best;
    uint32_t diamonds;
    uint16_t crc;
    uint16_t commit;
} RiderSavedRecord;

typedef char save_record_exactly_20_bytes[(sizeof(RiderSavedRecord)==20)?1:-1];
static uint16_t crc16(const uint8_t *data,uint32_t count)
{
    uint16_t crc=0xffffu;
    for(uint32_t i=0;i<count;i++){
        crc^=(uint16_t)data[i]<<8;
        for(unsigned j=0;j<8;j++)
            crc=(uint16_t)((crc<<1)^((crc&0x8000u)?0x1021u:0u));
    }
    return crc;
}
static uint32_t addr_of(unsigned page,unsigned slot)
{
    return RIDER_SAVES_BASE + page*FLASH_PAGE_SIZE + slot*RECORD_SIZE;
}
static bool valid(const RiderSavedRecord *r)
{
    return r->magic==SAVE_MAGIC && r->commit==SAVE_COMMIT &&
           r->crc==crc16((const uint8_t*)r,16u);
}
static bool newer(uint32_t a,uint32_t b)
{
    return (int32_t)(a-b)>0;
}
static bool scan(RiderSavedRecord *latest,unsigned *p_last)
{
    bool found=false;
    for(unsigned p=0;p<SAVE_PAGES;p++)
        for(unsigned slot=0;slot<RECORDS_PER_PAGE;slot++){
            const RiderSavedRecord *r=(const RiderSavedRecord*)readFlash(addr_of(p,slot),RECORD_SIZE);
            if(valid(r) && (!found || newer(r->seq,latest->seq))){
                *latest=*r;
                *p_last=p;
                found=true;
            }
        }
    return found;
}
static int find_blank(unsigned page)
{
    for(unsigned slot=0;slot<RECORDS_PER_PAGE;slot++){
        const uint8_t *r=readFlash(addr_of(page,slot),RECORD_SIZE);
        bool all_ff=true;
        for(unsigned i=0;i<RECORD_SIZE;i++)if(r[i]!=0xffu){all_ff=false;break;}
        if(all_ff)return (int)slot;
    }
    return -1;
}
bool rider_saves_load(uint32_t *best,uint32_t *diamonds)
{
    if(!best||!diamonds)return false;
    RiderSavedRecord last={0};unsigned page=0;
    if(!scan(&last,&page)){*best=0;*diamonds=0;return true;}
    *best=last.best;*diamonds=last.diamonds;
    return true;
}
bool rider_saves_store(uint32_t best,uint32_t diamonds)
{
    RiderSavedRecord last={0};unsigned last_page=0;
    bool has_last=scan(&last,&last_page);
    if(has_last && last.best==best && last.diamonds==diamonds)return true;
    unsigned page=has_last?last_page:0;
    int slot=find_blank(page);
    if(slot<0){
        page=1u-page;
        slot=find_blank(page);
        /* If this page contains old data, erase it while the newer valid
         * record remains intact on the OTHER page. Power loss is safe. */
        if(slot<0){
            if(!eraseFlash(addr_of(page,0)))return false;
            slot=0;
        }
    }
    RiderSavedRecord next={SAVE_MAGIC,has_last?last.seq+1u:1u,best,diamonds,0, SAVE_COMMIT};
    next.crc=crc16((const uint8_t*)&next,16u);
    const uint32_t addr=addr_of(page,(unsigned)slot);
    if(!writeFlash(addr,(const uint8_t*)&next,18u))return false;
    if(!writeFlash(addr+18u,(const uint8_t*)&next.commit,2u))return false;
    const RiderSavedRecord *check=(const RiderSavedRecord*)readFlash(addr,RECORD_SIZE);
    return valid(check) && check->seq==next.seq;
}
#endif
