#ifndef RIDER_SAVES_H
#define RIDER_SAVES_H
#include <stdint.h>
#include <stdbool.h>
/* Reserved GC01 application-save partition, independent of measurement log.
 * This module only writes when called explicitly from the game controller. */
bool rider_saves_load(uint32_t *best, uint32_t *diamonds);
bool rider_saves_store(uint32_t best, uint32_t diamonds);
#endif
