from pathlib import Path
import os, subprocess, sys, tempfile, shutil
ROOT = Path(__file__).resolve().parents[1]
# This runs after a copied repo is patched, asserts exact layout text + boundaries.
ini=(ROOT/'platform.io/platformio.ini').read_text()
head=(ROOT/'platform.io/src/peripherals/flash.h').read_text()
start=ini.index('[env:fnirsi-gc01_apm32f103rb-en]')
end=ini.find('\n[',start+1)
section=ini[start:end if end!=-1 else None]
assert section.count('-DFIRMWARE_SIZE=0x13000')==1
assert section.count('-DGC01_RIDER')==1
assert '#define RIDER_SAVES_SIZE (2 * FLASH_PAGE_SIZE)' in head
assert '#define STATES_BASE (RIDER_SAVES_BASE + RIDER_SAVES_SIZE)' in head
app_start=0x08004000; app_size=0x13000; page=0x400
saves=app_start+app_size
states=saves+2*page
log=states+page
assert (saves,states,log)==(0x08017000,0x08017800,0x08017c00)
assert (0x08020000-log)//page==33
assert app_start+app_size <= saves < states < log < 0x08020000
print('PASS: Exact 76+2+1+33 KiB partition boundaries; only APM32 English target modified')

# Independent compile-time check of the installed C header, including journal
# and logging end addresses. No board or host runtime memory access.
check = r"""
#include "flash.h"
_Static_assert(FIRMWARE_BASE == 0x08004000, "app base");
_Static_assert(FIRMWARE_SIZE == 0x13000, "app size");
_Static_assert(RIDER_SAVES_BASE == 0x08017000, "save base");
_Static_assert(RIDER_SAVES_SIZE == 0x800, "save size");
_Static_assert(STATES_BASE == 0x08017800, "settings base");
_Static_assert(STATES_SIZE == 0x400, "settings size");
_Static_assert(DATALOG_BASE == 0x08017c00, "log base");
_Static_assert(DATALOG_SIZE == 0x8400, "log size");
_Static_assert(DATALOG_END == 0x08020000, "log end");
_Static_assert(DATALOG_BASE % FLASH_PAGE_SIZE == 0, "log page alignment");
_Static_assert((DATALOG_END - DATALOG_BASE) / FLASH_PAGE_SIZE == 33, "log pages");
"""
subprocess.run([os.environ.get('CC', 'gcc'), '-std=c11', '-x', 'c', '-fsyntax-only',
    '-I'+str(ROOT/'platform.io/src/peripherals'), '-DGC01', '-DGC01_RIDER',
    '-DFIRMWARE_BASE=0x08004000', '-DFIRMWARE_SIZE=0x13000',
    '-DFLASH_BASE_=0x08000000', '-DFLASH_SIZE_=0x20000', '-DFLASH_PAGE_SIZE=1024',
    '-'], input=check, text=True, check=True)
print('PASS: actual C flash.h app, save, settings and log bounds match the 76 KiB audit')
