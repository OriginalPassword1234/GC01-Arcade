# GC01 Rider v0.9 — independent graphics / track / physics update

This is experimental firmware for the FNIRSI GC01 APM32F103RBT6, integrated with Rad Pro 3.1.1. Source is independently written; it does not contain the original Rider textures, level data or physics engine. Not a one-to-one reconstruction.

## Tested changes
- Stable ground contact now uses road projection while *already in contact*, preventing a small wheel-tilt correction from becoming a phantom jump. Crest launches are handled separately to preserve actual airtime and scoring.
- 4096 angular positions per turn; flips start counting at 270 degrees following published reconstruction data; multiple completed flips award multiple points on a successful landing.
- 40 small terrain/rail templates (including flat, valley, ramps and gap patterns), with closed loop and two hand-authored 2D paths: high vertical wall with launch and deep U-shaped bowl. Four score-dependent difficulty pools at 0/15/40/75.
- Three independently collectible diamonds on selected sections; spike platforms with matching collision metadata; saws above the rail; on-rail luminous chevron boosts.
- Dark blue sky, darker angular below-track terrain, thinner pink-white rail, smaller bike, short exhaust particles only while accelerating, slower saw animation, white score, BEST high score and functional pause HUD.
- The active-game power timer is refreshed on the event heartbeat **and** the main game loop (including pause), leaving the normal power behavior unchanged in menus.
- Rendering stays in 320x3 RGB565 strips. Three small per-strip change hashes allow a single horizontal changed tile to be transferred rather than a whole strip. Host pixel reconstruction tests validate exact output. Downsampled distant silhouette uses 240 B less RAM and 75% fewer far-background hash computations. No full framebuffer, heap or DMA takeover.
- Persistent best and diamond counts use the existing two-page 2-KiB game-save journal; writes on death or exit, not continuously.

## Verified host checks
- GCC and Clang AddressSanitizer/UndefinedBehaviorSanitizer. 500 deterministic novice-track seeds, random button presses, saving/recovery, loop/wall/bowl traversal, 270 degree scoring, grouped diamonds, grounded stability, spike metadata, renderer stress, and pixel-perfect partial-screen transfer reconstruction.
- Hardware 30 FPS, one-to-one Rider level appearance, true Box2D physics, and correct radiation interrupts during internal flash writes are **NOT** proven. Real GC01 measurement is still needed; the user's previous reference was ~20 FPS.

## Flash and safety boundaries
The reserved layout is 16 KiB bootloader + 68 KiB application + 2 KiB game saves + 1 KiB settings + 41 KiB radiation log. Pre-existing settings/history may not be migrated by the expanded update. A signed GitHub build is a candidate, NOT a proven hardware-safe upgrade; keep a recovery method, known-good firmware, and calibration/history backups.

## Research and inspiration
Compared against the user-provided original 2017 Ketchapp Rider screenshots and the independent NumPlay Rider documentation, which reports 95 original endless sections and Box2D/LiquidFun physics. This v0.9 does **not** incorporate those source/game assets. See https://github.com/Mason363/NumPlay/blob/main/games/rider/README.md.
