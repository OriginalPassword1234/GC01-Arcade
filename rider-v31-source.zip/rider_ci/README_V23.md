# Rider v2.3 — memory-focused optimization candidate

Baseline: exact v2.2 source. User's real ARM build was 76,476 bytes (6,848 over 69,628-byte payload) with 2,704 bytes spare SRAM (368 below 3,072). No partition or safety gate is changed.

RAM: 240-byte simulation retained, previous render state replaced by exact 24-byte snapshot, 3-row rendering retained, 2 x 32-bit checksums per strip instead of 3. Periodic full-strip repair retained. Measured game static subtotal 3,965 B instead of 4,501 B (536 B reduction); nominal full-firmware headroom must be rechecked. Two larger tiles can transfer more pixels: host extended test 192,034,560 vs 179,888,484, identical transaction count and zero pixel mismatches. Actual LCD speed unknown.

Flash: shared exact Q8 and surface delta calculations, common takeoff setup, deduplicated height rows and blank rock texture rows, exact bounded fractional division without 64-bit divide, selected no-inline functions based on Cortex-M3 Clang object measurements. Keep all template IDs, geometry, physics and visible pixels.

New automatic fallback to GCC 12.3 with -Oz and LTO variants, only if original compiler profiles do not fit. All profile reports saved even on failure. Compiler timing and compatibility unverified on hardware. Full ARM link not possible locally: no installed PlatformIO toolchain or accessible upstream checkout. No guarantee of fit. DO NOT FLASH; expanded-layout and hardware safety remain unresolved.
