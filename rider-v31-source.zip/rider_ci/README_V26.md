# Rider v2.6 — diagnostic 74 KiB application layout

Game implementation and compiler profiles are unchanged from v2.5. The last user build measured 74596 bytes and 3232 bytes of nominal spare SRAM. The application partition increases from 68 to 74 KiB solely by consuming six 1 KiB pages from the radiation-log allocation. Payload limit is 75772 bytes (four-byte CRC reserved), leaving 1176 bytes if the build size is unchanged. The 3072-byte nominal SRAM requirement is unchanged.

Partition map (end addresses exclusive):

- Bootloader: 0x08000000–0x08004000 (16 KiB, untouched by application layout)
- Application: 0x08004000–0x08016800 (74 KiB; CRC at 0x080167fc)
- Game journal: 0x08016800–0x08017000 (2 KiB)
- Instrument settings: 0x08017000–0x08017400 (1 KiB)
- Radiation log: 0x08017400–0x08020000 (35 KiB)

Log capacity decreases from 41 to 35 KiB relative to v2.5, and from 55 to 35 KiB relative to the original 56 KiB app layout. The data log codec, measurement code, alarms, settings logic, USB code and bootloader are not modified by this revision. Existing settings, game saves and radiation logs are NOT migrated; installation could erase or invalidate them. No USB bootloader compatibility, settings migration, physical stack, radiation accuracy or recovery validation has been performed. Do not flash the resulting diagnostic image or use it for radiation safety decisions.
