#!/usr/bin/env python3
"""One-target-only fail-closed Rad Pro 3.1.1 76+2+1+33 KiB layout patch.

Makes NO claim that the physical USB bootloader supports a longer application.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
INI = ROOT/'platform.io/platformio.ini'
FLASH_H = ROOT/'platform.io/src/peripherals/flash.h'
TARGET='[env:fnirsi-gc01_apm32f103rb-en]'

def apply():
    ini=INI.read_text()
    if ini.count(TARGET)!=1:raise RuntimeError('Expected exact APM32 English target once')
    pos=ini.index(TARGET)
    end=ini.find('\n[',pos+len(TARGET))
    if end<0:end=len(ini)
    block=ini[pos:end]
    if block.count('-DFIRMWARE_SIZE=0xe000')!=1:
        raise RuntimeError('Original 56KiB app setting missing; unexpected Rad Pro checkout')
    if '-DGC01_RIDER' in block:
        raise RuntimeError('Rider flag already present; refusing unexpected patched input')
    block=block.replace('    -DFIRMWARE_SIZE=0xe000','    -DFIRMWARE_SIZE=0x13000\n    -DGC01_RIDER',1)
    ini=ini[:pos]+block+ini[end:]
    # Only update the target English environment; all others are untouched.
    if ini.count('-DFIRMWARE_SIZE=0x13000') != 1:
        raise RuntimeError('Unexpected number of expanded partition target settings')
    original='#define STATES_BASE (FIRMWARE_BASE + FIRMWARE_SIZE)'
    before=FLASH_H.read_text()
    if before.count(original)!=1:
        raise RuntimeError('Expected original flash.h layout not found')
    patch='''/* The GC01 Rider partition deliberately reserves 2 KiB after the 76 KiB
 * program for the power-fail-safe high-score journal. App writes are limited
 * to changes on crash/quit; they do not affect radiation history pages.
 * Settings and history move upward. Old logs/settings are not migrated.
 * This diagnostic layout must not be flashed until recovery is validated.
 */
#if defined(GC01_RIDER) && defined(GC01)
#define RIDER_SAVES_BASE (FIRMWARE_BASE + FIRMWARE_SIZE)
#define RIDER_SAVES_SIZE (2 * FLASH_PAGE_SIZE)
#define STATES_BASE (RIDER_SAVES_BASE + RIDER_SAVES_SIZE)
#else
#define STATES_BASE (FIRMWARE_BASE + FIRMWARE_SIZE)
#endif'''
    after=before.replace(original,patch,1)
    assert '#define STATES_SIZE FLASH_PAGE_SIZE' in after
    INI.write_text(ini)
    FLASH_H.write_text(after)
    print('LAYOUT: boot 0x08000000-0x08003FFF (16 KiB)')
    print('LAYOUT: app  0x08004000-0x08016FFF (76 KiB, includes CRC footer)')
    print('LAYOUT: save 0x08017000-0x080177FF (2 KiB Rider score journal)')
    print('LAYOUT: state 0x08017800-0x08017BFF (1 KiB)')
    print('LAYOUT: log  0x08017c00-0x0801FFFF (33 KiB)')
    print('WARNING: old settings and history are NOT automatically migrated.')

if __name__=='__main__':apply()
