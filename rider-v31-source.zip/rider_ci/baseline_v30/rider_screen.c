/* GC01 ST7789: three-row strips, full 32-bit hashes, split middle
 * region, at most 80 transactions. No heap or interrupt changes. */
#if defined(GC01_RIDER)
#include <stdint.h>
#include <string.h>
#include "rider_screen.h"
#include "rider_render.h"
#include "draw.h"

#define ROWS 3
#define WIDTH 320
#define HEIGHT 240
#define STRIPS (HEIGHT/ROWS)
#define SPLIT_START 20u
#define SPLIT_COUNT 40u
static uint32_t previous_hash[STRIPS];
static uint32_t second_hash[SPLIT_COUNT]; /* 160 B: exact 32-bit right-half hashes */
static uint8_t refresh_phase,cache_valid;
void rider_screen_invalidate(void){cache_valid=0;refresh_phase=0;}
static uint32_t hash_region(const uint16_t *p,unsigned start,unsigned width)
{
    uint32_t h=2166136261u;
    for(unsigned y=0;y<ROWS;y++)for(unsigned i=start;i<start+width;i+=2u){
        uint32_t pair=(uint32_t)p[y*WIDTH+i]|((uint32_t)p[y*WIDTH+i+1u]<<16);
        h^=pair;
        h=((h<<13)|(h>>19))*0x9e3779b1u;
    }
    return h;
}
static void send_rows(int top,int rows,const uint16_t *p,void *unused)
{
    (void)unused;
    if(rows!=ROWS || top<0 || top+rows>HEIGHT || top%ROWS!=0)return;
    unsigned slot=(unsigned)top/ROWS;
    bool force=!cache_valid || slot==refresh_phase;
    unsigned start=0,width=WIDTH;
    if(slot-SPLIT_START<SPLIT_COUNT){
        unsigned j=slot-SPLIT_START;
        uint32_t l=hash_region(p,0,160),r=hash_region(p,160,160);
        bool left=force||l!=previous_hash[slot],right=force||r!=second_hash[j];
        previous_hash[slot]=l;second_hash[j]=r;
        if(!left&&!right)return;
        if(left!=right){start=left?0:160;width=160;}
    }else{
        uint32_t h=hash_region(p,0,WIDTH);
        if(!force&&h==previous_hash[slot])return;
        previous_hash[slot]=h;
    }
    const mr_rectangle_t area={(int16_t)start,(int16_t)top,(int16_t)width,ROWS};
    if(width!=WIDTH){
        uint16_t *q=(uint16_t *)(void *)p;
        for(unsigned y=0;y<ROWS;y++)memmove(q+y*160,p+y*WIDTH+start,160*sizeof(uint16_t));
        drawImage(&area,q);
    }else drawImage(&area,p);
}
void rider_draw_gc01_snapshot(const RiderState *s,const RiderRenderPrevious *prev,uint8_t alpha)
{
    rider_render_snapshot(s,prev,alpha,send_rows,0);
    cache_valid=1;
    refresh_phase=(uint8_t)((refresh_phase+1u)%80u);
}
#endif

#if defined(GC01_RIDER) && defined(RIDER_HOST_TEST)
void rider_draw_gc01(const RiderState *s,const RiderState *prev,uint8_t alpha)
{
    RiderRenderPrevious snapshot;
    if(prev)rider_capture_previous(&snapshot,prev);
    rider_draw_gc01_snapshot(s,prev?&snapshot:0,alpha);
}
#endif
