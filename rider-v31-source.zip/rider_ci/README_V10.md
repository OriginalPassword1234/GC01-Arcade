# GC01 Rider v1.0 — experimental, separately tested host source

Firmware for the APM32F103RBT6 / GC01, overlaid on Rad Pro 3.1.1. Not the original Ketchapp Rider binary, not a perfect graphics replica. Original game's exact Box2D wheel-joint physics, all 95 levels, advanced moving obstacles and asset textures remain unavailable in this miniature implementation.

## Revisions from v0.9

- Rebalanced novice/preset difficulty pools: 808/1100 sampled early pieces are straight sections; avoid most tiny hills and over-used deep valleys. Adds 4 smoother ramp contours and one 2D open-loop, using flash-resident spline control points. The curved wall and deep bowl use integer cubic interpolation, not sharp point-to-point corners. The closed loop is somewhat larger and flatter at its entrance.
- Tuned normal top speed to 180 world pixels/s; temporary boost permits 300 world pixels/s. Falling force and ramp-launch speed revised to preserve stunt airtime. Controlled air spin peaks at ~369 degrees/s versus >570 previously; released input damps spin faster. Two independent surface probes avoid snapping a far-away wheel into contact. This is NOT a true two-wheel rigid-body simulation.
- Fixed visual frame interpolation: predict a bounded fraction of the latest completed 60 Hz step, rather than interpolating backward from the previous tick. Camera change is independent of scoring/collision. Camera and vehicle are still quantized to LCD pixels.
- Faster loop glow rendering by restricting 7-radius brush to pixels that actually contribute. HUD digit rasterization skips off-strip rows. Terrain rendering samples half-resolution knots with interpolation only on safe, close adjacent heights. Display output sends the smallest contiguous tile range affected, not an entire 320-pixel strip if two tiles happen to change. All operations are static-memory; no heap.
- Delayed game-save flash writes until explicit exit to avoid mid-game erase/program stalls. Paused game no longer continuously redraws; crashed scene redraws only every 250 ms. High scores can be lost on abrupt power-off without exiting Rider.
- Preserved pause icon, high-score journal, diamond count, boost chevrons, green neon car, bright track rails, red saws/spikes, Geiger priority and screen-awake heartbeat integration.

## Host verification

GCC and Clang AddressSanitizer/UndefinedBehaviorSanitizer tests, 500 automated beginner runs, 100 button-driven stunt runs, two-flip scoring, 2D closed/open loop and wall/bowl path checks, 1000 simulated flash saves, rectangle display pixel reconstruction, screenshot rendering, and air spin damping. Some automatic novice runs fail at intentionally introduced saws (5/500 by last measurement); the game is not guaranteed to have traversable structures for all control choices.

Render static allocation 3045 bytes; 480 bytes of checksum cache and two game states of 472 bytes. Full build must still pass the **unchanged** >=3072 B nominal SRAM headroom check; the stack and radiation ISR nesting are not measured by host tests.

## Critical safety / flashing notes

This has NOT been built to ARM or run on an actual GC01 in this environment. The GitHub workflow creates a CRC-signed candidate only after its tests and memory audit pass. The 68-KiB app, 2-KiB game-save, 1-KiB settings and 41-KiB radiation-log partition layout has no migration mechanism: old calibration and radiation history may be erased or inaccessible. USB bootloader acceptance is unverified. Have a working known-good firmware and SWD recovery plan; do not treat the modified GC01 as a verified radiation safety instrument.

The users reported possible radiation interference; v1.0 defers game-related flash writes until leaving Rider, but interrupt timing and pulse accuracy still MUST be measured on hardware. Screen bus bandwidth and real hardware FPS also remain unmeasured.

Use the v1.0 self-contained GitHub Actions workflow. No other repository folders needed.
