# GC01 Rider v0.8 — experimental candidate

This independent small-memory Rider-inspired engine targets the APM32 GC01 through Rad Pro 3.1.1.

## Changes from v0.7
- **Car stability:** improved surface tangent following, damped midair control, and more forgiving contact orientation while preserving crashes on genuinely inverted landings.
- **Track variety:** ten more height profiles, including larger ramps, valleys, narrow gaps, more booster and saw variants. These are **not** the 95 extracted original Rider chunks.
- **Loop performance:** bounded segment-to-strip culling; desktop loop benchmark measured ~0.22 ms/frame versus ~0.32 ms for v0.7; an exact pixel comparison of the loop renderer passed. These are NOT physical-device FPS measurements.
- **Visuals:** a single anchored and fading exhaust plume; slower blade animation; 320x240 neon purple/white rail and faceted terrain.
- **HUD and pause:** clear BEST counter; pause icon changes to a play triangle; pause overlay; game logic remains frozen when paused.
- **Stay awake:** while Rider's view is active, Rad Pro's backlight timer is refreshed on the heartbeat. Once exiting, the ordinary display timeout is restored automatically.
- **Persistent best and diamonds:** two-page flash journal in the reserved 2KiB save partition, with CRC and last-field commit, writing only when the result changes on crash or exit.
- **Scoring:** confirmed at least one score in a real generated run; unchanged requirement that a full rotation is safely landed.

## Tests
- 500 seeded novice runs under a simple ground-drive policy.
- Determinism, hazard clearance, pause display and state preservation, boost/gems, loop traversal, and randomized input/restarts.
- AddressSanitizer/UndefinedBehaviorSanitizer tests with GCC and Clang (GitHub Actions).
- 1,000 simulated flash saves including interrupted write recovery, 18 page erases observed.
- Renderer static RAM: 3412 bytes, plus screen checksums and two game states. Total firmware RAM limit audited by the ARM build.

## Boundaries and unresolved risks
- 16 KiB bootloader / 68 KiB app / 2 KiB saves / 1 KiB states / 41 KiB radiation log.
- This is NOT the original game's Box2D engine and NOT its 95 original track sections; moving platforms/trapdoors are not reproduced. Do not claim perfect physics or parity.
- No real GC01 frame rate measured for v0.8. User observed around 20 FPS in v0.7; this version needs physical testing.
- Internal flash save writes can stall flash fetch and should be measured against high-rate pulse detection on hardware. They happen only at crash/exit, never each frame.
- This workflow is not proof of bootloader compatibility, radiation safety, or settings/history preservation. The device remains experimental.
- Save records are intended to survive normal restarts; updating firmware may erase the reserved save pages depending on the bootloader.
- The user must back up calibration/settings/history and keep a known-good image before reflashing.
