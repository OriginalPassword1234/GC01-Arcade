/* Test the exact firmware app using mocked hardware and Rad Pro callbacks. */
#include <assert.h>
#include <stdio.h>
#include "extras/rider_app.c"
uint32_t currentTick;
static bool game_mode,held=true,draw_requested,alarm,measurement_view;
static unsigned simulated_draw_ms=32,draws,backlight;
static OnViewEvent *current_view;
void setKeyboardMode(int m){game_mode=m==KEYBOARD_MODE_GAME;}
bool isGameKeyHeld(int k){(void)k;return held;}
bool isKeyboardGameMode(void){return game_mode;}
void showMenu(const Menu*m){(void)m;current_view=NULL;}
void showSettingsMenu(void){}
void selectMenuItem(const Menu*m,menu_size_t k){m->select(k);}
void requestViewUpdate(void){draw_requested=true;}
void requestBacklightTrigger(void){backlight++;}
void showView(OnViewEvent *v){current_view=v;requestViewUpdate();}
bool isCurrentView(OnViewEvent*v){return current_view==v;}
bool isPoweredOn(void){return true;}
bool isDisplayAwake(void){return true;}
int getAlertLevel(void){return alarm?1:ALERTLEVEL_NONE;}
void setMeasurementView(void){measurement_view=true;current_view=NULL;}
bool rider_saves_load(uint32_t*b,uint32_t*d){*b=0;*d=0;return true;}
bool rider_saves_store(uint32_t b,uint32_t d){(void)b;(void)d;return true;}
void rider_screen_invalidate(void){}
void rider_draw_gc01_snapshot(const RiderState*s,const RiderRenderPrevious*p,uint8_t a){assert(s&&p);(void)a;draws++;currentTick+=simulated_draw_ms;}
static void pump_draw(void){if(draw_requested){draw_requested=false;assert(current_view);current_view(EVENT_DRAW);}}
int main(void){
    resetGame();assert(game_active&&game_mode);pump_draw();assert(draws==1);
    /* 32 ms of drawing plus 2 ms idle, 17 ms minimum, no stale request-time timestamp. */
    assert(draw_interval_ms==34);updateGame();assert(!draw_requested);
    currentTick++;updateGame();assert(!draw_requested);
    currentTick++;updateGame();assert(draw_requested);pump_draw();assert(draws==2&&rider.theme==34);
    assert(last_draw==34u);assert(currentTick==66u);
    /* Confirm pause doesn't accrue physics time and preserves the FPS estimate. */
    on_rider_event(EVENT_KEY_GAME_OK);assert(paused&&rider.paused&&step_accumulator==0);pump_draw();
    unsigned tick=rider.tick_count;currentTick+=1000;updateGame();assert(rider.tick_count==tick);
    on_rider_event(EVENT_KEY_GAME_OK);assert(!paused&&!rider.paused);pump_draw();
    /* Restart from a paused crash must resume instead of sticking paused. */
    rider.phase=RIDER_CRASHED;on_rider_event(EVENT_KEY_GAME_OK);assert(paused);
    on_rider_event(EVENT_KEY_GAME_RIGHT);assert(!paused&&!rider.paused&&rider.phase==RIDER_READY&&step_accumulator==0);
    alarm=true;updateGame();assert(!game_active&&!game_mode&&measurement_view);
    puts("PASS: exact app callback scheduler, 2ms interval, pause/restart, presentation timing and alarm priority");return 0;
}
