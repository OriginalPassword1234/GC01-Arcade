/* New actual simulation, hazard and render regression tests. */
#include "../src/rider_render.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
static uint16_t frame[320*240];
static void sink(int y,int rows,const uint16_t *p,void *ignored){(void)ignored;assert(y>=0&&y+rows<=240);memcpy(frame+y*320,p,(size_t)rows*320*2);}
static void ring(void){
 RiderState s;rider_init(&s,3);s.track[0].template_id=65;s.track[0].flags=0;s.track[0].start_y=166;
 int32_t x,y;assert(rider_piece_ring_q(&s,0,&x,&y));assert(x==112*RIDER_Q&&y==72*RIDER_Q);
 assert(rider_ring_contains_q(32*RIDER_Q,0,0,0));assert(rider_ring_contains_q(-32*RIDER_Q,0,0,0));
 assert(!rider_ring_contains_q(0,32*RIDER_Q,0,0));assert(!rider_ring_contains_q(0,0,0,0));
 assert(rider_ring_contains_q(0,32*RIDER_Q,128,0));assert(!rider_ring_contains_q(32*RIDER_Q,0,128,0));
 s.camera_x=0;s.camera_y=-50*RIDER_Q;s.x=5*RIDER_Q;s.y=160*RIDER_Q;
 rider_render(&s,NULL,0,sink,NULL);unsigned red=0;for(unsigned i=0;i<320*240;i++){unsigned p=frame[i];if((p>>11)>26&&((p>>5)&63)<30&&(p&31)<16)red++;}assert(red>100);
 s.phase=RIDER_RUNNING;s.x=x+32*RIDER_Q;s.y=y;s.grounded=0;s.vx=s.vy=0;rider_step(&s,false);assert(s.phase==RIDER_CRASHED);
 puts("v1.6 opposed ring sectors rotate, actual red pixels, open middle, lethal active sector PASS");
}
static void pause_score(void){RiderState s;rider_init(&s,1);s.phase=RIDER_RUNNING;s.paused=1;RiderState copy=s;rider_step(&s,true);assert(!memcmp(&s,&copy,sizeof s));s.paused=0;s.score=INT32_MAX-1;s.pending_score=16;s.pending_ticks=1;rider_step(&s,false);assert(s.score==INT32_MAX&&s.best==INT32_MAX);puts("v1.6 paused core is unchanged; saturated pending score PASS");}
static void routes(void){unsigned seen[RIDER_TEMPLATE_COUNT]={0},pass[RIDER_TEMPLATE_COUNT]={0},crash[RIDER_TEMPLATE_COUNT]={0};for(unsigned seed=1;seed<=400;seed++){RiderState s;rider_init(&s,seed);unsigned old=0,k=0;for(unsigned t=0;t<11000;t++){rider_step(&s,s.grounded);unsigned pn=(unsigned)s.x/65536u;if(pn!=old){assert(k<RIDER_TEMPLATE_COUNT);if(pn>old)pass[k]++;old=pn;k=s.track[pn%12].template_id;assert(k<RIDER_TEMPLATE_COUNT);seen[k]++;}if(s.phase==RIDER_CRASHED){crash[k]++;break;}if(pn>=120)break;}}for(unsigned k=65;k<RIDER_TEMPLATE_COUNT;k++){if(k==75u)continue; /* retired from endless generation; explicit geometry tests retained */ printf("v1.6 template %u: encounters=%u exits=%u crashes=%u\n",k,seen[k],pass[k],crash[k]);assert(seen[k]>=30&&pass[k]>=30);}}
static void lift(void){RiderState s;rider_init(&s,1);RiderPiece *p=&s.track[0];p->template_id=70;p->start_y=180;p->flags=0;int32_t a,b,y,z;assert(rider_platform_q(&s,0,&a,&b,&y));s.phase=RIDER_RUNNING;s.x=120*RIDER_Q;s.y=y-5*RIDER_Q;s.grounded=1;s.tick_count=65529;rider_step(&s,1);assert(p->flags&0x10);s.tick_count=65545;assert(rider_platform_q(&s,0,&a,&b,&z)&&z<y);assert(rider_surface_q(&s,120*RIDER_Q,&a)&&a==z);s.tick_count=65611;rider_step(&s,0);assert(p->flags&0x40);s.tick_count=65530+65536;assert(rider_platform_q(&s,0,&a,&b,&z)&&z==y-20*RIDER_Q);puts("v1.6 contact-triggered lift: shared surface, real activation, permanent height across tick wrap PASS");}
int main(void){ring();pause_score();lift();routes();return 0;}
