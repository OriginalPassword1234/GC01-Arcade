/* Current engine tests; deliberately include implementation for template audit. */
#include "../src/rider_core.c"
#include <stdio.h>
#include <assert.h>
static const unsigned meta[]={0,0,0,0,0,0,0,0,0,4,4,8,16,18,0,16,3,0,0,0,0,16,8,0,0,4,0,3,3,2,2,0,0,0,0,0,2,0,0,8,3,2,0,2,0,3,3,3,0,2,0,2,3,2,3,3,3,3,3,7,7,3,3,3,3,3,3,3,3,3,3,7,3,3,3,3,19,3,3,3,3,3,7,3};
static void fixture(RiderState *s,unsigned k){rider_init(s,1);for(unsigned i=0;i<12;i++){s->track[i].template_id=0;s->track[i].start_y=166;s->track[i].flags=0;}s->track[1].template_id=(uint8_t)k;s->track[1].flags=(uint8_t)((meta[k]>>1)&14u);for(unsigned i=2;i<12;i++)s->track[i].start_y=(int16_t)(166+piece_end_delta((uint8_t)k,166));s->phase=RIDER_RUNNING;s->x=220*256;s->y=161*256;}
static void audit(unsigned hard){unsigned total=0;for(unsigned k=0;k<RIDER_TEMPLATE_COUNT;k++){unsigned ok=0;for(unsigned phase=0;phase<8;phase++)for(unsigned mode=0;mode<8;mode++){RiderState s;fixture(&s,k);if(hard){s.track[1].flags|=PIECE_FLAG_HARD;s.score=400;}s.vx=(2+mode%3)*256;s.tick_count=phase*32;for(unsigned t=0;t<400;t++){bool held=s.grounded ? (mode<3||((t+phase*5)%32)<(mode==3?24:mode==4?20:mode==5?16:mode==6?12:8)):false;rider_step(&s,held);if(s.phase==RIDER_CRASHED)break;if(s.x>=2*65536+24*256&&s.grounded){ok++;break;}}}printf("template %u: %u/64 isolated crossings\n",k,ok);assert(ok>0);if(k==60||k==65||k==71||k==82)assert(ok<64);total+=ok;}printf("%u template types (hard=%u), %u/%u successful isolated crossing attempts\n",RIDER_TEMPLATE_COUNT,hard,total,RIDER_TEMPLATE_COUNT*64u);}
static void landing_fixture(RiderState *s,unsigned rotation,int angle){
    fixture(s,0);s->x=70*256;s->y=160*256;s->vx=0;s->vy=256;s->grounded=0;
    s->angle=angle;s->air_rotation=rotation;s->airborne_ticks=30;
}
static void scoring(void){
    RiderState s;
    const unsigned rotations[]={0,3072,3968,4096,8064,8192,12288};
    const unsigned points[]={0,0,2,2,4,4,6};
    for(unsigned i=0;i<sizeof rotations/sizeof *rotations;++i){
        landing_fixture(&s,rotations[i],0);
        rider_step(&s,false);
        assert(s.phase==RIDER_RUNNING&&s.score==(int)points[i]);
        assert(s.flips_landed==points[i]/2 && s.best==s.score);
        int old=s.score;
        for(unsigned j=0;j<70;j++){rider_step(&s,false);assert(s.score==old);}
        assert(!s.pending_score&&!s.pending_ticks);
    }
    /* A real rotation that is short of two full turns must not round up. */
    landing_fixture(&s,7000,0);rider_step(&s,false);assert(s.score==2);
    landing_fixture(&s,8192,2048);rider_step(&s,false);assert(s.phase==RIDER_CRASHED&&s.score==0&&s.flips_landed==0);
    /* Safe but non-perfect orientation earns one point per turn. */
    landing_fixture(&s,8192,256);rider_step(&s,false);assert(s.phase==RIDER_RUNNING&&s.score==2&&s.flips_landed==2);
    fixture(&s,0);s.pending_score=7;s.pending_ticks=1;s.x=70*256;s.y=411*256;rider_step(&s,true);assert(s.phase==RIDER_CRASHED&&s.score==0&&s.best==0&&s.pending_score==0);
    /* No score for any ordinary crossing, even a hazard, a guided loop,
       collecting gems, or an airborne skip. No airtime throttle here. */
    for(unsigned k=0;k<RIDER_TEMPLATE_COUNT;k++)for(unsigned phase=0;phase<8;phase++){
        fixture(&s,k);s.vx=4*256;s.tick_count=phase*32;
        for(unsigned t=0;t<180&&s.phase==RIDER_RUNNING;t++){
            rider_step(&s,s.grounded!=0);assert(s.score==0&&s.flips_landed==0);
        }
    }
    /* Ballistic simulation, not injecting accumulated rotation: use the
       actual rotation controls and integration from a high rising lip. */
    unsigned multi=0;
    for(unsigned release=52;release<96;release++){
        fixture(&s,0);s.x=70*256;s.y=120*256;s.vx=3*256;s.vy=-3*256;
        s.grounded=0;s.angle=0;s.takeoff_angle=0;
        for(unsigned t=0;t<180 && s.phase==RIDER_RUNNING&&!s.grounded;t++)rider_step(&s,t<release);
        if(s.phase==RIDER_RUNNING&&s.grounded&&s.flips_landed>=2){assert(s.score>=2);multi++;}
    }
    assert(multi>0);printf("PASS: immediate exact single/double/triple scoring; zero unearned points; %u simulated double-turn control schedules\n",multi);
}
static void generation(void){unsigned seen[RIDER_TEMPLATE_COUNT]={0},late[RIDER_TEMPLATE_COUNT]={0},different=0;for(unsigned seed=1;seed<=2048;seed++){RiderState a,b;rider_init(&a,seed*0x9e3779b9u);rider_init(&b,seed*0x9e3779b9u);assert(rider_hash(&a)==rider_hash(&b));assert(a.track[0].template_id==0);for(unsigned i=1;i<12;i++){assert(a.track[i].template_id<RIDER_TEMPLATE_COUNT);seen[a.track[i].template_id]++;}unsigned old=a.track[2].template_id;rider_restart(&a);different+=a.track[2].template_id!=old;b.score=400;for(unsigned i=0;i<48;i++){append_piece(&b);unsigned k=b.last_template;assert(k<RIDER_TEMPLATE_COUNT);late[k]++;}}unsigned n=0,e=0;for(unsigned i=0;i<RIDER_TEMPLATE_COUNT;i++){n+=seen[i]>0;e+=late[i]>0&&!seen[i];}assert(n>=45&&e>=12&&different>1800);assert(seen[82]&&seen[83]);for(unsigned i=0;i<4;i++){unsigned k=(unsigned[]){16,47,52,75}[i];assert(!seen[k]&&!late[k]);}printf("PASS: %u early templates, %u late-exclusive templates, %u/2048 changed opening challenges\n",n,e,different);}
static void fuzz(void){uint32_t rng=12345;for(unsigned seed=1;seed<=512;seed++){RiderState s;rider_init(&s,seed*0x9e3779b9u);for(unsigned t=0;t<2400;t++){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;int32_t old=s.score;uint32_t oldflips=s.flips_landed;rider_step(&s,(rng&15u)<12u);assert(s.score>=old);assert(s.phase<=RIDER_CRASHED);if(s.score>old){assert(s.grounded&&!s.looping&&s.flips_landed>oldflips);assert(s.score-old==(int)(s.flips_landed-oldflips)||s.score-old==2*(int)(s.flips_landed-oldflips));}if(s.phase==RIDER_CRASHED){assert(!s.pending_score&&!s.pending_ticks);rider_restart(&s);}assert(s.vx>=-4*256&&s.vx<=9*256);}}puts("PASS: 1,228,800 randomized physics steps");}
static void timing(void){
    for(unsigned hard=0;hard<2;hard++){
        RiderState s;fixture(&s,0);s.vx=4*256;s.score=hard?400:0;
        unsigned t=0;while(s.vx>0 && t<200){rider_step(&s,false);t++;}
        assert(s.vx==0&&t==(hard?86u:52u));printf("Brake stop hard=%u in %u ticks\n",hard,t);
        fixture(&s,58);s.track[1].flags|=PIECE_FLAG_FALLING;s.track[1].fall_tick=0;
        int32_t a,b,y;s.tick_count=0;assert(rider_platform_q(&s,1,&a,&b,&y));s.tick_count=40;assert(!rider_platform_q(&s,1,&a,&b,&y));
        fixture(&s,83);s.track[1].flags|=PIECE_FLAG_FALLING;s.track[1].fall_tick=0;s.tick_count=30;
        assert(!rider_platform_at_q(&s,1,0,&a,&b,&y)&&rider_platform_at_q(&s,1,1,&a,&b,&y));
        s.tick_count=60;assert(!rider_platform_at_q(&s,1,1,&a,&b,&y));
    }
    /* A halted player on the collapsing tile must actually fall. */
    RiderState s;fixture(&s,58);s.x=(256+128)*256;s.vx=0;
    int32_t y;assert(rider_surface_q(&s,s.x,&y));s.y=y-5*256;
    for(unsigned i=0;i<240 && s.phase==RIDER_RUNNING;i++)rider_step(&s,false);
    assert(s.phase==RIDER_CRASHED);
    puts("PASS: brake, staggered tile decay and stationary collapse");
}
static void actual_hazards(void){
    for(unsigned hard=0;hard<2;hard++)for(unsigned j=0;j<5;j++){
        unsigned k=(unsigned[]){9,60,65,71,82}[j];unsigned crashed=0,crossed=0;
        for(unsigned phase=0;phase<32;phase++){
            RiderState s;fixture(&s,k);s.vx=4*256;s.tick_count=phase*8;
            if(hard){s.score=400;s.track[1].flags|=PIECE_FLAG_HARD;}
            for(unsigned t=0;t<300;t++){
                rider_step(&s,s.grounded!=0);
                if(s.phase==RIDER_CRASHED){crashed++;break;}
                if(s.x>=2*65536+24*256&&s.grounded){crossed++;break;}
            }
        }
        printf("Timed hazard %u hard=%u: %u crossings / %u crashes (32 approach phases)\n",k,hard,crossed,crashed);
        assert(crashed>0&&crossed>0);
    }
}
int main(void){generation();scoring();timing();actual_hazards();audit(0);audit(1);fuzz();return 0;}
