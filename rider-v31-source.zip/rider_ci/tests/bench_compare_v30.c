#define _POSIX_C_SOURCE 200809L
#include "../src/rider_render.h"
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <string.h>
#include <assert.h>
extern void base_rider_init(RiderState*,uint32_t);
extern void base_rider_step(RiderState*,bool);
extern void base_rider_restart(RiderState*);
extern void base_rider_draw_gc01(const RiderState*,const RiderState*,uint8_t);
extern void base_rider_screen_invalidate(void);
extern void rider_draw_gc01(const RiderState*,const RiderState*,uint8_t);
extern void rider_screen_invalidate(void);
typedef struct {int16_t x,y,width,height;} mr_rectangle_t;
static uint64_t calls,pixels;
static uint16_t lcd[320*240];
void drawImage(const mr_rectangle_t *a,const uint16_t *p){calls++;pixels+=(uint32_t)a->width*a->height;for(int y=0;y<a->height;y++)memcpy(lcd+(a->y+y)*320+a->x,p+y*a->width,a->width*sizeof(uint16_t));}
static uint64_t now(void){struct timespec t;assert(!clock_gettime(CLOCK_MONOTONIC,&t));return (uint64_t)t.tv_sec*1000000000u+(uint64_t)t.tv_nsec;}
int main(void){static RiderState states[600],prev[600];RiderState s;base_rider_init(&s,0x49d1u);for(unsigned i=0;i<600;i++){prev[i]=s;for(unsigned j=0;j<3;j++){base_rider_step(&s,s.grounded);if(s.phase==RIDER_CRASHED){base_rider_restart(&s);prev[i]=s;}}states[i]=s;}for(unsigned mode=0;mode<2;mode++){uint64_t elapsed=0;calls=pixels=0;for(unsigned repeat=0;repeat<3;repeat++){if(mode)rider_screen_invalidate();else base_rider_screen_invalidate();uint64_t t=now();for(unsigned i=0;i<600;i++){if(mode)rider_draw_gc01(&states[i],&prev[i],180);else base_rider_draw_gc01(&states[i],&prev[i],180);}elapsed+=now()-t;}printf("%s: 1800 matched input frames, %.3f ms/frame host CPU incl simulated LCD, %llu transfers, %llu pixels\n",mode?"v3.0":"v2.9.1",elapsed/1800000000.0,(unsigned long long)calls,(unsigned long long)pixels);}puts("No physical bus timing measured; changed exhaust/hazard pixels may affect transfer counts.");}
