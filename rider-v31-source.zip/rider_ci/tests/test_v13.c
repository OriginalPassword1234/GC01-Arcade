/* Shared geometry, proximity-triggered arc and measured narrow rail. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static void arch(void){
 RiderState s;rider_init(&s,3);s.track[0].template_id=54;s.track[0].flags=1;s.track[0].gem_mask=7;
 int32_t x,y;assert(rider_track_special_q(&s,0,54,256,&x,&y));
 int a=-800;int sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
 s.phase=RIDER_RUNNING;s.grounded=0;s.angle=a;s.vx=3*cs;s.vy=3*sn-15;
 s.x=x+5*sn-s.vx;s.y=y-5*cs-s.vy-15;
 RiderState far=s;far.x-=70*RIDER_Q;rider_step(&far,0);assert(!far.looping);
 rider_step(&s,0);assert(s.looping&&s.loop_piece==0&&s.loop_t<600);
 unsigned ticks=0;while(s.looping&&ticks++<400)rider_step(&s,1);
 assert(s.phase==RIDER_RUNNING&&!s.looping&&!s.grounded&&s.loop_t==4096);
 puts("v1.3 detached rail: proximity/direction capture, no distant snap, tangent exit PASS");
}
static void gap(void){
 RiderState s;rider_init(&s,1);s.track[0].template_id=53;s.track[0].flags=1;s.track[0].gem_mask=7;
 int32_t x,y,l,r;assert(rider_surface_q(&s,123*RIDER_Q,&l));assert(!rider_surface_q(&s,150*RIDER_Q,&y));assert(rider_surface_q(&s,174*RIDER_Q,&r));
 assert(r>l+30*RIDER_Q);
 for(unsigned i=0;i<3;i++){assert(rider_piece_gem_q(&s,0,i,&x,&y));assert(y<l+(r-l)*(x-123*RIDER_Q)/(51*RIDER_Q));}
 puts("v1.3 split rail: collision-free gap and airborne gems PASS");
}
static uint16_t line[240];
static void sink(int y,int rows,const uint16_t*p,void*ctx){(void)ctx;for(int i=0;i<rows;i++)line[y+i]=p[i*320+100];}
static void thin(void){
 RiderState s;rider_init(&s,3);s.track[0].template_id=0;s.track[0].flags=0;s.camera_x=s.camera_y=0;s.x=15*RIDER_Q;
 rider_render(&s,NULL,0,sink,NULL);
 int mid=166*2/3,bright=0;for(int y=mid-12;y<=mid+12;y++)if((line[y]>>11)>25&&((line[y]>>5)&63)>50&&(line[y]&31)>25)bright++;
 assert(bright>=1&&bright<=4);assert((line[mid-5]>>11)<15);assert((line[mid-5]>>11)>0);
 printf("v1.3 rail: %d high-intensity pixels across horizontal rail plus soft exterior PASS\n",bright);
}
int main(void){arch();gap();thin();return 0;}
