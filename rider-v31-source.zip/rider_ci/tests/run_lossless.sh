#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-cc}
flags=(-std=c11 -O2 -Wall -Wextra -Werror)
# Rename all public reference symbols, preserving the unmodified baseline files.
mapfile -t names < <(grep -hE '^(bool|void|int16_t|int32_t|uint32_t) rider_[a-zA-Z0-9_]+\(' tests/reference_v21a/*.h | sed -E 's/^[^ ]+ (rider_[a-zA-Z0-9_]+)\(.*/\1/' | sort -u)
rename=(); for n in "${names[@]}"; do rename+=("-D$n=base_$n"); done
"$cc" "${flags[@]}" "${rename[@]}" -c tests/reference_v21a/rider_core.c -o "$work/base_core.o"
"$cc" "${flags[@]}" "${rename[@]}" -c tests/reference_v21a/rider_render.c -o "$work/base_render.o"
"$cc" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_lossless.c "$work/base_core.o" "$work/base_render.o" -o "$work/test"
"$work/test"
