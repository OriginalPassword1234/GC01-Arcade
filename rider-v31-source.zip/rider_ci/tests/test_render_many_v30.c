#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static int expected;
static int rows;
static uint64_t sum;
static void sink(int top,int n,const uint16_t *data,void *ctx)
{
    (void)ctx;
    assert(n==3);
    assert(top==expected);
    for(int i=0;i<n*320;i++) sum+=(uint32_t)data[i];
    expected+=n;
    rows+=n;
}
int main(void)
{
    assert(rider_render_static_ram()<=4096);
    for(unsigned seed=1;seed<=7;seed++) {
        RiderState s,prev;
        rider_init(&s,seed*0x12479u);
        for(int tick=0;tick<800;tick++) {
            prev=s;
            rider_step(&s,s.grounded!=0);
            if(tick%37==0) {
                expected=0;
                rows=0;
                rider_render(&s,&prev,117,sink,0);
                assert(rows==240);
            }
        }
    }
    printf("render 7 seeds x 800 physics ticks verified; checksum=%llu, staticRAM=%u\n",
      (unsigned long long)sum,(unsigned)rider_render_static_ram());
    return 0;
}
