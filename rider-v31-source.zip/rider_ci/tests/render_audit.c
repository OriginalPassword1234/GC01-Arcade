/* 300 original-to-this-replica live-frame QA samples, NOT original Rider screenshots.
 * Run: mkdir -p /tmp/rider-qa; ./render_audit /tmp/rider-qa */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
static FILE *out;
static uint32_t h;
static int next_row;
static void sink(int top,int rows,const uint16_t *p,void *ctx){(void)ctx;assert(top==next_row&&rows>0&&top+rows<=240);next_row+=rows;for(int i=0;i<rows*320;i++){unsigned c=p[i];h=(h^c)*16777619u; if(out){unsigned char rgb[]={((c>>11)&31)*255/31,((c>>5)&63)*255/63,(c&31)*255/31};assert(fwrite(rgb,1,3,out)==3);}}}
int main(int argc,char **argv){unsigned count=0;uint32_t hashes[300];for(unsigned seed=1;seed<=30&&count<300;seed++){RiderState s,prev;rider_init(&s,seed);for(unsigned t=0;t<11000&&count<seed*10&&count<300;t++){prev=s;rider_step(&s,s.grounded);if(s.phase==RIDER_CRASHED){rider_restart(&s);continue;}if(t<80||(t+seed*13)%677!=0||s.phase!=RIDER_RUNNING)continue;char fn[512];if(argc==2){int n=snprintf(fn,sizeof fn,"%s/%03u.ppm",argv[1],count+1);assert(n>0&&(size_t)n<sizeof fn);out=fopen(fn,"wb");assert(out);fprintf(out,"P6\n320 240\n255\n");}next_row=0;h=2166136261u;rider_render(&s,&prev,120,sink,NULL);assert(next_row==240);if(out){fclose(out);out=NULL;}for(unsigned i=0;i<count;i++)assert(hashes[i]!=h);hashes[count++]=h;unsigned pn=(unsigned)s.x/65536u;printf("%03u seed=%u tick=%u section=%u template=%u framehash=%08x\n",count,seed,t,pn,s.track[pn%12].template_id,h);}}
assert(count==300);puts("300 distinct live replica frame hashes; 240 rows each; no staged states PASS");return 0;}
