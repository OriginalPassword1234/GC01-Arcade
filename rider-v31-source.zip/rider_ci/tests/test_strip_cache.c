#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static uint32_t calls,pixels;
static uint16_t actual[320*240], expected[320*240];
void rider_screen_invalidate(void);
void rider_draw_gc01(const RiderState *s,const RiderState *p,uint8_t alpha);
typedef struct { int16_t x,y,width,height; } mr_rectangle_t;
void drawImage(const mr_rectangle_t *a,const uint16_t *buffer)
{
    assert(a->x>=0 && a->x+a->width<=320 && a->width>0);
    assert(a->height==2 && a->y%2==0 && a->y+a->height<=240);
    assert(buffer);
    for(int row=0;row<a->height;row++)
        memcpy(actual+(a->y+row)*320+a->x,buffer+row*a->width,
               (size_t)a->width*sizeof(uint16_t));
    calls++;pixels+=(unsigned)a->width*(unsigned)a->height;
}
static void sink(int y,int rows,const uint16_t *data,void *ctx)
{
    (void)ctx;assert(rows==2);
    memcpy(expected+y*320,data,(size_t)rows*320*sizeof(uint16_t));
}
static void compare(const RiderState *s,const RiderState *p,uint8_t a)
{
    rider_render(s,p,a,sink,NULL);
    assert(memcmp(actual,expected,sizeof(actual))==0);
}
int main(void)
{
    RiderState s;rider_init(&s,0x1aeu);
    rider_screen_invalidate();
    rider_draw_gc01(&s,NULL,0);
    assert(calls==120 && pixels==320u*240u);
    compare(&s,NULL,0);
    calls=0;pixels=0;
    rider_draw_gc01(&s,NULL,0);
    assert(calls==0 && pixels==0);
    RiderState prev=s;
    for(int i=0;i<15;i++)rider_step(&s,true);
    rider_draw_gc01(&s,&prev,180);
    compare(&s,&prev,180);
    assert(calls>0 && calls<120);
    printf("v0.9 rectangle redraw: %u transactions, %u/%u pixels transferred\n",
            calls,pixels,320u*240u);
    rider_screen_invalidate();
    calls=0;pixels=0;
    rider_draw_gc01(&s,NULL,0);
    compare(&s,NULL,0);
    assert(calls==120 && pixels==320u*240u);
    puts("PASS: partial strip transfers match full renderer byte-for-byte");
}
