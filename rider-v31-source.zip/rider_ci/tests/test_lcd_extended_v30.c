#include "rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static uint32_t calls,pixels;
static uint16_t actual[320*240], expected[320*240];
void rider_screen_invalidate(void);
void rider_draw_gc01(const RiderState *s,const RiderState *p,uint8_t alpha);
typedef struct { int16_t x,y,width,height; } mr_rectangle_t;
void drawImage(const mr_rectangle_t *a,const uint16_t *buffer)
{
    assert(a->x>=0 && a->x+a->width<=320 && a->width>0);
    assert(a->height==3 && a->y%3==0 && a->y+a->height<=240);
    assert(buffer);
    for(int row=0;row<a->height;row++)
        memcpy(actual+(a->y+row)*320+a->x,buffer+row*a->width,
               (size_t)a->width*sizeof(uint16_t));
    calls++;pixels+=(unsigned)a->width*(unsigned)a->height;
}
static void sink(int y,int rows,const uint16_t *data,void *ctx)
{
    (void)ctx;assert(rows==3);
    memcpy(expected+y*320,data,(size_t)rows*320*sizeof(uint16_t));
}
static uint16_t tilehash(const uint16_t *p,unsigned row,unsigned x0,unsigned x1){uint16_t h=0xA17B;for(unsigned y=row;y<row+2;y++)for(unsigned x=x0;x<x1;x++){h=(uint16_t)((h^p[y*320+x])*0x9E37u+0x1F7Bu);h=(uint16_t)((h<<3)|(h>>13));}return h;}
int main(void){
 /* Simulate an omitted update by corrupting a pixel, then keep rendering
  * the identical state. Scheduled refresh must recover the exact display. */
 RiderState fixed;rider_init(&fixed,1);rider_screen_invalidate();
 rider_draw_gc01(&fixed,NULL,0);actual[239*320+319]^=1u;
 for(unsigned i=0;i<80;i++)rider_draw_gc01(&fixed,NULL,0);
 rider_render(&fixed,NULL,0,sink,NULL);
 assert(memcmp(actual,expected,sizeof(actual))==0);
 puts("Periodic refresh repairs deliberately stale pixels within 80 draws PASS");
 calls=pixels=0;
 unsigned bad=0; unsigned first=0; unsigned frames=0; unsigned pixels_bad=0;
 for(unsigned seed=1;seed<=4;seed++){
 RiderState s;rider_init(&s,seed);rider_screen_invalidate();
 for(unsigned t=0;t<1200;t++){
 RiderState prev=s;rider_step(&s,s.grounded);
 if(s.phase==RIDER_CRASHED){rider_restart(&s);rider_screen_invalidate();prev=s;}
 rider_draw_gc01(&s,&prev,180);rider_render(&s,&prev,180,sink,NULL);frames++;
 unsigned diff=0;for(unsigned j=0;j<320*240;j++)if(actual[j]!=expected[j])diff++;
 if(diff){if(!bad){first=t;printf("first mismatch seed=%u tick=%u pixels=%u\n",seed,t,diff);for(unsigned j=0;j<320*240;j++)if(actual[j]!=expected[j]){unsigned x=j%320,row=(j/320)/2*2;unsigned a=x<160?0:160,b=x<160?160:320;printf("tile rows=%u..%u cols=%u..%u actual_hash=%04x expected_hash=%04x actual_pixel=%04x expected_pixel=%04x\n",row,row+1,a,b-1,tilehash(actual,row,a,b),tilehash(expected,row,a,b),actual[j],expected[j]);break;}}bad++;pixels_bad+=diff;}
 }
 }
 printf("frames=%u mismatched=%u pixel-differences=%u first_tick=%u\n",frames,bad,pixels_bad,first);printf("transferred %u pixels in %u calls\n",pixels,calls);return bad?1:0;
}
