#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp"/{measurements,peripherals,system,ui,tests}
cp datalog_v28.c "$tmp/measurements/datalog.c"
cp tests/test_datalog_v27.c "$tmp/tests/"
cp tests/datalog_shim.h "$tmp/shim.h"
for file in measurements/{datalog,history}.h peripherals/{flash,rtc}.h system/{cmath,settings}.h ui/{menu,system,view}.h; do printf '#include "../shim.h"\n' > "$tmp/$file"; done
"${CC:-gcc}" -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -no-pie "$tmp/tests/test_datalog_v27.c" -o "$tmp/test"
UBSAN_OPTIONS=halt_on_error=1 "$tmp/test"
for test in test_minute_v28 test_fault_v28; do
  cp "tests/$test.c" "$tmp/tests/"
  "${CC:-gcc}" -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -no-pie "$tmp/tests/$test.c" -o "$tmp/test"
  UBSAN_OPTIONS=halt_on_error=1 "$tmp/test"
done
cp tests/test_datalog_storage.c "$tmp/tests/"
for version in v26 v27 v28; do
  if [[ "$version" == v26 ]]; then cp baseline_v26/datalog.c "$tmp/measurements/datalog.c"; elif [[ "$version" == v27 ]]; then cp baseline_v27/datalog.c "$tmp/measurements/datalog.c"; else cp datalog_v28.c "$tmp/measurements/datalog.c"; fi
  "${CC:-gcc}" -std=c11 -O2 -Wall -Wextra -Werror "$tmp/tests/test_datalog_storage.c" -lm -o "$tmp/storage"
  printf 'Storage benchmark %s (synthetic Poisson, 20 CPM):\n' "$version"
  "$tmp/storage"
done
