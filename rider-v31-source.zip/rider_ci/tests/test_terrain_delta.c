/* Compare the real firmware decoder with the exact v2.9 run table. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../src/rider_render.c"
#include "texture_reference/v29_terrain.h"

int main(void)
{
    uint8_t rows[2][TERRAIN_MAX_RUNS]={{127u},{0}};
    unsigned pos=0, len=1;
    for(unsigned y=0;y<TERRAIN_ROWS;y++){
        unsigned slot=y&1u;
        if(y)len=terrain_decode(rows[slot^1u],rows[slot],&pos);
        const uint8_t *r=terrain_runs+terrain_offsets[y];
        assert(len==(unsigned)(terrain_offsets[y+1]-terrain_offsets[y]));
        assert(len<=TERRAIN_MAX_RUNS && pos<=TERRAIN_NIBBLES);
        assert(!memcmp(rows[slot],r,len));
        uint8_t ref[512];unsigned x=0;
        for(unsigned i=0;i<len;i++){
            unsigned q=r[i], n=q==127u?512u:(q&63u)+1u;
            assert(x+n<=512u);
            memset(ref+x,q==127u?0:(q>>6),n);x+=n;
        }
        assert(x==512u);
        /* Test every possible scroll origin and a full wrap plus one pixel. */
        for(unsigned origin=0;origin<512u;origin++){
            TerrainScan t=terrain_scan(rows[slot],len,origin);
            for(unsigned i=0;i<=512u;i++){
                assert(t.shade==ref[(origin+i)&511u]);
                assert(t.left>0);
                if(--t.left==0)terrain_next(&t);
            }
        }
    }
    assert(pos==TERRAIN_NIBBLES);
    /* HUD buffers now use their exact required sizes. Verify clamping,
     * digit boundaries, random full-range values and a plus prefix. */
    uint32_t rng=0x6f31b2a4u;
    for(unsigned i=0;i<100010u;i++){
        rng=rng*1664525u+1013904223u;
        uint32_t n=i<10u?(uint32_t[]){0,9,10,99,100,9999999,10000000,99999999,100000000,UINT32_MAX}[i]:rng;
        char actual[9],expected[9],bonus[10];
        uint32_t clamped=n>99999999u?99999999u:n;
        int count=snprintf(expected,sizeof expected,"%lu",(unsigned long)clamped);
        assert(count>=1 && count<=8);
        assert(number(actual,n)==(unsigned)count && !strcmp(actual,expected));
        bonus[0]='+';assert(number(bonus+1,n)==(unsigned)count && bonus[0]=='+' && !strcmp(bonus+1,expected));
    }
    puts("PASS: 100010 HUD number/buffer boundary cases");
    printf("PASS: %u exact RLE rows, %u texture pixels and %u wrapped pixel checks\n",
           TERRAIN_ROWS,TERRAIN_ROWS*512u,TERRAIN_ROWS*512u*513u);
    return 0;
}
