/* Host-only live timing comparison. Native RGB565 frame plus 12px input indicator;
 * no game state or camera manipulation. argv: seed frames mode (0 hold,1 deliberate). */
#include "../src/rider_render.h"
#include <stdio.h>
#include <stdlib.h>
static void sink(int top,int rows,const uint16_t *p,void *ctx){(void)top;(void)ctx;for(int i=0;i<320*rows;i++){putchar(p[i]&255);putchar(p[i]>>8);}}
int main(int argc,char **argv){if(argc!=4)return 2;unsigned seed=(unsigned)strtoul(argv[1],0,10),n=(unsigned)strtoul(argv[2],0,10);bool deliberate=atoi(argv[3])!=0;RiderState s,prev;rider_init(&s,seed);bool held=true;unsigned stable=0;
for(unsigned frame=0;frame<n;frame++){prev=s;if(deliberate){if(!s.grounded){held=false;stable=0;}else if(!held&&++stable>=6)held=true;}rider_step(&s,held);rider_render(&s,&prev,255,sink,NULL);uint16_t col=s.phase==RIDER_CRASHED?0xf986:held?0x07e0:0x4208;for(int i=0;i<320*12;i++){putchar(col&255);putchar(col>>8);}}
fprintf(stderr,"seed=%u deliberate=%u phase=%d score=%d piece=%d ticks=%u\n",seed,deliberate,s.phase,s.score,s.x/65536,s.tick_count);return ferror(stdout)?5:0;}
