/* Host integration test: the exact firmware C file, with mock flash and RTC.
 * Run in a temporary tree with shim headers; no target flash access. */
#include <assert.h>
#include <stdio.h>
#include <math.h>
#include "../measurements/datalog.c"
static uint8_t flash[DATALOG_SIZE];
static uint32_t now, pulses, writes, erases;
Settings settings;
const uint8_t *readFlash(uint32_t a,uint32_t n){assert(a>=DATALOG_BASE && a-DATALOG_BASE<=DATALOG_SIZE && n<=DATALOG_SIZE-(a-DATALOG_BASE));return flash+(a-DATALOG_BASE);}
bool writeFlash(uint32_t a,const uint8_t *p,uint32_t n){assert(a%2==0 && n%2==0);uint8_t *q=(uint8_t*)readFlash(a,n);for(unsigned i=0;i<n;i++){assert(q[i]==0xff);q[i]=p[i];}writes+=n/2;return true;}
bool eraseFlash(uint32_t a){assert(a%FLASH_PAGE_SIZE==0);memset((void*)readFlash(a,FLASH_PAGE_SIZE),255,FLASH_PAGE_SIZE);++erases;return true;}
uint32_t getDeviceTime(void){return now;} uint32_t getDeviceTimeFast(void){return now;} uint32_t getTubePulseCount(void){return pulses;}
void clearHistory(void){} void selectMenuItem(const Menu *m,menu_size_t i){(void)m;(void)i;} void showMenu(const Menu *m){(void)m;} const char *getString(cstring c){(void)c;return "";} void showSettingsMenu(void){} void showDatalogMenu(void); void showView(OnViewEvent *e){(void)e;} void drawNotification(const char *a,const char *b){(void)a;(void)b;}
static void reset(unsigned mode){memset(flash,255,sizeof flash);memset(&datalog,0,sizeof datalog);now=100;pulses=0xfffffff0u;writes=erases=0;settings.loggingMode=mode;initDatalog();startDatalog();}
static void step(uint32_t delta){now+=loggingModeIntervals[settings.loggingMode];pulses+=delta;updateDatalog();}
static uint32_t rng=0xabc12345u;
static uint32_t random32(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static unsigned poisson(double mean){unsigned k=0;double x=1.0,limit=exp(-mean);do{++k;x*=((double)random32()+1.0)/4294967297.0;}while(x>limit);return k-1;}
int main(void){unsigned modes[]={DATALOG_LOGGINGMODE_1_SECOND,DATALOG_LOGGINGMODE_10_SECONDS,DATALOG_LOGGINGMODE_1_MINUTE};for(unsigned j=0;j<3;j++){reset(modes[j]);rng=0xabc12345u;for(unsigned i=0;i<6000;i++)step(poisson((double)loggingModeIntervals[modes[j]]/3.0));stopDatalog();printf("%u s: %u bytes programmed for 6000 samples\n",loggingModeIntervals[modes[j]],writes*2);}unsigned rates[]={5,10,20,30,40,60,100,200,500,1000};for(unsigned j=0;j<sizeof rates/sizeof rates[0];j++){reset(DATALOG_LOGGINGMODE_1_MINUTE);rng=0xabc12345u;for(unsigned i=0;i<6000;i++){unsigned v=0,m=rates[j];while(m>100){v+=poisson(100);m-=100;}v+=poisson(m);step(v);}stopDatalog();printf("%u CPM minute: %u programmed bytes for 6000 samples\n",rates[j],writes*2);}return 0;}
