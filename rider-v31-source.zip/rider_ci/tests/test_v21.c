#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
static void structures(void){
 for(unsigned k=80;k<=81;k++){
  RiderState s;rider_init(&s,1);s.track[0].template_id=k;s.track[0].start_y=166;s.track[0].flags=1;s.track[0].gem_mask=7;
  int32_t y,x,gy;assert(!rider_surface_q(&s,(k==80?94:89)*RIDER_Q,&y));assert(!rider_surface_q(&s,(k==80?183:171)*RIDER_Q,&y));
  for(unsigned i=0;i<3;i++){assert(rider_piece_gem_q(&s,0,i,&x,&gy));assert(rider_surface_q(&s,x,&y)&&gy<y);}
  if(k==80){int32_t a,b,h;assert(rider_platform_q(&s,0,&a,&b,&h));assert(b-a==74*RIDER_Q);assert(rider_surface_q(&s,a,&y)&&y==h);assert(rider_surface_q(&s,b,&y)&&y==h);}
  else{int32_t a,b,c;assert(rider_surface_q(&s,96*RIDER_Q,&a)&&rider_surface_q(&s,130*RIDER_Q,&b)&&rider_surface_q(&s,164*RIDER_Q,&c)&&b>a&&b>c);}
 }
 puts("v2.1 separate deck and bowl: real gaps, actual collectible positions, shared deck surface PASS");
}
static void boost_without_input(void){RiderState s;rider_init(&s,1);s.track[0].template_id=11;s.track[0].flags=4;s.phase=RIDER_RUNNING;s.x=90*RIDER_Q;s.y=161*RIDER_Q;s.grounded=1;s.vx=3*RIDER_Q;int32_t v=s.vx;rider_step(&s,false);assert(s.boost_ticks&&s.vx>v+50);puts("v2.1 existing booster accelerates without held input PASS");}
static void routes(void){
 unsigned seen[82]={0},exit[82]={0},dead[82]={0},reached=0;
 for(unsigned seed=1;seed<=500;seed++){RiderState s;rider_init(&s,seed);unsigned old=0,k=0;bool got=false;for(unsigned t=0;t<10500;t++){rider_step(&s,s.grounded);unsigned pn=(unsigned)s.x/65536u;if(pn!=old){if(pn>old)exit[k]++;old=pn;k=s.track[pn%12].template_id;assert(k<82);seen[k]++;}if(s.phase==RIDER_CRASHED){dead[k]++;break;}if(!got&&pn>=35){got=true;reached++;}if(pn>=130)break;}}
 printf("v2.1 beginner routes: %u/500\n",reached);assert(reached==500);
 for(unsigned k=80;k<=81;k++){printf("v2.1 template %u: %u exits/%u encounters, %u crashes\n",k,exit[k],seen[k],dead[k]);assert(seen[k]>=100&&exit[k]*100u>=seen[k]*95u);}
}
int main(void){structures();boost_without_input();routes();return 0;}
