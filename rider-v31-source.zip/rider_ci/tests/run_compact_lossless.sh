#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-clang}
python3 tools/compact_backend.py ../overlay/platform.io/src "$work/compact"
# Compile reference API with independent names as in the existing lossless test.
mapfile -t names < <(grep -hE '^(bool|void|int16_t|int32_t|uint32_t) rider_[a-zA-Z0-9_]+\(' tests/reference_v21a/*.h | sed -E 's/^[^ ]+ (rider_[a-zA-Z0-9_]+)\(.*/\1/' | sort -u)
rename=(); for n in "${names[@]}"; do rename+=("-D$n=base_$n"); done
flags=(-std=c11 -O2 -Wall -Wextra -Werror)
"$cc" "${flags[@]}" "${rename[@]}" -c tests/reference_v21a/rider_core.c -o "$work/base_core.o"
"$cc" "${flags[@]}" "${rename[@]}" -c tests/reference_v21a/rider_render.c -o "$work/base_render.o"
printf '#include "%s"\n#include "%s"\n' "$work/compact/combined.c" "$PWD/tests/test_lossless.c" > "$work/test.c"
"$cc" "${flags[@]}" -Wno-unused-function "$work/test.c" "$work/base_core.o" "$work/base_render.o" -o "$work/test"
"$work/test"
