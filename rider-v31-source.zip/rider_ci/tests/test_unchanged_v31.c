/* Exact differential comparison against v3.0, with ONLY the intended palette
 * replacement made to its renderer in the test build. Intentional geometry
 * changes to the lift/moving/falling platforms, ring and double-saw valley are excluded. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
extern void base_rider_init(RiderState*,uint32_t);
extern bool base_rider_surface_q(const RiderState*,int32_t,int32_t*);
extern void base_rider_render(const RiderState*,const RiderState*,uint8_t,RiderPixels,void*);
static uint16_t frames[2][320*240];
static void sink(int y,int rows,const uint16_t *p,void *ctx){unsigned n=*(unsigned*)ctx;memcpy(frames[n]+y*320,p,(size_t)rows*320*sizeof(*p));}
static void render_compare(const RiderState *s,const RiderState *p,const RiderState *expected,uint8_t alpha){unsigned a=0,b=1;rider_render(s,p,alpha,sink,&a);rider_render(expected,NULL,0,sink,&b);assert(!memcmp(frames[0],frames[1],sizeof frames[0]));}
int main(void){unsigned compared=0,samples=0;for(unsigned k=0;k<82;k++){
 if(k==57||k==58||k==65||k==70||k==71)continue;
 RiderState s;base_rider_init(&s,1);for(unsigned i=0;i<12;i++){s.track[i].template_id=0;s.track[i].flags=0;s.track[i].gem_mask=0;s.track[i].start_y=166;}s.track[1].template_id=(uint8_t)k;s.x=330*256;s.y=160*256;s.camera_x=200*256;s.camera_y=-25*256;s.throttle_active=0;
 for(unsigned x=0;x<65536;x+=3){int32_t a=0,b=0;bool p=rider_surface_q(&s,65536+(int32_t)x,&a),q=base_rider_surface_q(&s,65536+(int32_t)x,&b);assert(p==q&&(!p||a==b));samples++;}
 for(unsigned i=0;i<5;i++){s.camera_x=(int32_t)(180+i*19)*256+21*i;s.camera_y=(int32_t)(-25+(int)i*7)*256;s.tick_count=i*43;unsigned a=0,b=1;rider_render(&s,NULL,0,sink,&a);base_rider_render(&s,NULL,0,sink,&b);if(memcmp(frames[0],frames[1],sizeof frames[0])){fprintf(stderr,"unexpected pixel difference: template=%u fixture=%u\n",k,i);return 1;}compared++;}}
 printf("PASS: %u unchanged surface queries, %u pixel-identical static frames after intentional rail-palette substitution\n",samples,compared);
 RiderState s,p,e;rider_init(&s,2);for(unsigned i=0;i<12;i++){s.track[i].template_id=0;s.track[i].flags=0;}
 s.phase=RIDER_RUNNING;s.grounded=1;s.x=80*256;s.y=161*256;s.camera_x=-60*256;s.camera_y=-29*256;s.angle=0;p=s;
 p.grounded=0;p.x-=4*256;p.y-=2*256;p.camera_x-=4*256;p.camera_y-=256;p.angle=4096-128;
 for(unsigned alpha=0;alpha<256;alpha+=17){e=s;int b=(int)(256-alpha);e.x-=4*256*b/256;e.y-=2*256*b/256;e.camera_x-=4*256*b/256;e.camera_y-=256*b/256;e.angle-=128*b/256;render_compare(&s,&p,&e,(uint8_t)alpha);}
 puts("PASS: 16 interpolation phases across airborne-to-ground transition, including angle wrap");return 0;}
