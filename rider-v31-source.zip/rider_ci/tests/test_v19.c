/* v1.9: quantitative rail orientation and contact regression. */
#include "../src/rider_core.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
int main(void){
 RiderState s;rider_init(&s,37u);s.track[0].template_id=28u;s.track[0].flags=0;s.phase=RIDER_RUNNING;s.x=65*RIDER_Q;s.y=161*RIDER_Q;s.vx=4*RIDER_Q;s.grounded=1;
 unsigned steps=0,contact=0,positive=0,negative=0,steep=0,matching=0;int min=0,max=0;
 for(unsigned t=0;t<100;t++){
  rider_step(&s,true);if(s.x>205*RIDER_Q)break;assert(s.phase==RIDER_RUNNING);steps++;contact+=s.grounded!=0;
  if(s.angle<min)min=s.angle;
  if(s.angle>max)max=s.angle;
  int32_t a,b;if(s.grounded&&rider_surface_q(&s,s.x-9*RIDER_Q,&a)&&rider_surface_q(&s,s.x+9*RIDER_Q,&b)&&abs(b-a)>10*RIDER_Q){steep++;if((b>a&&s.angle>200)||(b<a&&s.angle< -200))matching++;}
  positive+=s.grounded&&s.angle>350;negative+=s.grounded&&s.angle< -350;
 }
 printf("v1.9 deep bowl: contact %u/%u, slope direction agreement %u/%u, angle range %d..%d (4096/turn), steep down/up samples %u/%u\n",contact,steps,matching,steep,min,max,positive,negative);
#ifndef BASELINE_REPORT
 assert(steps>25&&contact==steps&&positive>3&&negative>3&&steep>8&&matching*10>=steep*8);
#endif
 unsigned early_loop=0;
 for(unsigned seed=1;seed<=100;seed++){rider_init(&s,seed);early_loop+=s.track[1].template_id==45u;}
 printf("Early open curl (v2.0 opening): %u/100 seeds\n",early_loop);
#ifndef BASELINE_REPORT
 assert(early_loop==100);
#endif
 return 0;
}
