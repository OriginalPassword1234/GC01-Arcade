#include "../src/rider_core.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void test_continuity(void)
{
    RiderState s; rider_init(&s, 12345678);
    for (uint32_t i=1;i<RIDER_TRACK_SLOTS;i++) {
        int32_t a,b;
        assert(rider_surface_q(&s,(int32_t)i*256*256,&b));
        assert(rider_surface_q(&s,(int32_t)i*256*256-1,&a));
        assert((a-b)<256 && (a-b)>-256);
    }
}
static void test_determinism(void)
{
    RiderState a,b; rider_init(&a, 7123); rider_init(&b,7123);
    for(int i=0;i<50000;i++) {
        bool down=(i%117)<105;
        rider_step(&a, down); rider_step(&b,down);
        assert(rider_hash(&a)==rider_hash(&b));
        assert(a.next_piece <= 12+(uint32_t)(a.x/(256*256))+2);
        assert(a.phase>=RIDER_READY && a.phase<=RIDER_CRASHED);
        if(a.phase==RIDER_CRASHED) { rider_restart(&a); rider_restart(&b); }
    }
}
static void test_restarts(void)
{
    RiderState s; rider_init(&s,0);
    s.best=128; s.diamonds=77; for(int i=0;i<300;i++)rider_step(&s,true);
    int best=s.best, diamonds=s.diamonds;
    rider_restart(&s); assert(s.best==best && s.diamonds==diamonds && s.phase==RIDER_READY);
    assert(s.track[0].number==0 && s.x==70*RIDER_Q);
}
static void test_generated_reachability(void)
{
    int crashes=0;
    uint64_t distance=0;
    for(uint32_t seed=1;seed<=500;seed++) {
        RiderState s;rider_init(&s,seed);
        for(int j=0;j<3500;j++) {
            rider_step(&s,s.grounded != 0);
            if((uint32_t)(s.x/(256*256)) >= 35u) break;
            if(s.phase==RIDER_CRASHED) { crashes++;break; }
        }
        distance += (uint32_t)(s.x/(256*256));
    }
    printf("Novice track auto-drive results: %d/500 crashes, distance=%llu pieces\n", crashes, (unsigned long long)distance);
    assert(crashes<=10);
}
static void test_start_ground_contact(void)
{
    RiderState s; rider_init(&s, 0x312af77u);
    assert(s.phase==RIDER_READY && s.grounded);
    rider_step(&s,true);
    assert(s.phase==RIDER_RUNNING && s.grounded);
    assert(s.airborne_ticks==0);
}
static void test_random_input_survival_and_recovery(void)
{
    for(uint32_t seed=1;seed<=256;seed++) {
        RiderState s; rider_init(&s,seed*0x9e3779b9u);
        uint32_t z=seed ^ 0x1234cafeu;
        for(int t=0;t<3200;t++) {
            z^=z<<13;z^=z>>17;z^=z<<5;
            bool pressed=(z&15u)<(t%201<100?13u:4u);
            rider_step(&s,pressed);
            if(s.phase==RIDER_CRASHED){
                assert(s.pending_ticks==0 && s.pending_score==0);
                rider_restart(&s);
                assert(s.grounded && s.phase==RIDER_READY);
            }
            /* A released inverted loop can impart backward ballistic velocity. */
            assert(s.vx>=-4*RIDER_Q && s.vx<=9*RIDER_Q);
            assert(s.phase<=RIDER_CRASHED);
        }
    }
}
static void test_saw_metadata(void)
{
    RiderState s;rider_init(&s,1234u);
    s.track[0].template_id=9u;
    s.track[0].flags|=0x02u;
    int32_t x,y,r;
    assert(rider_piece_saw_q(&s,0u,&x,&y,&r));
    assert(r>=10*RIDER_Q);
    int32_t ground;
    assert(rider_surface_q(&s,x,&ground));
    assert(y+r < ground-5*RIDER_Q);
}
static void test_score_in_generated_gameplay(void)
{
    /* With slower, controllable angular speed, no single pre-v1.0 fixed
     * seed can serve as the sole proof that flips are physically possible.
     * Require points to be earned in many actual generated beginner tracks
     * using the same button rule (accelerate; rotate early in flight). */
    int scored=0;
    for(uint32_t seed=1;seed<=100u;++seed){
        RiderState s;rider_init(&s,seed);
        for(int tick=0;tick<2000;++tick){
            rider_step(&s,s.grounded || s.airborne_ticks<55u);
            if(s.flips_landed>0){scored++;break;}
            if(s.phase==RIDER_CRASHED)break;
        }
    }
    assert(scored>=20);
    printf("v1.0 scored flip in %d/100 generated beginner runs with slower air rotation\n", scored);
}

static void test_two_full_spins_count_once_each(void)
{
    /* Isolate the landing/scoring accounting from stunt input timing:
     * two complete in-air revolutions, perfect wheels-down, award 4. */
    RiderState s;rider_init(&s,4u);
    s.phase=RIDER_RUNNING;
    s.grounded=0;
    s.x=70*RIDER_Q;
    s.y=160*RIDER_Q;
    s.vx=0;
    s.vy=RIDER_Q;
    s.angle=2*RIDER_ANGLE_TURN;
    s.angular_speed=0;
    s.air_rotation=2u*RIDER_ANGLE_TURN;
    rider_step(&s,false);
    assert(s.phase==RIDER_RUNNING);
    assert(s.pending_score==4 && s.pending_ticks==30 && s.flips_landed==2);
    for(int tick=0;tick<30;tick++)rider_step(&s,false);
    assert(s.score==4 && s.best==4 && s.pending_score==0);
}

static void test_loop_traversal(void)
{
    RiderState s;rider_init(&s,5u);
    s.track[0].template_id=16u;
    s.phase=RIDER_RUNNING;
    s.vx=4*RIDER_Q;
    s.x=65*RIDER_Q;
    s.y=161*RIDER_Q;
    s.grounded=1;
    int entered=0,exited=0,reverse=0,min_y=10000;
    int32_t last_x=s.x;
    for(int i=0;i<170;++i){
        rider_step(&s,1);
        assert(s.phase!=RIDER_CRASHED);
        if(s.looping) {
            entered=1;
            if(s.y<min_y)min_y=s.y;
            if(s.x<last_x)reverse=1;
        }
        if(entered && !s.looping){exited=1;break;}
        last_x=s.x;
    }
    assert(entered && exited && reverse);
    assert(min_y<100*RIDER_Q);
    assert(s.grounded && s.x>=130*RIDER_Q);
}

static void test_saw_clearance(void)
{
    RiderState s;rider_init(&s,9u);
    /* Force a saw tile with normal terrain. Its bottom must NOT touch rail. */
    s.track[0].flags|=0x02u;
    int32_t cx,cy,r,ground;
    assert(rider_piece_saw_q(&s,0,&cx,&cy,&r));
    assert(rider_surface_q(&s,cx,&ground));
    assert(cy+r<=ground-5*RIDER_Q);
}

static void test_boost_effect(void)
{
    RiderState s;rider_init(&s,12u);
    s.track[0].template_id=11u;
    s.track[0].flags|=0x04u;
    s.phase=RIDER_RUNNING;
    s.x=90*RIDER_Q;
    s.y=161*RIDER_Q;
    s.grounded=1;
    s.vx=3*RIDER_Q;
    int32_t before=s.vx;
    rider_step(&s,1);
    assert(s.boost_ticks>0 && s.vx>before+50);
}

static void test_diamond_collection(void)
{
    RiderState s;rider_init(&s,0x2222u);
    /* The original base game has collectible gems. With garage excluded,
     * they still have a visible counter and persist across game restarts. */
    s.phase=RIDER_RUNNING;
    s.track[1].template_id=0u;
    s.track[1].flags|=1u; s.track[1].gem_mask=1u;
    s.x=(256+127)*RIDER_Q;
    s.y=161*RIDER_Q;
    s.vx=2*RIDER_Q;
    s.vy=0;
    s.grounded=1;
    int32_t prev=s.diamonds;
    rider_step(&s,1);
    assert(s.diamonds==prev+1);
    assert((s.track[1].flags&1u)==0u);
    rider_step(&s,1);
    assert(s.diamonds==prev+1);
    rider_restart(&s);
    assert(s.diamonds==prev+1);
}

static void test_subdegree_angles(void)
{
    /* 4096 states per turn instead of 256 sampled directions. */
    assert(rider_sin4096(0)==0);
    assert(rider_sin4096(1024)==256);
    assert(rider_sin4096(2048)==0);
    assert(rider_sin4096(3072)==-256);
    assert(rider_sin4096(4096+512)==rider_sin4096(512));
}

static void test_ground_acceleration_and_airtime(void)
{
    RiderState s; rider_init(&s,0x19772106u);
    for(int tick=0;tick<59;++tick)rider_step(&s,true);
    assert(s.phase==RIDER_RUNNING);
    assert(s.vx>2*RIDER_Q);  /* restrained acceleration, but still responsive */
    int air=0;
    for(int tick=0;tick<1400;++tick){
        rider_step(&s,s.grounded!=0);
        if(s.phase==RIDER_CRASHED)break;
        if(!s.grounded)++air;
    }
    assert(air>=30);  /* real airborne periods exist with no jump button */
}

int main(void)
{
    test_continuity();
    test_determinism();
    test_restarts();
    test_start_ground_contact();
    test_random_input_survival_and_recovery();
    test_generated_reachability();
    test_saw_metadata();
    test_saw_clearance();
    test_boost_effect();
    test_diamond_collection();
    test_subdegree_angles();
    test_loop_traversal();
    test_ground_acceleration_and_airtime();
    test_score_in_generated_gameplay();
    test_two_full_spins_count_once_each();
    puts("Core tests passed");
    return 0;
}
