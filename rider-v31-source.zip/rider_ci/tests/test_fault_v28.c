#include <assert.h>
#include <stdio.h>
#include "../measurements/datalog.c"
static uint8_t flash[DATALOG_SIZE];
static uint32_t now,pulses,fail_address=UINT32_MAX,fail_erase=UINT32_MAX;
Settings settings;
const uint8_t *readFlash(uint32_t a,uint32_t n){assert(a>=DATALOG_BASE&&a-DATALOG_BASE<=DATALOG_SIZE&&n<=DATALOG_SIZE-(a-DATALOG_BASE));return flash+(a-DATALOG_BASE);}
bool writeFlash(uint32_t a,const uint8_t*p,uint32_t n){assert(a%2==0&&n%2==0);uint8_t*q=(uint8_t*)readFlash(a,n);for(unsigned i=0;i<n;i+=2){if(a+i==fail_address){fail_address=UINT32_MAX;return false;}assert(q[i]==255&&q[i+1]==255);q[i]=p[i];q[i+1]=p[i+1];}return true;}
bool eraseFlash(uint32_t a){assert(a%FLASH_PAGE_SIZE==0);if(a==fail_erase)return false;memset((void*)readFlash(a,FLASH_PAGE_SIZE),255,FLASH_PAGE_SIZE);return true;}
uint32_t getDeviceTime(void){return now;}uint32_t getDeviceTimeFast(void){return now;}uint32_t getTubePulseCount(void){return pulses;}
void clearHistory(void){}void selectMenuItem(const Menu*m,menu_size_t i){(void)m;(void)i;}void showMenu(const Menu*m){(void)m;}const char*getString(cstring c){(void)c;return "";}void showSettingsMenu(void){}void showView(OnViewEvent*e){(void)e;}void drawNotification(const char*a,const char*b){(void)a;(void)b;}
static void reset(unsigned mode){memset(flash,255,sizeof flash);memset(&datalog,0,sizeof datalog);now=100;pulses=0;fail_address=fail_erase=UINT32_MAX;settings.loggingMode=mode;initDatalog();startDatalog();}
static void step(uint32_t d){now+=loggingModeIntervals[settings.loggingMode];pulses+=d;updateDatalog();}
static void reboot(void){memset(&datalog,0,sizeof datalog);initDatalog();startDatalog();}
static void committed_prefix(void){DatalogRecord r={0};assert(startDatalogRead());assert(readDatalog(&r)&&r.dose.time==100&&r.dose.pulseCount==0);for(unsigned i=1;i<=4;i++)assert(readDatalog(&r)&&r.dose.time==100+60*i&&r.dose.pulseCount==20*i);assert(!readDatalog(&r));}
int main(void){
 for(unsigned cut=0;cut<6;cut+=2){reset(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<4;i++)step(20);unsigned off=datalog.write.pageOffset;fail_address=DATALOG_BASE+off+cut;step(0x12345678u);assert(WRITE_FAULT&&datalog.write.pageOffset==off);committed_prefix();}
 puts("PASS: all three halfword failure positions in a large minute record retain prior measurements");
 for(unsigned cut=0;cut<MINUTE_HEADER;cut+=2){reset(DATALOG_LOGGINGMODE_OFF);settings.loggingMode=DATALOG_LOGGINGMODE_1_MINUTE;fail_address=DATALOG_BASE+cut;startDatalog();assert(WRITE_FAULT);DatalogRecord r={0};assert(startDatalogRead());assert(!readDatalog(&r));}
 puts("PASS: seven interrupted minute header positions cannot publish a fabricated anchor");
 for(unsigned cut=0;cut<10;cut+=2){reset(DATALOG_LOGGINGMODE_OFF);settings.loggingMode=DATALOG_LOGGINGMODE_1_SECOND;fail_address=DATALOG_BASE+2+cut;startDatalog();assert(WRITE_FAULT);DatalogRecord r={0};assert(startDatalogRead());assert(!readDatalog(&r));}
 puts("PASS: five interrupted new legacy anchor positions cannot publish a fabricated anchor");
 reset(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<4;i++)step(20);unsigned off=datalog.write.pageOffset;fail_address=DATALOG_BASE+DATALOG_PAGE_STATE_OFFSET;assert(!writePageStateAndAdvance(PAGESTATE_FULL));assert(WRITE_FAULT&&datalog.write.pageOffset==off);committed_prefix();reboot();assert(!WRITE_FAULT);assert(datalog.write.pageBase!=DATALOG_BASE);puts("PASS: failed minute page status write preserves history; reboot can seal prewritten CRC");
 reset(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<4;i++)step(20);fail_address=DATALOG_BASE+MINUTE_DATA_END;assert(!writePageStateAndAdvance(PAGESTATE_FULL));assert(WRITE_FAULT);committed_prefix();puts("PASS: CRC write failure preserves previously committed readings");
 reset(DATALOG_LOGGINGMODE_1_MINUTE);flash[FLASH_PAGE_SIZE]=0;fail_erase=DATALOG_BASE+FLASH_PAGE_SIZE;assert(!writePageStateAndAdvance(PAGESTATE_FULL));assert(WRITE_FAULT&&flash[FLASH_PAGE_SIZE]==0);puts("PASS: failed page erase stops writer");
 return 0;
}
