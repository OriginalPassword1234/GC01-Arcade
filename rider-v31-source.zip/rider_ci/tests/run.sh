#!/usr/bin/env bash
set -euo pipefail
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
cd "$(dirname "$0")/.."
flags=(-std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -no-pie)
# Fail fast if RAM savings are accidentally reverted, while keeping the
# unchanged 3072 B full-firmware headroom threshold in verify_expanded.py.
"${CC:-cc}" -std=c11 -O2 -Wall -Wextra -Werror src/rider_core.c src/rider_render.c tests/test_ram.c -o /tmp/rider_v09_ram_guard
/tmp/rider_v09_ram_guard
"${CC:-cc}" "${flags[@]}" src/rider_core.c tests/test_core.c -o /tmp/rider_v09_core
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_core
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_render_many.c -o /tmp/rider_v09_render
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_render
"${CC:-cc}" "${flags[@]}" -DGC01_RIDER -DRIDER_HOST_TEST -Isrc -Itests/fake src/rider_core.c src/rider_render.c rider_screen.c tests/test_strip_cache.c -o /tmp/rider_v09_dirty
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_dirty
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/render_scenes.c -o /tmp/rider_v09_preview
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_preview score /tmp/rider_v09_score.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_preview saw /tmp/rider_v09_saw.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_preview loop /tmp/rider_v09_loop.ppm
# Game saves are kept in a separate 2-KiB flash journal. Exercise the *real*
# save source against an emulated flash chip, including interrupted writes.
"${CC:-cc}" "${flags[@]}" -DGC01_RIDER -DGC01 tests/flash_sim/extras/rider_saves.c tests/flash_sim/test_saves.c -o /tmp/rider_v09_saves
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_saves
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_pause_hud.c -o /tmp/rider_v09_pause
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_pause

# Additional 2D rails, grounded-stability, 270-degree flip and multi-gem checks.
"${CC:-cc}" "${flags[@]}" src/rider_core.c tests/test_v09.c -o /tmp/rider_v09_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_regression

# Bright overlapping neon rails and original-like emerald diamonds.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_visual_v09.c -o /tmp/rider_v09_visual
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_visual

# v1.0 original-game-inspired track distributions and open arc geometry;
# verify smooth sub-tick visuals and slower airborne input in the REAL core.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v10.c -o /tmp/rider_v10_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v10_regression
# v1.1: more authentic challenge cadence, speed and per-frame scroll limits.
"${CC:-cc}" "${flags[@]}" src/rider_core.c tests/test_v11.c -o /tmp/rider_v11_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v11_regression

# Source-level Rider v1.1 repair regressions: identical camera scale for
# objects, actual micro-loop, timed/moving hazards and stable gem clusters.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_reference_repairs.c -o /tmp/rider_v11_real_source_repairs
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v11_real_source_repairs

# v1.2: variable elevation, actual special-path transforms, stall and two visible rails.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v12.c -o /tmp/rider_v12_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v12_regression
# v1.3 shared detached rail, contact/release, split gap, narrow rail output.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v13.c -o /tmp/rider_v13_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v13_regression

# v1.4: one visual palette, actual new gaps, tangent launch / relative landing.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v14.c -o /tmp/rider_v14_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v14_regression

# v1.5 actual animated surface and procedural reachability checks.
"${CC:-cc}" "${flags[@]}" src/rider_core.c tests/test_v15.c -o /tmp/rider_v15_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v15_regression

# v1.6 shared ring barrier geometry, score saturation, pause, late route coverage.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v16.c -o /tmp/rider_v16_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v16_regression

# v1.7 compound hazards, independent moving platforms and generated coverage.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v17.c -o /tmp/rider_v17_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v17_regression

# v1.8: true swept-circle contacts, retracting spike rail, roof-first impact and 500-seed route audit.
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v18.c -o /tmp/rider_v18_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v18_regression

# v1.9: actual vehicle slope, continuous rail contact and early stunt cadence.
"${CC:-cc}" "${flags[@]}" src/rider_core.c tests/test_v19.c -o /tmp/rider_v19_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v19_regression

# v2.0 reference curl, safe scoring, hold vs deliberate timing.
"${CC:-cc}" "${flags[@]}" src/rider_core.c tests/test_v20.c -o /tmp/rider_v20_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v20_regression

# v2.1: extended LCD comparison is fail-closed, plus refresh recovery.
"${CC:-cc}" "${flags[@]}" -DGC01_RIDER -DRIDER_HOST_TEST -Isrc -Itests/fake src/rider_core.c src/rider_render.c rider_screen.c tests/test_lcd_extended.c -o /tmp/rider_v21_lcd
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v21_lcd
"${CC:-cc}" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v21.c -o /tmp/rider_v21_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v21_regression
