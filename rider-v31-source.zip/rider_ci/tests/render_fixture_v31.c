/* Diagnostic scenes from exact renderer, with explicit fixture placement.
 * These are geometry inspections, not evidence of a real playthrough. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static FILE *out;
static void sink(int y,int rows,const uint16_t *p,void *ctx){(void)y;(void)ctx;for(int i=0;i<rows*320;i++){unsigned c=p[i];unsigned char rgb[]={((c>>11)&31)*255/31,((c>>5)&63)*255/63,(c&31)*255/31};assert(fwrite(rgb,1,3,out)==3);}}
int main(int argc,char **argv){
 if(argc!=3)return 2;
 static const struct {const char *name;uint8_t kind;} scenes[]={{"referencecurl",45},{"curlexit",45},{"referencedrop",40},{"arc",54},{"gap",53},{"risegap",55},{"highgap",56},{"moving",57},{"falling",58},{"giantsaw",59},{"sawvalley",60},{"wall",27},{"bowl",28},{"perfect",29},{"ring",65},{"lift",70},{"twosaws",71},{"twopads",72},{"timedspikes",76},{"splitbowl",78},{"slopeup",42},{"slopedown",44},{"openloop",46},{"score",36},{"spikes",13},{"triangle",80},{"detachedbowl",81},{"timeddualsaw",82},{"collapsebridge",83}};
 unsigned i=0;while(i<sizeof scenes/sizeof scenes[0]&&strcmp(argv[1],scenes[i].name))i++;if(i==sizeof scenes/sizeof scenes[0])return 2;unsigned k=scenes[i].kind;
 RiderState s;rider_init(&s,0x68a8e26fu);for(unsigned j=0;j<RIDER_TRACK_SLOTS;j++){s.track[j].template_id=0;s.track[j].start_y=166;s.track[j].flags=0;s.track[j].gem_mask=0;}
 s.track[1].template_id=(uint8_t)k;s.track[1].flags=1;s.track[1].gem_mask=7;s.tick_count=80;s.phase=RIDER_RUNNING;s.throttle_active=1;s.vx=4*RIDER_Q;
 if(k==9||k==10||k==25||k==59||k==60||k==71||k==82)s.track[1].flags|=2;
 if(k==13||k==76)s.track[1].flags|=8;
 if(k==58||k==70||k==83){s.track[1].flags|=16;s.track[1].fall_tick=68;}
 if(k==71||k==72||k==76||k==78||k==80||k==81){s.score=120;s.track[1].flags|=128;}
 int32_t xx=(256+95)*RIDER_Q,yy=166*RIDER_Q;
 if((rider_template_properties(k)&RIDER_T_SPECIAL)&&k!=28&&strcmp(argv[1],"curlexit")){s.looping=1;s.loop_piece=1;s.loop_t=1500;assert(rider_track_special_q(&s,1,(uint8_t)k,s.loop_t,&xx,&yy));}else{int32_t q;if(rider_surface_q(&s,xx,&q))yy=q;else s.grounded=0;}
 s.x=xx;s.y=yy-5*RIDER_Q;s.camera_x=165*RIDER_Q;s.camera_y=-80*RIDER_Q;
 if(!strcmp(argv[1],"score")||!strcmp(argv[1],"perfect")){s.score=23;s.best=42;s.pending_score=2;s.pending_ticks=20;s.perfect_ticks=30;}
 out=fopen(argv[2],"wb");assert(out);fprintf(out,"P6\n320 240\n255\n");rider_render(&s,NULL,0,sink,NULL);assert(fclose(out)==0);printf("DIAGNOSTIC FIXTURE %s template=%u\n",argv[1],k);return 0;
}
