/* Desktop CPU microbenchmark only. Not a measurement of physical GC01 FPS. */
#define _POSIX_C_SOURCE 200809L
#include "../src/rider_render.h"
#include <stdint.h>
#include <stdio.h>
#include <time.h>
static volatile uint32_t checksum;
static void sink(int top,int rows,const uint16_t *pixels,void *ignored)
{
    (void)ignored;
    checksum+=pixels[(top+1)%rows*320];
}
int main(void)
{
    struct timespec a,b;
    RiderState s,prev;
    rider_init(&s,0x49d1u);
    clock_gettime(CLOCK_MONOTONIC,&a);
    for(int frame=0;frame<160;frame++){
        prev=s;
        for(int step=0;step<2;step++) {
            rider_step(&s,s.grounded || s.airborne_ticks<23u);
            if(s.phase==RIDER_CRASHED)rider_restart(&s);
        }
        rider_render(&s,&prev,120,sink,0);
    }
    clock_gettime(CLOCK_MONOTONIC,&b);
    long long nsec=(long long)(b.tv_sec-a.tv_sec)*1000000000ll+b.tv_nsec-a.tv_nsec;
    printf("Host-only renderer: %lld ns for 160 frames (%.2f ms/render), checksum=%u\n", nsec,(double)nsec/160000000.0,(unsigned)checksum);
    puts("This does NOT include GC01 parallel-LCD transfers or radiation interrupts.");
    return 0;
}
