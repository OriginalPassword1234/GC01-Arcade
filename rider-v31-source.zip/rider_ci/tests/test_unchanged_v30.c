/* Compare unchanged geometry and decor with the exact previous release. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
extern void base_rider_init(RiderState*,uint32_t);
extern bool base_rider_surface_q(const RiderState*,int32_t,int32_t*);
extern void base_rider_render(const RiderState*,const RiderState*,uint8_t,RiderPixels,void*);
static uint16_t frames[2][320*240];
static void sink(int y,int rows,const uint16_t *p,void *ctx){unsigned n=*(unsigned*)ctx;memcpy(frames[n]+y*320,p,(size_t)rows*320*sizeof(*p));}
int main(void){unsigned compared=0,samples=0;for(unsigned k=0;k<82;k++){RiderState s;base_rider_init(&s,1);for(unsigned i=0;i<12;i++){s.track[i].template_id=0;s.track[i].flags=0;s.track[i].gem_mask=0;s.track[i].start_y=166;}s.track[1].template_id=(uint8_t)k;s.x=330*256;s.y=160*256;s.camera_x=200*256;s.camera_y=-25*256;s.throttle_active=0;
for(unsigned x=0;x<65536;x+=3){int32_t a=0,b=0;bool p=rider_surface_q(&s,65536+(int32_t)x,&a),q=base_rider_surface_q(&s,65536+(int32_t)x,&b);assert(p==q&&(!p||a==b));samples++;}
for(unsigned i=0;i<5;i++){s.camera_x=(int32_t)(180+i*19)*256+21*i;s.camera_y=(int32_t)(-25+(int)i*7)*256;s.tick_count=i*43;unsigned a=0,b=1;rider_render(&s,NULL,0,sink,&a);base_rider_render(&s,NULL,0,sink,&b);if(memcmp(frames[0],frames[1],sizeof frames[0])){fprintf(stderr,"unexpected pixel difference: template=%u fixture=%u\n",k,i);return 1;}compared++;}}
printf("PASS: %u unchanged surface queries, %u pixel-identical static frames\n",samples,compared);return 0;}
