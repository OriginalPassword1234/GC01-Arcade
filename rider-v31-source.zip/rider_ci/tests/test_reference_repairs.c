/* Regression tests against the real v1.0-derived engine and RGB565 renderer.
 * Protect previously-missed camera zoom, collectible, micro-loop and dynamic
 * collision errors. No fake independent gameplay model. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>

static unsigned emerald_pixels,coral_pixels;
static int diamond_x,diamond_y,blade_x,blade_y;
static void check_pixels(int top,int rows,const uint16_t *pixels,void *unused)
{
    (void)unused;
    assert(rows==2);
    for(int row=0;row<rows;++row){
        int yy=top+row;
        for(int xx=0;xx<320;++xx){
            uint16_t c=pixels[row*320+xx];
            int red=((c>>11)&31u)*255/31;
            int green=((c>>5)&63u)*255/63;
            if(xx>=diamond_x-8&&xx<=diamond_x+8&&yy>=diamond_y-11&&yy<=diamond_y+11 &&
               green>190&&red<175)++emerald_pixels;
            if(xx>=blade_x-28&&xx<=blade_x+28&&yy>=blade_y-28&&yy<=blade_y+28 &&
               red>220&&green<120)++coral_pixels;
        }
    }
}
static void test_world_screen_alignment(void)
{
    RiderState s;rider_init(&s,23u);
    s.track[0].template_id=9u;
    s.track[0].flags=0x03u;
    s.track[0].gem_mask=1u;
    s.camera_x=0;
    s.camera_y=-80*RIDER_Q; /* nonzero camera offset exposes mixed zoom bug */
    int32_t gx,gy,bx,by,br;
    assert(rider_piece_gem_q(&s,0,0,&gx,&gy));
    assert(rider_piece_saw_q(&s,0,&bx,&by,&br));
    diamond_x=gx/(384); diamond_y=(gy-s.camera_y)/384;
    blade_x=bx/384;blade_y=(by-s.camera_y)/384;
    emerald_pixels=0;coral_pixels=0;
    rider_render(&s,0,0,check_pixels,0);
    assert(emerald_pixels>=5u); /* emerald really ABOVE track at 2:3 zoom */
    assert(coral_pixels>=50u); /* red swept teeth at SAME physics y */
    printf("actual renderer object alignment PASS: green=%u, saw=%u\n",emerald_pixels,coral_pixels);
}
static void test_micro_loop(void)
{
    RiderState s;rider_init(&s,0x772u);
    s.track[0].template_id=47u;
    s.track[0].flags=0u;
    s.phase=RIDER_RUNNING;
    s.x=65*RIDER_Q;s.y=161*RIDER_Q;s.vx=4*RIDER_Q;s.grounded=1;
    int entered=0,finished=0,reversed=0,miny=200*RIDER_Q;
    int32_t prior=s.x;
    for(int t=0;t<200;++t){
        rider_step(&s,true);
        assert(s.phase!=RIDER_CRASHED);
        if(s.looping){
            entered=1;
            if(s.y<miny)miny=s.y;
            if(s.x<prior)reversed=1;
        } else if(entered){finished=1;break;}
        prior=s.x;
    }
    assert(entered && finished && reversed && s.grounded);
    assert(miny<125*RIDER_Q);
    int32_t x,y;
    assert(rider_special_point_q(0,47u,4096u,&x,&y));
    assert(x==133*RIDER_Q && y==166*RIDER_Q);
}
static void test_dynamic_hazards(void)
{
    RiderState s;rider_init(&s,24u);
    s.track[0].template_id=25u;s.track[0].flags=0x02u;
    int32_t x0,y0,r0,x1,y1,r1,road;
    s.tick_count=0;
    assert(rider_piece_saw_q(&s,0,&x0,&y0,&r0));
    s.tick_count=55;
    assert(rider_piece_saw_q(&s,0,&x1,&y1,&r1));
    assert(x0!=x1 && r0==r1);
    assert(rider_surface_q(&s,x1,&road));
    assert(y1+r1<road-5*RIDER_Q);
    s.track[0].template_id=15u;s.track[0].flags=0x08u;
    s.tick_count=20;
    assert(!rider_piece_spikes_q(&s,0,&x0,&x1,&y0));
    s.tick_count=70;
    assert(rider_piece_spikes_q(&s,0,&x0,&x1,&y0));
}
static void test_oscillating_bridge(void)
{
    RiderState s;rider_init(&s,0x4424u);
    s.track[0].template_id=48u;
    int32_t a,b;
    assert(!rider_surface_q(&s,96*RIDER_Q,&a));
    assert(!rider_surface_q(&s,184*RIDER_Q,&a));
    s.tick_count=0;
    assert(rider_surface_q(&s,130*RIDER_Q,&a));
    s.tick_count=48;
    assert(rider_surface_q(&s,130*RIDER_Q,&b));
    assert(a!=b); /* bridge is alive in PHYSICS, not only cosmetic */
    assert(rider_surface_q(&s,195*RIDER_Q,&b));
    assert(b==166*RIDER_Q); /* runout still starts at original height */
}
static void test_gem_arc_persists_after_pickups(void)
{
    RiderState s;rider_init(&s,29u);
    s.track[0].template_id=29u;s.track[0].flags=0x01u;s.track[0].gem_mask=7u;
    int32_t x,y,ground;
    assert(rider_piece_gem_q(&s,0,1,&x,&y));
    assert(rider_surface_q(&s,x,&ground));
    assert(y<ground-16*RIDER_Q);
    int32_t before_x=x,before_y=y;
    s.track[0].gem_mask=0x06u;
    assert(rider_piece_gem_q(&s,0,1,&x,&y));
    assert(x==before_x && y==before_y);
}
int main(void)
{
    test_world_screen_alignment();
    test_micro_loop();
    test_dynamic_hazards();
    test_oscillating_bridge();
    test_gem_arc_persists_after_pickups();
    puts("PASS: real v1.0-derived geometry, collisions and 2:3 screen-space objects");
    return 0;
}
