/* CPU-only microbenchmark; NEVER use as an on-device FPS claim. */
#define _POSIX_C_SOURCE 200809L
#include "../src/rider_render.h"
#include <stdint.h>
#include <stdio.h>
#include <time.h>
static volatile uint32_t sink_value;
static void sink(int y,int rows,const uint16_t *buffer,void *context)
{
    (void)context; sink_value += (uint32_t)buffer[(y%rows)*320];
}
int main(void)
{
    RiderState s;rider_init(&s,42);
    s.track[0].template_id=16;
    s.x=95*RIDER_Q;
    s.y=80*RIDER_Q;
    s.camera_x=0;
    s.camera_y=-4*RIDER_Q;
    struct timespec t0,t1;clock_gettime(CLOCK_MONOTONIC,&t0);
    for(int i=0;i<120;i++){
        rider_render(&s,NULL,0,sink,NULL);
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    long long ns=(long long)(t1.tv_sec-t0.tv_sec)*1000000000ll+(t1.tv_nsec-t0.tv_nsec);
    printf("%lld ns per 120 loop frames, %.3f ms/frame, checksum=%u\n",ns,(double)ns/120000000.0,(unsigned)sink_value);
    return 0;
}
