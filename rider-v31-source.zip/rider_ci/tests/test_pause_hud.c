#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static uint32_t hash;
static int current_y;
static void sink(int top,int rows,const uint16_t *p,void *ctx)
{
    (void)ctx;
    assert(top==current_y && rows==2);
    /* Only the upper-left HUD and central pause region matter here. */
    for(int y=0;y<rows;y++)
        for(int x=0;x<320;x++)
            if((top+y<56&&x<90)||(top+y>80&&top+y<125&&x>85&&x<230))
                hash=(hash^p[y*320+x])*16777619u;
    current_y+=rows;
}
static uint32_t render_hash(RiderState *s)
{
    hash=2166136261u;current_y=0;
    rider_render(s,0,0,sink,0);
    assert(current_y==240);
    return hash;
}
int main(void)
{
    RiderState s;rider_init(&s,5);
    s.best=25;
    s.score=7;
    uint32_t before=render_hash(&s);
    s.paused=1;
    uint32_t paused=render_hash(&s);
    assert(before!=paused);
    assert(s.score==7 && s.best==25);
    s.paused=0;
    assert(render_hash(&s)==before);
    puts("PASS: pause/play HUD switches without modifying physics or scores");
}
