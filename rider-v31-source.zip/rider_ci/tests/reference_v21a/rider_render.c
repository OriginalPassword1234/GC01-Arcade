#include "rider_render.h"
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define W 320
#define H 240
#define STRIP_ROWS 3
#define RGB(r,g,b) ((((r)>>3)<<11)|(((g)>>2)<<5)|((b)>>3))

static uint16_t strip[W*STRIP_ROWS];
static int16_t surface[W];
/* Distant silhouette has no fine detail: cache in four-pixel columns.
 * 240 bytes RAM reclaimed and 75% fewer background hash calculations. */
static uint8_t backdrop[W/8];
/* Body-only fill height for special paths, at four-column resolution. */
static uint8_t facet[W/4]; /* body-only heights for wall/bowl gaps, 255=none */
static int16_t gemx[10], gemy[10];
static uint8_t gem_n;
static int16_t sawx[4], sawy[4], sawr[4];
static uint8_t saw_n;
/* Boost y is obtained from the surface when painting; no unused cache. */
static int16_t boostx0[4], boostx1[4];
static uint8_t boost_n;
/* One visible triangle per normal 3-piece cadence; two for fixture safety. */
static int16_t triangle[2][3];
static uint8_t triangle_n;
static int16_t spikex0[4],spikex1[4],spikey[4];
static uint8_t spike_n;
/* Two visible paths cached from shared FLASH geometry into compact screen offsets. */
#define PATH_CACHE_COUNT 2
#define PATH_POINTS 49
static uint8_t loop_dx[PATH_CACHE_COUNT][PATH_POINTS];
static int8_t loop_dy[PATH_CACHE_COUNT][PATH_POINTS];
/* Two Q2 fractional coordinates per point, packed into one nibble. */
static uint8_t loop_fraction[PATH_CACHE_COUNT][(PATH_POINTS+1)/2];
static int16_t loop_anchor_x[PATH_CACHE_COUNT],loop_anchor_y[PATH_CACHE_COUNT];
static uint8_t loop_n[PATH_CACHE_COUNT];
static int16_t upper_sky_limit;
static int16_t texture_origin;
/* Q3 screen height, INT16_MAX is a genuine gap. */
#define YQ 8
static int rail_y(int x){return surface[x]==INT16_MAX?INT16_MAX:surface[x]/YQ;}
static int floor4(int n){return n>=0?n/4:-((-n+3)/4);}
/* Independent atmospheric rock silhouettes; 512x66 native-resolution two-bit scanline RLE.
 * Generated from irregular overlapping polygonal rock faces, soft edges,
 * non-grid spacing. Stored in flash; stream runs directly with no decompression buffer or heap. */
static const uint16_t terrain_offsets[67]={
    0,8,16,24,32,40,48,56,64,72,80,88,
    96,104,114,127,140,153,168,184,201,218,235,253,
    273,294,317,341,365,391,417,446,475,508,541,573,
    606,642,677,711,744,774,805,836,864,893,926,958,
    990,1022,1054,1087,1116,1147,1174,1200,1227,1253,1277,1297,
    1317,1337,1357,1377,1398,1418,1437,
};
static const uint8_t terrain_runs[1437]={
    0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,
    0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,
    0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,
    0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,
    0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,
    0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,
    0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x3f,0x37,0xc0,0x3f,0x3f,0x3f,0x3f,
    0x3f,0x06,0x18,0xc0,0x3f,0x3f,0x1c,0x80,0xc3,0x3f,0x3f,0x3f,0x3f,0x3f,0x03,0x16,
    0x81,0xc3,0x3f,0x3f,0x17,0x83,0xc6,0x3f,0x3f,0x3f,0x3f,0x3f,0x15,0x82,0xc6,0x3f,
    0x3f,0x13,0x84,0xc9,0x3f,0x3f,0x3f,0x3f,0x3c,0x13,0x84,0xc9,0x3f,0x3f,0x0f,0x85,
    0xca,0x3f,0x3f,0x06,0xc0,0x3f,0x3f,0x33,0x11,0x86,0xcb,0x3f,0x3f,0x0b,0x87,0xcc,
    0x3f,0x3f,0x03,0x80,0xc1,0x3f,0x3f,0x32,0x0f,0x88,0xce,0x11,0xc0,0x3f,0x34,0x89,
    0xcc,0x3f,0x3f,0x01,0x81,0xc2,0x3f,0x3f,0x31,0x0e,0x89,0xd1,0x0d,0x81,0xc6,0x3f,
    0x2c,0x8a,0xcd,0x3f,0x3f,0x82,0xc4,0x3f,0x3f,0x2f,0x0c,0x8b,0xd4,0x09,0x82,0xce,
    0x3f,0x22,0x8c,0xcf,0x3f,0x3c,0x83,0xc5,0x3f,0x3f,0x2e,0x0a,0x8d,0xd2,0x0a,0x84,
    0xce,0x3f,0x20,0x8d,0xd0,0x3f,0x3a,0x84,0xc6,0x39,0xc0,0x3f,0x32,0x09,0x8e,0xd0,
    0x0b,0x85,0xcf,0x3f,0x1e,0x8f,0xd0,0x3f,0x38,0x85,0xc7,0x36,0x81,0xd3,0x1f,0xc0,
    0x3e,0x07,0x8f,0xcf,0x0c,0x87,0xd0,0x3f,0x1a,0x91,0xd1,0x3f,0x36,0x86,0xc9,0x32,
    0x84,0xd2,0x1e,0x80,0xc1,0x3d,0x05,0x91,0xce,0x0b,0x89,0xd1,0x3f,0x18,0x92,0xd3,
    0x3f,0x33,0x87,0xca,0x2f,0x86,0xd3,0x1b,0x82,0xc2,0x33,0xc0,0x07,0x04,0x92,0xcc,
    0x0c,0x8b,0xd1,0x3f,0x16,0x93,0xd4,0x3f,0x31,0x88,0xd0,0x28,0x87,0xd3,0x1a,0x84,
    0xc2,0x2f,0x82,0xc2,0x05,0x02,0x94,0xca,0x0d,0x8c,0xd2,0x3f,0x13,0x96,0xd4,0x3f,
    0x2f,0x89,0xd6,0x20,0x8a,0xd3,0x17,0x86,0xc3,0x2b,0x85,0xc5,0x02,0x00,0x96,0xc7,
    0x40,0x0e,0x8e,0xd2,0x3f,0x11,0x97,0xd6,0x3f,0x2d,0x89,0xdb,0x40,0x18,0x8c,0xd3,
    0x16,0x87,0xc5,0x26,0x88,0xc7,0x00,0xc1,0x95,0xc5,0x42,0x0d,0x90,0xd3,0x3f,0x01,
    0xcc,0x98,0xd7,0x3f,0x2b,0x8a,0xd8,0x43,0x16,0x8f,0xd2,0x14,0x89,0xc6,0x22,0x8b,
    0xc8,0xc3,0x93,0xc4,0x44,0x0b,0x91,0xd4,0x3d,0x82,0xca,0x9a,0xd8,0x25,0xca,0x03,
    0x80,0x33,0x8b,0xd5,0x46,0x14,0x91,0xd3,0x12,0x8b,0xc6,0x1e,0x8e,0xc8,0xc4,0x92,
    0xc2,0x46,0x0a,0x93,0xd4,0x38,0x86,0xc9,0x9c,0xd9,0x22,0x80,0xce,0x84,0x2e,0x8c,
    0xd3,0x48,0x12,0x93,0xd3,0x10,0x8d,0xc7,0x1a,0x91,0xc8,0xc6,0x90,0xc1,0x47,0x03,
    0x80,0x04,0x94,0xd5,0x34,0x88,0xca,0x9c,0xd9,0x40,0x20,0x81,0xcd,0x88,0x2a,0x8d,
    0xd0,0x4b,0x11,0x95,0xd3,0x0e,0x8e,0xcc,0x40,0x11,0x94,0xc8,0xc7,0x8f,0x49,0x02,
    0xc0,0x81,0x02,0x96,0xd5,0x2f,0x8c,0xc5,0xa1,0xd4,0x45,0x1f,0x82,0xcd,0x8c,0x25,
    0x8e,0xcd,0x4f,0x0e,0x97,0xd3,0x0c,0x90,0xcb,0x41,0x0e,0x96,0xc9,0xc9,0x8d,0x4a,
    0x00,0xc1,0x9b,0xd7,0x2a,0x8f,0xc5,0xa1,0xcf,0x4b,0x1c,0x84,0xcd,0x90,0xc0,0x1f,
    0x8f,0xca,0x52,0x0c,0x99,0xd3,0x0b,0x92,0xc9,0x42,0x0c,0x98,0xc9,0xcb,0x8b,0x4a,
    0xc1,0x9d,0xd7,0x26,0x92,0xc6,0xa1,0xc9,0x50,0x1b,0x85,0xcd,0x93,0xc2,0x19,0x90,
    0xc7,0x55,0x0a,0x9c,0xd3,0x05,0x80,0x01,0x94,0xc9,0x42,0x09,0x9b,0xc9,0xcc,0x8a,
    0x49,0xc2,0x9d,0xd7,0x40,0x21,0x96,0xc6,0xa1,0xc4,0x4e,0x96,0x0a,0x86,0xcc,0x98,
    0xc4,0x12,0x91,0xc5,0x57,0x08,0x88,0xc1,0x93,0xd3,0x04,0xc0,0x97,0xc8,0x44,0x05,
    0x9e,0xc9,0xce,0x88,0x48,0xc3,0x9e,0xcf,0x47,0x1e,0x99,0xc6,0xa1,0x53,0x97,0x08,
    0x87,0xcc,0x9a,0xc7,0x0c,0x92,0xc2,0x5a,0x06,0x88,0xc2,0x95,0xd3,0x02,0xc2,0x96,
    0xc7,0x45,0x02,0xa1,0xc9,0xcf,0x87,0x47,0xc4,0x9e,0xc7,0x4f,0x10,0xa6,0xc8,0xa0,
    0x52,0xc0,0x99,0x05,0x88,0xcc,0x9b,0xcb,0x06,0x93,0x5d,0x05,0x86,0xc5,0x95,0xd3,
    0x02,0xc2,0x96,0xc6,0x46,0xa4,0xc9,0xd1,0x85,0x46,0xc4,0xa0,0x56,0x0f,0xc0,0xa6,
    0xc8,0xa0,0x52,0xc1,0x99,0x03,0x88,0xcc,0x9e,0xcf,0x94,0x5d,0x03,0x86,0xc7,0x95,
    0xd3,0x01,0xc4,0x96,0xc5,0x43,0xa7,0xc9,0xd3,0x83,0x45,0xc5,0x9f,0x58,0x0c,0xc2,
    0xa6,0xc8,0xa0,0x52,0xc1,0xa6,0xcc,0xa0,0xcd,0x94,0x5d,0x01,0x86,0xc8,0x97,0xd9,
    0x96,0xc4,0x41,0xaa,0x40,0xc8,0xd4,0x82,0x44,0xc6,0x9f,0x58,0x0b,0xc3,0xa6,0xc9,
    0xa0,0x50,0xc2,0xa6,0xcc,0xa1,0xc5,0x45,0x95,0x5d,0x86,0xca,0x97,0x40,0xd0,0x80,
    0xc7,0x95,0xc3,0xad,0x49,0x47,0xce,0x80,0x42,0xc8,0x9e,0x59,0x09,0xc5,0xa5,0xca,
    0xa2,0x4e,0xc2,0xa6,0xcc,0xa3,0x49,0x95,0x5b,0x86,0xcc,0x97,0x4a,0xc5,0x80,0xc8,
    0x95,0xc0,0xb0,0x49,0x50,0xc6,0x41,0xc8,0x9f,0x59,0x08,0xc6,0xa4,0xcb,0x9f,0x50,
    0xc4,0xa5,0xcb,0xa6,0x47,0x95,0x59,0x85,0xce,0x98,0x4e,0x81,0xc9,0xbf,0x88,0x48,
    0x4a,0x80,0x4c,0xc9,0x9e,0x5a,0x05,0x80,0xc8,0xa3,0xcd,0x9c,0x52,0xc4,0xa5,0xcb,
    0xa7,0x46,0x96,0x57,0x84,0xd0,0x97,0x4e,0x82,0xca,0xbf,0x87,0x48,0x48,0xc1,0x85,
    0x46,0xca,0x9e,0x5a,0x01,0x83,0xc9,0xa2,0xce,0x99,0x55,0xc4,0xa5,0xcb,0xa9,0x43,
    0x95,0xc0,0x82,0x53,0x84,0xd2,0x97,0x4e,0x81,0xcb,0xbd,0xc1,0x87,0x48,0x46,0xc4,
    0x8a,0xcb,0x9d,0x5a,0x84,0xcb,0xa1,0xcf,0x97,0x56,0xc5,0xa5,0x48,0xc1,0xac,0x41,
    0x93,0xc2,0x84,0x4f,0x84,0xd4,0x97,0x4d,0x81,0xcd,0xba,0xc3,0x87,0x48,0x44,0xc6,
    0x89,0xcb,0xa0,0x58,0x83,0xcc,0xa0,0xd1,0x93,0x59,0xc6,0xa4,0x47,0xc2,0xad,0x40,
    0x92,0xc3,0x86,0x4b,0x83,0xd6,0x98,0x4d,0x80,0xce,0xb8,0xc6,0x87,0x47,0x42,0xc8,
    0x88,0xcc,0xa3,0x54,0x83,0xcd,0x9f,0xd2,0x91,0x5b,0xc6,0xa5,0x46,0xc2,0xae,0x40,
    0x8f,0xc5,0x88,0x49,0x81,0xd8,0x98,0x4c,0x80,0xd0,0xb5,0xc8,0x87,0x47,0x40,0xcb,
    0x86,0xcd,0xa4,0x53,0x81,0xcf,0x9d,0x40,0xd3,0x8e,0x5d,0xc7,0xa4,0x46,0xc2,0xa7,
    0x48,0x8e,0xc6,0x8a,0x46,0x80,0xda,0x98,0x4c,0xd1,0xb2,0xcb,0x87,0x47,0xcc,0x85,
    0xce,0x9f,0x58,0x80,0xd0,0x9b,0x41,0xd5,0x8a,0x60,0xc7,0x9b,0x49,0x80,0x44,0xc2,
    0x9f,0x51,0x8b,0xc8,0x8c,0x43,0xdb,0x98,0x4d,0xd2,0xaf,0xcd,0x87,0x46,0xc0,0xcc,
    0x84,0xce,0x9b,0x5c,0xd2,0x99,0x43,0xd5,0x88,0x61,0xc9,0x91,0x57,0xc3,0x97,0x59,
    0x8a,0xc9,0x8e,0xdd,0x98,0x4c,0xd3,0xad,0xcf,0x88,0x43,0xc2,0xcd,0x83,0xce,0x96,
    0x60,0xd4,0x97,0x43,0xd6,0x85,0x64,0xc9,0x88,0x5c,0x80,0x42,0xc3,0x8e,0x62,0x88,
    0xcc,0x8a,0xe0,0x98,0x4b,0xd4,0xab,0xd2,0x88,0x40,0xc4,0xcd,0x82,0xcf,0x92,0x62,
    0xd6,0x95,0x44,0xd8,0x82,0x66,0xc9,0x68,0xc3,0x87,0x6b,0x86,0xcd,0x88,0xe1,0x99,
    0x4a,0xd6,0xa8,0xd4,0x89,0xc4,0xcd,0x82,0xcf,0x8d,0x66,0xd7,0x93,0x45,0xd9,0x68,
    0xc9,0x69,0xc3,0x73,0x85,0xce,0x86,0xe3,0x40,0x98,0x49,0xd7,0xa6,0xd6,0x8a,0xc3,
    0xce,0x81,0xce,0x89,0x69,0xd9,0x91,0x46,0xda,0x68,0xc9,0x67,0x80,0xc5,0x72,0x83,
    0xd0,0x86,0xe4,0x45,0x92,0x48,0xd9,0xa3,0xd8,0x8b,0xc2,0xce,0x80,0xcf,0x84,0x6d,
    0xda,0x8f,0x47,0xda,0x69,0xc8,0x69,0xc5,0x73,0x81,0xd1,0x85,0xe6,0x4a,0x8c,0x48,
    0xd9,0xa1,0xda,0x8c,0xc1,0xce,0x80,0xcf,0x71,0xdb,0x8e,0x48,0xda,0x68,0xc9,0x68,
    0xc7,0x72,0xd3,0x85,0xe7,0x50,0x85,0x47,0xdb,0x9e,0xdd,0x8c,0xc0,0x80,0xdf,0x6e,
    0xdd,0x8c,0x49,0xda,0x69,0xc8,0x69,0xc8,0x70,0xd4,0x85,0xe8,0x5c,0xdc,0x5b,0xe0,
    0x8d,0x81,0xde,0x6d,0xde,0x8a,0x4b,0xda,0x68,0xc9,0x68,0xc9,0x6e,0xd6,0x84,0xea,
    0x5a,0xdd,0x59,0xe2,0x8d,0x82,0xde,0x6a,0xe0,0x88,0x4d,0xd9,0x69,0xc8,0x68,0xcb,
    0x6c,0xd7,0x84,0xeb,0x58,0xdd,0x58,0xe4,0x8d,0x83,0xdd,0x69,0xe1,0x86,0x4f,0xd9,
    0x69,0xc8,0x68,0xcc,0x69,0xd9,0x84,0xec,0x57,0xdd,0x56,0xe6,0x8d,0x84,0xdd,0x66,
    0xe3,0x84,0x50,0xda,0x68,0xc8,0x68,0xce,0x67,0xda,0x84,0xed,0x55,0xdd,0x55,0xe9,
    0x8c,0x84,0x40,0xdd,0x64,0xe4,0x83,0x51,0xd9,0x69,0xc8,0x68,0xce,0x65,0xdc,0x83,
    0xef,0x53,0xde,0x55,0xe9,0x8c,0x47,0xdb,0x62,0xe6,0x81,0x53,0xd9,0x68,0xc8,0x68,
    0xd0,0x63,0xdd,0x83,0xf0,0x51,0xdf,0x54,0xea,0x4c,0x49,0xda,0x60,0xe7,0x54,0xd9,
    0x67,0xca,0x67,0xd2,0x60,0xdf,0x83,0xf1,0x50,0xde,0x55,0xea,0x4c,
};

#define WHITE RGB(250,251,255)
#define TRACK_CORE RGB(253,246,255)
#define TRACK_EDGE RGB(248,188,244)
#define TRACK_GLOW RGB(94,23,117)
#define TRACK_FAR RGB(36,15,67)
#define TRACK_UNDER_EDGE RGB(19,12,44)
#define GREEN_CORE RGB(245,255,244)
#define GREEN_EDGE RGB(155,255,176)
#define GREEN_HOT RGB(69,255,126)
#define GREEN_GLOW RGB(18,129,61)
#define GREEN_FAR RGB(7,61,38)
#define TRACK_BOOST RGB(255,180,35)
#define TRACK_BOOST2 RGB(255,249,161)
#define SPIKE_RED RGB(255,97,87)
#define SPIKE_GLOW RGB(172,37,67)
#define PINK_HOT RGB(223,90,207)
#define SHADOW_BG RGB(3,9,26)
#define VIOLET_FILL RGB(7,13,29)
#define VIOLET_FACET1 RGB(10,17,38)
#define VIOLET_FACET2 RGB(8,14,32)
#define VIOLET_FACET3 RGB(7,12,27)
#define CAR_GREEN RGB(52,206,111)
#define CAR_GREEN2 RGB(27,145,79)
#define CAR_HALO RGB(115,255,164)
#define CAR_DARK RGB(5,39,32)
#define WHEEL_HALO RGB(106,255,174)
#define GEM_WHITE RGB(244,255,252)
#define GEM_MID RGB(91,255,183)
#define GEM_BLOOM RGB(28,235,135)
#define GEM_OUTER RGB(13,89,66)
#define SAW_RED RGB(255,97,87)
#define SAW_DARK RGB(124,15,24)
#define SAW_CORE RGB(255,210,214)

/* World-to-screen camera zoom: 2/3. More stage is visible on the small
 * GC01 display, and a faster car does not make the terrain jump 12+ screen
 * pixels between two physical LCD updates. Geometry/physics stay in Q8. */
#define VIEW_NUM 2
#define VIEW_DEN 3
static int screen_x(int32_t wx,int32_t camx)
{
    return (wx-camx)/(VIEW_DEN*RIDER_Q/VIEW_NUM);
}
static int screen_y(int32_t wy,int32_t camy)
{
    return (wy-camy)/(VIEW_DEN*RIDER_Q/VIEW_NUM);
}
static int32_t view_world_x(int32_t camx,int pixel_x)
{
    return camx + pixel_x*(VIEW_DEN*RIDER_Q/VIEW_NUM);
}
static uint32_t hash32(uint32_t x)
{
    x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;
    return x;
}
static int absolute(int n) {return n<0?-n:n;}
/* One rail hue and one blue world for every run. No seed-dependent
 * palette selection. Quarter-pixel falloff: luminous narrow core, soft
 * magenta halo. Same table for terrain, gaps, and every special path. */
static const uint16_t rail_palette[32]={
    RGB(255,250,255),RGB(255,250,255),RGB(255,244,255),RGB(253,219,253),
    RGB(249,166,249),RGB(245,114,245),RGB(192,47,181),RGB(165,40,155),
    RGB(141,34,133),RGB(120,29,113),RGB(103,25,97),RGB(88,22,83),
    RGB(75,18,71),RGB(64,16,61),RGB(55,13,52),RGB(47,12,44),
    RGB(40,10,38),RGB(35,8,33),RGB(30,7,28),RGB(25,6,24),
    RGB(22,5,20),RGB(18,5,17),RGB(16,4,15),RGB(14,3,13),
    RGB(12,3,11),RGB(9,2,8),RGB(6,2,6),RGB(5,1,4),
    RGB(3,1,3),RGB(2,0,2),RGB(1,0,1),RGB(0,0,0)
};
static uint16_t sky_color(int y,int dither)
{
    /* Dark blue overhead, nearly black toward the horizon. Ordered
     * quantization is faint rather than a strong checkerboard. */
    return RGB(0,29-y*20/240+dither/2,82-y*61/240+dither);
}
static uint16_t max_rgb(uint16_t a,uint16_t b)
{
    unsigned r=(a&0xf800u)>(b&0xf800u)?a&0xf800u:b&0xf800u;
    unsigned g=(a&0x07e0u)>(b&0x07e0u)?a&0x07e0u:b&0x07e0u;
    unsigned bl=(a&31u)>(b&31u)?a&31u:b&31u;
    return (uint16_t)(r|g|bl);
}
typedef struct { unsigned first,next,end,left,shade; } TerrainScan;
static void terrain_next(TerrainScan *t)
{
    unsigned q=terrain_runs[t->next++];
    if(t->next>=t->end)t->next=t->first;
    t->left=(q&63u)+1u;t->shade=q>>6;
}
static TerrainScan terrain_scan(int y,unsigned x)
{
    TerrainScan t={0};
    t.first=terrain_offsets[y];t.next=t.first;t.end=terrain_offsets[y+1];
    terrain_next(&t);x&=511u;
    while(x>=t.left){x-=t.left;terrain_next(&t);}
    t.left-=x;
    return t;
}
/* Bottom fade is global, not restarted at each rail or discontinuity.
 * Most of the foreground is the same deep solid blue as the reference.
 * Large, softly shaded rocks appear only near the bottom of the view. */
static uint16_t ground_color(int y,unsigned t)
{
    if(y<164)return RGB(0,35,94);
    int v=y-164;
    int g=35-v*27/76,b=94-v*77/76;
    if(y>=174){
        int fade=240-y;
        if(y<190)fade=fade*(y-174)/16;
        g+=(int)t*fade/64;
        b+=(int)t*fade/24;
    }
    return RGB(0,g,b);
}
static int far_peak(int wx)
{
    uint32_t xx=(uint32_t)(wx+32768);
    uint32_t block=xx/32;
    int t=(int)(xx%32);
    int a=151-(int)(hash32(block^0x91u)%68u);
    int b=151-(int)(hash32((block+1u)^0x91u)%68u);
    return a+(b-a)*t/32;
}
static void build_caches(const RiderState *s,int32_t camx,int32_t camy)
{
    int ox=camx/RIDER_Q;
    int min_h=H,min_bg=H;
    texture_origin=(int16_t)((ox*2/3)&511);
    /* Evaluate the true surface at each LCD column, preserving 1/8-pixel
     * vertical phase. Never interpolate across a gap or independently drawn arc. */
    for(int x=0;x<W;++x){
        int32_t h;
        if(rider_surface_q(s,view_world_x(camx,x),&h)){
            int32_t v=(h-camy)/(VIEW_DEN*RIDER_Q/VIEW_NUM/YQ);
            if(v< -16000)v=-16000;
            if(v>16000)v=16000;
            surface[x]=(int16_t)v;
        }else surface[x]=INT16_MAX;
        if((x&3)==0){
            facet[x>>2]=255u;
        }
        if((x&7)==0)backdrop[x>>3]=(uint8_t)far_peak((x*VIEW_DEN/VIEW_NUM+ox)/3);
        int hy=rail_y(x);
        if(hy<min_h)min_h=hy;
        if(backdrop[x>>3]<min_bg)min_bg=backdrop[x>>3];
    }
    upper_sky_limit=(int16_t)(min_h-14<min_bg?min_h-14:min_bg);
    if(upper_sky_limit<0)upper_sky_limit=0;
    gem_n=0; saw_n=0; boost_n=0; spike_n=0; triangle_n=0; memset(loop_n,0,sizeof(loop_n)); memset(loop_fraction,0,sizeof(loop_fraction));
    unsigned path_count=0;
    uint32_t begin=camx>0?(uint32_t)(camx/(256*RIDER_Q)):0u;
    for(uint32_t k=begin;k<begin+4;++k){
        const RiderPiece *p=&s->track[k%RIDER_TRACK_SLOTS];
        if(k>=s->next_piece||p->number!=k) continue;
        if(path_count<PATH_CACHE_COUNT && (p->template_id==45u||p->template_id==16u||p->template_id==27u||p->template_id==46u||p->template_id==47u||p->template_id==52u||p->template_id==54u||p->template_id==65u||p->template_id==75u)){
            /* Cache the closed 2D loop once per FRAME, not per raster strip. */
            int32_t bx=(int32_t)(k*RIDER_PIECE_WIDTH)*RIDER_Q;
            int anchor=screen_x(bx,camx);
            /* Do not let a fully offscreen arc consume a cache slot. */
            if(anchor<=W+10 && anchor+172>=-10){
                unsigned j=path_count++;
                loop_anchor_x[j]=(int16_t)anchor;
                loop_anchor_y[j]=(int16_t)screen_y((int32_t)p->start_y*RIDER_Q,camy);
                for(unsigned i=0;i<PATH_POINTS;++i){
                    int32_t px,py;
                    uint16_t t=(uint16_t)(i*4096u/(PATH_POINTS-1u));
                    if(!rider_track_special_q(s,k,p->template_id,t,&px,&py))break;
                    const int qx=(int)((px-camx)*4/(VIEW_DEN*RIDER_Q/VIEW_NUM))-4*loop_anchor_x[j];
                    const int qy=(int)((py-camy)*4/(VIEW_DEN*RIDER_Q/VIEW_NUM))-4*loop_anchor_y[j];
                    const int ix=floor4(qx),iy=floor4(qy);
                    if(ix<0||ix>255||iy< -128||iy>127)break; /* no narrowing wrap */
                    loop_dx[j][i]=(uint8_t)ix;
                    loop_dy[j][i]=(int8_t)iy;
                    loop_fraction[j][i/2]|=(uint8_t)(((qx-4*ix)|((qy-4*iy)<<2))<<((i&1u)*4u));
                    loop_n[j]=(uint8_t)(i+1u);
                }
            }
        }
        if(p->template_id==16u||p->template_id==47u||p->template_id==52u||p->template_id==65u||p->template_id==75u){
            /* The solid base beneath the connected rail has no extra stroke.
             * Previously the loop's heightfield hole left a vertical black
             * rectangle through the terrain below its entry and exit. */
            const int32_t bx=(int32_t)(k*RIDER_PIECE_WIDTH)*RIDER_Q;
            const int first=screen_x(bx+(p->template_id==75u?48:68)*RIDER_Q,camx);
            const int last=screen_x(bx+(p->template_id==75u?190:(p->template_id==47u?133:156))*RIDER_Q,camx);
            const int y=screen_y((p->start_y-((p->template_id==52u||p->template_id==65u)?32:0))*RIDER_Q,camy);
            if(y<H)for(int x=first<0?0:first;x<=last&&x<W;++x)
                if(y<facet[x>>2])facet[x>>2]=(uint8_t)(y<0?0:y);
        }
        if(p->template_id==27u){
            /* Wall and bowl are filled terrain, but their stroke is drawn
             * solely from the shared 2D path; no invented heightfield rail. */
            for(unsigned t=0;t<=4096u;t+=32u){
                int32_t ax,ay;
                if(!rider_track_special_q(s,k,p->template_id,(uint16_t)t,&ax,&ay))continue;
                int x=screen_x(ax,camx),y=screen_y(ay,camy);
                if(x>=0&&x<W&&y<H){
                    if(y<0)y=0;
                    if(y<facet[x>>2])facet[x>>2]=(uint8_t)y;
                }
            }
        }
        if(p->template_id==81u){
            int a=screen_x((int32_t)(k*256u+96u)*RIDER_Q,camx);
            int b=screen_x((int32_t)(k*256u+164u)*RIDER_Q,camx);
            for(int x=a<0?0:a;x<=b&&x<W;x++)facet[x>>2]=254u;
        }
        int32_t pa,pb,py;
        for(unsigned slot=0;slot<2u;slot++)if(rider_platform_at_q(s,k,slot,&pa,&pb,&py)){
            int a=screen_x(pa,camx),b=screen_x(pb,camx);
            for(int x=a<0?0:a;x<=b && x<W;x++)facet[x>>2]=254u;
            if(p->template_id==80u && a<W && b>=0 && triangle_n<2u){
                triangle[triangle_n][0]=(int16_t)a;triangle[triangle_n][1]=(int16_t)b;
                triangle[triangle_n++][2]=(int16_t)screen_y(py,camy);
            }
        }
        for(uint8_t j=0;j<3u && gem_n<10u;++j){
            int32_t wx,wy;
            if(rider_piece_gem_q(s,k,j,&wx,&wy)){
                int xx=screen_x(wx,camx);
                int yy=screen_y(wy,camy);
                if(xx>=-11&&xx<=W+11&&yy>=-13&&yy<=H+13){
                    gemx[gem_n]=(int16_t)xx;
                    gemy[gem_n]=(int16_t)yy;
                    ++gem_n;
                }
            }
        }
        for(unsigned slot=0;slot<2u && saw_n<4;slot++){
            int32_t sx,sy,sr;
            bool ring=slot==0u && rider_piece_ring_q(s,k,&sx,&sy);
            if(ring)sr=36*RIDER_Q;
            if(ring || rider_piece_saw_at_q(s,k,slot,&sx,&sy,&sr)){
                int xx=screen_x(sx,camx),yy=screen_y(sy,camy);
                if(xx>=-sr/384-8 && xx<=W+sr/384+8 && yy>=-sr/384-8 && yy<=H+sr/384+8){
                    sawx[saw_n]=(int16_t)xx;
                    sawy[saw_n]=(int16_t)yy;
                    sawr[saw_n]=(int16_t)(sr/(VIEW_DEN*RIDER_Q/VIEW_NUM));
                    if(ring)sawr[saw_n]=-sawr[saw_n];
                    ++saw_n;
                }
            }
        }
        if(spike_n<4){
            int32_t x0,x1,tip;
            if(rider_piece_spikes_q(s,k,&x0,&x1,&tip)){
                int px0=screen_x(x0,camx);
                int px1=screen_x(x1,camx);
                if(px1>=0&&px0<W){
                    spikex0[spike_n]=(int16_t)px0;
                    spikex1[spike_n]=(int16_t)px1;
                    spikey[spike_n]=(int16_t)screen_y(tip,camy);
                    ++spike_n;
                }
            }
        }
        if(boost_n<4){
            int32_t x0,x1,yq;
            if(rider_piece_boost_q(s,k,&x0,&x1,&yq)){
                int xx0=screen_x(x0,camx);
                int xx1=screen_x(x1,camx);
                if(xx1>=-12 && xx0<=W+12){
                    boostx0[boost_n]=(int16_t)xx0;
                    boostx1[boost_n]=(int16_t)xx1;
                    (void)yq; /* boost position comes from cached rail */
                    ++boost_n;
                }
            }
        }
    }
    /* Refine sky-only fast path to include the tall wall and deep bowl. */
    for(int x=0;x<W;++x){
        if(surface[x]!=INT16_MAX && rail_y(x)<upper_sky_limit+16)
            upper_sky_limit=(int16_t)(rail_y(x)-16);
    }
    for(int x=0;x<W/4;++x)if(facet[x]<254u && facet[x]<upper_sky_limit)upper_sky_limit=facet[x];
    if(upper_sky_limit<0)upper_sky_limit=0;
}

static const uint8_t SCORE_FONT[11][9]={
  {0x3e,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x3e},
  {0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18},
  {0x3e,0x03,0x03,0x03,0x3e,0x60,0x60,0x60,0x7f},
  {0x7e,0x03,0x03,0x03,0x3e,0x03,0x03,0x03,0x7e},
  {0x63,0x63,0x63,0x63,0x7f,0x03,0x03,0x03,0x03},
  {0x7f,0x60,0x60,0x60,0x7e,0x03,0x03,0x03,0x7e},
  {0x3e,0x60,0x60,0x60,0x7e,0x63,0x63,0x63,0x3e},
  {0x7f,0x03,0x06,0x06,0x0c,0x0c,0x18,0x18,0x30},
  {0x3e,0x63,0x63,0x63,0x3e,0x63,0x63,0x63,0x3e},
  {0x3e,0x63,0x63,0x63,0x3f,0x03,0x03,0x03,0x3e},
  {0x00,0x00,0x08,0x08,0x3e,0x08,0x08,0x00,0x00},
};

static void number(char *out,uint32_t n)
{
    char rev[12];unsigned count=0;
    if(n>99999999u)n=99999999u;
    do{rev[count++]=(char)('0'+n%10u);n/=10u;}while(n&&count<11);
    for(unsigned i=0;i<count;++i)out[i]=rev[count-i-1];
    out[count]='\0';
}
static int glyph_index(char ch)
{
    if(ch>='0'&&ch<='9')return ch-'0';
    return ch=='+'?10:-1;
}
static void put(int x,int y,int top,uint16_t c)
{
    if(x>=0&&x<W&&y>=top&&y<top+STRIP_ROWS)
        strip[(y-top)*W+x]=c;
}
static void draw_digits(const char *txt,int xx,int yy,int scale,int top,uint16_t c)
{
    if(yy>=top+STRIP_ROWS || yy+9*scale<=top)return;
    for(int i=0;txt[i];++i){
        int idx=glyph_index(txt[i]);
        if(idx<0)continue;
        for(int row=0;row<9;++row){
            int py=yy+row*scale;
            if(py>=top+STRIP_ROWS || py+scale<=top) continue;
            uint8_t b=SCORE_FONT[idx][row];
            for(int col=0;col<7;++col)if(b&(1u<<(6-col)))
                for(int ry=0;ry<scale;++ry)
                    for(int rx=0;rx<scale;++rx)
                        put(xx+i*scale*9+col*scale+rx,yy+row*scale+ry,top,c);
        }
    }
}
/* Compact letterforms for a real high-score label and pause overlay.
 * Rendered as bitmap glyphs to preserve an angular, legible HUD on 320x240. */
static const uint8_t label_font[][7]={
  /* B */ {30,17,17,30,17,17,30},
  /* E */ {31,16,16,30,16,16,31},
  /* S */ {15,16,16,14,1,1,30},
  /* T */ {31,4,4,4,4,4,4},
  /* P */ {30,17,17,30,16,16,16},
  /* A */ {14,17,17,31,17,17,17},
  /* U */ {17,17,17,17,17,17,14},
  /* H */ {17,17,17,31,17,17,17},
  /* I */ {31,4,4,4,4,4,31},
  /* R */ {30,17,17,30,20,18,17},
  /* F */ {31,16,16,30,16,16,16},
  /* C */ {15,16,16,16,16,16,15},
  /* L */ {16,16,16,16,16,16,31},
  /* M */ {17,27,21,21,17,17,17},
  /* O */ {14,17,17,17,17,17,14},
  /* space */ {0,0,0,0,0,0,0}
};
static int label_index(char ch)
{
    const char *letters="BESTPAUHIRFCLMO ";
    for(int i=0;letters[i];++i)if(letters[i]==ch)return i;
    return 15;
}
static void draw_label(const char *txt,int x,int y,int scale,int top,uint16_t color)
{
    if(y>=top+STRIP_ROWS || y+7*scale<=top)return;
    for(unsigned i=0;txt[i];++i){
        const uint8_t *glyph=label_font[label_index(txt[i])];
        for(int row=0;row<7;++row){
            const int py=y+row*scale;
            if(py>=top+STRIP_ROWS || py+scale<=top)continue;
            for(int col=0;col<5;++col)if(glyph[row] & (1u<<(4-col)))
                for(int dy=0;dy<scale;++dy)
                    for(int dx=0;dx<scale;++dx)
                        put(x+(int)i*6*scale+col*scale+dx,py+dy,top,color);
        }
    }
}

static uint16_t bike_pixel(int x,int y)
{
    int a=(x+14)*(x+14)+(y-1)*(y-1);
    int b=(x-14)*(x-14)+(y-1)*(y-1);
    int r=a<b?a:b;
    if(r<=35){
        if(r<=8)return CAR_DARK;
        if(r<=27)return RGB(235,255,241);
        return WHEEL_HALO;
    }
    /* slimmer, more Rider-like luminous wedge */
    if(x>=-24 && x<=24){
        int top,bottom=-1;
        if(x< -16) top=-6-(x+24)/3;
        else if(x< -4) top=-10-(x+16)/6;
        else if(x<10) top=-13;
        else if(x<20) top=-12+(x-10)/3;
        else top=-9+(x-20)/2;
        if(x>18) bottom=-2-(x-18)/3;
        if(y>=top && y<=bottom){
            if(y==top || x==24 || x==-24)return CAR_HALO;
            if(y==bottom)return CAR_GREEN2;
            if(y==top+1)return CAR_GREEN;
            if(x>=-2 && x<=9 && y>=top+2 && y<=top+5)return CAR_DARK;
            if(x>=6 && x<=16 && y==top+5)return CAR_HALO;
            if(y>bottom-2 && x>=-10&&x<20)return CAR_GREEN2;
            if(x< -12 && y<bottom-1)return CAR_GREEN2;
            return CAR_GREEN;
        }
    }
    if(x>=-24&&x< -9 && y==-6)return CAR_HALO;
    return 0;
}
static uint16_t bike_and_trail(int px,int py,int cx,int cy,int fx,int fy,int sn,int cs,int throttle,uint32_t tick,int ts,int tc)
{
    int dx=px-cx,dy=py-cy;
    if(dx< -48||dx>39||dy< -42||dy>42)return 0;
    /* One inverse transform, rather than truncating the rotation and then
     * truncating the scale. Keeps the wheels attached as the car rotates. */
    if(dx*dx+dy*dy<=18*18){
    int dx4=dx*4-fx,dy4=dy*4-fy;
    int tx0=(dx4*cs+dy4*sn)*7,ty0=(-dx4*sn+dy4*cs)*7;
    int sx=(tx0+(tx0>=0?2048:-2048))/4096;
    int sy=(ty0+(ty0>=0?2048:-2048))/4096;
    if(sx>=-26&&sx<=26&&sy>=-20&&sy<=10){
        uint16_t hit=bike_pixel(sx,sy);
        if(hit)return hit;
    }
    }
    if(!throttle || dx*dx+dy*dy>41*41)return 0;
    /* Exhaust follows movement, not the rotating vehicle body. A flip no
     * longer swings the entire trail around the vehicle. Small taper and
     * fading spark points are generated analytically, with no history RAM. */
    int tx=(dx*tc+dy*ts)/256,ty=(-dx*ts+dy*tc)/256;
    if(tx>=-9||tx< -39||ty< -5||ty>5)return 0;
    int tail=tx+39,offset=1+tail/15;
    int line=absolute(absolute(ty)-offset);
    if(line<=1){
        if(line==1)return tail>20?RGB(12,71,45):RGB(5,29,24);
        return tail>22?RGB(43,183,100):(tail>10?RGB(20,97,63):RGB(8,38,29));
    }
    int phase=(int)(tick%9u);
    if((tx+39+phase)%11==0 && absolute(ty)==offset+2)return RGB(55,210,119);
    return 0;
}
static uint16_t gem_pixel(int dx,int dy)
{
    int x=absolute(dx),y=absolute(dy);
    if(x>10||y>12)return 0;
    int rank=x*14+y*8;
    if(rank<=24)return GEM_WHITE;
    if(rank<=35)return GEM_MID;
    if(rank<=48)return RGB(30,186,110);
    if(rank<=60)return RGB(16,100,65);
    if(rank<=74)return RGB(7,45,32);
    return 0;
}
/* 22 swept, closely spaced coral teeth, not a starburst. */
static const uint8_t swept_saw_mask[65*9]={
    0x00,0x00,0x00,0x04,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0x0c,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x0e,0x1e,0x10,0x00,0x00,0x00,0x00,0x00,0x02,0x0e,0x1e,
    0x18,0x00,0x00,0x00,0x00,0x00,0x0e,0x0e,0x0f,0x1c,0x00,0x00,0x00,0x00,0x00,0x0e,
    0x9f,0x0f,0x0f,0x00,0x00,0x00,0x00,0x00,0x1e,0xff,0xff,0x0f,0x00,0x00,0x00,0x00,
    0x00,0x9e,0xff,0xff,0x07,0x10,0x00,0x00,0x00,0x04,0xfe,0xff,0xff,0x07,0x0e,0x00,
    0x00,0x00,0x1c,0xfe,0xff,0xff,0xff,0x0f,0x00,0x00,0x00,0x3c,0xff,0xff,0xff,0xff,
    0x07,0x00,0x00,0x00,0x78,0xff,0xff,0xff,0xff,0x03,0x00,0x00,0x00,0xf8,0xff,0xff,
    0xff,0xff,0x01,0x00,0x00,0x00,0xf8,0xff,0xff,0xff,0xff,0x07,0x04,0x00,0x00,0xf8,
    0xff,0xff,0xff,0xff,0xff,0x03,0x00,0x70,0xf8,0xff,0xff,0xff,0xff,0xff,0x03,0x00,
    0xe0,0xf8,0xff,0xff,0xff,0xff,0xff,0x01,0x00,0xe0,0xff,0xff,0xff,0xff,0xff,0x7f,
    0x00,0x00,0xc0,0xff,0xff,0xff,0xff,0xff,0x3f,0x00,0x00,0xc0,0xff,0xff,0xff,0xff,
    0xff,0x7f,0x00,0x00,0x80,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0x00,0x80,0xff,0xff,
    0xff,0xff,0xff,0xff,0x7f,0x00,0x80,0xff,0xff,0xff,0xff,0xff,0xff,0x3f,0x00,0x88,
    0xff,0xff,0xff,0xff,0xff,0xff,0x1f,0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,
    0x00,0xfe,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0x00,0xf8,0xff,0xff,0xff,0xff,0xff,
    0xff,0x03,0x00,0xf0,0xff,0xff,0xff,0xff,0xff,0xff,0x03,0x00,0xe0,0xff,0xff,0xff,
    0xff,0xff,0xff,0x07,0x00,0xe0,0xff,0xff,0xff,0xff,0xff,0xff,0x1f,0x00,0xc0,0xff,
    0xff,0xff,0xff,0xff,0xff,0xff,0x00,0xc0,0xff,0xff,0xff,0xff,0xff,0xff,0x7f,0x00,
    0xfe,0xff,0xff,0xff,0xff,0xff,0xff,0x03,0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
    0x03,0x00,0xf8,0xff,0xff,0xff,0xff,0xff,0xff,0x07,0x00,0xe0,0xff,0xff,0xff,0xff,
    0xff,0xff,0x07,0x00,0xc0,0xff,0xff,0xff,0xff,0xff,0xff,0x0f,0x00,0xc0,0xff,0xff,
    0xff,0xff,0xff,0xff,0x1f,0x00,0x80,0xff,0xff,0xff,0xff,0xff,0xff,0x7f,0x00,0x80,
    0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x00,0xf8,0xff,0xff,0xff,0xff,0xff,0xff,0x11,
    0x00,0xfc,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0x00,0xfe,0xff,0xff,0xff,0xff,0xff,
    0xff,0x01,0x00,0x80,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0x00,0x00,0xfe,0xff,0xff,
    0xff,0xff,0xff,0x03,0x00,0x00,0xfc,0xff,0xff,0xff,0xff,0xff,0x03,0x00,0x00,0xfe,
    0xff,0xff,0xff,0xff,0xff,0x07,0x00,0x80,0xff,0xff,0xff,0xff,0xff,0x1f,0x07,0x00,
    0xc0,0xff,0xff,0xff,0xff,0xff,0x1f,0x0e,0x00,0xc0,0xff,0xff,0xff,0xff,0xff,0x1f,
    0x00,0x00,0x20,0xe0,0xff,0xff,0xff,0xff,0x1f,0x00,0x00,0x00,0x80,0xff,0xff,0xff,
    0xff,0x1f,0x00,0x00,0x00,0xc0,0xff,0xff,0xff,0xff,0x1e,0x00,0x00,0x00,0xe0,0xff,
    0xff,0xff,0xff,0x3c,0x00,0x00,0x00,0xf0,0xff,0xff,0xff,0x7f,0x38,0x00,0x00,0x00,
    0x70,0xe0,0xff,0xff,0x7f,0x20,0x00,0x00,0x00,0x08,0xe0,0xff,0xff,0x79,0x00,0x00,
    0x00,0x00,0x00,0xf0,0xff,0xff,0x78,0x00,0x00,0x00,0x00,0x00,0xf0,0xf0,0xf9,0x70,
    0x00,0x00,0x00,0x00,0x00,0x38,0xf0,0x70,0x70,0x00,0x00,0x00,0x00,0x00,0x18,0x78,
    0x70,0x40,0x00,0x00,0x00,0x00,0x00,0x08,0x78,0x70,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x30,0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x10,0x20,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};

static unsigned saw_mask_at(int dx4,int dy4,int radius,int sn,int cs)
{
    const int mx=32+(dx4*cs+dy4*sn)*8/(256*radius);
    const int my=32+(-dx4*sn+dy4*cs)*8/(256*radius);
    if(mx<0||mx>=65||my<0||my>=65)return 0;
    return (swept_saw_mask[my*9+(mx>>3)]>>(mx&7))&1u;
}
static uint16_t saw_pixel(int dx,int dy,int radius,int sin_rot,int cos_rot,uint16_t bg)
{
    if(radius<1)return bg;
    int r2=dx*dx+dy*dy;
    if(r2>(radius+2)*(radius+2))return bg;
    if(r2*16<radius*radius*9)return SAW_RED;
    /* Four sub-pixel samples only at the swept teeth. Do not turn the
     * solid original coral blade into a jagged white/red starburst. */
    unsigned hit=0;
    for(int v=-1;v<=1;v+=2)for(int u=-1;u<=1;u+=2)
        hit+=saw_mask_at(dx*4+u,dy*4+v,radius,sin_rot,cos_rot);
    if(!hit)return bg;
    if(hit==4)return SAW_RED;
    unsigned rr=(((bg>>11)&31u)*(4-hit)+((SAW_RED>>11)&31u)*hit+2)/4;
    unsigned gg=(((bg>>5)&63u)*(4-hit)+((SAW_RED>>5)&63u)*hit+2)/4;
    unsigned bb=((bg&31u)*(4-hit)+(SAW_RED&31u)*hit+2)/4;
    return (uint16_t)((rr<<11)|(gg<<5)|bb);
}
/* Paint only object bounding boxes after the background. The old renderer
 * tested up to 15 objects for every one of the 76,800 screen pixels, which
 * wasted most cycles on empty sky and terrain. Layer order is unchanged. */
static int imin(int a,int b) { return a<b ? a:b; }
static int imax(int a,int b) { return a>b ? a:b; }

/* Quarter-pixel endpoints and one normal-distance glow for all paths.
 * Connected endpoints, crossings and detached rails have the same color. */
static void paint_segment_q2(int top,int px,int py,int x,int y)
{
    int dx=x-px,dy=y-py,len2=dx*dx+dy*dy;
    if(imax(y,py)+32<top*4 || imin(y,py)-32>=(top+STRIP_ROWS)*4 ||
       imax(x,px)+32<0 || imin(x,px)-32>=W*4)return;
    int ax=absolute(dx),ay=absolute(dy);
    int len=imax(ax,ay)+imin(ax,ay)*3/8;
    if(!len)len=1;
    int x0=imax(0,floor4(imin(x,px)-32)),x1=imin(W-1,floor4(imax(x,px)+32));
    int y0=imax(top,floor4(imin(y,py)-32)),y1=imin(top+STRIP_ROWS-1,floor4(imax(y,py)+32));
    for(int sy=y0;sy<=y1;++sy)for(int sx=x0;sx<=x1;++sx){
        int ex=sx*4-px,ey=sy*4-py,dot=ex*dx+ey*dy,dist;
        if(!len2 || dot<0 || dot>len2){
            if(dot>len2){ex=sx*4-x;ey=sy*4-y;}
            int a=absolute(ex),b=absolute(ey);
            dist=imax(a,b)+imin(a,b)*3/8;
        }else dist=absolute(ex*dy-ey*dx)/len;
        if(dist<32){
            uint16_t *dst=&strip[(sy-top)*W+sx];
            *dst=max_rgb(*dst,rail_palette[dist]);
        }
    }
}
static void paint_loop(int top,const uint16_t *ends,unsigned nends)
{
    /* Inverted triangular structural support: muted outline below rideable
     * deck (not a second collision rail). */
    for(unsigned j=0;j<triangle_n;j++){
        int a=triangle[j][0],b=triangle[j][1],y=triangle[j][2],mid=(a+b)/2;
        if(top+STRIP_ROWS<=y || top>y+26)continue;
        for(int sy=imax(top,y+1);sy<top+STRIP_ROWS && sy<=y+26;sy++){
            int l=a+(mid-a)*(sy-y)/26, r=b-(b-mid)*(sy-y)/26;
            for(int x=imax(0,l);x<=imin(W-1,r);x++){
                uint16_t *dst=&strip[(sy-top)*W+x];
                *dst=max_rgb(*dst,(x-l<=1||r-x<=1)?RGB(245,135,244):RGB(4,23,58));
            }
        }
    }
    for(unsigned j=0;j<PATH_CACHE_COUNT;++j)for(unsigned i=1;i<loop_n[j];++i){
        unsigned f0=(loop_fraction[j][(i-1)/2]>>(((i-1)&1u)*4u))&15u;
        unsigned f1=(loop_fraction[j][i/2]>>((i&1u)*4u))&15u;
        int x=4*(loop_anchor_x[j]+loop_dx[j][i])+(int)(f1&3u);
        int y=4*(loop_anchor_y[j]+loop_dy[j][i])+(int)(f1>>2);
        int px=4*(loop_anchor_x[j]+loop_dx[j][i-1])+(int)(f0&3u);
        int py=4*(loop_anchor_y[j]+loop_dy[j][i-1])+(int)(f0>>2);
        paint_segment_q2(top,px,py,x,y);
    }
    /* Most views have 0–6 endpoints. Discover them once per frame,
     * not once per three-row LCD strip. Overflow is lossless. */
    for(unsigned i=0;i<nends;++i){
        int x=nends<=16u?ends[i]:(int)i;
        if(surface[x]==INT16_MAX || surface[x]<8*(top-8) || surface[x]>=8*(top+STRIP_ROWS+8))continue;
        if(nends<=16u || (x>0&&surface[x-1]==INT16_MAX)||(x+1<W&&surface[x+1]==INT16_MAX))
            paint_segment_q2(top,4*x,surface[x]/2,4*x,surface[x]/2);
    }
}

static void paint_objects(int top, int cx, int cy, int fx, int fy, int sn, int cs, int sin_rot, int cos_rot, int throttle, uint32_t tick,int trail_sn,int trail_cs,const uint16_t *ends,unsigned nends)
{
    const int bottom=top+STRIP_ROWS;
    paint_loop(top,ends,nends);
    /* Four right-facing chevrons above the local rail, aligned to its slope. */
    for(uint8_t i=0;i<boost_n;++i){
        for(int k=0;k<4;++k){
            int x=boostx0[i]+4+k*8;
            if(x>boostx1[i]-3||x<1||x>=W-1||surface[x]==INT16_MAX)continue;
            int y=rail_y(x)-5;
            for(int dy=-3;dy<=3;++dy){
                int px=x-absolute(dy);
                put(px,y+dy,top,TRACK_BOOST2);
                put(px-1,y+dy,top,TRACK_BOOST);
            }
        }
    }
    /* Saw-style hazard platforms, but embedded BELOW the intentional gap
     * rather than in the rail or at an impossible random height. */
    for(uint8_t i=0;i<spike_n;++i){
        const int xa=imax(0,spikex0[i]);
        const int xb=imin(W,spikex1[i]+1);
        const int depth=12*VIEW_NUM/VIEW_DEN;
        for(int y=imax(top,spikey[i]);y<imin(bottom,spikey[i]+depth+1);++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=xa;x<xb;++x){
                int32_t profile=rider_spike_profile_q((x-spikex0[i])*(VIEW_DEN*RIDER_Q/VIEW_NUM));
                const int tip=spikey[i]+profile/(VIEW_DEN*RIDER_Q/VIEW_NUM);
                if(y>=tip)dst[x]=SPIKE_RED;
            }
        }
    }
    for(uint8_t i=0;i<saw_n;++i){
        const int halo=absolute(sawr[i])+7;
        const int y0=imax(top,sawy[i]-halo);
        const int y1=imin(bottom,sawy[i]+halo+1);
        const int x0=imax(0,sawx[i]-halo);
        const int x1=imin(W,sawx[i]+halo+1);
        for(int y=y0;y<y1;++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=x0;x<x1;++x){
                if(sawr[i]<0){
                    int dx=(x-sawx[i])*(VIEW_DEN*RIDER_Q/VIEW_NUM);
                    int dy=(y-sawy[i])*(VIEW_DEN*RIDER_Q/VIEW_NUM);
                    if(rider_ring_contains_q(dx,dy,tick,0))dst[x]=RGB(255,98,82);
                    else if(rider_ring_contains_q(dx,dy,tick,2))dst[x]=max_rgb(dst[x],RGB(89,18,20));
                }else dst[x]=saw_pixel(x-sawx[i],y-sawy[i],sawr[i],sin_rot,cos_rot,dst[x]);
            }
        }
    }
    int tx=throttle?-trail_cs*40/256:0,ty=throttle?-trail_sn*40/256:0;
    int bx0=imin(-18,tx-7),bx1=imax(18,tx+7);
    int by0=imin(-18,ty-7),by1=imax(18,ty+7);
    for(int y=imax(top,cy+by0);y<imin(bottom,cy+by1+1);++y){
        uint16_t *dst=strip+(y-top)*W;
        for(int x=imax(0,cx+bx0);x<imin(W,cx+bx1+1);++x){
            const uint16_t c=bike_and_trail(x,y,cx,cy,fx,fy,sn,cs,throttle,tick,trail_sn,trail_cs);
            if(c)dst[x]=c;
        }
    }
    for(uint8_t i=0;i<gem_n;++i){
        for(int y=imax(top,gemy[i]-12);y<imin(bottom,gemy[i]+13);++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=imax(0,gemx[i]-10);x<imin(W,gemx[i]+11);++x){
                const uint16_t c=gem_pixel(x-gemx[i],y-gemy[i]);
                if(c)dst[x]=c;
            }
        }
    }
}

uint32_t rider_render_static_ram(void)
{
    return (uint32_t)(sizeof(strip)+sizeof(surface)+sizeof(backdrop)+sizeof(facet)+
                      sizeof(gemx)+sizeof(gemy)+sizeof(gem_n)+sizeof(sawx)+
                      sizeof(sawy)+sizeof(sawr)+sizeof(saw_n)+sizeof(boostx0)+
                      sizeof(boostx1)+sizeof(boost_n)+sizeof(triangle)+sizeof(triangle_n)+
                      sizeof(spikex0)+sizeof(spikex1)+sizeof(spikey)+sizeof(spike_n)+
                      sizeof(loop_dx)+sizeof(loop_dy)+sizeof(loop_fraction)+sizeof(loop_anchor_x)+sizeof(loop_anchor_y)+sizeof(loop_n)+sizeof(upper_sky_limit)+sizeof(texture_origin));
}
void rider_render(const RiderState *s,const RiderState *prev,uint8_t alpha,
                  RiderPixels out,void *context)
{
    if(!s||!out)return;
    int32_t camx=s->camera_x,camy=s->camera_y;
    int32_t xx=s->x,yy=s->y,a=s->angle;
    if(prev && !s->paused && s->phase==RIDER_RUNNING &&
       prev->phase==RIDER_RUNNING && s->looping==prev->looping && s->grounded==prev->grounded){
        /* Predict fractional time after the last *completed* physics step.
         * v0.9 interpolated from PREVIOUS to CURRENT using accumulator alpha,
         * producing a variable whole-tick visual delay and chunky scrolling.
         * Extrapolate only bounded camera/vehicle motion. This is visual-only:
         * no collision, scoring or radiation state is modified. */
        int32_t dcx=camx-prev->camera_x;
        int32_t dcy=camy-prev->camera_y;
        int32_t dx=xx-prev->x;
        int32_t dy=yy-prev->y;
        if(absolute(dcx)<=8*RIDER_Q && absolute(dcy)<=5*RIDER_Q &&
           absolute(dx)<=7*RIDER_Q && absolute(dy)<=9*RIDER_Q){
            camx+=dcx*alpha/256;
            camy+=dcy*alpha/256;
            bool moving_contact=s->looping!=0;
            if(s->grounded && !moving_contact && s->x>=0){
                uint32_t pn=(uint32_t)s->x/(256u*RIDER_Q);
                int32_t pa,pb,py;
                for(unsigned slot=0;slot<2;slot++)if(rider_platform_at_q(s,pn,slot,&pa,&pb,&py)&&s->x>=pa&&s->x<=pb){moving_contact=true;break;}
            }
            if(!moving_contact){xx+=dx*alpha/256; yy+=dy*alpha/256;}
            int32_t da=(int32_t)(((uint32_t)a-(uint32_t)prev->angle+2048u)&4095u)-2048;
            if(!moving_contact && absolute(da)<=200) a+=da*alpha/256;
        }
    }
    build_caches(s,camx,camy);
    uint16_t ends[16];unsigned nends=0;
    for(int x=0;x<W;++x)if(surface[x]!=INT16_MAX && ((x>0&&surface[x-1]==INT16_MAX)||(x+1<W&&surface[x+1]==INT16_MAX))){
        if(nends==16u){nends=W;break;}
        ends[nends++]=(uint16_t)x;
    }
    int sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
    /* Slower, softer decorative motion. The blade remains dangerous even while
     * stationary; animation must never alter the collision geometry. */
    uint8_t saw_ai=(uint8_t)(s->tick_count/3u);
    int sin_rot=rider_sin256(saw_ai), cos_rot=rider_sin256((uint8_t)(saw_ai+64));
    int cx=screen_x(xx,camx),cy=screen_y(yy,camy);
    int fx=((xx-camx)%(VIEW_DEN*RIDER_Q/VIEW_NUM))*4/(VIEW_DEN*RIDER_Q/VIEW_NUM);
    int fy=((yy-camy)%(VIEW_DEN*RIDER_Q/VIEW_NUM))*4/(VIEW_DEN*RIDER_Q/VIEW_NUM);
    int trail_sn=sn,trail_cs=cs;
    if(!s->grounded && !s->looping){
        int vx=s->vx,vy=s->vy;
        int ax=absolute(vx),ay=absolute(vy),norm=imax(ax,ay)+imin(ax,ay)*3/8;
        if(norm>0){trail_sn=vy*256/norm;trail_cs=vx*256/norm;}
    }
    char score[16];number(score,(uint32_t)(s->score>0?s->score:0));
    char high[16];number(high,(uint32_t)(s->best>0?s->best:0));
    int score_size=(int)strlen(score)*18-4;
    char bonus[16];bonus[0]='+';number(bonus+1,s->pending_score);
    char diamond_count[16];
    number(diamond_count,(uint32_t)(s->diamonds>0?s->diamonds:0));
    int diamond_len=(int)strlen(diamond_count);
    for(int top=0;top<H;top+=STRIP_ROWS){
        for(int row=0;row<STRIP_ROWS;++row){
            int y=top+row;
            uint16_t bg[2]={sky_color(y,(y&1)?3:0),sky_color(y,(y&1)?1:2)};
            uint16_t *dst=&strip[row*W];
            if(y<upper_sky_limit){
                /* Upper rows are uniform sky for this frame. This removes
                 * most geometry/texture conditionals from blank pixels. */
                for(int x=0;x<W;++x)dst[x]=bg[x&1];
                continue;
            }
            uint16_t ground_row[4],back_row[4],shadow[2][9];
            bool rocks=y>=174;
            for(unsigned t=0;t<(rocks?4u:1u);++t){
                ground_row[t]=ground_color(y,t*4u);
                unsigned g=(ground_row[t]>>5)&63u,bl=ground_row[t]&31u;
                back_row[t]=(uint16_t)(((g*7/8)<<5)|(bl*7/8));
            }
            /* A subtle distant silhouette, not a second solid ground
             * surface across gaps. Cache the nine possible transition
             * shades once per row instead of multiplying for every pixel. */
            for(unsigned i=0;i<2u;++i){
                unsigned g=(bg[i]>>5)&63u,bl=bg[i]&31u;
                for(unsigned m=0;m<=8u;++m)
                    shadow[i][m]=(uint16_t)(((g*(32u-m)/32u)<<5)|(bl*(32u-m)/32u));
            }
            if(rocks && y<184){
                unsigned m=(unsigned)(y-174);
                for(unsigned t=0;t<4;++t){
                    unsigned g=((shadow[0][8]>>5)&63u)*(10u-m)+((back_row[t]>>5)&63u)*m;
                    unsigned bl=(shadow[0][8]&31u)*(10u-m)+(back_row[t]&31u)*m;
                    back_row[t]=(uint16_t)(((g/10u)<<5)|(bl/10u));
                }
            }
            TerrainScan rock={0};
            if(rocks)rock=terrain_scan(y-174,(unsigned)texture_origin);
            for(int x=0;x<W;++x){
                unsigned shade=rocks?rock.shade:0u;
                if(rocks && --rock.left==0u)terrain_next(&rock);
                int h=surface[x];
                int d=y-(h==INT16_MAX?INT16_MAX:h/YQ);
                uint16_t c;
                bool body=(h!=INT16_MAX && d>=0 && facet[x>>2]!=254u) ||
                    (h==INT16_MAX && facet[x>>2]<254u && y>=facet[x>>2]);
                if(body && (!rocks || y<208 || d<12))c=ground_row[shade];
                else if(rocks){
                    /* Fade into one continuous lower rock layer; no jagged
                     * blue stripe attached to the distant mountains. */
                    c=back_row[shade];
                }else{
                    /* Lookup interpolated silhouette only in rows where
                     * it matters; no background work on solid ground. */
                    int f=backdrop[x>>3];
                    if(x<312)f+=(backdrop[(x>>3)+1]-f)*(x&7)/8;
                    c=y>=f?shadow[x&1][imin(8,y-f)]:bg[x&1];
                }
                if(h!=INT16_MAX){
                    if(d>=-16 && d<=16){
                        int l=x?surface[x-1]:h,r=x+1<W?surface[x+1]:h;
                        if(l==INT16_MAX)l=h;
                        if(r==INT16_MAX)r=h;
                        int slope=absolute(r-l)/2;
                        /* Euclidean normal length approximation in Q3. */
                        int norm=imax(8,slope)+imin(8,slope)*3/8;
                        int rank=absolute(y*YQ-h)*4/norm;
                        if(rank<32)c=max_rgb(c,rail_palette[rank]);
                    }
                }
                dst[x]=c;
            }
        }
        paint_objects(top,s->phase==RIDER_CRASHED?-100:cx,cy,fx,fy,sn,cs,sin_rot,cos_rot,s->throttle_active||(s->phase==RIDER_RUNNING&&!s->grounded&&s->vx>RIDER_Q),s->tick_count,trail_sn,trail_cs,ends,nends);
        if(s->phase==RIDER_CRASHED && s->crash_ticks<28u){
            unsigned age=s->crash_ticks+2u;
            for(unsigned i=0;i<20u;++i){
                int a=(int)(i*205u+s->tick_count*31u);
                int len=(int)age*(2+(int)(i%4u))/2;
                int px=cx+rider_sin4096(a)*len/256;
                int py=cy+rider_sin4096(a+1024)*len/256;
                /* Angular wire fragments, not an intact bike plus dots. */
                int size=2+(int)(i%4u);
                uint16_t col=age<12u?RGB(202,226,238):age<21u?RGB(110,148,175):RGB(57,85,118);
                for(int q=0;q<=size;q++){
                    put(px+q,py+q/2,top,col);
                    put(px-q/2,py+q,top,col);
                    put(px+size-q,py+size/2+q/2,top,col);
                }
            }
        }
        draw_digits(score,(W-score_size)/2,24,2,top,WHITE);
        /* Best score is shown in pause/crash, separate from the live score. */
        if(s->paused || s->phase==RIDER_CRASHED){
            draw_label("BEST",8,34,1,top,WHITE);
            draw_digits(high,8,44,1,top,WHITE);
        }
        /* Diamonds now have visible feedback, even without garage mode. */
        draw_digits(diamond_count,W-15-diamond_len*9,7,1,top,GEM_WHITE);
        for(int dy=-4;dy<=4;++dy){
            for(int dx=-4;dx<=4;++dx){
                int rank=absolute(dx)+absolute(dy);
                if(rank<=4)put(W-8+dx,12+dy,top,rank<3?GEM_WHITE:GEM_MID);
            }
        }
        if(s->pending_score){
            int bonus_x=cx-15;
            if(bonus_x<3)bonus_x=3;
            if(bonus_x>W-55)bonus_x=W-55;
            int by=cy-19-(30-(int)s->pending_ticks)/2;
            draw_digits(bonus,bonus_x,by,s->pending_score>=3u?2:1,top,
                        s->pending_ticks>8u?WHITE:RGB(176,181,194));
        }
        if(s->perfect_ticks && s->phase==RIDER_RUNNING && !s->paused){
            draw_label("PERFECT FLIP",(W-12*12)/2,176,2,top,WHITE);
        }
        if(s->paused){
            /* A play triangle replaces the pause bars when gameplay stops. */
            for(int x=8;x<19;++x)
                for(int y=8;y<20;++y)
                    if(x>=8 && x<=18 && absolute(y-14)<=((18-x)/2))
                        put(x,y,top,WHITE);
            draw_label("PAUSE",115,92,2,top,WHITE);
        }else{
            for(int y=8;y<20;++y){
                for(int x=8;x<11;++x)put(x,y,top,RGB(77,110,129));
                for(int x=15;x<18;++x)put(x,y,top,RGB(77,110,129));
            }
        }
        if(s->phase==RIDER_CRASHED){
            for(int y=73;y<75;++y)for(int x=130;x<190;++x)put(x,y,top,WHITE);
        }
        out(top,STRIP_ROWS,strip,context);
    }
}
