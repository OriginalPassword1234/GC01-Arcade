/* Independent Rider-inspired simulation prototype v2.0.
 * Builds on v0.4 with more section variety, saw/boost piece metadata,
 * small gaps, subpixel track sampling and compact hazard collision checks.
 * Still NOT a Box2D/LiquidFun port and still not full original parity. */
#include "rider_core.h"
#include <limits.h>
#include <string.h>

#define PIECE_FLAG_GEM   0x01u
#define PIECE_FLAG_SAW   0x02u
#define PIECE_FLAG_BOOST 0x04u
#define PIECE_FLAG_SPIKES 0x08u
#define PIECE_FLAG_FALLING 0x10u
#define PIECE_FLAG_CLEARED 0x20u
#define PIECE_FLAG_AWAIT_LANDING 0x80u

/* Compact synthesized geometry. Template 16 is a real non-heightfield
 * loop PATH, guided by the same model used to draw it. Not original game data. */
static const int8_t heights[][RIDER_TRACK_NODES] = {
  {0, 0, 0, 0, 0, 0, 0, 0, 0},
  {0, 0, -5, -20, -29, -18, -4, 0, 0},
  {0, 0, 8, 24, 30, 17, 3, 0, 0},
  {0, -4, -17, -9, 5, 0, -12, -3, 0},
  {0, 0, -9, -28, -16, -3, 9, 0, 0},
  {0, 0, 6, 18, 8, -14, -24, -5, 0},
  {0, 0, -8, -22, -34, -17, -7, 0, 0},
  {0, 0, 5, 14, 24, 10, -8, 0, 0},
  {0, 0, -12, -30, -42, -24, -9, 0, 0},
  {0, 0, 10, 28, 38, 20, 5, 0, 0},
  {0, -2, -10, -5, 12, 3, -14, -5, 0},
  {0, 0, -4, -12, -18, -10, -4, 0, 0},
  {0, 0, -2, -8, -10, -7, -2, 0, 0},
  {0, -6, -21, -32, -35, 12, 22, 8, 0}, /* split ramp and descending landing */
  {0, 0, -10, -29, -43, -8, 12, 1, 0}, /* tall ejector and drop */
  {0, -5, -14, -25, -34, 2, 17, 5, 0}, /* lip to landing gap */
  {0, 0, 0, 0, 0, 0, 0, 0, 0},  /* closed loop */
  {0, 0, -8, -16, -14, -8, -3, 0, 0}, /* gentle two-step rise */
  {0, 0, 9, 17, 10, -10, -17, -4, 0}, /* shallow valley and up */
  {0, 0, -8, -30, -40, -32, -8, 0, 0}, /* long flight ramp */
  {0, 0, 4, 12, 7, 0, -4, 0, 0}, /* small rolling dip */
  {0, -4, -15, -28, -8, 18, 8, -3, 0}, /* cliff and landing */
  {0, 0, -4, -11, -18, -5, 4, 0, 0}, /* undulating boost */
  {0, -3, -15, -20, -6, -23, -11, -3, 0}, /* twin crests */
  {0, 0, 5, 16, 25, -10, -24, -7, 0}, /* downhill to ejector */
  {0, -2, -9, -22, -36, -22, -8, 0, 0}, /* steep saw approach */
  {0, 0, -8, -16, 3, 15, 4, 0, 0}, /* descending landing */
  {0,0,0,0,0,0,0,0,0},             /* 27: true rising wall */
  {0,0,0,0,0,0,0,0,0},             /* 28: true deep bowl */
  {0,0,-18,-45,-58,-31,-5,0,0},  /* 29: tall ejector */
  {0,3,16,27,31,17,-8,0,0},      /* 30: smooth downhill valley */
  {0,-3,-12,-26,-40,-31,-15,-3,0}, /* 31: long approach and launch */
  {0,0,0,-11,-30,-35,-17,-1,0},  /* 32: late lip */
  {0,0,6,23,36,15,0,0,0},        /* 33: deep valley */
  {0,-1,-8,-18,-31,-28,-6,0,0},  /* 34: rising arch */
  {0,0,0,0,0,0,0,0,0},            /* 35: long flat run */
  {0,0,-3,-15,-28,-10,9,0,0},    /* 36: tall leap */
  {0,0,10,22,13,-12,-29,-5,0},  /* 37: valley into ramp */
  {0,-3,-10,-12,0,8,15,4,0},     /* 38: undulating approach */
  {0,0,0,-7,-16,-25,-15,-3,0},   /* 39: boost rise */
  {0,0,0,-4,-26,29,20,7,0},       /* 40: detached drop and landing */
  {0,0,0,-10,-30,-54,-38,-8,0},/* 41: clean rising ramp (open lip) */
  {0,1,9,24,34,29,15,4,0},      /* 42: descending runout */
  {0,0,0,-4,-25,-58,-40,-8,0},/* 43: longer high launch */
  {0,-2,-9,-20,-33,-39,-28,-9,0},/* 44: progressive incline */
  {0,0,0,0,0,0,0,0,0},            /* 45: reference open curl with detached landing */
  {0,0,0,0,0,0,0,0,0},            /* 46: open loop, 2D path */
  {0,0,0,0,0,0,0,0,0},            /* 47: compact circular micro-loop */
  {0,0,0,0,0,0,0,0,0},            /* 48: legacy oscillating detached bridge */
  {0,3,25,57,89,57,25,3,0},      /* 49: steep V valley, reference 70359 */
  {0,-3,-23,-55,-87,-55,-23,-3,0}, /* 50: angular peak, reference 71004 */
  {0,8,34,65,81,69,39,12,0},      /* 51: asymmetric broad U, ref 71012 */
  {0,0,0,0,0,0,0,0,0},            /* 52: loop integrated into an elevated crest, ref 71002 */
  {0,-4,-23,-48,-75,26,37,19,0},  /* 53: split rising lip and lower detached landing, ref 70980 */
  {0,-8,-30,-55,-70,-35,-10,0,0}, /* 54: climb beneath independent open arc, ref 71002 */
  {0,0,0,0,0,0,0,0,0}, /* 55: two rising lips on a sustained incline, reference 70353 */
  {0,0,-8,-38,-78,-69,-34,-8,0}, /* 56 */
  {0,0,-8,-13,-13,-13,-8,0,0}, /* 57: detached moving rail */
  {0,0,-8,-13,-13,-13,-8,0,0}, /* 58: contact-triggered falling rail */
  {0,0,-16,-53,-65,-14,22,13,0}, /* 59: curved launch, wide saw gap, independent bowl landing */
  {0,-2,-5,13,49,13,-5,-2,0}, /* 60: double crest, saw above valley */
  {0,-24,-47,-18,27,47,22,-8,0}, /* 61: asymmetric S wave */
  {0,-28,-45,-4,-38,15,-24,-12,0}, /* 62: triangular zigzag */
  {0,12,32,44,30,-12,-46,-24,0}, /* 63: deep downhill into rising launch */
  {0,-8,-30,-10,32,12,-34,-18,0}, /* 64: compound wave */
  {0,0,0,0,0,0,0,0,0}, /* 65: elevated loop with opposed coral arc barriers */
  {0,-8,-35,-56,-22,32,35,14,0}, /* 66: asymmetric crest into deep basin */
  {0,8,28,30,0,-32,-34,-10,0}, /* 67: bowl into sustained climb */
  {0,-8,-24,-6,12,-24,-42,-10,0}, /* 68: double launch crests */
  {0,4,23,49,52,36,8,0,0}, /* 69: deep broad trough */
  {0,0,-8,-13,-13,-13,-8,0,0}, /* 70: contact-triggered rising platform */
  {0,-6,-30,-20,50,-20,-30,-6,0}, /* 71: two peaks / overhead saws */
  {0,-4,-10,-12,-12,-12,-10,-4,0}, /* 72: two independently moving suspended rails */
  {0,-5,-28,-52,-22,26,49,27,0}, /* 73: long crest to deep runout */
  {0,18,39,16,-25,-48,-20,12,0}, /* 74: asymmetric linked bowls */
  {0,0,0,0,0,0,0,0,0}, /* 75: consecutive small and large loops */
  {0,0,-14,-43,-66,16,29,12,0}, /* 76: retracting spike trench beneath jump */
  {0,-31,-5,-39,-7,-33,-4,-21,0}, /* 77: closely spaced rounded bunny hops */
  {0,0,-18,-52,-71,32,42,22,0}, /* 78: steep drop to separated bowl */
  {0,9,34,66,38,-15,-48,-14,0}, /* 79: deep asymmetric bowl and climb */
  {0,0,-8,-13,-13,-13,-8,0,0}, /* 80: detached triangular deck */
  {0,0,0,0,0,0,0,0,0}, /* 81: independently suspended bowl */
};
#define N_TEMPLATES ((uint32_t)(sizeof(heights)/sizeof(heights[0])))
_Static_assert(N_TEMPLATES == RIDER_TEMPLATE_COUNT, "track table/count mismatch");
static const int16_t sine256[256] = {
       0,    6,   13,   19,   25,   31,   38,   44,   50,   56,   62,   68,   74,   80,   86,   92,
      98,  104,  109,  115,  121,  126,  132,  137,  142,  147,  152,  157,  162,  167,  172,  177,
     181,  185,  190,  194,  198,  202,  206,  209,  213,  216,  220,  223,  226,  229,  231,  234,
     237,  239,  241,  243,  245,  247,  248,  250,  251,  252,  253,  254,  255,  255,  256,  256,
     256,  256,  256,  255,  255,  254,  253,  252,  251,  250,  248,  247,  245,  243,  241,  239,
     237,  234,  231,  229,  226,  223,  220,  216,  213,  209,  206,  202,  198,  194,  190,  185,
     181,  177,  172,  167,  162,  157,  152,  147,  142,  137,  132,  126,  121,  115,  109,  104,
      98,   92,   86,   80,   74,   68,   62,   56,   50,   44,   38,   31,   25,   19,   13,    6,
       0,   -6,  -13,  -19,  -25,  -31,  -38,  -44,  -50,  -56,  -62,  -68,  -74,  -80,  -86,  -92,
     -98, -104, -109, -115, -121, -126, -132, -137, -142, -147, -152, -157, -162, -167, -172, -177,
    -181, -185, -190, -194, -198, -202, -206, -209, -213, -216, -220, -223, -226, -229, -231, -234,
    -237, -239, -241, -243, -245, -247, -248, -250, -251, -252, -253, -254, -255, -255, -256, -256,
    -256, -256, -256, -255, -255, -254, -253, -252, -251, -250, -248, -247, -245, -243, -241, -239,
    -237, -234, -231, -229, -226, -223, -220, -216, -213, -209, -206, -202, -198, -194, -190, -185,
    -181, -177, -172, -167, -162, -157, -152, -147, -142, -137, -132, -126, -121, -115, -109, -104,
     -98,  -92,  -86,  -80,  -74,  -68,  -62,  -56,  -50,  -44,  -38,  -31,  -25,  -19,  -13,   -6,
};
int16_t rider_sin256(uint8_t angle_index) { return sine256[angle_index]; }
int16_t rider_sin4096(int32_t angle)
{
    uint32_t a=(uint32_t)angle & (RIDER_ANGLE_TURN-1u);
    uint32_t k=a>>4, f=a&15u;
    int32_t v0=sine256[k], v1=sine256[(k+1u)&255u];
    return (int16_t)(v0+(v1-v0)*(int32_t)f/16);
}
/* A full, continuously curved loop with long shallow approach/exit,
 * whose rail is not a heightfield. The large circle follows the visual
 * proportions in the reference frames and retains a rounded entry tangent.
 * Coordinates Q8; no dynamic allocation, no float operations in firmware. */
bool rider_loop_point_q(uint32_t pn, uint16_t t, int32_t *xq, int32_t *yq)
{
    if (t>RIDER_ANGLE_TURN || pn>25000u || !xq || !yq) return false;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+68u)*RIDER_Q +
        ((int32_t)88*RIDER_Q*t)/RIDER_ANGLE_TURN + 78*rider_sin4096(t);
    *yq=166*RIDER_Q-62*(RIDER_Q-rider_sin4096((int32_t)t+1024));
    return true;
}
/* Flash-only two-dimensional rail templates: the vertical wall and deep U
 * cannot be represented by a 1D heightfield. The control points are compact,
 * and evaluated only for the visible path or while traversing one structure.
 * These are hand-recreated from gameplay references, not original game data. */
/* Small closed loop attached to a short approach and runout. Reuses the
 * original fixed-point sine LUT; no vertex heap, extra state or float. */
static bool rider_micro_loop_point_q(uint32_t pn,uint16_t t,int32_t *xq,int32_t *yq)
{
    if(t>4096u || pn>25000u || !xq || !yq)return false;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+68u)*RIDER_Q+
         ((int32_t)65*RIDER_Q*t)/4096+42*rider_sin4096(t);
    *yq=166*RIDER_Q-32*(RIDER_Q-rider_sin4096((int32_t)t+1024));
    return true;
}
static const int16_t wall_xy[][2] = {
    {70,166},{93,164},{113,147},{125,112},{127,78},{140,54},{165,45}
};
/* Open C-shaped curved rail. It launches the bike into the next platform
 * after the lip rather than pretending to be a closed circle or a hill. */
static const int16_t open_xy[][2] = {
    {70,166},{85,166},{102,153},{112,131},{110,107},{96,86},
    {75,81},{55,92},{49,114},{65,133},{92,134},{119,124},{150,122}
};
bool rider_special_point_q(uint32_t pn,uint8_t kind,uint16_t t,int32_t *xq,int32_t *yq)
{
    if(!xq||!yq||t>4096||pn>25000u)return false;
    if(kind==45u){
        /* Reference 70992: a rising rail curls around an OPEN circle,
         * then launches toward a physically separate lower landing.
         * The 60-degree opening remains a genuine gap. */
        int32_t bx=(int32_t)(pn*256u)*RIDER_Q;
        if(t<1024u){
            int32_t u=(int32_t)t, v=1024-u;
            /* De Casteljau at Q8, smooth tangent into the circular rail. */
            int32_t ax=(34*v+65*u)/4,bx1=(65*v+102*u)/4,cx=(102*v+125*u)/4;
            int32_t ay=(166*v+166*u)/4,by=(166*v+141*u)/4,cy=(141*v+125*u)/4;
            ax=(ax*v+bx1*u)/1024;bx1=(bx1*v+cx*u)/1024;
            ay=(ay*v+by*u)/1024;by=(by*v+cy*u)/1024;
            *xq=bx+(ax*v+bx1*u)/1024;*yq=(ay*v+by*u)/1024;
        }else{
            int32_t a=626-((int32_t)(t-1024u)*3413)/3072;
            *xq=bx+100*RIDER_Q+43*rider_sin4096(a+1024);
            *yq=90*RIDER_Q+43*rider_sin4096(a);
        }
        return true;
    }
    if(kind==16u)return rider_loop_point_q(pn,t,xq,yq);
    if(kind==52u||kind==65u){
        if(!rider_loop_point_q(pn,t,xq,yq))return false;
        *yq-=32*RIDER_Q;
        return true;
    }
    if(kind==47u)return rider_micro_loop_point_q(pn,t,xq,yq);
    if(kind==75u){
        /* Two genuinely distinct 2-D rail turns with continuous horizontal
         * tangents at the shared bottom point. One path, no extra state. */
        int32_t u=(int32_t)t*2;
        int32_t bx=48,advance=64,rx=43,ry=36;
        if(t>=2048u){u-=4096;bx=112;advance=78;rx=58;ry=48;}
        *xq=(int32_t)(pn*256u+(uint32_t)bx)*RIDER_Q+advance*RIDER_Q*u/4096+rx*rider_sin4096(u);
        *yq=166*RIDER_Q-ry*(RIDER_Q-rider_sin4096(u+1024));
        return true;
    }
    if(kind==54u){
        /* Separate open arc over the crest. Traversal starts at the lower
         * right, then wraps around the top and exits at the lower left.
         * Unlike a closed track loop, the lower opening is not connected
         * to the continuous heightfield under it. */
        int32_t a=448-(int32_t)t*2944/4096;
        *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+130u)*RIDER_Q+48*rider_sin4096(a+1024);
        *yq=50*RIDER_Q+45*rider_sin4096(a);
        return true;
    }
    const int16_t (*points)[2]=NULL;
    uint32_t segments=6u;
    if(kind==27u)points=wall_xy;
    if(kind==28u){
        *xq=(int32_t)(pn*256u+70u)*RIDER_Q+128*RIDER_Q*t/4096;
        *yq=166*RIDER_Q+27*(RIDER_Q-rider_sin4096(t+1024));
        return true;
    }
    if(kind==46u){points=open_xy;segments=12u;}
    if(!points)return false;
    uint32_t step=(uint32_t)t*segments, k=step/4096u;
    if(k>=segments)k=segments-1u;
    uint32_t frac=step-k*4096u;
    /* Cubic Hermite between authored 2D knots. Straight joining lines
     * made the old open arcs look hexagonal; this shares the exact rail
     * path with collision and uses integer-only fixed point. */
    const int32_t u=(int32_t)(frac>>4); /* [0,256] */
    const int32_t u2=u*u/256, u3=u2*u/256;
    const int32_t h00=2*u3-3*u2+256;
    const int32_t h01=-2*u3+3*u2;
    const int32_t h10=u3-2*u2+u;
    const int32_t h11=u3-u2;
    int32_t mx0=(points[k+1][0]-points[k? k-1u: k][0])/2;
    int32_t my0=(points[k+1][1]-points[k? k-1u: k][1])/2;
    int32_t mx1=(points[(k+2u<=segments)? k+2u:k+1u][0]-points[k][0])/2;
    int32_t my1=(points[(k+2u<=segments)? k+2u:k+1u][1]-points[k][1])/2;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q +
        h00*points[k][0]+h01*points[k+1][0]+h10*mx0+h11*mx1;
    *yq=h00*points[k][1]+h01*points[k+1][1]+h10*my0+h11*my1;
    return true;
}
bool rider_track_special_q(const RiderState *s,uint32_t pn,uint8_t kind,uint16_t t,int32_t *xq,int32_t *yq)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(p->number!=pn || pn>=s->next_piece || p->template_id!=kind ||
       !rider_special_point_q(pn,kind,t,xq,yq))return false;
    *yq+=((int32_t)p->start_y-166)*RIDER_Q;
    return true;
}
static bool special_piece(uint8_t k){return k==45u||k==16u||k==27u||k==28u||k==46u||k==47u||k==52u||k==54u||k==65u||k==75u;}
static int32_t angle_from_vector(int32_t dx,int32_t dy)
{
    /* atan2 approximation in 4096 turn units, max error a few degrees. */
    int32_t ax=dx<0?-dx:dx, ay=dy<0?-dy:dy;
    if(!ax && !ay) return 0;
    int32_t oct=(ax>=ay)? (ay*512)/(ax?ax:1) :
                              1024-(ax*512)/ay;
    if(dx<0) oct=2048-oct;
    if(dy<0) oct=-oct;
    return oct;
}

static uint32_t next_random(RiderState *s)
{
    uint32_t x = s->random_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    s->random_state = x;
    return x;
}

static int32_t clamp_i32(int32_t a,int32_t lo,int32_t hi)
{
    return a<lo ? lo : a>hi ? hi : a;
}

/* Each three-piece group is an intentionally designed challenge:
 * an approach, a launch/obstacle, then a suitable runout.  The long flat
 * streaks in v1.0 made almost every run boring and suppressed the score
 * progression needed to unlock later stages.  Difficulty is now also
 * unlocked by distance, so runs with no scored flips don't get stuck
 * in the initial pool forever.  All section data stays in FLASH. */
static uint8_t choose_template(RiderState *s, uint32_t pn)
{
    static const uint8_t novice_challenges[]={
        29,36,19,41,31,43,34,14,39,36,29,19,41,43
    };
    static const uint8_t mid_challenges[]={
        29,36,41,31,43,39,45,27,46,54,14,9,19,34,13,55,56,9
    };
    static const uint8_t expert_challenges[]={
        29,36,41,43,45,27,46,54,13,9,28,39,14,19,34,44,53,54,55,56
    };
    static const uint8_t recoveries[]={0,35,42,0,35,44,35,42};
    /* Intentionally predictable first few structures.  The first ramp
     * teaches a controlled jump; the following runout allows landing. */
    if(pn==1u) return 45u;
    if(pn==2u) return 29u;
    if(pn==3u) return 42u;
    if(pn==4u) return 39u; /* boost in the first ten seconds */
    if(pn==5u) return 40u;
    if(pn==6u) return 51u;
    if(pn==7u) return 35u;
    if(pn==8u) return 54u; /* detached circular arc above an approach */
    /* Legacy oscillating bridge is no longer selected in endless mode. */
    /* Two to three distinct structures per eight pieces, with breathing
     * room, but never an indefinite chain of empty 256px straights. */
    if(pn>=36u && pn%3u==0u && ((s->random_state>>12)&3u)==0u)
        return (uint8_t)(61u+next_random(s)%4u);
    if(pn>=17u && pn%3u==2u && ((s->random_state>>16)&3u)==0u)
        return (uint8_t)(57u+next_random(s)%4u);
    if(pn>=39u && pn%3u==0u && ((s->random_state>>27)&3u)==0u)
        return (uint8_t)(76u+next_random(s)%4u);
    if(pn>=36u && pn%3u==0u && ((s->random_state>>4)&3u)==0u)
        return (uint8_t)(71u+next_random(s)%4u);
    if(pn>=36u && pn%3u==0u && ((s->random_state>>8)&7u)==0u)
        return (uint8_t)(66u+next_random(s)%4u);
    if(pn>=44u && pn%3u==2u && ((s->random_state>>24)&7u)==0u)
        return 70u;
    if(pn>=38u && pn%3u==2u && (s->last_template==0u||s->last_template==35u) && ((s->random_state>>20)&3u)==0u)
        return 65u;
    if(pn>=36u && pn%3u==2u && (s->last_template==0u||s->last_template==35u) && ((s->random_state>>17)&3u)==0u)
        return 45u;
    if(pn>=45u && pn%3u==2u && (s->last_template==0u||s->last_template==35u) && ((s->random_state>>18)&3u)==0u)
        return (uint8_t)(80u+next_random(s)%2u);
    if(pn%3u==0u) {
        uint8_t r=recoveries[next_random(s)%sizeof(recoveries)];
        if(pn>=15u && (r==26u || r==30u))r=(r==26u?49u:51u);
        return r;
    }
    if(pn%3u==1u) {
        static const uint8_t approaches[]={0,35,42,44,35,0,0,35};
        uint8_t a=approaches[next_random(s)%sizeof(approaches)];
        
        return a;
    }
    if(pn>=11u && (s->last_template==0u||s->last_template==35u) && ((s->random_state>>10)&3u)!=0u && (s->track[(pn-2u)%RIDER_TRACK_SLOTS].template_id<=44u)){
        static const uint8_t stunts[]={45,46,40,54,57,58,59,70,53,65,45,72,76,53,56};
        unsigned count=pn<20u?3u:(pn<36u?9u:sizeof(stunts));
        return stunts[next_random(s)%count];
    }
    uint32_t progression=pn*2u;
    if(s->score>=75 || progression>=75)progression=75;
    else if(s->score>=40 || progression>=40)progression=40;
    else if(s->score>=15 || progression>=15)progression=15;
    else progression=0;
    const uint8_t *pool=novice_challenges;
    uint32_t len=sizeof(novice_challenges);
    if(progression>=40){pool=expert_challenges;len=sizeof(expert_challenges);}
    else if(progression>=15){pool=mid_challenges;len=sizeof(mid_challenges);}
    uint8_t chosen=pool[next_random(s)%len];
    if(chosen==s->last_template)chosen=pool[next_random(s)%len];
    if((chosen==52u || chosen==9u) && s->last_template!=0u && s->last_template!=35u && s->last_template!=42u && s->last_template!=26u)chosen=42u;
    uint8_t prior2=s->track[(pn-2u)%RIDER_TRACK_SLOTS].template_id;
    if((chosen==27u || chosen==46u || chosen==47u || chosen==52u || chosen==9u) &&
       (prior2==50u||prior2==61u||prior2==62u||prior2==63u||prior2==64u))chosen=42u;
    if(chosen==27u && (prior2!=0u&&prior2!=35u&&prior2!=42u&&prior2!=26u))chosen=47u;
    if(special_piece(chosen) && s->last_template!=0u && s->last_template!=35u && chosen!=52u && chosen!=54u)chosen=42u;
    if(chosen==25u && s->last_template==50u)chosen=42u;
    if(chosen==9u && (s->last_template==26u || s->last_template==44u || s->last_template==31u || s->last_template==34u))chosen=51u;
    return chosen;
}

/* Bounded continuous elevation changes on ordinary slopes. No extra state.
 * Start/end tangents of the additional smoothstep are zero. */
static int32_t piece_end_delta(uint8_t kind,int32_t start_y)
{
    int32_t d=0;
    if(kind==42u || kind==51u) d=32;
    if(kind==30u) d=24;
    if(kind==44u || kind==34u) d=-32;
    if(kind==55u) d=-72;
    if(kind==73u) d=24;
    if(kind==74u || kind==79u) d=-24;
    return clamp_i32(start_y+d,108,214)-start_y;
}
static void append_piece(RiderState *s)
{
    uint32_t n = s->next_piece++;
    RiderPiece *p = &s->track[n % RIDER_TRACK_SLOTS];
    uint8_t pattern = 0;
    if (n != 0) pattern = choose_template(s,n);
    p->number = n;
    p->template_id = pattern;
    p->start_y = 166;
    if(n){
        const RiderPiece *prev=&s->track[(n-1u)%RIDER_TRACK_SLOTS];
        p->start_y=(int16_t)(prev->start_y+piece_end_delta(prev->template_id,prev->start_y));
    }
    /* Only select the sustained double ascent when there is enough world
     * elevation headroom; otherwise select the independent high gap. */
    if(pattern==55u && p->start_y<164){pattern=56u;p->template_id=pattern;}
    p->flags = 0;
    p->gem_mask=0;
    p->fall_tick=0;
    if (n != 0u && ((n & 1u) || special_piece(pattern) || pattern==40u || pattern==55u || pattern==56u || pattern>=57u) && pattern!=48u) {
        p->flags |= PIECE_FLAG_GEM;
        p->gem_mask = (special_piece(pattern) || pattern==40u || pattern==13u || pattern==30u ||
                       pattern==29u || pattern==36u || pattern==41u || pattern==43u ||
                       pattern==49u || pattern==51u || pattern==53u || pattern==55u || pattern==56u || pattern>=57u)?7u:1u;
    }
    /* No disconnected floating saws. Later saws belong only to explicit
     * hazard sections with nearby rail geometry. */
    if (pattern == 9u || pattern == 10u || pattern == 25u || pattern==59u || pattern==60u || pattern==71u)
        p->flags |= PIECE_FLAG_SAW;
    if (pattern == 11u || pattern == 22u || pattern==39u) p->flags |= PIECE_FLAG_BOOST;
    if(pattern==12u || pattern==13u || pattern==15u || pattern==21u || pattern==76u) p->flags |= PIECE_FLAG_SPIKES;
    s->last_template = pattern;
}

/* Hermite curve with slopes derived from adjacent knots; flat end tangents. */
static int32_t sample_curve_q(uint8_t kind, uint32_t local_x_q)
{
    if (kind >= N_TEMPLATES) return 0;
    uint32_t k = local_x_q / (32u*RIDER_Q);
    if (k >= 8) return 0;
    int32_t t = (int32_t)((local_x_q % (32u*RIDER_Q)) / 32u);
    int32_t t2 = t * t / RIDER_Q, t3 = t2 * t / RIDER_Q;
    int32_t a = 2*t3-3*t2+RIDER_Q, b=-2*t3+3*t2;
    int32_t c = t3-2*t2+t, d=t3-t2;
    int32_t v0 = heights[kind][k];
    int32_t v1 = heights[kind][k+1];
    int32_t m0 = k ? ((int32_t)heights[kind][k+1]-heights[kind][k-1])/2 : 0;
    int32_t m1 = k+1<8 ? ((int32_t)heights[kind][k+2]-heights[kind][k])/2 : 0;
    /* Keep the central sharp apex of V/peak templates; their outer
     * transitions are still Hermite and have flat endpoints. */
    if(((kind==49u || kind==50u) && (k==3u || k==4u)) || (kind==62u && k>=1u && k<=6u))
        return v0*(RIDER_Q-t)+v1*t;
    return a*v0 + b*v1 + c*m0 + d*m1;
}

static bool template_gap(uint8_t kind, uint32_t local_x_q)
{
    if (kind == 80u) return (local_x_q>=86u*RIDER_Q && local_x_q<102u*RIDER_Q) || (local_x_q>176u*RIDER_Q && local_x_q<=190u*RIDER_Q);
    if (kind == 81u) return (local_x_q>=82u*RIDER_Q && local_x_q<96u*RIDER_Q) || (local_x_q>164u*RIDER_Q && local_x_q<=178u*RIDER_Q);
    if (kind == 45u) return local_x_q>=34u*RIDER_Q && local_x_q<142u*RIDER_Q;
    if (kind == 40u) return local_x_q>=112u*RIDER_Q && local_x_q<174u*RIDER_Q;
    if (kind == 76u) return local_x_q>=118u*RIDER_Q && local_x_q<=158u*RIDER_Q;
    if (kind == 78u) return local_x_q>=124u*RIDER_Q && local_x_q<=172u*RIDER_Q;
    if (kind == 75u) return local_x_q>=48u*RIDER_Q && local_x_q<=190u*RIDER_Q;
    if (kind == 72u) return (local_x_q>=66u*RIDER_Q && local_x_q<78u*RIDER_Q) || (local_x_q>116u*RIDER_Q && local_x_q<138u*RIDER_Q) || (local_x_q>176u*RIDER_Q && local_x_q<=188u*RIDER_Q);
    if (kind == 59u) return local_x_q>=88u*RIDER_Q && local_x_q<=190u*RIDER_Q;
    if (kind == 57u || kind == 58u || kind == 70u) return (local_x_q>=86u*RIDER_Q && local_x_q<98u*RIDER_Q) || (local_x_q>158u*RIDER_Q && local_x_q<=170u*RIDER_Q);
    if (kind == 16u || kind == 52u || kind == 65u) return local_x_q>=68u*RIDER_Q && local_x_q<=156u*RIDER_Q;
    if (kind == 47u) return local_x_q>=68u*RIDER_Q && local_x_q<=133u*RIDER_Q;
    if (kind == 27u) return local_x_q>=70u*RIDER_Q && local_x_q<=220u*RIDER_Q;
    
    if (kind == 46u) return local_x_q>=70u*RIDER_Q && local_x_q<=221u*RIDER_Q;
    if (kind == 55u) return local_x_q>=116u*RIDER_Q && local_x_q<=148u*RIDER_Q;
    if (kind == 56u) return local_x_q>=120u*RIDER_Q && local_x_q<=158u*RIDER_Q;
    if (kind == 53u) return local_x_q>=124u*RIDER_Q && local_x_q<=173u*RIDER_Q;
    if (kind == 12u) return local_x_q >= 102u*RIDER_Q && local_x_q <= 152u*RIDER_Q;
    if (kind == 13u || kind == 15u || kind == 21u) return local_x_q >= 102u*RIDER_Q && local_x_q <= 154u*RIDER_Q;
    return false;
}

/* Shared moving/falling surface, with compact per-piece trigger time. The
 * exact timing is an independently tuned approximation, not original data. */
bool rider_platform_at_q(const RiderState *s,uint32_t pn,unsigned slot,int32_t *x0,int32_t *x1,int32_t *y)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(pn>=s->next_piece || p->number!=pn)return false;
    if(p->template_id==72u){
        if(slot>=2u)return false;
        *x0=(int32_t)(pn*256u+78u+60u*slot)*RIDER_Q; *x1=*x0+38*RIDER_Q;
        *y=((int32_t)p->start_y-12)*RIDER_Q+5*rider_sin256((uint8_t)(s->tick_count+pn*13u+slot*128u));
        return true;
    }
    if(p->template_id==80u){
        if(slot)return false;
        *x0=(int32_t)(pn*256u+102u)*RIDER_Q; *x1=*x0+74*RIDER_Q;
        *y=((int32_t)p->start_y-34)*RIDER_Q; return true;
    }
    if(slot || (p->template_id!=57u&&p->template_id!=58u&&p->template_id!=70u))return false;
    *x0=(int32_t)(pn*256u+98u)*RIDER_Q; *x1=*x0+60*RIDER_Q;
    *y=((int32_t)p->start_y-13)*RIDER_Q;
    if(p->template_id==57u)*y+=7*rider_sin256((uint8_t)(s->tick_count+pn*13u));
    else if(p->template_id==70u){
        if(p->flags&PIECE_FLAG_FALLING){
            unsigned age=(uint16_t)((uint16_t)s->tick_count-p->fall_tick);
            if(age>=30u || (p->flags&0x40u))*y-=20*RIDER_Q;
            else {int32_t u=(int32_t)age*256/30,u2=u*u/256;*y-=20*(3*u2-2*u2*u/256);}
        }
    }
    else if(p->flags&PIECE_FLAG_FALLING){
        unsigned age=(uint16_t)((uint16_t)s->tick_count-p->fall_tick);
        if(age>80u || (p->flags&0x40u))return false;
        *y+=(int32_t)(age*age*15u/2u);
    }
    return true;
}
bool rider_platform_q(const RiderState *s,uint32_t pn,int32_t *x0,int32_t *x1,int32_t *y)
{
    return rider_platform_at_q(s,pn,0u,x0,x1,y);
}
bool rider_surface_q(const RiderState *s, int32_t world_x_q, int32_t *world_y_q)
{
    if (world_x_q < 0) return false;
    uint32_t number = (uint32_t)world_x_q / (RIDER_PIECE_WIDTH*RIDER_Q);
    const RiderPiece *p = &s->track[number % RIDER_TRACK_SLOTS];
    if (p->number != number || number >= s->next_piece) return false;
    uint32_t local_x_q = (uint32_t)world_x_q % (RIDER_PIECE_WIDTH*RIDER_Q);
    if(p->template_id==72u){
        for(unsigned j=0;j<2u;j++){
            int32_t a,b,y;
            if(rider_platform_at_q(s,number,j,&a,&b,&y) && world_x_q>=a && world_x_q<=b){*world_y_q=y;return true;}
        }
    }
    if((p->template_id==57u||p->template_id==58u||p->template_id==70u) && local_x_q>=98u*RIDER_Q && local_x_q<=158u*RIDER_Q){
        int32_t a,b;return rider_platform_q(s,number,&a,&b,world_y_q);
    }
    if(p->template_id==48u){
        /* Small gaps around a vertically oscillating suspended bridge.
         * Trigger and visual motion require NO additional state allocation. */
        if((local_x_q>=90u*RIDER_Q && local_x_q<103u*RIDER_Q) ||
           (local_x_q>177u*RIDER_Q && local_x_q<=190u*RIDER_Q))return false;
        if(local_x_q>=103u*RIDER_Q && local_x_q<=177u*RIDER_Q){
            *world_y_q=(int32_t)p->start_y*RIDER_Q +
              18*rider_sin256((uint8_t)(2u*s->tick_count+number*13u));
            return true;
        }
    }
    if (template_gap(p->template_id, local_x_q)) return false;
    if(p->template_id==80u && local_x_q>=102u*RIDER_Q && local_x_q<=176u*RIDER_Q){int32_t a,b;return rider_platform_q(s,number,&a,&b,world_y_q);}
    int32_t offset = sample_curve_q(p->template_id, local_x_q);
    if(p->template_id==80u){
        if(local_x_q<86u*RIDER_Q){int32_t u=(int32_t)(local_x_q/86u);offset=-36*(u*u/RIDER_Q)*u/RIDER_Q;}
        else {int32_t u=(int32_t)((256u*RIDER_Q-local_x_q)/66u);offset=-28*u*u/RIDER_Q;}
    }
    if(p->template_id==81u){
        /* Three separate rails, based on the 2017 detached-bowl capture.
         * Exact widths and heights are tuned for this fixed-point engine. */
        if(local_x_q<82u*RIDER_Q){int32_t u=(int32_t)(local_x_q/82u);offset=-15*u*u/RIDER_Q;}
        else if(local_x_q<=164u*RIDER_Q){int32_t u=(int32_t)((local_x_q-96u*RIDER_Q)/68u);offset=-12*RIDER_Q+16*(4*u*(RIDER_Q-u)/RIDER_Q);}
        else {int32_t u=(int32_t)((256u*RIDER_Q-local_x_q)/78u);offset=-8*u*u/RIDER_Q;}
    }
    if(p->template_id==45u && local_x_q>=142u*RIDER_Q){
        int32_t u=(int32_t)((local_x_q-142u*RIDER_Q)/114u);
        offset=18*(RIDER_Q-u*u/RIDER_Q);
    }
    if(p->template_id==40u){
        if(local_x_q<112u*RIDER_Q){
            int32_t u=(int32_t)(local_x_q/112u);
            offset=-25*u*u/RIDER_Q;
        }else{
            int32_t u=(int32_t)((256u*RIDER_Q-local_x_q)/82u);
            offset=31*u*u/RIDER_Q;
        }
    }
    if(p->template_id==28u && local_x_q>=70u*RIDER_Q && local_x_q<=198u*RIDER_Q){
        int32_t t=(int32_t)((local_x_q-70u*RIDER_Q)/8u);
        offset=27*(RIDER_Q-rider_sin4096(t+1024));
    }
    if(p->template_id==52u||p->template_id==65u){
        /* Same elevated tangent as the 2D path at x=68 and x=156.
         * Smooth approach, no invisible rail under the loop. */
        int32_t t=local_x_q<68u*RIDER_Q?(int32_t)(local_x_q/68u):
            (int32_t)((256u*RIDER_Q-local_x_q)/100u);
        if(t>RIDER_Q)t=RIDER_Q;
        int32_t t2=t*t/RIDER_Q;
        offset=-32*(3*t2-2*t2*t/RIDER_Q);
    }
    const int32_t u=(int32_t)(local_x_q/RIDER_PIECE_WIDTH);
    const int32_t u2=u*u/RIDER_Q;
    offset+=piece_end_delta(p->template_id,p->start_y)*(3*u2-2*u2*u/RIDER_Q);
    if(p->template_id==55u && local_x_q>148u*RIDER_Q){
        /* A few world pixels of landing clearance compensate for gravity
         * during the gap; the second rail still climbs continuously. */
        int32_t z=(int32_t)((256u*RIDER_Q-local_x_q)/108u);
        int32_t z2=z*z/RIDER_Q;
        offset+=6*(3*z2-2*z2*z/RIDER_Q);
    }
    if((p->template_id==57u || p->template_id==58u || p->template_id==70u) && local_x_q>170u*RIDER_Q){
        int32_t z=(int32_t)((256u*RIDER_Q-local_x_q)/86u);
        offset+=10*z;
    }
    *world_y_q = (int32_t)p->start_y*RIDER_Q + offset;
    return true;
}

/* Opposed red arc segments inside an elevated loop, visible in original Rider.
 * Radius/width/timing are independently tuned. No extra per-piece state. */
bool rider_piece_ring_q(const RiderState *s,uint32_t pn,int32_t *x,int32_t *y)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(pn>=s->next_piece||p->number!=pn||p->template_id!=65u)return false;
    *x=(int32_t)(pn*256u+112u)*RIDER_Q;
    *y=((int32_t)p->start_y-94)*RIDER_Q;
    return true;
}
bool rider_ring_contains_q(int32_t dx,int32_t dy,uint32_t tick,int margin)
{
    /* Q4 geometry, two opposite 84-degree arc sectors. */
    if(dx<-48*RIDER_Q||dx>48*RIDER_Q||dy<-48*RIDER_Q||dy>48*RIDER_Q)return false;
    int32_t x=dx/16,y=dy/16;
    int32_t d2=x*x+y*y,lo=(29-margin)*16,hi=(36+margin)*16;
    if(d2<lo*lo||d2>hi*hi)return false;
    uint8_t a=(uint8_t)(tick/2u);
    int32_t dot=x*rider_sin256((uint8_t)(a+64u))+y*rider_sin256(a);
    /* |projection| / length >= cos(42 deg), relaxed for wheel radius. */
    int32_t v=dot/256;if(v<0)v=-v;
    int32_t threshold=margin?166:190;
    return v*v >= (d2*threshold/256)*threshold/256;
}

/* Approximate swept contact for the two rotating sectors. Endpoints and
 * quarter steps cover intermediate motion; bounded broad phase avoids work
 * for distant hazards. Not a continuous rigid-body solver. */
static bool ring_swept(int32_t ax,int32_t ay,int32_t bx,int32_t by,uint32_t tick,int margin)
{
    const int32_t r=48*RIDER_Q;
    if((ax<-r&&bx<-r)||(ax>r&&bx>r)||(ay<-r&&by<-r)||(ay>r&&by>r))return false;
    for(int i=0;i<=4;i++){
        int32_t x=ax+(bx-ax)*i/4,y=ay+(by-ay)*i/4;
        if(rider_ring_contains_q(x,y,tick,margin)||
           (i<4 && rider_ring_contains_q(x,y,tick-1u,margin)))return true;
    }
    return false;
}

static bool saw_at_tick(const RiderState *s, uint32_t piece_number, unsigned slot, uint32_t tick, int32_t *cx_q, int32_t *cy_q, int32_t *radius_q)
{
    const RiderPiece *p = &s->track[piece_number % RIDER_TRACK_SLOTS];
    if (piece_number>=s->next_piece || p->number != piece_number || !(p->flags & PIECE_FLAG_SAW)) return false;
    if(p->template_id==71u){
        if(slot>=2u)return false;
        *cx_q=(int32_t)(piece_number*256u+(slot?218u:118u))*RIDER_Q;
        *cy_q=((int32_t)p->start_y-(slot?180:195))*RIDER_Q;
        if(slot)*cx_q+=8*rider_sin256((uint8_t)(tick+piece_number*13u));
        *radius_q=(slot?28:44)*RIDER_Q;
        return true;
    }
    if(slot)return false;
    if(p->template_id==59u){
        *cx_q=(int32_t)(piece_number*256u+139u)*RIDER_Q;
        *cy_q=((int32_t)p->start_y+34)*RIDER_Q; *radius_q=56*RIDER_Q;return true;
    }
    if(p->template_id==60u){
        *cx_q=(int32_t)(piece_number*256u+128u)*RIDER_Q;
        *cy_q=((int32_t)p->start_y-100)*RIDER_Q; *radius_q=42*RIDER_Q;return true;
    }
    uint32_t local_px = (p->template_id == 10u) ? 176u : 146u;
    *cx_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + local_px) * RIDER_Q;
    if(p->template_id==25u) {
        const uint8_t phase=(uint8_t)(2u*tick+piece_number*13u);
        *cx_q += 13*rider_sin256(phase); /* +/-13 world pixels, no RAM */
    }
    int32_t yq;
    if (!rider_surface_q(s, *cx_q, &yq)) return false;
    /* Place the full blade above the LOCAL rail. Collisions are computed
     * against the same center/radius used by the renderer. */
    /* Larger original-inspired blade; maintain safe clearance in the
     * pretested novice route despite the late-game horizontal oscillation. */
    *cy_q=yq-(p->template_id==25u?96:108)*RIDER_Q;
    *radius_q = (p->template_id==25u?33:42) * RIDER_Q;
    return true;
}

bool rider_piece_saw_at_q(const RiderState *s,uint32_t pn,unsigned slot,int32_t *x,int32_t *y,int32_t *r)
{
    return saw_at_tick(s,pn,slot,s->tick_count,x,y,r);
}
bool rider_piece_saw_q(const RiderState *s,uint32_t pn,int32_t *x,int32_t *y,int32_t *r)
{
    return rider_piece_saw_at_q(s,pn,0u,x,y,r);
}
bool rider_piece_boost_q(const RiderState *s, uint32_t piece_number, int32_t *x0_q, int32_t *x1_q, int32_t *y_q)
{
    const RiderPiece *p = &s->track[piece_number % RIDER_TRACK_SLOTS];
    if (p->number != piece_number || !(p->flags & PIECE_FLAG_BOOST)) return false;
    *x0_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 92u) * RIDER_Q;
    *x1_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 148u) * RIDER_Q;
    int32_t mid = *x0_q + (*x1_q-*x0_q)/2;
    return rider_surface_q(s, mid, y_q);
}

bool rider_piece_gem_q(const RiderState *s,uint32_t pn,uint8_t slot,int32_t *xq,int32_t *yq)
{
    if(slot>=3u || !xq || !yq)return false;
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(pn>=s->next_piece || p->number!=pn || !(p->flags&PIECE_FLAG_GEM) || !(p->gem_mask&(1u<<slot)))return false;
    if(special_piece(p->template_id)) {
        static const uint16_t ts[3]={1050,2050,3050};
        uint16_t t=ts[slot];
        if(p->template_id==28u){static const uint16_t bowl[3]={1100,2200,3350};t=bowl[slot];}
        int32_t ax,ay,bx,by;
        if(!rider_track_special_q(s,pn,p->template_id,t,xq,yq) ||
           !rider_track_special_q(s,pn,p->template_id,t-32,&ax,&ay) ||
           !rider_track_special_q(s,pn,p->template_id,t+32,&bx,&by))return false;
        /* Put diamonds on the rider-facing side of the actual 2D path. */
        int32_t a=angle_from_vector(bx-ax,by-ay);
        *xq+=14*rider_sin4096(a);
        *yq-=14*rider_sin4096(a+1024);
        return true;
    }
    if(p->template_id==81u){
        *xq=(int32_t)(pn*256u+108u+slot*22u)*RIDER_Q;
        if(!rider_surface_q(s,*xq,yq))return false;
        *yq-=16*RIDER_Q;return true;
    }
    if(p->template_id==57u || p->template_id==58u || p->template_id==70u || p->template_id==80u){
        int32_t a,b,y;if(!rider_platform_q(s,pn,&a,&b,&y))return false;
        *xq=a+(12+(int32_t)slot*18)*RIDER_Q;*yq=y-17*RIDER_Q;return true;
    }
    if(p->template_id==40u){
        *xq=(int32_t)(pn*256u+123u+slot*19u)*RIDER_Q;
        *yq=((int32_t)p->start_y-36+(int32_t)slot*5)*RIDER_Q;return true;
    }
    if(p->template_id==59u){
        *xq=(int32_t)(pn*256u+103u+slot*35u)*RIDER_Q;
        *yq=((int32_t)p->start_y-68-(slot==1u?15:0))*RIDER_Q;return true;
    }
    if(p->template_id==72u){
        int32_t a,b,y;
        if(!rider_platform_at_q(s,pn,slot==2u?1u:0u,&a,&b,&y))return false;
        *xq=a+(slot==1u?28:12)*RIDER_Q;*yq=y-17*RIDER_Q;return true;
    }
    if(p->template_id==76u || p->template_id==78u){
        int32_t base=(int32_t)(pn*256u)*RIDER_Q,yl,yr;
        int l=p->template_id==76u?117:123,r=p->template_id==76u?159:173;
        if(!rider_surface_q(s,base+l*RIDER_Q,&yl)||!rider_surface_q(s,base+r*RIDER_Q,&yr))return false;
        int u=(r-l)*(slot+1)/4;
        *xq=base+(l+u)*RIDER_Q;
        /* Airborne arc above the highest lip, never under the descending chord. */
        *yq=(yl<yr?yl:yr)-(16+(slot==1u?6:0))*RIDER_Q;
        return true;
    }
    if(p->template_id>=60u){
        *xq=(int32_t)(pn*256u+78u+slot*50u)*RIDER_Q;
        if(!rider_surface_q(s,*xq,yq))return false;
        *yq-=18*RIDER_Q;return true;
    }
    if(p->template_id==55u || p->template_id==56u){
        /* Airborne diamond path follows the actual two lips, not the base
         * elevation. It is drawn and collected using this same function. */
        int32_t start=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q, yl,yr;
        int l=p->template_id==55u?115:119, r=p->template_id==55u?149:159;
        if(!rider_surface_q(s,start+l*RIDER_Q,&yl) ||
           !rider_surface_q(s,start+r*RIDER_Q,&yr))return false;
        int u=(r-l)*(slot+1)/4;
        *xq=start+(l+u)*RIDER_Q;
        *yq=yl+(yr-yl)*u/(r-l)-(20+(slot==1u?9:0))*RIDER_Q;
        return true;
    }
    if(p->template_id==53u){
        int32_t start=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q, yl,yr;
        if(!rider_surface_q(s,start+123*RIDER_Q,&yl) ||
           !rider_surface_q(s,start+174*RIDER_Q,&yr))return false;
        *xq=start+(130+(int32_t)slot*17)*RIDER_Q;
        *yq=yl+(yr-yl)*(7+(int32_t)slot*17)/51-(26+(slot==1u?12:0))*RIDER_Q;
        return true;
    }
    int32_t wx=(int32_t)(pn*RIDER_PIECE_WIDTH+128u)*RIDER_Q;
    if(p->template_id==13u || p->template_id==30u || p->template_id==49u || p->template_id==51u || p->template_id==53u)
        wx=(int32_t)(pn*RIDER_PIECE_WIDTH+100u+slot*28u)*RIDER_Q;
    int32_t wy;
    if((p->template_id==29u || p->template_id==36u ||
        p->template_id==41u || p->template_id==43u) && (p->flags&PIECE_FLAG_GEM)){
        wx=(int32_t)(pn*RIDER_PIECE_WIDTH+115u+slot*28u)*RIDER_Q;
        if(!rider_surface_q(s,wx,&wy))
            wy=(int32_t)p->start_y*RIDER_Q;
        /* The middle gem sits higher, forming a three-gem airborne arc. */
        wy-=(20+(slot==1u?8:0))*RIDER_Q;

    } else if(!rider_surface_q(s,wx,&wy)){
        /* Around real gaps the diamonds float over the missing rail. */
        wy=(int32_t)(p->start_y-19)*RIDER_Q;
    }
    *xq=wx;
    *yq=wy-(((p->template_id==29u||p->template_id==36u||
               p->template_id==41u||p->template_id==43u) &&
               (p->flags&PIECE_FLAG_GEM))?0:18*RIDER_Q);
    return true;
}
/* Repeating triangular spike profile in the same Q8 world coordinates
 * as the hazard bounds. A sawtooth is not a filled collision rectangle. */
int32_t rider_spike_profile_q(int32_t local_x_q)
{
    int32_t u=local_x_q%(10*RIDER_Q)-5*RIDER_Q;
    return (u<0?-u:u)*6/5;
}
static bool spikes_at_tick(const RiderState *s,uint32_t pn,uint32_t tick,int32_t *x0q,int32_t *x1q,int32_t *tipyq)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(pn>=s->next_piece || p->number!=pn || !(p->flags&PIECE_FLAG_SPIKES) || !x0q || !x1q || !tipyq)return false;
    if(p->template_id==15u && ((tick+pn*17u)%120u)<50u)
        return false; /* timed lance retracted: renderer AND physics agree */
    if(p->template_id==76u){
        /* A complete retract/extend cycle. The same translated solid spike
         * geometry is used for drawing and contact, including the warning motion. */
        unsigned t=(tick+pn*17u)%160u;
        int32_t extension=t<40u?0:t<64u?(int32_t)(t-40u)*RIDER_Q/24:t<112u?RIDER_Q:t<136u?(int32_t)(136u-t)*RIDER_Q/24:0;
        if(!extension)return false;
        *x0q=(int32_t)(pn*256u+120u)*RIDER_Q;
        *x1q=(int32_t)(pn*256u+156u)*RIDER_Q;
        *tipyq=(int32_t)(p->start_y+40)*RIDER_Q-30*extension;
        return true;
    }
    *x0q=(int32_t)(pn*RIDER_PIECE_WIDTH+106u)*RIDER_Q;
    *x1q=(int32_t)(pn*RIDER_PIECE_WIDTH+151u)*RIDER_Q;
    *tipyq=(int32_t)(p->start_y+14)*RIDER_Q;
    return true;
}
bool rider_piece_spikes_q(const RiderState *s,uint32_t pn,int32_t *x0q,int32_t *x1q,int32_t *tipyq)
{
    return spikes_at_tick(s,pn,s->tick_count,x0q,x1q,tipyq);
}
void rider_wheel_centers_q(const RiderState *s, int32_t *lx, int32_t *ly,
                           int32_t *rx, int32_t *ry)
{
    int32_t si = rider_sin4096(s->angle), co = rider_sin4096(s->angle+1024);
    int32_t dx = co*12, dy = si*12;
    *lx = s->x-dx; *ly=s->y-dy;
    *rx = s->x+dx; *ry=s->y+dy;
}

void rider_restart(RiderState *s)
{
    uint32_t saved_best = (uint32_t)s->best;
    int32_t saved_diamonds = s->diamonds;
    uint32_t seed = s->random_state ^ 0x9e3779b9u;
    rider_init(s, seed);
    s->best = (int32_t)saved_best;
    s->diamonds = saved_diamonds;
}

void rider_init(RiderState *s, uint32_t seed)
{
    memset(s, 0, sizeof(*s));
    s->random_state = seed ? seed : 0xd88ec19bu;
    s->theme=0u; /* fixed classic blue world / pink rail */
    for (uint32_t i=0; i<RIDER_TRACK_SLOTS; ++i) append_piece(s);
    s->x = 70*RIDER_Q;
    s->y = 161*RIDER_Q;
    s->camera_x = -70*RIDER_Q;
    s->camera_y = -30*RIDER_Q;
    s->phase=RIDER_READY;
    s->grounded=1;
}

static void add_score(RiderState *s,uint16_t n)
{
    if(s->score>INT32_MAX-(int32_t)n)s->score=INT32_MAX;
    else s->score+=n;
    if(s->score>s->best)s->best=s->score;
}
static void commit_pending(RiderState *s)
{
    if (s->pending_ticks) {
        --s->pending_ticks;
        if (!s->pending_ticks) {
            add_score(s,s->pending_score);
            if(s->score>s->best) s->best=s->score;
            s->pending_score=0;
        }
    }
}

static void crash(RiderState *s)
{
    s->phase=RIDER_CRASHED;
    if(s->pending_ticks){add_score(s,s->pending_score);if(s->score>s->best)s->best=s->score;}
    s->pending_score=0;
    s->pending_ticks=0;
}

static void maybe_collect_gem(RiderState *s, uint32_t piece_number)
{
    RiderPiece *p=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(p->number!=piece_number || !(p->flags&PIECE_FLAG_GEM))return;
    /* One collision per gem, so a U-shaped cluster awards three diamonds. */
    for(uint8_t j=0;j<3u;++j){
        int32_t gx,gy;
        if(!rider_piece_gem_q(s,piece_number,j,&gx,&gy))continue;
        if(s->x-gx> -13*RIDER_Q && s->x-gx<13*RIDER_Q &&
           s->y-gy> -20*RIDER_Q && s->y-gy<20*RIDER_Q){
            p->gem_mask&=(uint8_t)~(1u<<j);
            if(s->diamonds<INT32_MAX)++s->diamonds;
        }
    }
    if(!p->gem_mask)p->flags&=(uint8_t)~PIECE_FLAG_GEM;
}

/* Continuous segment versus circle in the obstacle's relative frame.
 * Bounding-box rejection is cheap on the MCU; the division runs only when
 * the segment can meet the circle. Coordinates reduced to Q4 with a one-Q4
 * conservative margin, avoiding overflow and 64-bit arithmetic in the hot path. */
bool rider_swept_circle_q(int32_t ax,int32_t ay,int32_t bx,int32_t by,int32_t rr)
{
    if(rr<=0 || rr>64*RIDER_Q)return false;
    if((ax< -rr&&bx< -rr)||(ax>rr&&bx>rr)||(ay< -rr&&by< -rr)||(ay>rr&&by>rr))return false;
    /* Callers supply near-piece coordinates and per-tick displacement < 32 px.
     * Clip the public helper's extreme inputs conservatively to avoid UB. */
    if(ax< -128*RIDER_Q || ax>128*RIDER_Q || ay< -128*RIDER_Q || ay>128*RIDER_Q || bx< -128*RIDER_Q || bx>128*RIDER_Q || by< -128*RIDER_Q || by>128*RIDER_Q)return false;
    ax/=16;ay/=16;bx/=16;by/=16;rr=(rr+15)/16+1;
    int32_t dx=bx-ax,dy=by-ay, len2=dx*dx+dy*dy;
    int32_t dot=-(ax*dx+ay*dy);
    if(dot>=len2){ax=bx;ay=by;}
    else if(dot>0){
        /* Q10 fraction: dot*1024 may exceed 32 bits for artificial inputs. */
        int32_t t=dot<=INT32_MAX/1024?dot*1024/len2:(int32_t)((int64_t)dot*1024/len2);
        ax+=dx*t/1024;ay+=dy*t/1024;
    }
    return ax*ax+ay*ay<=rr*rr;
}

/* Loop runs are deliberately guided: a small MCU cannot fit Box2D and the
 * original collision graph alongside Rad Pro. The path itself is a true
 * overlapping loop, not a fake x-height hill. This is NOT rigid-body parity. */
static void maybe_collect_gem(RiderState *s,uint32_t piece_number);
static void step_loop(RiderState *s,bool held)
{
    uint32_t pn=s->loop_piece;
    const RiderPiece *gp=&s->track[pn%RIDER_TRACK_SLOTS];
    const uint8_t kind=(gp->number==pn)?gp->template_id:16u;
    int32_t xa0,ya0,xb0,yb0;
    uint16_t ta=s->loop_t>64u?s->loop_t-64u:0u;
    uint16_t tb=s->loop_t<4032u?s->loop_t+64u:4096u;
    if(!rider_track_special_q(s,pn,kind,ta,&xa0,&ya0) ||
       !rider_track_special_q(s,pn,kind,tb,&xb0,&yb0)){crash(s);return;}
    int32_t dx=xb0-xa0,dy=yb0-ya0;
    int32_t ax=dx<0?-dx:dx,ay=dy<0?-dy:dy;
    int32_t length=(ax>ay?ax:ay)+(ax>ay?ay:ax)*3/8;
    if(length<1)length=1;
    int32_t slope=dy*14/length;
    /* Signed velocity on the constrained rail. A released bike can coast,
     * stall, and roll back down an incline instead of dying on an arbitrary
     * minimum-speed threshold. Gravity retains its direction along the rail. */
    int32_t drag=clamp_i32(-s->vx,-5,5);
    int32_t travel=clamp_i32(s->vx+(held?18:drag)+slope,-2*RIDER_Q,4*RIDER_Q);
    /* Compact contact-loss criterion for the inverted portions of a
     * closed rail. The prior model glued even slow bikes to the ceiling.
     * Approximate v^2/R >= inward gravity using Q8 units, then release
     * into ballistic motion along the actual shared tangent. */
    if(dx<0 && (kind==45u||kind==16u||kind==47u||kind==52u||kind==65u||kind==75u)){
        int radius=kind==45u?43:kind==47u?32:(kind==75u?(s->loop_t<2048u?36:48):62);
        int32_t tangent=angle_from_vector(dx,dy);
        int32_t co=rider_sin4096(tangent+1024),si=rider_sin4096(tangent);
        if(co<0 && travel*travel<15*radius*(-co)){
            int32_t xx,yy;
            if(!rider_track_special_q(s,pn,kind,s->loop_t,&xx,&yy)){crash(s);return;}
            s->x=xx+si*5;s->y=yy-co*5;
            s->vx=travel*co/256;s->vy=travel*si/256;
            s->angle=tangent;s->takeoff_angle=tangent;s->angular_speed=0;
            s->looping=0;s->grounded=0;s->airborne_ticks=0;s->air_rotation=0;
            return;
        }
    }
    s->vx=travel;
    int32_t advance=travel*(int32_t)(tb-ta)/length;
    if(!advance && travel)advance=travel>0?1:-1;
    advance=clamp_i32(advance,-180,180);
    int32_t nt=(int32_t)s->loop_t+advance;
    if(nt<=0 && travel<0){
        /* The entrance leads back onto the approach rail. No teleport or
         * automatic score; normal ground contact takes over next step. */
        int32_t ex,ey;
        if(!rider_track_special_q(s,pn,kind,0,&ex,&ey)){crash(s);return;}
        int32_t a=angle_from_vector(dx,dy),sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
        s->x=ex+sn*5-1;s->y=ey-cs*5;s->angle=a;
        s->vx=travel*cs/256;s->vy=0;s->loop_t=0;s->looping=0;
        s->grounded=1;s->angular_speed=0;s->airborne_ticks=0;s->air_rotation=0;
        return;
    }
    if(nt>=RIDER_ANGLE_TURN) {
        s->loop_t=RIDER_ANGLE_TURN;
        s->looping=0;
        if(kind==45u||kind==54u||kind==46u||kind==27u){
            /* Open rails exit at the real path tangent and speed. */
            int32_t ex,ey,px,py;
            if(!rider_track_special_q(s,pn,kind,4096u,&ex,&ey) ||
               !rider_track_special_q(s,pn,kind,4032u,&px,&py)){crash(s);return;}
            int32_t a=angle_from_vector(ex-px,ey-py);
            int32_t sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
            s->x=ex+sn*5;s->y=ey-cs*5;
            s->vx=clamp_i32(travel*cs/256,0,4*RIDER_Q);
            s->vy=travel*sn/256;s->angle=a;s->takeoff_angle=a;s->grounded=0;
        }else{
            int32_t ex,ey;
            if(!rider_track_special_q(s,pn,kind,4096u,&ex,&ey)){crash(s);return;}
            s->x=ex;
            s->y=ey-5*RIDER_Q;
            s->angle=((kind==16u || kind==47u || kind==52u || kind==65u || kind==75u)?-RIDER_ANGLE_TURN:0);
            s->vy=0;
            s->grounded=1;
        }
        s->angular_speed=0;
        s->airborne_ticks=0;
        s->air_rotation=0;
        maybe_collect_gem(s,pn);
        return;
    }
    s->loop_t=(uint16_t)nt;
    int32_t xx,yy,xb,yb,xa,ya;
    rider_track_special_q(s,pn,kind,s->loop_t,&xx,&yy);
    rider_track_special_q(s,pn,kind,(uint16_t)(s->loop_t>8?s->loop_t-8:0),&xb,&yb);
    rider_track_special_q(s,pn,kind,(uint16_t)(s->loop_t<4088?s->loop_t+8:4096),&xa,&ya);
    int32_t tangent=angle_from_vector(xa-xb,ya-yb);
    int32_t si=rider_sin4096(tangent),co=rider_sin4096(tangent+1024);
    s->x=xx+si*5;
    s->y=yy-co*5;
    /* Continuous 0..4096 rotation around loop. */
    if(s->loop_t>RIDER_ANGLE_TURN/2 && tangent>0)tangent-=RIDER_ANGLE_TURN;
    s->angle=tangent;
    s->grounded=1;
    s->vy=0;
    s->angular_speed=0;
    maybe_collect_gem(s,pn);
}

/* Contact with the inside of a detached rail requires actual proximity,
 * compatible orientation and velocity along the rail. This is a compact
 * rail constraint, not an automatic pickup when crossing its x coordinate.
 * A coarse search followed by fine local refinement uses only stack scalars. */
static bool arch_contact(RiderState *s,uint32_t pn)
{
    const RiderPiece *p=&s->track[pn%RIDER_TRACK_SLOTS];
    if(p->number!=pn || p->template_id!=54u || s->grounded)return false;
    int32_t base=(int32_t)(pn*RIDER_PIECE_WIDTH)*RIDER_Q;
    if(s->x<base+68*RIDER_Q || s->x>base+192*RIDER_Q ||
       s->y>((int32_t)p->start_y-67)*RIDER_Q || s->y<((int32_t)p->start_y-172)*RIDER_Q)return false;
    uint16_t best=0;
    int32_t best_d=INT32_MAX,best_x=0,best_y=0,best_a=0;
    for(unsigned pass=0;pass<2u;++pass){
        unsigned begin=pass?(best>128u?best-128u:0u):0u;
        unsigned end=pass?(best<3968u?best+128u:4096u):4096u;
        unsigned step=pass?16u:128u;
        for(unsigned t=begin;t<=end;t+=step){
            int32_t x,y,ax,ay,bx,by;
            uint16_t ta=(uint16_t)(t>32u?t-32u:0u),tb=(uint16_t)(t<4064u?t+32u:4096u);
            if(!rider_track_special_q(s,pn,54u,(uint16_t)t,&x,&y) ||
               !rider_track_special_q(s,pn,54u,ta,&ax,&ay) ||
               !rider_track_special_q(s,pn,54u,tb,&bx,&by))continue;
            int32_t a=angle_from_vector(bx-ax,by-ay);
            x+=5*rider_sin4096(a);y-=5*rider_sin4096(a+1024);
            int32_t dx=(s->x-x)/16,dy=(s->y-y)/16;
            int32_t d=dx*dx+dy*dy;
            if(d<best_d){best_d=d;best=(uint16_t)t;best_x=x;best_y=y;best_a=a;}
        }
    }
    if(best_d>80*80 || best>3968u)return false; /* five world pixels, not a magnetic snap */
    int32_t speed=(s->vx*rider_sin4096(best_a+1024)+s->vy*rider_sin4096(best_a))/256;
    int32_t angle_error=((s->angle-best_a+2048)&4095)-2048;
    if(speed<2*RIDER_Q || angle_error< -720 || angle_error>720)return false;
    s->looping=1;s->loop_piece=pn;s->loop_t=best;s->x=best_x;s->y=best_y;
    s->vx=clamp_i32(speed,0,4*RIDER_Q);s->vy=0;s->angle=best_a;
    s->grounded=1;s->angular_speed=0;s->air_rotation=0;s->airborne_ticks=0;
    maybe_collect_gem(s,pn);
    return true;
}

static void update_camera(RiderState *s)
{
    int32_t tx=s->x-140*RIDER_Q;
    int32_t ty=s->y-190*RIDER_Q;
    /* Resist 1px snaps as the vehicle crosses changing slopes. */
    s->camera_x += clamp_i32((tx-s->camera_x)/5,-7*RIDER_Q,7*RIDER_Q);
    s->camera_y += clamp_i32((ty-s->camera_y)/10,-3*RIDER_Q,3*RIDER_Q);
}

static bool spike_hit(int32_t x,int32_t y,int32_t x0,int32_t x1,int32_t tip)
{
    return x>=x0 && x<=x1 && y<=tip+12*RIDER_Q &&
           y+5*RIDER_Q>=tip+rider_spike_profile_q(x-x0);
}
static bool spike_swept(int32_t ax,int32_t ay,int32_t bx,int32_t by,int32_t x0,int32_t x1,int32_t oldtip,int32_t tip)
{
    if((ax<x0&&bx<x0)||(ax>x1&&bx>x1))return false;
    for(int i=0;i<=4;i++){
        int32_t x=ax+(bx-ax)*i/4,y=ay+(by-ay)*i/4,t=oldtip+(tip-oldtip)*i/4;
        if(spike_hit(x,y,x0,x1,t))return true;
    }
    return false;
}
static void step_motion(RiderState *s, bool held)
{
    if (s->phase==RIDER_CRASHED) {
        if (s->crash_ticks<UINT16_MAX) ++s->crash_ticks;
        return;
    }
    if (s->phase==RIDER_READY) {
        if (!held) return;
        s->phase=RIDER_RUNNING;
    }
    s->throttle_active=held?1u:0u;
    commit_pending(s);
    ++s->tick_count;
    if(s->perfect_ticks) --s->perfect_ticks;
    if(s->boost_ticks) --s->boost_ticks;
    if(s->looping) {
        step_loop(s,held);
        update_camera(s);
        return;
    }
    const bool was_grounded=s->grounded!=0;
    const int32_t old_x=s->x;
    if(was_grounded && s->x>=0){
        uint32_t pn=(uint32_t)s->x/(256u*RIDER_Q);
        int32_t a,b,y,prev_y;
        for(unsigned j=0;j<2u;j++){
            if(!rider_platform_at_q(s,pn,j,&a,&b,&y)||s->x<a||s->x>b)continue;
            --s->tick_count;
            bool ok=rider_platform_at_q(s,pn,j,&a,&b,&prev_y);
            ++s->tick_count;
            if(ok && s->y>=prev_y-8*RIDER_Q && s->y<=prev_y+2*RIDER_Q){s->y+=y-prev_y;s->vy=0;}
            break;
        }
    }
    int32_t prev_lx,prev_ly,prev_rx,prev_ry;
    rider_wheel_centers_q(s,&prev_lx,&prev_ly,&prev_rx,&prev_ry);
    if(was_grounded) {
        int32_t ahead,behind,slope_drive=0;
        if(rider_surface_q(s,s->x+12*RIDER_Q,&ahead) &&
           rider_surface_q(s,s->x-12*RIDER_Q,&behind))
            slope_drive=clamp_i32((ahead-behind)/384,-12,12);
        const int32_t cap=s->boost_ticks?6*RIDER_Q:4*RIDER_Q;
        if(s->vx<0){
            int32_t delta=(held?16:6)+slope_drive;
            s->vx=clamp_i32(s->vx+delta,-2*RIDER_Q,cap);
        }else s->vx=clamp_i32(s->vx+(held?16:-6)+slope_drive,0,cap);
        s->angular_speed=0;
    } else {
        if(s->airborne_ticks<UINT16_MAX) ++s->airborne_ticks;
        s->vy=clamp_i32(s->vy+15,-7*RIDER_Q,8*RIDER_Q);
        /* The original one-button control should not spin the bike wildly
         * after a short accidental press. Accelerate rotation gradually. */
        if(held && s->airborne_ticks>=6) {
            /* About 365 deg/s maximum at 60 Hz, versus v0.9's >570.
             * The release decay is much stronger for precise landing. */
            s->angular_speed=clamp_i32(s->angular_speed+7,0,70);
        } else {
            s->angular_speed=(s->angular_speed*212)/256;
        }
        if(s->angle< -65536 || s->angle>65536)
            s->angle=(int32_t)(((uint32_t)s->angle+2048u)&4095u)-2048;
        s->angle-=s->angular_speed;
        s->air_rotation+=(uint32_t)s->angular_speed;
        if(s->air_rotation>16u*RIDER_ANGLE_TURN)s->air_rotation=16u*RIDER_ANGLE_TURN;
    }
    s->x+=s->vx;
    s->y+=s->vy;
    uint32_t piece_number=(uint32_t)(s->x/(RIDER_PIECE_WIDTH*RIDER_Q));
    if(piece_number+7>=s->next_piece)append_piece(s);

    /* Enter a closed loop only on the leading rail and at adequate speed. */
    const RiderPiece *piece=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(piece->number==piece_number && special_piece(piece->template_id) && piece->template_id!=54u && piece->template_id!=28u) {
        int32_t entrance=(int32_t)(piece_number*RIDER_PIECE_WIDTH+(piece->template_id==45u?34u:piece->template_id==75u?48u:((piece->template_id==16u||piece->template_id==47u||piece->template_id==52u||piece->template_id==65u)?68u:70u)))*RIDER_Q;
        if(old_x<entrance && s->x>=entrance && s->vx>2*RIDER_Q) {
            int32_t ex,ey;
            if(!rider_track_special_q(s,piece_number,piece->template_id,0,&ex,&ey)){crash(s);return;}
            int32_t near=s->y-(ey-5*RIDER_Q);
            int32_t facing=(int32_t)(((uint32_t)s->angle+2048u)&4095u)-2048;
            /* The front wheel can pass the seam before the centre does. A
             * recent, close, forward-facing contact is eligible; a remote
             * airborne vehicle or a stunt rotation must never be captured. */
            bool near_lip=(piece->template_id==45u||piece->template_id==16u||piece->template_id==46u||piece->template_id==47u||piece->template_id==52u||piece->template_id==65u||piece->template_id==75u) &&
                s->airborne_ticks<=6u && near>=-6*RIDER_Q && near<=3*RIDER_Q &&
                facing>=-400 && facing<=400 && s->air_rotation==0;
            if(was_grounded||near_lip){
            s->looping=1;
            s->loop_piece=piece_number;
            s->loop_t=0;
            s->x=ex;
            s->y=ey-5*RIDER_Q;
            s->angle=0;
            s->angular_speed=0;
            step_loop(s,held);
            update_camera(s);
            return;
            }
        }
    }
    if(!was_grounded && arch_contact(s,piece_number)){update_camera(s);return;}
    /* At the end of the first rising lip, preserve its tangent momentum.
     * The ordinary one-wheel support path used to zero vertical speed at
     * a missing centre rail, causing the bike to fall through the higher
     * landing even when it was launched at full speed. */
    if(was_grounded && (piece->template_id==40u||piece->template_id==55u || piece->template_id==59u || piece->template_id==76u || piece->template_id==78u || piece->template_id==80u || piece->template_id==81u)){
        int32_t here,old,back;
        if(!rider_surface_q(s,s->x,&here) && rider_surface_q(s,old_x,&old) &&
           rider_surface_q(s,old_x-8*RIDER_Q,&back)){
            s->vy=clamp_i32((old-back)*s->vx/(8*RIDER_Q),-3*RIDER_Q,2*RIDER_Q);
            s->y=old-5*RIDER_Q+s->vy;
            s->grounded=0;s->takeoff_angle=s->angle;s->air_rotation=0;
            s->angular_speed=0;s->airborne_ticks=0;
            maybe_collect_gem(s,piece_number);
            update_camera(s);return;
        }
    }
    int32_t yl=0,yr=0,xl,xr,wl,wr;
    rider_wheel_centers_q(s,&xl,&wl,&xr,&wr);
    bool left=rider_surface_q(s,xl,&yl),right=rider_surface_q(s,xr,&yr);
    int32_t dl=left?wl+5*RIDER_Q-yl:INT32_MIN/4;
    int32_t dr=right?wr+5*RIDER_Q-yr:INT32_MIN/4;
    /* Independent wheel-contact probes: a wheel well above the rail is not
     * a supporting contact merely because its x coordinate has a surface.
     * This avoids snapping the whole bike to a remote slope when only one
     * wheel is actually on the ground. */
    bool l_support=left && dl>=-RIDER_Q && dl<=9*RIDER_Q;
    bool r_support=right && dr>=-RIDER_Q && dr<=9*RIDER_Q;
    /* Swept vertical crossing: a fast fall can travel farther than the
     * nine-pixel static support window in one tick. Test the old wheel
     * against its old rail, and the new wheel against the new rail. */
    if(!was_grounded){
        int32_t py;
        if(left && dl>=0 && rider_surface_q(s,prev_lx,&py) && prev_ly+5*RIDER_Q<=py)l_support=true;
        if(right && dr>=0 && rider_surface_q(s,prev_rx,&py) && prev_ry+5*RIDER_Q<=py)r_support=true;
    }
    bool contact=l_support||r_support;
    if(!was_grounded && !contact && rider_sin4096(s->angle+1024)<-96){
        int32_t roof_x=s->x+8*rider_sin4096(s->angle),roof_y=s->y-8*rider_sin4096(s->angle+1024),rail;
        if(rider_surface_q(s,roof_x,&rail) && roof_y>=rail && roof_y<=rail+12*RIDER_Q && s->vy>0){crash(s);return;}
    }
    /* A badly penetrated wheel is still rescued if the bike was already
     * grounded, rather than tunnelling through the rail on a long frame. */
    if(was_grounded && !contact){
        contact=(left&&dl>=0)||(right&&dr>=0);
        int32_t cy,oy;
        /* A continuous descending rail must not be mistaken for a gap
         * because both wheels briefly sit above its next contact point.
         * Preserve contact only when the old centre was actually near the
         * rail and the next centre stays on the same continuous surface. */
        if(!contact && rider_surface_q(s,old_x,&oy) && rider_surface_q(s,s->x,&cy) &&
           cy-oy<8*RIDER_Q && oy-cy<8*RIDER_Q && s->y-s->vy>=oy-10*RIDER_Q && s->y-s->vy<=oy+2*RIDER_Q)
            contact=true;
    }
    /* At a genuinely convex launch lip, keep momentum and leave the
     * rail instead of following the falling slope. Flat terrain and
     * tiny bumps never activate this. */
    if(was_grounded && contact && s->vx>2*RIDER_Q){
        int32_t before,here,after;
        if(rider_surface_q(s,s->x-20*RIDER_Q,&before) &&
           rider_surface_q(s,s->x,&here) &&
           rider_surface_q(s,s->x+20*RIDER_Q,&after) &&
           here-before< -5*RIDER_Q && after-here>5*RIDER_Q){
            s->grounded=0;
            s->vy=clamp_i32((here-before)/4,-3*RIDER_Q,-2*RIDER_Q);
            s->air_rotation=0;
            s->angular_speed=0;
            s->airborne_ticks=0;
            s->takeoff_angle=s->angle;
            maybe_collect_gem(s,piece_number);
            update_camera(s);
            return;
        }
    }
    /* Landing is descending relative to the rail, not necessarily relative
     * to the world. A bike can meet a rising landing while still moving up. */
    bool approaching=s->vy>=0;
    if(!was_grounded && !approaching && s->airborne_ticks>2u && contact){
        int32_t a,b;
        if(rider_surface_q(s,s->x,&a) && rider_surface_q(s,s->x+8*RIDER_Q,&b))
            approaching=s->vy >= (b-a)*s->vx/(8*RIDER_Q);
    }
    if(contact && (was_grounded || approaching)) {
        /* Ground angle must not collapse to zero merely because only one
         * wheel is inside the narrow impact-contact window. */
        int32_t tangent=0;
        if(was_grounded){
            int32_t lo,hi;
            if(rider_surface_q(s,s->x-9*RIDER_Q,&lo)&&rider_surface_q(s,s->x+9*RIDER_Q,&hi)&&hi-lo<35*RIDER_Q&&lo-hi<35*RIDER_Q)
                tangent=clamp_i32(angle_from_vector(18*RIDER_Q,hi-lo),-700,700);
            else if(l_support||r_support){
                int32_t at=l_support?xl:xr;
                if(rider_surface_q(s,at-2*RIDER_Q,&lo)&&rider_surface_q(s,at+2*RIDER_Q,&hi))
                    tangent=clamp_i32(angle_from_vector(4*RIDER_Q,hi-lo),-700,700);
                else tangent=(int32_t)(((uint32_t)s->angle+2048u)&4095u)-2048;
            }
        } else if(l_support&&r_support) {
            int32_t difference=yr-yl;
            tangent=clamp_i32((difference*652)/(24*RIDER_Q),-390,390);
        } else if(l_support||r_support) {
            int32_t at=l_support?xl:xr,lo,hi;
            if(rider_surface_q(s,at-2*RIDER_Q,&lo)&&rider_surface_q(s,at+2*RIDER_Q,&hi))
                tangent=clamp_i32(angle_from_vector(4*RIDER_Q,hi-lo),-390,390);
        }
        int32_t phase=((s->angle-tangent+2048)&4095)-2048;
        int32_t impact= s->vy;
        /* Small slopes don't kill the car. Serious upside-down impact does. */
        if((!was_grounded && s->airborne_ticks>=8u && (phase>1000||phase<-1000)) ||
           (phase>1580||phase<-1580) ||
           ((phase>1380||phase<-1380)&&impact>4*RIDER_Q)) {
            crash(s); return;
        }
        if(!was_grounded) {
            /* The original's firstFlipDegreesAmount is 270 degrees, not
             * our older 349-degree threshold. Further full turns each count. */
            uint32_t n=s->air_rotation>=3072u ?
               1u+(s->air_rotation-3072u)/RIDER_ANGLE_TURN:0u;
            if(n>8)n=8;
            if(n) {
                if(s->pending_ticks) {
                    add_score(s,s->pending_score);
                    if(s->score>s->best)s->best=s->score;
                    s->pending_score=0;
                }
                s->flips_landed=UINT32_MAX-s->flips_landed<n?UINT32_MAX:s->flips_landed+n;
                bool perfect=l_support&&r_support && dl-dr<2*RIDER_Q && dr-dl<2*RIDER_Q && phase<128 && phase>-128;
                s->pending_score=(uint16_t)(n*(perfect?2u:1u));
                s->pending_ticks=30;
                s->perfect_ticks=perfect?48:0;
                if(perfect){s->boost_ticks=18;s->vx=clamp_i32(s->vx+RIDER_Q/2,0,5*RIDER_Q);}
            }
        }
        int32_t lp=(was_grounded?left:l_support)?dl:INT32_MIN/4;
        int32_t rp=(was_grounded?right:r_support)?dr:INT32_MIN/4;
        int32_t penetration=lp>rp?lp:rp;
        if(penetration>0)s->y-=penetration;
        if(was_grounded){
            int32_t road_y;
            if(rider_surface_q(s,s->x,&road_y)){
                /* Wheel orientation must not turn positional correction into
                 * a fake jump. Project to the road while already grounded;
                 * intentional cliffs and missing rail still release it. */
                s->y=road_y-5*RIDER_Q;
            }
        }
        /* Never convert a ground-position correction into an upward kick. */
        /* A ground projection is not a bounce impulse. Retain only a
         * bounded upward takeoff velocity on an actual rising ramp. */
        if(!was_grounded) s->vy=0;
        else if(left && right && yr-yl<32*RIDER_Q && yl-yr<32*RIDER_Q) {
            /* Launch velocity follows the *road tangent*, not the amount of
             * penetration resolved this frame. Thus no phantom bounce. */
            int64_t motion=(int64_t)(yr-yl)*s->vx/(24*RIDER_Q);
            s->vy=clamp_i32((int32_t)motion,-3*RIDER_Q,2*RIDER_Q);
        } else s->vy=0;
        int32_t nearest=(s->angle & ~4095)+tangent;
        if(nearest-s->angle>2048)nearest-=4096;
        if(s->angle-nearest>2048)nearest+=4096;
        int32_t d=nearest-s->angle;
        /* While grounded there is no angular input: wheel suspension aligns
         * the bike gently with the road. This prevents phantom tip-overs. */
        if(was_grounded) {
            /* A bump cannot accumulate a rollover while in grounded mode. */
            s->angle+=clamp_i32(d*3/4,-220,220);
            /* Resolve the oriented wheelbase, not the old flat chassis.
             * On continuous rail the vertical circle clearance grows with
             * slope. Clamp to avoid attaching across a gap or ledge. */
            int32_t cx_y,al,ar,wx0,wy0,wx1,wy1;
            if(rider_surface_q(s,s->x,&cx_y)){
                rider_wheel_centers_q(s,&wx0,&wy0,&wx1,&wy1);
                if(rider_surface_q(s,wx0,&al)&&rider_surface_q(s,wx1,&ar)&&ar-al<32*RIDER_Q&&al-ar<32*RIDER_Q){
                    int32_t c=rider_sin4096(s->angle+1024);
                    if(c>=128){
                        int32_t clearance=5*RIDER_Q*256/c;
                        int32_t y0=al-(wy0-s->y)-clearance,y1=ar-(wy1-s->y)-clearance;
                        int32_t target=y0<y1?y0:y1;
                        s->y=clamp_i32(target,cx_y-8*RIDER_Q,cx_y-4*RIDER_Q);
                    }
                }
            }
        } else s->angle+=clamp_i32(d/3,-75,75);
        s->grounded=1;
        s->airborne_ticks=0;
        s->air_rotation=0;
    } else {
        if(was_grounded) {
            s->takeoff_angle=s->angle;
            s->air_rotation=0;
            s->airborne_ticks=0;
        }
        s->grounded=0;
    }
    /* Boost pads only trigger with the bike in ground contact and along the
     * underlying curved surface. They provide an obvious temporary effect. */
    if(s->grounded) {
        int32_t bx0,bx1,by;
        if(rider_piece_boost_q(s,piece_number,&bx0,&bx1,&by) &&
           s->x>=bx0 && s->x<=bx1) {
            if(s->boost_ticks<5)s->vx=clamp_i32(s->vx+125,0,6*RIDER_Q);
            s->boost_ticks=26;
        }
    }
    update_camera(s);
    if(s->x>INT32_MAX-150000 || s->y>410*RIDER_Q) crash(s);
}

/* Every movement path, including guided/open rails and gap-launch early
 * returns, now shares hazards, collectibles, distance score and world bounds. */
void rider_step(RiderState *s,bool held)
{
    if(s->paused)return;
    if(s->phase==RIDER_RUNNING && (s->x<0 || s->x>24990*256*RIDER_Q || s->y>410*RIDER_Q)){crash(s);return;}
    int32_t old_x=s->x,old_y=s->y;
    int32_t old_lx,old_ly,old_rx,old_ry;
    rider_wheel_centers_q(s,&old_lx,&old_ly,&old_rx,&old_ry);
    step_motion(s,held);
    if(s->phase!=RIDER_RUNNING)return;
    if(s->x<0 || s->x>24990*256*RIDER_Q || s->y>410*RIDER_Q){crash(s);return;}
    uint32_t piece_number=(uint32_t)s->x/(256u*RIDER_Q);
    for(unsigned i=0;i<RIDER_TRACK_SLOTS;i++){
        RiderPiece *p=&s->track[i];
        if((p->template_id==58u||p->template_id==70u) && (p->flags&PIECE_FLAG_FALLING) && (uint16_t)((uint16_t)s->tick_count-p->fall_tick)>80u)
            p->flags|=0x40u; /* permanently spent or raised, even after tick wrap */
    }
    RiderPiece *p=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(s->grounded && p->number==piece_number && (p->template_id==58u||p->template_id==70u) && !(p->flags&PIECE_FLAG_FALLING)){
        int32_t a,b,y;
        if(rider_platform_q(s,piece_number,&a,&b,&y) && s->x>=a && s->x<=b && s->y>=y-8*RIDER_Q && s->y<=y+2*RIDER_Q){p->flags|=PIECE_FLAG_FALLING;p->fall_tick=(uint16_t)s->tick_count;}
    }
    /* Recalculate wheel positions AFTER penetration correction. */
    int32_t xl,wl,xr,wr;
    rider_wheel_centers_q(s,&xl,&wl,&xr,&wr);
    for(uint32_t pn=piece_number?piece_number-1u:0u;pn<=piece_number+1u;++pn) {
        int32_t cx,cy,r;
        if(rider_piece_ring_q(s,pn,&cx,&cy) &&
           (ring_swept(old_x-cx,old_y-cy,s->x-cx,s->y-cy,s->tick_count,4)||
            ring_swept(old_lx-cx,old_ly-cy,xl-cx,wl-cy,s->tick_count,3)||
            ring_swept(old_rx-cx,old_ry-cy,xr-cx,wr-cy,s->tick_count,3))){crash(s);return;}
        for(unsigned j=0;j<2u;j++){
            if(!rider_piece_saw_at_q(s,pn,j,&cx,&cy,&r))break;
            int32_t pcx=cx,pcy=cy,pr;
            if(!saw_at_tick(s,pn,j,s->tick_count-1u,&pcx,&pcy,&pr)){pcx=cx;pcy=cy;}
            if(rider_swept_circle_q(old_x-pcx,old_y-pcy,s->x-cx,s->y-cy,r+6*RIDER_Q) ||
               rider_swept_circle_q(old_lx-pcx,old_ly-pcy,xl-cx,wl-cy,r+4*RIDER_Q) ||
               rider_swept_circle_q(old_rx-pcx,old_ry-pcy,xr-cx,wr-cy,r+4*RIDER_Q)) {crash(s);return;}
        }
    }
    for(uint32_t pn=piece_number?piece_number-1u:0u;pn<=piece_number+1u;++pn){
        int32_t x0,x1,tip;
        if(!rider_piece_spikes_q(s,pn,&x0,&x1,&tip))continue;
        /* The spikes sit below the normal rail, within intentional gaps. */
        int32_t a,b,oldtip;
        if(!spikes_at_tick(s,pn,s->tick_count-1u,&a,&b,&oldtip))oldtip=tip;
        if(spike_swept(old_x,old_y,s->x,s->y,x0,x1,oldtip,tip) ||
           spike_swept(old_lx,old_ly,xl,wl,x0,x1,oldtip,tip) ||
           spike_swept(old_rx,old_ry,xr,wr,x0,x1,oldtip,tip)){crash(s);return;}
    }
    for(uint32_t pn=piece_number?piece_number-1u:0u;pn<=piece_number+1u;++pn)
        if(pn<s->next_piece)maybe_collect_gem(s,pn);

    /* Only completed authored sections score, not empty approach chunks.
     * A crossing in flight remains pending until a safe grounded exit.
     * Per-piece flags prevent double scoring on backtracking. */
    uint32_t old_piece=(uint32_t)old_x/(256u*RIDER_Q);
    if(piece_number>old_piece && !s->looping && old_piece>0u){
        RiderPiece *done=&s->track[old_piece%RIDER_TRACK_SLOTS];
        if(done->number==old_piece && !(done->flags&PIECE_FLAG_CLEARED)){
            if(done->template_id==0u || done->template_id==35u || done->template_id==42u || done->template_id==44u)
                done->flags|=PIECE_FLAG_CLEARED;
            else done->flags|=PIECE_FLAG_AWAIT_LANDING;
        }
    }
    if(s->grounded && !s->looping){
        /* Commit any preceding pending exits still in the fixed track window. */
        for(unsigned lag=1;lag<RIDER_TRACK_SLOTS && lag<=piece_number;lag++){
            uint32_t pn=piece_number-lag;
            RiderPiece *done=&s->track[pn%RIDER_TRACK_SLOTS];
            if(done->number==pn && (done->flags&PIECE_FLAG_AWAIT_LANDING)){
                done->flags=(uint8_t)((done->flags&~PIECE_FLAG_AWAIT_LANDING)|PIECE_FLAG_CLEARED);
                add_score(s,1);
            }
        }
    }
}

uint32_t rider_hash(const RiderState *s)
{
    uint32_t x=2166136261u;
#define HASH(v) do { x^=(uint32_t)(v); x*=16777619u; } while(0)
    HASH(s->flips_landed); HASH(s->random_state); HASH(s->next_piece); HASH(s->x); HASH(s->y);
    HASH(s->vx);HASH(s->vy);HASH(s->angle);HASH(s->phase);HASH(s->score);HASH(s->tick_count);HASH(s->air_rotation);HASH(s->loop_t);HASH(s->looping);HASH(s->boost_ticks); HASH(s->throttle_active); HASH(s->theme);
    for (uint32_t i=0;i<RIDER_TRACK_SLOTS;i++) {
        HASH(s->track[i].number);HASH(s->track[i].start_y);HASH(s->track[i].template_id);HASH(s->track[i].flags);HASH(s->track[i].gem_mask); HASH(s->track[i].fall_tick);
    }
#undef HASH
    return x;
}
