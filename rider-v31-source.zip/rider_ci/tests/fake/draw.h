#ifndef RIDER_TEST_DRAW_H
#define RIDER_TEST_DRAW_H
#include <stdint.h>
typedef struct { int16_t x,y,width,height; } mr_rectangle_t;
void drawImage(const mr_rectangle_t *area, const uint16_t *pixels);
#endif
