/* Tests of new geometry and collision changes; tests never flash hardware. */
#include "../src/rider_render.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
static uint16_t frame[320*240];
static void capture(int top,int rows,const uint16_t *p,void *ctx){(void)ctx;memcpy(frame+top*320,p,(size_t)rows*320*sizeof(*p));}
static unsigned reds(int x0,int x1,int y0,int y1){unsigned n=0;for(int y=y0;y<y1;y++)for(int x=x0;x<x1;x++){unsigned p=frame[y*320+x];if((p>>11)>=28&&((p>>5)&63)<34&&(p&31)<16)++n;}return n;}
static void sweep(void){
    int q=RIDER_Q;
    assert(rider_swept_circle_q(-10*q,4*q,30*q,4*q,5*q)); /* endpoints and midpoint all miss */
    assert(!rider_swept_circle_q(-10*q,6*q,30*q,6*q,5*q));
    assert(rider_swept_circle_q(0,0,0,0,5*q));
    assert(!rider_swept_circle_q(6*q,0,6*q,0,5*q));
    assert(!rider_swept_circle_q(INT32_MIN,0,INT32_MAX,0,INT32_MIN));
    puts("v1.8 swept relative circle: off-midpoint contact, miss, stationary, invalid radius PASS");
}
static void timed(void){
    RiderState s;rider_init(&s,1);s.track[0].template_id=76;s.track[0].flags=8|1;s.track[0].gem_mask=7;
    int32_t a,b,y0,y1,y2,gx,gy;
    s.tick_count=10;assert(!rider_piece_spikes_q(&s,0,&a,&b,&y0));
    s.tick_count=52;assert(rider_piece_spikes_q(&s,0,&a,&b,&y0));
    s.tick_count=80;assert(rider_piece_spikes_q(&s,0,&a,&b,&y1));assert(y0-y1==15*RIDER_Q);
    s.tick_count=124;assert(rider_piece_spikes_q(&s,0,&a,&b,&y2)&&y2==y0);
    s.tick_count=80;assert(!rider_surface_q(&s,138*RIDER_Q,&y2));
    for(unsigned i=0;i<3;i++)assert(rider_piece_gem_q(&s,0,i,&gx,&gy)&&gx>a&&gx<b&&gy<y1);
    s.camera_x=0;s.camera_y=0;s.x=10*RIDER_Q;s.y=161*RIDER_Q;
    rider_render(&s,NULL,0,capture,NULL);unsigned active=reds(78,106,110,160);assert(active>35);
    s.tick_count=10;rider_render(&s,NULL,0,capture,NULL);assert(reds(78,106,110,160)==0);
    s.tick_count=79;s.phase=RIDER_RUNNING;s.grounded=0;s.x=135*RIDER_Q;s.y=y1+RIDER_Q;s.vx=s.vy=0;rider_step(&s,false);assert(s.phase==RIDER_CRASHED);
    puts("v1.8 retract/extend timing, lethal extended spikes, no red pixels retracted, actual gap and gems PASS");
}
static void roof(void){
    RiderState s;rider_init(&s,1);s.phase=RIDER_RUNNING;s.grounded=0;s.x=70*RIDER_Q;s.y=157*RIDER_Q;s.vx=0;s.vy=RIDER_Q;s.angle=2048;
    rider_step(&s,false);assert(s.phase==RIDER_CRASHED);
    puts("v1.8 inverted roof-first collision PASS");
}
static void routes(void){
    unsigned seen[RIDER_TEMPLATE_COUNT]={0},exit[RIDER_TEMPLATE_COUNT]={0},crashes[RIDER_TEMPLATE_COUNT]={0},reached=0;
    for(unsigned seed=1;seed<=500;seed++){
        RiderState s;rider_init(&s,seed);unsigned old=0,k=0;bool got=false;
        for(unsigned t=0;t<10500;t++){
            rider_step(&s,s.grounded);unsigned pn=(unsigned)s.x/65536u;
            if(pn!=old){if(pn>old)exit[k]++;old=pn;k=s.track[pn%RIDER_TRACK_SLOTS].template_id;assert(k<RIDER_TEMPLATE_COUNT);seen[k]++;}
            if(s.phase==RIDER_CRASHED){crashes[k]++;break;}
            if(pn>=35u&&!got){got=true;reached++;}if(pn>=130)break;
        }
    }
    printf("v1.8 beginner route: %u/500 reached piece 35\n",reached);assert(reached==500u);
    for(unsigned k=76;k<80;k++){printf("v1.8 template %u: seen=%u exits=%u crashes=%u\n",k,seen[k],exit[k],crashes[k]);assert(seen[k]>=100&&exit[k]*100u>=seen[k]*90u);}
}
int main(void){sweep();timed();roof();routes();return 0;}
