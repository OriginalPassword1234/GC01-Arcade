#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-gcc}
flags=(-std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -no-pie)
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 ASAN_OPTIONS=detect_leaks=1
"$cc" "${flags[@]}" tests/test_v31.c -o "$work/test"
"$work/test"
for t in test_ram_v30 test_render_many_v30 test_pause_hud_v30; do
  "$cc" "${flags[@]}" src/rider_core.c src/rider_render.c "tests/$t.c" -o "$work/test"
  "$work/test"
done
for t in test_strip_cache_v30 test_lcd_extended_v30; do
  "$cc" "${flags[@]}" -DGC01_RIDER -DRIDER_HOST_TEST -Isrc -Itests/fake src/rider_core.c src/rider_render.c rider_screen.c "tests/$t.c" -o "$work/test"
  "$work/test"
done
"$cc" "${flags[@]}" -DGC01_RIDER -DGC01 tests/flash_sim/extras/rider_saves.c tests/flash_sim/test_saves.c -o "$work/test"
"$work/test"
"$cc" "${flags[@]}" src/rider_core.c tests/test_terrain_delta.c -o "$work/test"
"$work/test"
CC="$cc" bash tests/run_unchanged_v31.sh
CC="$cc" bash tests/run_app_v31.sh
