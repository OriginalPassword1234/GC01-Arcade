/* v2.0: authored open curl, safe section scoring and release timing. */
#include "../src/rider_core.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static void geometry(void){
 RiderState s;rider_init(&s,1);assert(s.track[1].template_id==45);assert(s.track[5].template_id==40);assert(s.track[8].template_id==54);
 int32_t x0,y0,x1,y1,a,b;assert(rider_track_special_q(&s,1,45,0,&x0,&y0));assert(rider_track_special_q(&s,1,45,4096,&x1,&y1));
 assert(x1>x0&&y1<y0);assert(!rider_surface_q(&s,1*65536+105*RIDER_Q,&a));assert(rider_surface_q(&s,1*65536+145*RIDER_Q,&a)&&a>y1);
 assert(rider_track_special_q(&s,1,45,1023,&a,&b));assert(rider_track_special_q(&s,1,45,1024,&x0,&y0));assert(abs(a-x0)<RIDER_Q&&abs(b-y0)<RIDER_Q);
 assert(abs(x0-x1)>20*RIDER_Q);assert(!rider_surface_q(&s,5*65536+140*RIDER_Q,&a));
 unsigned guided=0,air=0;for(unsigned t=0;t<400;t++){rider_step(&s,s.grounded);assert(s.phase==RIDER_RUNNING);if(s.looping&&s.loop_piece==1)guided++;if(!s.grounded&&s.x/65536==1)air++;}
 assert(guided>30&&air>5);printf("v2.0 real open curl: %u guided steps, %u airborne steps, distinct lip and landing PASS\n",guided,air);
}
static void scoring(void){
 RiderState s;rider_init(&s,1);s.phase=RIDER_RUNNING;s.track[1].template_id=29;s.track[1].flags=0;s.track[2].template_id=0;s.track[2].flags=0;s.track[1].start_y=s.track[2].start_y=166;s.x=2*65536-2*RIDER_Q;s.y=138*RIDER_Q;s.vx=4*RIDER_Q;s.vy=0;s.grounded=0;s.angle=0;
 rider_step(&s,false);assert(s.phase==RIDER_RUNNING&&s.score==0&&(s.track[1].flags&0x80));
 for(int t=0;t<100&&s.score==0;t++)rider_step(&s,false);
 assert(s.phase==RIDER_RUNNING&&s.grounded&&s.score==1&&s.flips_landed==0&&(s.track[1].flags&0x20));
 s.x=2*65536-2*RIDER_Q;s.y=161*RIDER_Q;s.vx=4*RIDER_Q;s.vy=0;s.grounded=1;s.angle=0;rider_step(&s,true);assert(s.score==1);
 s.track[2].template_id=35;s.track[3].template_id=0;s.track[2].start_y=s.track[3].start_y=166;s.x=3*65536-2*RIDER_Q;s.y=161*RIDER_Q;s.vx=4*RIDER_Q;s.vy=0;s.grounded=1;s.angle=0;rider_step(&s,true);assert(s.score==1);
 puts("v2.0 section point only after safe landing; no repeat point or empty-road point PASS");
}
static void timing(void){
 unsigned continuous=0,controlled=0,reached=0;
 for(unsigned seed=1;seed<=500;seed++)for(unsigned mode=0;mode<2;mode++){
  RiderState s;rider_init(&s,seed);unsigned t;bool held=true;unsigned stable=0;
  for(t=0;t<3600;t++){
   if(mode){if(!s.grounded){held=false;stable=0;}else if(!held&&++stable>=6)held=true;}
   rider_step(&s,held);if(s.phase==RIDER_CRASHED)break;
  }
  if(t==3600){if(mode)controlled++;else continuous++;}if(mode&&s.x>=35*65536)reached++;
 }
 printf("v2.0 60s, hold-only %u/500, release and re-press %u/500; deliberate policy section35 %u/500\n",continuous,controlled,reached);
 assert(continuous<=50&&controlled>=350&&reached>=450);
}
int main(void){geometry();scoring();timing();return 0;}
