/* Desktop-only real-time preview; stream native RGB565, no fabricated states.
 * Usage: render_motion seed skip_ticks frames > video.rgb565le
 * ffmpeg -f rawvideo -pixel_format rgb565le -video_size 320x240 -framerate 60 -i video.rgb565le -c:v libx264 -pix_fmt yuv420p out.mp4
 */
#include "../src/rider_render.h"
#include <stdio.h>
#include <stdlib.h>
static void sink(int top,int rows,const uint16_t *p,void *ctx){(void)top;(void)ctx;for(int i=0;i<320*rows;i++){putchar(p[i]&255);putchar(p[i]>>8);}}
int main(int argc,char **argv){if(argc!=4)return 2;unsigned seed=(unsigned)strtoul(argv[1],0,10),skip=(unsigned)strtoul(argv[2],0,10),n=(unsigned)strtoul(argv[3],0,10);RiderState s,prev;rider_init(&s,seed);for(unsigned t=0;t<skip;t++){rider_step(&s,s.grounded);if(s.phase==RIDER_CRASHED)return 3;}
for(unsigned frame=0;frame<n;frame++){for(unsigned t=0;t<1;t++){prev=s;rider_step(&s,s.grounded);if(s.phase==RIDER_CRASHED)return 4;}rider_render(&s,&prev,0,sink,NULL);}return ferror(stdout)?5:0;}
