/* Actual procedural playthrough snapshots: no state or camera editing. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static FILE *out;
static void sink(int y,int rows,const uint16_t *p,void *ctx){(void)y;(void)ctx;for(int i=0;i<rows*320;i++){unsigned c=p[i];unsigned char rgb[]={((c>>11)&31)*255/31,((c>>5)&63)*255/63,(c&31)*255/31};assert(fwrite(rgb,1,3,out)==3);}}
int main(int argc,char **argv){
 if(argc!=3)return 2;
 const char *names[]={"jump","crest","arc","gap","saw","valley","wall","score","risegap","highgap","spikes","v","moving","falling","giantsaw","sawvalley","swave","zigzag","downhill","compound","bowl","perfect","ring","basin","climb","doublecrest","trough","lift","twosaws","twopads","longcrest","linkedbowls","doubleloop","timedspikes","bunnyhops","splitbowl","deepclimb","microloop","slopeup","slopedown","openloop","referencecurl","referencedrop","curlexit","triangle","detachedbowl"};
 unsigned count=sizeof(names)/sizeof(names[0]);unsigned mode=0;while(mode<count&&strcmp(argv[1],names[mode]))mode++;if(mode==count)return 2;
 for(unsigned seed=1;seed<=600;seed++){
  RiderState s,prev;rider_init(&s,seed);
  for(unsigned t=0;t<11000;t++){
   prev=s;rider_step(&s,s.grounded||((mode>=7&&mode<=11)&&s.flips_landed==0&&s.airborne_ticks<55u)||(mode==21&&s.airborne_ticks<35u+((seed+(unsigned)s.x/65536u*17u)%55u)));
   if(s.phase==RIDER_CRASHED)break;
   unsigned pn=(unsigned)s.x/(256*RIDER_Q),k=s.track[pn%12].template_id,l=(unsigned)(s.x/RIDER_Q)%256;
   int yes=0;
   switch(mode){
    case 0: yes=!s.grounded&&s.airborne_ticks>=25&&l>=40&&l<=210&&pn>=2&&pn<8;break;
    case 1: yes=s.looping&&k==52&&s.loop_t>1350&&s.loop_t<1700;break;
    case 2: yes=k==54&&l>=95&&l<=120;break;
    case 3: yes=k==53&&l>=135&&l<=160&&!s.grounded;break;
    case 4: yes=k==9&&l>=80&&l<=110;break;
    case 5: yes=(k==49||k==51)&&l>=100&&l<=125&&pn>12;break;
    case 6: yes=k==27&&s.looping&&s.loop_t>1400&&s.loop_t<2200;break;
    case 7: yes=s.flips_landed>=1&&s.grounded&&pn>=4&&l>=80&&l<=180;break;
    case 8: yes=k==55&&l>=118&&l<=145&&!s.grounded;break;
    case 9: yes=k==56&&l>=128&&l<=156&&!s.grounded;break;
    case 10: yes=k==13&&l>=90&&l<=125;break;
    case 11: yes=k==49&&l>=118&&l<=136;break;
    case 12: yes=k==57&&l>=110&&l<=140;break;
    case 13: yes=k==58&&l>=120&&l<=155&&(s.track[pn%12].flags&0x10)&&(uint16_t)((uint16_t)s.tick_count-s.track[pn%12].fall_tick)>=4;break;
    case 14: yes=k==59&&l>=115&&l<=150&&!s.grounded;break;
    case 15: yes=k==60&&l>=100&&l<=140;break;
    case 16: yes=k==61&&l>=100&&l<=140;break;
    case 17: yes=k==62&&l>=100&&l<=140;break;
    case 18: yes=k==63&&l>=100&&l<=140;break;
    case 19: yes=k==64&&l>=100&&l<=140;break;
    case 20: yes=k==28&&l>=100&&l<=150;break;
    case 21: yes=s.perfect_ticks>20&&s.grounded;break;
    case 22: yes=k==65&&s.looping&&s.loop_t>1100&&s.loop_t<1650;break;
    case 23: yes=k==66&&l>=100&&l<=140;break;
    case 24: yes=k==67&&l>=100&&l<=140;break;
    case 25: yes=k==68&&l>=100&&l<=140;break;
    case 26: yes=k==69&&l>=100&&l<=140;break;
    case 27: yes=k==70&&l>=115&&l<=155&&(s.track[pn%12].flags&0x10);break;
    case 28: if(k==71&&l>=45&&l<=125){int32_t x,y,r;yes=rider_piece_saw_at_q(&s,pn,0,&x,&y,&r)&&y-r-s.camera_y>=0&&y+r-s.camera_y<320*RIDER_Q&&rider_piece_saw_at_q(&s,pn,1,&x,&y,&r)&&y-r-s.camera_y>=0&&y+r-s.camera_y<320*RIDER_Q;}break;
    case 29: yes=k==72&&l>=85&&l<=108;break;
    case 30: yes=k==73&&l>=116&&l<=150;break;
    case 31: yes=k==74&&l>=105&&l<=145;break;
    case 32: yes=k==75&&s.looping&&s.loop_t>=2400&&s.loop_t<3000;break;
    case 33: {int32_t a,b,y;yes=k==76&&l>=95&&l<=148&&rider_piece_spikes_q(&s,pn,&a,&b,&y);break;}
    case 34: yes=k==77&&l>=80&&l<=150;break;
    case 35: yes=k==78&&l>=125&&l<=160&&!s.grounded;break;
    case 36: yes=k==79&&l>=100&&l<=150;break;
    case 37: yes=k==47&&s.looping&&s.loop_t>1100&&s.loop_t<1800;break;
    case 38: yes=s.grounded&&!s.looping&&s.angle < -350&&s.angle > -700&&pn>8;break;
    case 39: yes=s.grounded&&!s.looping&&s.angle > 350&&s.angle < 700&&pn>8;break;
    case 40: yes=k==46&&s.looping&&s.loop_t>900&&s.loop_t<2600;break;
    case 41: yes=k==45&&s.looping&&s.loop_t>1650&&s.loop_t<1950;break;
    case 42: yes=k==40&&!s.grounded&&l>126&&l<168;break;
    case 43: yes=k==45&&!s.looping&&!s.grounded&&l>100&&l<142;break;
    case 44: yes=k==80&&s.grounded&&l>=112&&l<=135;break;
    case 45: yes=k==81&&s.grounded&&l>=110&&l<=145;break;
   }
   if(!yes)continue;
   out=fopen(argv[2],"wb");assert(out);fprintf(out,"P6\n320 240\n255\n");rider_render(&s,&prev,255,sink,NULL);fclose(out);
   printf("%s seed=%u tick=%u piece=%u template=%u local=%u score=%d diamonds=%d guided=%u camera=(%d,%d)\n",argv[1],seed,t+1,pn,k,l,s.score,s.diamonds,s.looping,s.camera_x,s.camera_y);return 0;
  }
 }
 fprintf(stderr,"No live frame found for %s\n",argv[1]);return 1;
}
