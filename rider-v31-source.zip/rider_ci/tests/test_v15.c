/* Shared dynamic platforms, giant saws and actual generated route coverage. */
#include "../src/rider_core.h"
#include <assert.h>
#include <stdio.h>
static void platform(void){
 RiderState s;rider_init(&s,1);RiderPiece *p=&s.track[0];p->start_y=180;p->flags=0;p->template_id=57;
 int32_t a,b,y,z;assert(rider_platform_q(&s,0,&a,&b,&y));assert(a==98*RIDER_Q&&b==158*RIDER_Q);
 assert(!rider_surface_q(&s,90*RIDER_Q,&z));assert(rider_surface_q(&s,120*RIDER_Q,&z)&&z==y);
 s.tick_count=64;assert(rider_platform_q(&s,0,&a,&b,&z)&&z>y);
 p->template_id=58;s.tick_count=65530;assert(rider_platform_q(&s,0,&a,&b,&y));
 s.tick_count=65535;assert(rider_platform_q(&s,0,&a,&b,&z)&&z==y); /* untouched */
 p->flags=0x10;p->fall_tick=65530;s.tick_count=65540;
 assert(rider_platform_q(&s,0,&a,&b,&z)&&z==y+750);
 assert(rider_surface_q(&s,120*RIDER_Q,&y)&&y==z);
 s.tick_count=65611;assert(!rider_platform_q(&s,0,&a,&b,&z));
 s.phase=RIDER_RUNNING;rider_step(&s,true);assert(p->flags&0x40);
 s.tick_count=65530+65536;assert(!rider_platform_q(&s,0,&a,&b,&z));
 puts("v1.5 shared moving/falling rails: actual gaps, trigger age, wrap and permanent expiry PASS");
}
static void giant_saw(void){
 RiderState s;rider_init(&s,1);s.track[0].template_id=59;s.track[0].flags=2;s.track[0].start_y=170;
 int32_t cx,cy,r;assert(rider_piece_saw_q(&s,0,&cx,&cy,&r));assert(r>=25*RIDER_Q);
 s.phase=RIDER_RUNNING;s.x=cx;s.y=cy;s.grounded=0;s.vx=s.vy=0;
 rider_step(&s,false);assert(s.phase==RIDER_CRASHED);
 puts("v1.5 giant-saw airborne collision PASS");
}
static void generated(void){
 unsigned seen[RIDER_TEMPLATE_COUNT]={0},pass[RIDER_TEMPLATE_COUNT]={0},fail[RIDER_TEMPLATE_COUNT]={0},reached=0,fallen=0;
 for(unsigned seed=1;seed<=500;seed++){
  RiderState s;rider_init(&s,seed);unsigned prior=0,k=s.track[0].template_id;int got35=0;
  for(unsigned t=0;t<9000;t++){
   rider_step(&s,s.grounded);unsigned pn=(unsigned)s.x/(256u*RIDER_Q);
   if(pn!=prior){if(pn>prior&&k<RIDER_TEMPLATE_COUNT)pass[k]++;prior=pn;k=s.track[pn%12].template_id;assert(k<RIDER_TEMPLATE_COUNT);seen[k]++;}
   if(s.phase==RIDER_CRASHED){fail[k]++;break;}
   if(k==58&&(s.track[pn%12].flags&0x10))fallen++;
   if(pn>=35&&!got35){got35=1;reached++;}if(pn>=100)break;
  }
 }
 for(unsigned i=57;i<=64;i++){printf("v1.5 generated template %u: encounters=%u exits=%u crashes=%u\n",i,seen[i],pass[i],fail[i]);assert(seen[i]>=100&&pass[i]>=100);}
 assert(fallen>100&&reached>=495);printf("v1.5 reached piece 35: %u/500; falling-platform active ticks=%u PASS\n",reached,fallen);
}
int main(void){platform();giant_saw();generated();return 0;}
