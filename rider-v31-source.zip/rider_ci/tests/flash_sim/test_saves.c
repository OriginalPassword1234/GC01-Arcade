#include "extras/rider_saves.h"
#include "peripherals/flash.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static uint32_t erase_count, write_count;
static uint8_t memory[2048];
static unsigned truncated_write=0;
static int offset(uint32_t addr,uint32_t size)
{
    assert(addr>=RIDER_SAVES_BASE);
    uint32_t ofs=addr-RIDER_SAVES_BASE;
    assert(ofs<=sizeof(memory)&&size<=sizeof(memory)-ofs);
    return (int)ofs;
}
const uint8_t *readFlash(uint32_t addr,uint32_t bytes)
{
    return &memory[offset(addr,bytes)];
}
bool writeFlash(uint32_t addr,const uint8_t *bytes,uint32_t length)
{
    assert((addr%2u)==0 && (length%2u)==0);
    int ofs=offset(addr,length);
    if(truncated_write){
        /* Simulate power loss after a partial flash-program operation. */
        length=truncated_write;
        truncated_write=0;
        for(uint32_t j=0;j<length;j++) memory[ofs+j]&=bytes[j];
        return false;
    }
    for(uint32_t i=0;i<length;i++){
        assert((memory[ofs+i] & bytes[i])==bytes[i]);
        memory[ofs+i]&=bytes[i];
    }
    ++write_count;
    return true;
}
bool eraseFlash(uint32_t addr)
{
    int ofs=offset(addr,FLASH_PAGE_SIZE);
    assert((ofs%FLASH_PAGE_SIZE)==0);
    memset(&memory[ofs],0xff,FLASH_PAGE_SIZE);
    ++erase_count;
    return true;
}
int main(void)
{
    memset(memory,0xff,sizeof(memory));
    uint32_t best=123,diamond=123;
    assert(rider_saves_load(&best,&diamond));
    assert(best==0 && diamond==0);
    for(uint32_t seq=1;seq<=1000;seq++){
        assert(rider_saves_store(seq,seq*2));
        assert(rider_saves_load(&best,&diamond));
        assert(best==seq && diamond==seq*2);
    }
    unsigned before=write_count;
    assert(rider_saves_store(1000,2000));
    assert(before==write_count); /* no flash wear for unchanged saves */
    truncated_write=7;
    assert(!rider_saves_store(1001,2002));
    assert(rider_saves_load(&best,&diamond));
    assert(best==1000 && diamond==2000); /* old valid record survives */
    assert(rider_saves_store(1002,2004));
    assert(rider_saves_load(&best,&diamond));
    assert(best==1002 && diamond==2004);
    /* Corruption of newest commit should recover preceding valid record. */
    printf("PASS: 1000 append-only saves, interrupted write recovery, %u erases, %u writes\n",
           erase_count,write_count);
    return 0;
}
