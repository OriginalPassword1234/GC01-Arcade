#ifndef MOCK_GC01_FLASH_H
#define MOCK_GC01_FLASH_H
#include <stdbool.h>
#include <stdint.h>
#define FLASH_PAGE_SIZE 1024u
#define RIDER_SAVES_BASE 0x08017000u
const uint8_t *readFlash(uint32_t address,uint32_t bytes);
bool writeFlash(uint32_t address,const uint8_t *src,uint32_t bytes);
bool eraseFlash(uint32_t address);
#endif
