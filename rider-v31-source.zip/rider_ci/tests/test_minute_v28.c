#define main legacy_test_main
#include "test_datalog_v27.c"
#undef main
/* The real logger, not a model. Use cumulative counts to compare exact records. */
static void minute_mixed(void){
    enum {N=14000}; static uint32_t vals[N], totals[N+1];
    reset(DATALOG_LOGGINGMODE_1_MINUTE); totals[0]=pulses;
    for(unsigned i=0;i<N;i++){uint32_t x=random32();vals[i]=i%97==0?x:i%11==0?50000u+(x%12000):20+(x%20);totals[i+1]=totals[i]+vals[i];step(vals[i]);}
    assert(startDatalogRead());DatalogRecord r={0};unsigned n=0;
    while(readDatalog(&r)){assert(r.dose.time>=100&&(r.dose.time-100)%60==0);unsigned ix=(r.dose.time-100)/60;assert(ix<=N&&r.dose.pulseCount==totals[ix]);if(n) assert(ix==n); n=ix+1;}
    assert(n==N+1);printf("minute mixed: exact through %u intervals; %u erases\n",N,erases);
}
static void minute_ring(void){
    enum {N=85000}; reset(DATALOG_LOGGINGMODE_1_MINUTE);
    for(unsigned i=0;i<N;i++) step(20);
    assert(erases);assert(startDatalogRead()); DatalogRecord r={0};unsigned n=0,last=0;
    while(readDatalog(&r)){unsigned ix=(r.dose.time-100)/60;assert(r.dose.time==100+60*ix&&r.dose.pulseCount==0xfffffff0u+20u*ix);if(n)assert(ix==last+1);last=ix;++n;}
    assert(last==N&&n>62000);printf("minute ring: %u exact retained records; %u erases\n",n,erases);
}
static void minute_reboot(void){
    reset(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<11;i++)step(20);
    assert(datalog.write.minuteCount==3);unsigned off=datalog.write.pageOffset;
    memset(&datalog,0,sizeof datalog);initDatalog();assert(datalog.write.pageOffset==off);startDatalog();assert(datalog.write.pageBase==DATALOG_BASE);
    step(35);step(36);assert(startDatalogRead());DatalogRecord r={0};assert(readDatalog(&r)&&r.sessionStart&&r.dose.time==100);
    for(unsigned i=1;i<=8;i++){assert(readDatalog(&r)&&r.dose.time==100+60*i&&r.dose.pulseCount==0xfffffff0u+20u*i);}
    assert(readDatalog(&r)&&r.sessionStart&&r.dose.time==100+60*11&&r.dose.pulseCount==0xfffffff0u+20u*11);
    assert(readDatalog(&r)&&r.dose.pulseCount==0xfffffff0u+20u*11+35);assert(readDatalog(&r)&&r.dose.pulseCount==pulses);assert(!readDatalog(&r));
    puts("minute reboot: only three pending intervals lost; reuses page and restores session anchor");
}
static void minute_export(void){
    reset(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<8;i++)step(20);assert(startDatalogRead());
    for(unsigned i=0;i<8;i++){step(20);}assert(datalog.write.dose.time==now);
    DatalogRecord r={0};unsigned n=0;while(readDatalog(&r))n++;assert(n==17&&r.dose.pulseCount==pulses);puts("minute export: scheduled samples continue while reader active");
}
static void minute_crc_test(void){
    reset(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<2800;i++)step(20);assert(readPageState(DATALOG_BASE)==PAGESTATE_FULL);
    assert(getWord(flash+MINUTE_DATA_END)==minuteCRC(flash,MINUTE_DATA_END));
    flash[MINUTE_HEADER+1]^=1;assert(startDatalogRead());DatalogRecord r={0};assert(readDatalog(&r)&&r.dose.time>100);assert(r.dose.pulseCount==0xfffffff0u+20u*((r.dose.time-100)/60));puts("sealed page corruption rejected; next page anchor recovers");
}
static void minute_torn(void){
    reset(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<4;i++)step(20);unsigned off=datalog.write.pageOffset;
    /* Payload programmed, commit word left erased. */
    encodeFixedUInt32(flash+off+2,0x12345678u);memset(&datalog,0,sizeof datalog);initDatalog();startDatalog();assert(startDatalogRead());DatalogRecord r={0};assert(readDatalog(&r));for(unsigned i=0;i<4;i++)assert(readDatalog(&r)&&r.dose.time==160+60*i);assert(readDatalog(&r)&&r.sessionStart&&r.dose.time==now&&r.dose.pulseCount==pulses);assert(!readDatalog(&r));puts("torn minute escape: committed prefix survives, no invented sample");
}
static void minute_transitions(void){
    reset(DATALOG_LOGGINGMODE_1_SECOND);step(1);step(2);onDatalogModeMenuSelect(DATALOG_LOGGINGMODE_1_MINUTE);for(unsigned i=0;i<9;i++)step(20);onDatalogModeMenuSelect(DATALOG_LOGGINGMODE_10_SECONDS);step(7);step(8);stopDatalog();assert(startDatalogRead());DatalogRecord r={0};uint32_t prev=0;while(readDatalog(&r)){assert(r.dose.time>=prev);prev=r.dose.time;}assert(prev==now&&r.dose.pulseCount==pulses);puts("minute/second/10-second transitions and legacy decode pass");
}
int main(void){minute_mixed();minute_ring();minute_reboot();minute_export();minute_crc_test();minute_torn();minute_transitions();return 0;}
