#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-gcc}
mapfile -t names < <(grep -hE '^(bool|void|int16_t|int32_t|uint8_t|uint32_t) rider_[a-zA-Z0-9_]+\(' baseline_v30/src/*.h | sed -E 's/^[^ ]+ (rider_[a-zA-Z0-9_]+)\(.*/\1/' | sort -u)
rename=(); for n in "${names[@]}"; do rename+=("-D$n=base_$n"); done
flags=(-std=c11 -O2 -Wall -Wextra -Werror)
# Expected intentional rail-color change only. Never modify the stored baseline.
python3 - "$work/ref_render.c" <<'PY'
import re,sys
from pathlib import Path
p=r'static const uint16_t rail_palette\[32\]=\{[^}]+\};'
a=Path('baseline_v30/src/rider_render.c').read_text();b=Path('src/rider_render.c').read_text()
v=re.search(p,b);assert v
out,n=re.subn(p,lambda m:v[0],a);assert n==1
Path(sys.argv[1]).write_text(out)
PY
"$cc" "${flags[@]}" "${rename[@]}" -c baseline_v30/src/rider_core.c -o "$work/base_core.o"
"$cc" "${flags[@]}" "${rename[@]}" -Ibaseline_v30/src -c "$work/ref_render.c" -o "$work/base_render.o"
"$cc" "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_unchanged_v31.c "$work/base_core.o" "$work/base_render.o" -o "$work/test"
"$work/test"
