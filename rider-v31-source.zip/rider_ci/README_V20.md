# GC01 Rider v2.0 diagnostic candidate

Derived directly from v1.9. Do not flash: complete ARM firmware, expanded flash layout, Geiger counter functionality, USB recovery and physical frame rate are not validated.

## Reference mapping
- Supplied gameplay photo 70992 and App Store image https://is1-ssl.mzstatic.com/image/thumb/Purple114/v4/07/9c/53/079c533b-1a80-11df-eef5-9806f12d1054/pr_source.png/392x696bb.png : open curl rising from left, genuine opening with detached lower rail. New template 45, shared fixed-point curve for drawing, rail contact and collectible positions. Not extracted original game coordinates; dimensions tuned for this engine. The second independent loop visible in the source is not replicated exactly.
- Supplied photo 70980 and https://img.apponic.com/99/156/68182bd5ea61954772093612d8a75d4f.jpg : separated rise/drop, independent landing, uninterrupted dark gap. New template 40. Geometry is approximate.
- Supplied photo 71002: detached circular arc over crest, retained 54 and used early instead of generic closed loop. Legacy double loop 75 removed from ordinary generation but retained as explicit geometry fixture. Rare closed ring with rotating red barriers 65 retained; small 47 remains a fallback.
- https://seore.org/w/Rider (overview) documents +1 per track section, +1 per landed flip and double for perfect landings. https://writerparty.com/party/rider-ketchapp-tips-and-tricks-guide-hints-cheats-and-strategies/ documents press to accelerate and air rotation. https://www.levelwinner.com/rider-ketchapp-cheats-tips-tricks-get-super-high-score/ documents release on discontinuous paths. Exact original scoring spacing and landing tolerances unknown.

## Physics and score
- New curl has a cubic entry, circular rail with a 60-degree opening, physical release from the end to a lower landing; constrained contact still used on curl itself.
- Landing orientation tolerance for airborne >=8 ticks narrowed to ~88 degrees relative to the rail. This removes automatic rescue of very badly oriented vehicles, not an arbitrary timer or mandatory tap.
- Progression points still exist but connector pieces do not award them; crossing a section in air waits for a safe grounded exit, and flags prevent duplicate awards. Flip and perfect rewards preserved. Exact original point cadence is an approximation.
- Single palette, screen scheduling, Geiger integration, save journal and expanded layout unchanged. No extra static state. No claim of faster rendering or bug-free physics.

## Verification and reproduction
- `bash rider_ci/tests/run.sh` runs the full test suite. Earlier tests tied to retired generator opening IDs updated to reflect intentional changes; old double-loop geometry remains tested directly. The old full GCC sanitizer run locally timed out after v1.1 tests (those passed); later v1.2–v1.9 optimized tests passed. New v2.0 targeted test passed GCC and Clang ASan/UBSan.
- `test_v20.c` checks open geometry, actual airborne exit, safe section scoring and 500-seed 60s hold-vs-release comparison. Deliberate policy holds on ground, releases while airborne, waits six grounded ticks before re-pressing. It is a scripted control policy, not a human playtest. Ground-aware simpler policy reached section35 in 500/500 seeds.
- `render_timing.c` produces 320x252 RGB565 frames with a 12px external input indicator (green held, grey released, red crash), not part of device UI. Video uses two normal runs at 60 simulation ticks/s, seed 1, no state or camera injection.
