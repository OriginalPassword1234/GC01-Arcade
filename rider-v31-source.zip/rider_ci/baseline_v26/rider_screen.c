/* GC01 ST7789 update adapter. Bounded 3-row streaming with 2 horizontal
 * changed-region hashes per strip. All memory statically allocated.
 * The first pass hashes all tiles; when exactly one tile differs, compact
 * that rectangle in the renderer's mutable work strip and transfer only it.
 * When more tiles change, send the whole strip in ONE display transaction.
 * No heap, DMA reconfiguration, or changes to Rad Pro interrupt processing.
 */
#if defined(GC01_RIDER)
#include <stdint.h>
#include <string.h>
#include "rider_screen.h"
#include "rider_render.h"
#include "draw.h"

#define ROWS 3
#define WIDTH 320
#define HEIGHT 240
#define STRIPS (HEIGHT/ROWS)
#define TILES 2
static const uint16_t bounds[TILES+1]={0,160,320};
static uint32_t previous_hash[STRIPS][TILES]; /* 640 bytes, no framebuffer */
static uint8_t refresh_phase;
static uint8_t cache_valid;

void rider_screen_invalidate(void){cache_valid=0;refresh_phase=0;}

static uint32_t hash_tile(const uint16_t *p,uint16_t begin,uint16_t end)
{
    uint32_t h=2166136261u;
    for(int r=0;r<ROWS;r++)
        for(uint16_t x=begin;x<end;x++){
            uint16_t v=p[r*WIDTH+x];
            h=(h ^ v)*16777619u;
        }
    return h;
}
static void send_rows(int top,int rows,const uint16_t *p,void *unused)
{
    (void)unused;
    if(rows!=ROWS || top<0 || top+rows>HEIGHT || top%ROWS!=0)return;
    const unsigned slot=(unsigned)top/ROWS;
    uint32_t next[TILES];
    /* Rotate four forced strips every fourth draw. Even a 32-bit collision
     * cannot leave pixels stale indefinitely (80 completed draws maximum). */
    const int force=cache_valid && (refresh_phase%4u)==3u &&
        slot>=refresh_phase-3u && slot<=refresh_phase;
    int min_changed=TILES,max_changed=-1;
    for(int j=0;j<TILES;j++){
        next[j]=hash_tile(p,bounds[j],bounds[j+1]);
        if(!cache_valid || force || next[j]!=previous_hash[slot][j]){
            if(j<min_changed)min_changed=j;
            max_changed=j;
        }
    }
    if(max_changed<0)return;
    /* Send the smallest contiguous rectangle covering ALL changed tiles,
     * not an entire 320px strip whenever two adjacent tiles differ.
     * One LCD transaction is generally cheaper than many tiny fragments. */
    const uint16_t start=bounds[min_changed];
    const uint16_t width=bounds[max_changed+1]-start;
    if(width<WIDTH){
        uint16_t *mutable_strip=(uint16_t *)(void *)p;
        for(int r=0;r<ROWS;r++)
            memmove(mutable_strip+r*width,p+r*WIDTH+start,(size_t)width*sizeof(uint16_t));
        const mr_rectangle_t area={(int16_t)start,(int16_t)top,(int16_t)width,ROWS};
        drawImage(&area,mutable_strip);
    }else{
        const mr_rectangle_t area={0,(int16_t)top,WIDTH,ROWS};
        drawImage(&area,p);
    }
    for(int j=0;j<TILES;j++)previous_hash[slot][j]=next[j];
}
void rider_draw_gc01_snapshot(const RiderState *s,const RiderRenderPrevious *prev,uint8_t alpha)
{
    rider_render_snapshot(s,prev,alpha,send_rows,0);
    cache_valid=1;
    refresh_phase=(uint8_t)((refresh_phase+1u)%STRIPS);
}
#endif

#if defined(GC01_RIDER) && defined(RIDER_HOST_TEST)
void rider_draw_gc01(const RiderState *s,const RiderState *prev,uint8_t alpha)
{
    RiderRenderPrevious snapshot;
    if(prev)rider_capture_previous(&snapshot,prev);
    rider_draw_gc01_snapshot(s,prev?&snapshot:0,alpha);
}
#endif
