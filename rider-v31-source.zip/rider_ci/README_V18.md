# GC-01 Rider v1.8 — reference-inspired physics and renderer diagnostic candidate

Based on the exact supplied v1.7 archive. Fixed pink-violet rail and dark blue world; original Geiger integration, save journal, flash layout and firmware audit unchanged. **Not safe to flash without confirming bootloader, physical runtime and the inherited expanded flash partition layout.** No complete ARM firmware build or physical GC-01 was available locally. Two game translation units were separately compiled using Clang Cortex-M3 freestanding target and minimal header shims; this is not a firmware link. This is not a port of proprietary assets or an exact physics recreation.

## Reference research (2026-11-24)
- https://www.youtube.com/watch?v=5_yiVYxrcII — official 2017 trailer listing and publisher description.
- https://www.youtube.com/watch?v=ihvsoTtQ8XM — original 2017 gameplay recording listing.
- https://www.youtube.com/watch?v=5K9esdtiK9Q — additional gameplay URL; opening failed.
- https://writerparty.com/party/rider-ketchapp-tips-and-tricks-guide-hints-cheats-and-strategies/ — ground acceleration, backward air rotation, landed flip scoring.
- https://www.commonsensemedia.org/app-reviews/rider — roof/edge crashes and one-button control.
- https://www.speedrun.com/hi-IN/rider/guides/b2sk5 — round bunny hops, timed spikes and rotating platforms in level gameplay; this does not establish exact endless-mode geometry.
- https://ketchapp-rider.en.aptoide.com/app — curved repeated peaks and overhead saws in original app screenshots.
- https://apps.appfollow.io/ios/rider-stunt-bike-racing/1229618961?country=sn — rotating red arcs, diamonds and narrow luminous rails.
- https://www.appbrain.com/appstore/rider-stunt-bike-racing/ios-1229618961 — original-like dark blue backdrop and trail.
- Supplied earlier screenshot montage reference_crop_grid.jpg (especially 70357, 70980, 71040, 71042): spike trenches, separated drops, triangular crash shards and dark silhouette layers.

The external video bytes were not accessible (YouTube fetch failed; local DNS unavailable). No original video frames were extracted and no original physics constants were measured. Research used accessible descriptions, still images and the supplied gameplay photographs. The 37 generated previews and motion clip are replica output, NOT original footage. Shapes, timing and collision tolerances are independent approximations.

## Changes
- 76–79: vertically extending/retracting spike trench, rounded bunny hops, separated steep drop and runout, asymmetric deep bowl to climb. Introduced after piece 39 without changing the initial tutorial pool. Shared gap/gem geometry. Timed spikes use the same translated hazard in physics and renderer. 80 IDs total (including legacy reserved/disabled templates); not 80 unique active obstacles.
- Continuous relative-motion saw contact: conservative Q4 closest-point test for the center and both wheels, including previous moving-saw coordinates. No claim of full continuous polygon collision. Roof-first falling contact in ordinary terrain, bounded angular and landed-flip counters. Fixed near-lip open-loop entry for seed 132. Rejected a single-wheel slope change after it introduced three novice route failures. Closed-loop motion remains guided.
- Background silhouette and low rock layer now separated; no spurious jagged blue stripe crossing gaps. Updated vehicle raster rounding and trail shading; crash hides intact vehicle and draws angular fragments. No extra static game RAM or framebuffer.
- Cached gap endpoints per frame (16 entries, lossless fallback); per-row shadow-color lookup; smaller oriented vehicle/trail paint bounds. Host microbenchmark, not device timing. Host GCC stack-use estimate increased 112 bytes for rider_render (416 -> 528), Cortex-M3 compile-only stack estimate for rider_render rose from 352 to 440 bytes; rider_step remained 200 bytes. Combined game object text increased 1,568 bytes (not final linked flash usage). Actual stack depth/runtime unmeasured. Full firmware audit still requires 3072 B nominal stack headroom.
- Added targeted tests and 37 live generated preview modes; motion renderer streams native pixels for optional desktop playback only. Existing tests retained. A 500-seed beginner audit passes 500/500; late obstacle crashes remain possible and logged. The workflow builds only a diagnostic candidate if all safety checks pass.
