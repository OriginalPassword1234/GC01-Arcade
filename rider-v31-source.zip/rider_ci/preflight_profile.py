#!/usr/bin/env python3
"""Pre-sign checks. Output nominal spare SRAM only; diagnostics to stderr.
Oversize profiles are reported (not signed) by the calling selection script.
"""
import pathlib,struct,sys
from elftools.elf.elffile import ELFFile
from verify_expanded import (FLASH_BASE,FLASH_END,APP_BASE,APP_SIZE,SETTINGS_BASE,
    SETTINGS_SIZE,LOG_BASE,LOG_SIZE,RAM_BASE,RAM_END,extract_metadata)
raw,elf=map(pathlib.Path,sys.argv[1:])
_,meta=extract_metadata(elf)
expected=dict(FLASH_BASE=FLASH_BASE,FLASH_SIZE=FLASH_END-FLASH_BASE,FIRMWARE_BASE=APP_BASE,
              FIRMWARE_SIZE=APP_SIZE,STATES_BASE=SETTINGS_BASE,STATES_SIZE=SETTINGS_SIZE,
              DATALOG_BASE=LOG_BASE,DATALOG_SIZE=LOG_SIZE)
if any(meta.get(k)!=v for k,v in expected.items()):
    raise SystemExit(f'Unexpected layout metadata {meta}')
buf=raw.read_bytes()
if len(buf)<0x28:raise SystemExit('Raw image too short')
sp,reset=struct.unpack_from('<II',buf)
if not (RAM_BASE<sp<=RAM_END and sp%8==0 and reset&1 and APP_BASE<=(reset&~1)<APP_BASE+APP_SIZE-4):
    raise SystemExit('Invalid initial stack or reset vector')
with elf.open('rb') as f:
    e=ELFFile(f)
    if e['e_machine']!='EM_ARM':raise SystemExit('Wrong ELF machine')
    ram=[]
    for sec in e.iter_sections():
        a=int(sec['sh_addr']); n=int(sec['sh_size'])
        if not (int(sec['sh_flags'])&2) or not n:continue
        if RAM_BASE<=a<RAM_END:ram.append(a+n)
    if not ram:raise SystemExit('No SRAM allocations')
    print(RAM_END-max(ram))
