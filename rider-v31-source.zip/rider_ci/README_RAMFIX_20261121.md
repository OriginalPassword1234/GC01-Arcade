# Rider v0.9 SRAM optimization patch (2026-11-21)

The GitHub ARM build for v0.9 compiled and signed successfully but rejected the
candidate at the last memory audit: **3048 B** nominal free SRAM versus the
unchanged **3072 B** minimum. This is a 24-byte shortfall, not a CRC error.

This patch keeps the full-resolution 320-pixel rail, vehicle, obstacles and
RGB565 output buffer, and the three-column-region dirty display cache. It
stores terrain facet metadata once per horizontal pair of pixels rather than
once per pixel, saving **160 B** static RAM and halving facet metadata writes;
it also removes an unused 8-byte boost-height array. Terrain fill's fine
faceting is rounded to two-pixel horizontal samples, but rail, collectibles
and vehicle edges are not resampled. The test and source have both been
patched in the CI and firmware copies to stay synchronized.

The expected nominal ARM SRAM headroom is approximately **3216 B**, based on
the prior ARM audit and 168 B of source-level static savings. Actual RAM use
will be reported by the new workflow's unchanged ARM memory auditor.

The renderer host test and display reconstruction tests passed. This does **not**
prove that the GC01 boots, can USB-flash safely, sustains a target frame rate,
or that the real stack and interrupt usage fit; those require hardware tests.
Do not flash based on the source-level estimate alone.
