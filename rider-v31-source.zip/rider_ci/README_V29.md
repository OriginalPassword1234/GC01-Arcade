# GC01 Rider v2.9 diagnostic candidate

Derived from exact v2.8 source and failure diagnostics. 16/75/2/1/34 KiB layout; one page transferred from radiation history. Old settings, scores and history are NOT migrated. Export and back up before any future validated update. Physical bootloader acceptance remains unknown; DO NOT FLASH.

Maximum raw payload 76,796 B after CRC, target <=76,496 B (300 B spare). Best v2.8 linked size was 76,836 B, thus 340 B reduction needed. No downgrade of the v2.8 logger or graphics. 2-row render strip reduces array by 640 B, hash cache grows by 320 B; net 320 B nominal static RAM improvement. 120 instead of 80 possible strip transactions per full frame; actual timing must be checked. Refresh coverage remains 80 draws. Required nominal headroom 3,328 B; physical stack remains unmeasured. Mixed backend uses short enums and all 51 ABI assertions retained. GCC12 failure diagnostics preserved where available. CI fails closed on target or audit failure.
