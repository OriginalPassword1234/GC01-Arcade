#!/usr/bin/env python3
"""Generate the independently authored, periodic 512x66 faceted rock layer.
Requires Pillow for this offline authoring tool only. C firmware contains
only the generated scanline RLE bytes; no Pillow, heap, or texture buffer.
Usage: python tools/generate_terrain.py src/rider_render.c
"""
import random, sys, re
from pathlib import Path
from PIL import Image, ImageDraw
W,H=512,66
rng=random.Random(1907)
im=Image.new('L',(W,H)); d=ImageDraw.Draw(im)
for layer in (0,1):
    x=-28
    while x<W-28:
        w=rng.randint(56,111) if layer==0 else rng.randint(39,83)
        peak=rng.randint(9,30) if layer==0 else rng.randint(27,45)
        cx=x+rng.randint(max(8,w//4),max(9,3*w//4)); right=x+w
        left=(x+rng.randint(0,7),peak+rng.randint(13,27))
        apex=(cx,peak); cap=(cx+rng.randint(9,22),peak+rng.randint(-1,8)); shoulder=(right-rng.randint(5,13),peak+rng.randint(9,23))
        base=(right,H+4); foot=(x-3,H+4)
        ridge=(cx+rng.randint(-10,12),peak+rng.randint(15,29))
        low=(cx+rng.randint(-8,12),H+4)
        faces=[([foot,left,apex,cap,shoulder,base],1),([left,apex,ridge,low,foot],2 if layer==0 else 3),([apex,cap,shoulder,ridge],3 if layer==0 else 2),([ridge,shoulder,base,low],1)]
        for shift in (-W,0,W):
            for poly,col in faces:d.polygon([(a+shift,b) for a,b in poly],fill=col)
        x+=max(19,w-rng.randint(4,21))
# Every row is exactly 512 pixels; 2-bit shade, 6-bit length-minus-one.
runs=[]; offsets=[0]
for y in range(H):
    x=0
    while x<W:
        color=im.getpixel((x,y)); n=1
        while x+n<W and n<64 and im.getpixel((x+n,y))==color:n+=1
        runs.append((color<<6)|(n-1));x+=n
    offsets.append(len(runs))
assert len(runs)<65536
p=Path(sys.argv[1]);s=p.read_text();blob='static const uint16_t terrain_offsets[67]={\n'+''.join('    '+','.join(str(v) for v in offsets[i:i+12])+',\n' for i in range(0,len(offsets),12))+'};\nstatic const uint8_t terrain_runs[%d]={\n'%len(runs)+''.join('    '+','.join(f'0x{v:02x}' for v in runs[i:i+16])+',\n' for i in range(0,len(runs),16))+'};'
s,n=re.subn(r'static const uint8_t terrain_tex\[2048\]=\{.*?\};|static const uint16_t terrain_offsets\[67\]=\{.*?\};\s*static const uint8_t terrain_runs\[\d+\]=\{.*?\};',blob,s,count=1,flags=re.S); assert n==1
p.write_text(s);print(f'512x66 faceted texture: {len(runs)} run bytes + {2*len(offsets)} index bytes = {len(runs)+2*len(offsets)} B flash')
