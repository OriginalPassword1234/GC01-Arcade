#!/usr/bin/env python3
"""Reproduce the lossless nibble stream from the exact v2.9 RLE data.
Checks every edit's source and destination bounds before the firmware builds.
No external dependencies. Does not modify source files.
"""
import functools
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
reference = (root / 'tests/texture_reference/v29_terrain.h').read_text()
renderer = (root / 'src/rider_render.c').read_text()

def values(text, name):
    match = re.search(r'\b' + name + r'\[\d+\]\s*=\s*\{([^}]+)\}', text)
    assert match, name
    return [int(v, 0) for v in re.findall(r'0x[0-9a-fA-F]+|\d+', match.group(1))]

offsets = values(reference, 'terrain_offsets')
runs = values(reference, 'terrain_runs')
rows = [runs[a:b] for a, b in zip(offsets, offsets[1:])]
assert offsets[0] == 0 and offsets[-1] == len(runs)
assert len(rows) == 54 and rows[0] == [127] and max(map(len, rows)) == 36
assert all(sum(512 if q == 127 else (q & 63) + 1 for q in row) == 512 for row in rows)
stream = []
for prev, row in zip(rows, rows[1:]):
    @functools.lru_cache(None)
    def dp(i, j):
        if j == len(row):
            return (15,)
        q = row[j]
        choices = [(13, q >> 4, q & 15) + dp(i, j + 1)]
        if i < len(prev):
            diff = q - prev[i]
            if -6 <= diff <= 5:
                choices.append((diff + 6,) + dp(i + 1, j + 1))
            choices.extend([(12,) + dp(i + 1, j), (14, q >> 4, q & 15) + dp(i + 1, j + 1)])
        return min(choices, key=len)
    stream.extend(dp(0, 0))
assert int(re.search(r'#define TERRAIN_NIBBLES (\d+)', renderer).group(1)) == len(stream)
assert int(re.search(r'#define TERRAIN_MAX_RUNS (\d+)', renderer).group(1)) == max(map(len, rows))
assert int(re.search(r'#define TERRAIN_ROWS (\d+)', renderer).group(1)) == len(rows)
packed = values(renderer, 'terrain_delta')
padded = stream + [15] * (len(stream) % 2)
assert packed == [(a << 4) | b for a, b in zip(padded[::2], padded[1::2])]
# Decode independently and prove each read/write is valid; decoder only uses
# these immutable bytes at runtime, never accepts external texture data.
p = 0
prev = rows[0]
for want in rows[1:]:
    got = []
    i = 0
    while True:
        op = stream[p]; p += 1
        if op == 15:
            break
        if op < 12:
            assert i < len(prev)
            got.append(prev[i] + op - 6); i += 1
        elif op == 12:
            assert i < len(prev); i += 1
        else:
            if op == 14:
                assert i < len(prev); i += 1
            got.append((stream[p] << 4) | stream[p + 1]); p += 2
        assert len(got) <= 36 and all(0 <= q <= 255 for q in got)
    assert got == want
    prev = got
assert p == len(stream)
print(f'PASS: {len(rows)} rows, {len(stream)} validated nibbles, {len(packed)} compressed bytes, {len(runs)+2*len(offsets)-len(packed)} table bytes saved')
