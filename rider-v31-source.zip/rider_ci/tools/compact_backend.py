"""Build an equivalent game-only combined C translation unit for Clang ARM.
Only the four symbols used by the firmware adapter are externally visible.
Original source files remain intact. Reject unknown external references at link time.
"""
from pathlib import Path
import re,sys
source=Path(sys.argv[1]); dest=Path(sys.argv[2]); dest.mkdir(parents=True,exist_ok=True)
keep={'rider_init','rider_step','rider_restart','rider_render_snapshot'}
# The host-only public API remains available in the original source; the
# generated ARM translation unit never exports a conflicting replacement.
header=source/'extras/rider_core.h'; render_header=source/'ui/rider_render.h'
headers=[header.read_text(),render_header.read_text()]
pat=r'(?m)^(?:__attribute__\(\(noinline\)\) )?(?:bool|void|int16_t|int32_t|uint8_t|uint32_t) (rider_\w+)\('
names=set(re.findall(pat,'\n'.join(headers)))-keep
assert len(names)>=20 and not names&keep
# Include paths in the generated renderer header refer to the same directory.
headers[1]=headers[1].replace('../extras/rider_core.h','rider_core.h')
texts=headers+[(source/'extras/rider_core.c').read_text(),(source/'ui/rider_render.c').read_text()]
for text,name in zip(texts,['rider_core.h','rider_render.h','rider_core.c','rider_render.c']):
    text=re.sub(pat,lambda m:'static '+m[0] if m[1] in names else m[0],text)
    (dest/name).write_text(text)
(dest/'combined.c').write_text('#include "rider_core.c"\n#include "rider_render.c"\n')
print('Internalized',len(names),'host/API-only symbols; preserved firmware entry points',', '.join(sorted(keep)))
