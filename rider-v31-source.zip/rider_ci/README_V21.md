# GC01 Rider v2.1 — diagnostic candidate

Based on actual v2.0. Two reference-inspired stunt layouts: raised triangular deck with independent launch and landing, and detached concave bowl. The underside of the triangular outline is decorative; the top is the physical rail. Original geometry and dynamics are not pixel-exact. New structures start after section 45. Fixed palette retained. No copied game assets.

Physics: signed rail velocity and rollback at low uphill speed, instead of automatic death; four-point sampled relative ring/spike collision; detached exits use takeoff tangent. Guided rail model is still approximate. Prior low-speed forced-death test is intentionally replaced by a rollback assertion.

Display: 32-bit tile hashes plus periodic refresh (all tiles within 80 draws), not a framebuffer. Cache RAM doubles from 480 to 960 bytes. Renderer arrays 3061 B. Nominal firmware headroom gate remains 3072 B. A checksum collision is still theoretically possible, but periodic refresh limits persistent stale pixels. No physical FPS measurement.

## Build
Put the standalone YAML in .github/workflows/ in your GitHub repository, commit, then manually run GC01 Rider v2.1 in Actions. The workflow checks out pinned Rad Pro, overlays exact source, tests GCC/Clang, builds English APM32 firmware, adds Rad Pro update CRC, verifies ELF/partition boundaries and SRAM, and uploads one diagnostic artifact only when all gates pass. Failed runs upload logs and previews, not firmware.

## Flashing
DO NOT FLASH the diagnostic image without validating bootloader compatibility, actual RAM/stack and radiation measurement, and backup/migration of instrument calibration/settings/logs. This inherits the experimental 68 KiB application layout (previously 56 KiB). Original settings and radiation history are moved. No migration or recovery verification has been done. No hardware-verified image is supplied. No local complete ARM link was possible; the workflow is provided for compilation, not as proof it succeeded.

Original references: September 2017 independent Rider review with triangular deck; original Rider screenshots from AppCheaters and previous audit. Exact dimensions, original physics constants, and original videos are unavailable. See V20_REFERENCE_AND_BUG_AUDIT.md in source archive.
