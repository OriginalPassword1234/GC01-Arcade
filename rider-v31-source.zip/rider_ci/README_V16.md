# GC01 Rider v1.6 — diagnostic source candidate
Based on the actual v1.5 source. Retains one fixed pink-violet/blue palette, 320x240 strip renderer and prior Geiger integration. Not an approved firmware release.

## Changes
- Six new templates (65–70): raised ring with paired rotating coral sectors, asymmetric crest/basin, bowl/climb, double crest, broad trough, and contact-triggered lifting rail. The last is a simplified interpretation of original Rider switch roads, not a reverse-engineered copy. Circular hazards share render and collision geometry; lift displacement is shared by contact, carry, collectibles and rendering.
- Bounded near-contact loop entry recovery for 52/65, correcting the front-wheel release before center reaches the entrance. Closed loops remain guided approximations. Airborne wheel correction uses supporting wheels only. Pause freezes core; pending score saturates; angular interpolation crosses wrap correctly; cached slot identities checked.
- Larger irregular angular blue terrain faces, less repetitive horizon, fixed palette; skip off-strip glyphs and format gem counter once per frame. No full framebuffer or new heap allocation.
- GCC and Clang sanitizer suites passed. Measured static renderer 3048 bytes; two simulation states 480 bytes; display hash cache 480 bytes; subtotal 4008 bytes, unchanged. This is NOT whole-firmware SRAM or stack usage. Host benchmark near v1.5, not an on-device measurement.
- 28 named live gameplay previews; 300 additional live replica QA frames across 30 seeds. These are not original Rider screenshots. No staged state/camera changes. QA checks unique hashes and full row delivery; not proof of visual or physics perfection.

## Research limits
Original Rider 2017 trailer: https://www.youtube.com/watch?v=5_yiVYxrcII (located, not frame-extracted). Screenshot galleries and image search results show paired coral sectors on circular tracks, large angular rocks, open arcs, separated platforms. Additional image results include repeats; 300 distinct original screenshots were NOT obtained. Community descriptions of switch roads informed the simplified lift. User-supplied screenshot collage was also reviewed. The numerical physics and track layouts are approximations. Exact timings, complete obstacle library, challenge and vehicle collection systems remain incomplete.

## Safety
DO NOT FLASH. Full ARM compile/sign and physical GC01 testing were not performed locally. The existing expanded partition layout is unchanged: 16 KiB bootloader, 68 KiB application, 2 KiB game journal, 1 KiB relocated settings, 41 KiB relocated radiation log. USB recovery, calibration/history preservation, interrupt timing, and LCD frame rate are not verified. A successful CI run is not evidence of safe installation. Do not rely on this diagnostic firmware for radiation safety decisions.
