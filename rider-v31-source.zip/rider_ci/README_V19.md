# GC01 Rider v1.9 diagnostic candidate

Based on the exact v1.8 source. User requested less bumpy terrain, more authentic stunt structures, correct vehicle slope orientation and smoother motion. No original proprietary assets used. Fixed pink-violet rails and dark blue terrain.

## Changes
- Grounded orientation uses geometric rail tangent even when the wheel contact window is asymmetric; oriented wheelbase clearance and bounded continuous-contact recovery on downhill curves. 35/35 deep-bowl ground-contact steps and 22/22 steep-slope directional checks; baseline 0/22 slope agreement. Airborne and loop motion remain approximations.
- Early micro-loop, gentler lead-ins and increased stunt scheduling, delayed compound hills. Enlarged giant saw, wider separated curved launch/landing rails. No unsupported new mechanic added. Original screenshots of paired open loops, detached curved rails, red circular barriers and giant saw over a separated launch were studied; exact original layout and dynamics remain unknown. See v1.8 research links; no access to original video bytes.
- Quarter-pixel rotated vehicle center, suppress extrapolation across contact transitions, larger low-contrast terrain facets and compressed 1,571-byte rock texture (previous 2,062 B).
- Adaptive draw requests: 17 ms minimum interval or measured render time plus 8 ms, capped at 100 ms; simulation stays 60 Hz. Not a physical FPS guarantee. 20 s, 1,200 frames at 60 fps native C-rendered host video.
- 25 gameplay preview scenes generated without edited states. Old visual test now checks emerald pixels around all three actual gem positions before pickup, rather than a fixed region. Old early-ramp quota adjusted to reflect the new stunt emphasis; explicitly asserts first micro-loop. Gap traversal test now checks actual runs across seeds instead of assuming fixed schedule.
- Save journal and flash layout unchanged. Game adapter changes draw scheduling only. No hardware validation, no full ARM build, no calibration/history migration; radiation safety and USB recovery unverified. DO NOT FLASH.
