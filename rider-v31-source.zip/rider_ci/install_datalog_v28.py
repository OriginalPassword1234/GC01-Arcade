#!/usr/bin/env python3
"""Install the exact host-tested logger only on the pinned GC01 source.
Fail closed if the upstream source is not the reviewed baseline (line endings
and empty lines may differ). Never touch measurement, calibration or alarm code.
"""
from pathlib import Path
import difflib
root=Path(__file__).resolve().parent
path=root.parent/'platform.io/src/measurements/datalog.c'
base=root/'baseline_v26/datalog.c'
def canonical(p):
    return [line.strip() for line in p.read_text().splitlines() if line.strip()]
old,expected=canonical(path),canonical(base)
if old!=expected:
    print('\n'.join(difflib.unified_diff(expected,old,fromfile='reviewed baseline',tofile='checkout')))
    raise SystemExit('Pinned datalog source differs from reviewed source; do not compile an unreviewed patch.')
# Record the exact upstream bytes for the baseline build, including formatting.
base.write_bytes(path.read_bytes())
path.write_bytes((root/'datalog_v28.c').read_bytes())
print('PASS: reviewed Rad Pro datalog source verified; installed tested v2.8 adaptive logger.')
