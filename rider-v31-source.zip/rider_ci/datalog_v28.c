/*
 * Rad Pro
 * Data log
 *
 * (C) 2022-2026 Gissio
 *
 * License: MIT
 */

#include "../measurements/datalog.h"
#include "../measurements/history.h"
#include "../peripherals/flash.h"
#include "../peripherals/rtc.h"
#include "../system/cmath.h"
#include "../system/settings.h"
#include "../ui/menu.h"
#include "../ui/system.h"
#include "../ui/view.h"

#define DATALOG_PAGE_SIZE FLASH_PAGE_SIZE
#define DATALOG_PAGE_STATE_OFFSET (DATALOG_PAGE_SIZE - DATALOG_PAGE_STATE_SIZE)
#define DATALOG_PAGE_STATE_SIZE FLASH_WORD_SIZE

#define DATALOG_BUFFER_SIZE 16
#define MINUTE_DATA_END (DATALOG_PAGE_STATE_OFFSET-2u)
static uint16_t minuteCRC(const uint8_t *p, unsigned n);
static uint16_t getWord(const uint8_t *p);
static void putWord(uint8_t *p,uint16_t v);
_Static_assert(FLASH_WORD_SIZE == 2, "v2.7 packed logger is for GC01 halfword flash only");

#define DATALOG_ENTRY_INCREMENTAL_2BYTES 0x80
#define DATALOG_ENTRY_INCREMENTAL_3BYTES 0xc0
#define DATALOG_ENTRY_INCREMENTAL_4BYTES 0xe0
#define DATALOG_ENTRY_INCREMENTAL_5BYTES 0xf0
#define DATALOG_ENTRY_ABSOLUTE 0xf1
#define DATALOG_ENTRY_SESSION_START 0xf8
#define DATALOG_ENTRY_PACK4 0xf9
#define DATALOG_ENTRY_PACK3 0xfa /* 0xfa or 0xfb: high bit of 9-bit payload */
#define DATALOG_ENTRY_FILLER 0xfe
#define DATALOG_ENTRY_EMPTY 0xff

typedef enum
{
    PAGESTATE_FULL = 0x00,
    PAGESTATE_RESET = 0x01,
    PAGESTATE_WRITABLE = 0xff,
} PageState;

static const Menu datalogMenu;
static const Menu datalogModeMenu;

typedef struct
{
    uint8_t active; /* 0 off, 1 recording, 2 latched flash fault */
    uint8_t packedCount;
    uint16_t packed;

    uint32_t pageBase;
    uint32_t pageOffset;

    Dose dose;
    Dose committed;
    uint32_t minuteQ;
    uint8_t minuteCount;
    bool minutePage;

    union { uint8_t buffer[DATALOG_BUFFER_SIZE]; uint16_t minutePending[4]; };
    size_t bufferLength;
} DatalogWrite;

typedef struct
{
    bool active;
    uint8_t packedCount;
    uint16_t packed;

    uint32_t pageBase;
    uint32_t pageOffset;
    const uint8_t *page;

    uint32_t timeInterval;
    uint32_t minuteQ;
    uint16_t minutePending[4];
    uint8_t minuteCount;
    bool minutePage;
    bool anchored;
} DatalogRead;

static struct
{
    uint32_t previousTimeFast;

    DatalogWrite write;
    DatalogRead read;
} datalog;

/* Experimental fail-stop latch; reset only on reboot. */
#define WRITE_FAULT (datalog.write.active == 2u)

static const uint16_t loggingModeIntervals[] = {
    0,
    60 * 60,
    10 * 60,
    1 * 60,
    10,
    1,
};

static void stopDatalogRead(void);

void resetDatalog(void)
{
    selectMenuItem(&datalogMenu, 0);
    selectMenuItem(&datalogModeMenu, settings.loggingMode);
}

// Page management

static __attribute__((noinline)) bool isFlashEmpty(uint32_t address, uint32_t count)
{
    const uint8_t *p = readFlash(address, count);

    for (uint32_t i = 0; i < count; i++)
    {
        if (p[i] != 0xff)
            return false;
    }

    return true;
}

static uint32_t alignAddressToFlashWordSize(uint32_t value)
{
    return (value + FLASH_WORD_SIZE - 1) & ~(FLASH_WORD_SIZE - 1);
}

static __attribute__((noinline)) uint32_t getPreviousPage(uint32_t pageBase)
{
    if (pageBase >= (DATALOG_BASE + DATALOG_PAGE_SIZE))
        return pageBase - DATALOG_PAGE_SIZE;

    return DATALOG_END - DATALOG_PAGE_SIZE;
}

static uint32_t getNextPage(uint32_t pageBase)
{
    if (pageBase < (DATALOG_END - DATALOG_PAGE_SIZE))
        return pageBase + DATALOG_PAGE_SIZE;

    return DATALOG_BASE;
}

static PageState readPageState(uint32_t pageBase)
{
    const uint8_t *pageStateData = readFlash(pageBase + DATALOG_PAGE_STATE_OFFSET, DATALOG_PAGE_STATE_SIZE);

    // Check page state trailing bytes
    for (uint8_t i = 1; i < DATALOG_PAGE_STATE_SIZE; i++)
        if (pageStateData[i] != 0xff && !(i==1 && pageStateData[i]==0x28 && pageStateData[0]!=0xff))
            return PAGESTATE_RESET;

    // Check page state first byte
    PageState pageState = pageStateData[0];

    switch (pageState)
    {
    case PAGESTATE_FULL:
    case PAGESTATE_WRITABLE:
        return pageState;

    default:
        return PAGESTATE_RESET;
    }
}

// Fixed value encoder/decoder

static __attribute__((noinline)) uint32_t encodeFixedUInt32(uint8_t *p, uint32_t value)
{
    p[0] = (value >> 24) & 0xff;
    p[1] = (value >> 16) & 0xff;
    p[2] = (value >> 8) & 0xff;
    p[3] = (value >> 0) & 0xff;

    return 4;
}

static uint32_t decodeFixedUInt32(const uint8_t *p, uint32_t *value)
{
    *value = ((uint32_t)p[0] << 24) | (p[1] << 16) | (p[2] << 8) | (p[3] << 0);

    return 4;
}

// Variable value encoder/decoder

static uint32_t encodeVariableUInt32(uint8_t *p, uint32_t value)
{
    if (value >= 0x10000000u) {
        p[0] = DATALOG_ENTRY_INCREMENTAL_5BYTES;
        return 1 + encodeFixedUInt32(p + 1, value);
    }
    unsigned n = 1;
    while (value >= (1u << (7 * n))) ++n;
    unsigned i = n;
    while (--i) { p[i] = (uint8_t)value; value >>= 8; }
    p[0] = (uint8_t)((0xffu << (9 - n)) | value);
    return n;
}

static uint32_t decodeVariableUInt32(const uint8_t *p, uint32_t *value, uint32_t available)
{
    if (!available) return 0;
    uint8_t c = p[0];
    if (c >= DATALOG_ENTRY_INCREMENTAL_5BYTES) {
        if (c != DATALOG_ENTRY_INCREMENTAL_5BYTES || available < 5) return 0;
        return 1 + decodeFixedUInt32(p + 1, value);
    }
    unsigned n = 1;
    for (unsigned mask = 0x80; c & mask; mask >>= 1) ++n;
    if (n > available) return 0;
    uint32_t v = c & (0xffu >> n);
    for (unsigned i = 1; i < n; ++i) v = (v << 8) | p[i];
    *value = v;
    return n;
}

// Datalog write

static __attribute__((noinline)) bool failDatalogWrite(void)
{
    datalog.write.active = 2u;
    datalog.write.bufferLength = 0;
    datalog.write.packedCount = 0;
    datalog.write.packed = 0;
    datalog.write.minuteCount = 0;
    return false;
}

static bool writePageStateAndAdvance(PageState pageState)
{
    if (WRITE_FAULT) return false;
    uint8_t pageStateData[DATALOG_PAGE_STATE_SIZE];
    pageStateData[0] = pageState;
    memset(pageStateData + 1, 0xff, DATALOG_PAGE_STATE_SIZE - 1);
    if(datalog.write.minutePage) {
        const uint8_t *page=readFlash(datalog.write.pageBase,DATALOG_PAGE_SIZE);
        uint16_t crc=minuteCRC(page,MINUTE_DATA_END);
        uint16_t existing=getWord(page+MINUTE_DATA_END);
        uint8_t word[2]; putWord(word,crc);
        if(existing!=crc && (existing!=0xffffu || !writeFlash(datalog.write.pageBase+MINUTE_DATA_END,word,2))) return failDatalogWrite();
        pageStateData[1]=0x28;
    }
    /* Never erase the current page to recover from a failed status write. */
    if (!writeFlash(datalog.write.pageBase + DATALOG_PAGE_STATE_OFFSET, pageStateData, DATALOG_PAGE_STATE_SIZE))
        return failDatalogWrite();
    uint32_t next = getNextPage(datalog.write.pageBase);
    if (datalog.read.active) stopDatalogRead();
    if (!isFlashEmpty(next, DATALOG_PAGE_SIZE) && !eraseFlash(next))
        return failDatalogWrite();
    datalog.write.pageBase = next;
    datalog.write.pageOffset = 0;
    datalog.write.minutePage = false;
    return true;
}

static bool flushDatalogBuffer(void)
{
    if (WRITE_FAULT) return false;
    if (!datalog.write.bufferLength) return true;
    uint32_t alignedLength = alignAddressToFlashWordSize(datalog.write.bufferLength);
    memset(datalog.write.buffer + datalog.write.bufferLength, DATALOG_ENTRY_FILLER, alignedLength - datalog.write.bufferLength);
    if (!writeFlash(datalog.write.pageBase + datalog.write.pageOffset, datalog.write.buffer, alignedLength))
        return failDatalogWrite();
    datalog.write.pageOffset += alignedLength;
    datalog.write.bufferLength = 0;
    return true;
}

static bool appendDatalogEntryToCurrentPage(const uint8_t *entry, uint32_t count)
{
    if (WRITE_FAULT) return false;
    // Fail if entry does not fit within page
    if ((datalog.write.pageOffset + alignAddressToFlashWordSize(datalog.write.bufferLength + count)) > DATALOG_PAGE_STATE_OFFSET)
        return false;

    // Append
    memcpy(datalog.write.buffer + datalog.write.bufferLength, entry, count);
    datalog.write.bufferLength += count;

    // Flush if buffer full
    if (datalog.write.bufferLength >= FLASH_WORD_SIZE)
        return flushDatalogBuffer();

    return true;
}

/* All new legacy-format pages receive an independent committed anchor. */
static bool writeLegacyAnchor(Dose dose)
{
    uint8_t e[10];
    e[0]=DATALOG_ENTRY_ABSOLUTE+(settings.loggingMode-1u);
    encodeFixedUInt32(e+1,dose.time); encodeFixedUInt32(e+5,dose.pulseCount);
    e[9]=DATALOG_ENTRY_FILLER;
    uint32_t a=datalog.write.pageBase+datalog.write.pageOffset;
    if(!writeFlash(a+2,e+2,8)||!writeFlash(a,e,2)) return failDatalogWrite();
    datalog.write.pageOffset+=10u;
    return true;
}

static bool appendDatalogEntryWithPageRollover(const uint8_t *entry, uint32_t count)
{
    if (appendDatalogEntryToCurrentPage(entry, count))
        return true;

    if (!flushDatalogBuffer() || !writePageStateAndAdvance(PAGESTATE_FULL)) return false;
    if(!writeLegacyAnchor(datalog.write.dose)) return false;
    return appendDatalogEntryToCurrentPage(entry, count);
}

/* Pending small readings fit in the former alignment padding of DatalogWrite.
 * A full packed record is one GC01 halfword, never split across page boundaries.
 * Reserved room is sufficient even for the uncompressed fallback. */
static void flushPacked(void)
{
    unsigned n = datalog.write.packedCount;
    if (!n) return;
    unsigned bits = datalog.write.packed;
    uint8_t entry[2];
    if (n == 3) {
        entry[0] = DATALOG_ENTRY_PACK3 + (bits >> 8);
        entry[1] = (uint8_t)bits;
        n = 2;
    } else {
        entry[0] = bits & 7u;
        entry[1] = (bits >> 3) & 7u;
    }
    if(!appendDatalogEntryToCurrentPage(entry,n)) { failDatalogWrite(); return; }
    datalog.write.packedCount = 0;
    datalog.write.packed = 0;
}

static bool appendPulseDelta(uint32_t value)
{
    unsigned n = datalog.write.packedCount;
    unsigned bits = datalog.write.packed;
    /* No multi-minute buffering: only the one- and ten-second modes. */
    if (settings.loggingMode >= DATALOG_LOGGINGMODE_10_SECONDS && value <= 7 &&
        !datalog.write.bufferLength &&
        (n != 3 || value <= 3) &&
        datalog.write.pageOffset + alignAddressToFlashWordSize(datalog.write.bufferLength + n + 1) <= DATALOG_PAGE_STATE_OFFSET) {
        if (n == 3) {
            uint8_t entry[2] = {DATALOG_ENTRY_PACK4,
                (uint8_t)((bits & 3u) | ((bits >> 1) & 12u) | ((bits >> 2) & 48u) | (value << 6))};
            if(!appendDatalogEntryToCurrentPage(entry,2)) return failDatalogWrite();
            datalog.write.packedCount = 0;
            datalog.write.packed = 0;
        } else {
            datalog.write.packed = (uint16_t)(bits | (value << (3 * n)));
            datalog.write.packedCount = ++n;
            if (n == 3 && ((datalog.write.packed & 0x124u) || settings.loggingMode == DATALOG_LOGGINGMODE_10_SECONDS))
                flushPacked();
        }
        return !WRITE_FAULT;
    }
    flushPacked();
    if(WRITE_FAULT) return false;
    uint8_t entry[5];
    unsigned count = encodeVariableUInt32(entry, value);
    return appendDatalogEntryToCurrentPage(entry, count);
}

/* Minute-only format: 14-byte independently anchored page header, adaptive
 * mixed radix halfwords, full uint32 escape, commit-last payload writes.
 * Distinct header (f6,28/29) never emitted by legacy encoder. */
#define MINUTE_MAGIC 0x28f6u
#define MINUTE_HEADER 14u
#define MINUTE_SINGLE 64908u /* 15^4 + 23^3 + 46^2 */
#define MINUTE_ESCAPE (MINUTE_SINGLE + 512u)
#define MINUTE_ABSOLUTE (MINUTE_ESCAPE + 1u)
#define MINUTE_SHORT (MINUTE_ESCAPE + 2u)
#define MINUTE_SESSION (MINUTE_ESCAPE + 3u)
static const uint8_t minuteWidths[] = {46,23,15};
static const uint16_t minuteSizes[] = {2116,12167,50625};

static uint16_t getWord(const uint8_t *p) { return p[0] | ((uint16_t)p[1] << 8); }
static void putWord(uint8_t *p, uint16_t v) { p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static uint16_t minuteCRC(const uint8_t *p, unsigned n)
{
    uint16_t crc=0xffffu;
    while(n--) { crc ^= (uint16_t)*p++ << 8; for(unsigned i=0;i<8;++i) crc=(uint16_t)((crc<<1)^((crc&0x8000u)?0x1021u:0)); }
    return crc;
}
static uint32_t minuteAdvance(uint32_t q, uint32_t v)
{
    /* Robust EWMA: a single huge radiation spike must not make many later
     * ordinary samples expensive. Clamp only the predictor input, never data. */
    uint32_t center=q>>4, cap=center+(center>>1)+32u;
    if(cap>65535u) cap=65535u;
    return q-center+(v>cap?cap:v);
}
static __attribute__((noinline)) unsigned minuteLow(uint32_t q, unsigned width)
{
    unsigned c=(q+8u)>>4;
    return c>width/2?c-width/2:0;
}
static bool minuteHeader(bool session)
{
    uint8_t h[MINUTE_HEADER];
    putWord(h,MINUTE_MAGIC+(session?0x100u:0));
    encodeFixedUInt32(h+2,datalog.write.committed.time);
    encodeFixedUInt32(h+6,datalog.write.committed.pulseCount);
    unsigned center=(datalog.write.minuteQ+8u)>>4;
    if(center>65535u) center=65535u;
    putWord(h+10,(uint16_t)center);
    putWord(h+12,minuteCRC(h,12));
    uint32_t a=datalog.write.pageBase;
    if(!writeFlash(a+2,h+2,MINUTE_HEADER-2)||!writeFlash(a,h,2)) return failDatalogWrite();
    datalog.write.pageOffset=MINUTE_HEADER;
    datalog.write.minutePage=true;
    datalog.write.minuteQ=center<<4;
    return true;
}
static bool minuteRoom(unsigned n)
{
    if(WRITE_FAULT) return false;
    if(datalog.write.pageOffset+n<=MINUTE_DATA_END) return true;
    return writePageStateAndAdvance(PAGESTATE_FULL)&&minuteHeader(false);
}
static bool minuteWrite(uint16_t tag,const uint8_t *payload,unsigned n)
{
    uint8_t h[2]; putWord(h,tag);
    uint32_t a=datalog.write.pageBase+datalog.write.pageOffset;
    if((n&&!writeFlash(a+2,payload,n))||!writeFlash(a,h,2)) return failDatalogWrite();
    datalog.write.pageOffset+=n+2;
    return true;
}
/* Prefer the longest exact group. Recompute after rollover, because a page
 * header resets the predictor to its rounded value. */
static bool minuteFlushOne(void)
{
    if(!minuteRoom(2)) return false;
    unsigned n=datalog.write.minuteCount, count=1;
    unsigned v0=datalog.write.minutePending[0], singleLow=minuteLow(datalog.write.minuteQ,512u);
    unsigned code=MINUTE_SINGLE+v0-singleLow;
    unsigned base=0;
    for(unsigned k=4;k>=2;--k) {
        unsigned w=minuteWidths[k-2], lo=minuteLow(datalog.write.minuteQ,w), rank=0;
        if(n>=k) {
            unsigned j=0;
            for(;j<k;++j) { unsigned v=datalog.write.minutePending[j]; if(v<lo||v-lo>=w) break; rank=rank*w+v-lo; }
            if(j==k) { code=base+rank; count=k; break; }
        }
        base+=minuteSizes[k-2];
    }
    if(count==1 && (v0<singleLow||v0-singleLow>=512u)) {
        uint8_t p[2]; putWord(p,datalog.write.minutePending[0]);
        if(!minuteRoom(4)||!minuteWrite(MINUTE_SHORT,p,2)) return false;
    } else if(!minuteWrite((uint16_t)code,0,0)) return false;
    for(unsigned j=0;j<count;++j) {
        uint32_t v=datalog.write.minutePending[j];
        datalog.write.minuteQ=minuteAdvance(datalog.write.minuteQ,v);
        datalog.write.committed.time+=60u;
        datalog.write.committed.pulseCount+=v;
    }
    n-=count;
    for(unsigned j=0;j<n;++j) datalog.write.minutePending[j]=datalog.write.minutePending[j+count];
    datalog.write.minuteCount=n;
    return true;
}
static __attribute__((noinline)) bool minuteFlush(void)
{
    while(datalog.write.minuteCount) if(!minuteFlushOne()) return false;
    return !WRITE_FAULT;
}
static bool minuteDelta(uint32_t value)
{
    if(value<=65535u) {
        datalog.write.minutePending[datalog.write.minuteCount++]=(uint16_t)value;
        return datalog.write.minuteCount<4||minuteFlushOne();
    }
    uint8_t p[4]; encodeFixedUInt32(p,value);
    if(!minuteFlush()||!minuteRoom(6)||!minuteWrite(MINUTE_ESCAPE,p,4)) return false;
    datalog.write.minuteQ=minuteAdvance(datalog.write.minuteQ,value);
    datalog.write.committed.time+=60u;
    datalog.write.committed.pulseCount+=value;
    return true;
}
static bool minuteAnchor(Dose dose,bool session)
{
    if(!minuteFlush()) return false;
    if(!session&&dose.time==datalog.write.committed.time&&dose.pulseCount==datalog.write.committed.pulseCount) return true;
    uint8_t p[8]; encodeFixedUInt32(p,dose.time); encodeFixedUInt32(p+4,dose.pulseCount);
    if(!minuteRoom(10)||!minuteWrite(session?MINUTE_SESSION:MINUTE_ABSOLUTE,p,8)) return false;
    datalog.write.committed=dose;
    return true;
}

static void writeDatalogSessionStart(void)
{
    /* Keep the session marker and its absolute anchor on the same page. */
    if (datalog.write.pageOffset + alignAddressToFlashWordSize(datalog.write.bufferLength + 12) > DATALOG_PAGE_STATE_OFFSET) {
        if (!flushDatalogBuffer() || !writePageStateAndAdvance(PAGESTATE_FULL)) return;
    }
    const uint8_t sessionStartEntry[] = {DATALOG_ENTRY_SESSION_START};

    appendDatalogEntryWithPageRollover(sessionStartEntry, sizeof(sessionStartEntry));
}

static void appendDatalogAbsoluteEntry(void)
{
    flushPacked();
    if (WRITE_FAULT) return;
    Dose dose = { .time = getDeviceTime(), .pulseCount = getTubePulseCount() };

    if(datalog.write.minutePage) {
        if(minuteAnchor(dose,false)) datalog.write.dose=dose;
        return;
    }
    /* Payload first, commit tag last; flush old halfword before anchoring. */
    if(!flushDatalogBuffer()) return;
    if(datalog.write.pageOffset+10u>DATALOG_PAGE_STATE_OFFSET && !writePageStateAndAdvance(PAGESTATE_FULL)) return;
    if(!writeLegacyAnchor(dose)) return;
    datalog.write.dose = dose;

    stopDatalogRead();
}

static bool appendDatalogIncrementalEntry(void)
{
    uint32_t pulseCount = getTubePulseCount();
    uint32_t value = pulseCount - datalog.write.dose.pulseCount;

    if (!(datalog.write.minutePage ? minuteDelta(value) : appendPulseDelta(value)))
        return false;

    datalog.write.dose.pulseCount = pulseCount;
    datalog.write.dose.time += loggingModeIntervals[settings.loggingMode];

    return true;
}

void startDatalog(void)
{
    if (datalog.write.active || !settings.loggingMode || settings.loggingMode >= DATALOG_LOGGINGMODE_NUM)
        return;

    datalog.write.active = true;

    if(settings.loggingMode==DATALOG_LOGGINGMODE_1_MINUTE && datalog.write.minutePage) {
        Dose d={.time=getDeviceTime(),.pulseCount=getTubePulseCount()};
        if(minuteAnchor(d,true)) datalog.write.dose=d;
        return;
    }
    if(settings.loggingMode==DATALOG_LOGGINGMODE_1_MINUTE || datalog.write.minutePage) {
        if(!flushDatalogBuffer()) return;
        if(datalog.write.pageOffset && !writePageStateAndAdvance(PAGESTATE_FULL)) return;
    }
    if(settings.loggingMode==DATALOG_LOGGINGMODE_1_MINUTE) {
        datalog.write.dose=(Dose){.time=getDeviceTime(),.pulseCount=getTubePulseCount()};
        datalog.write.committed=datalog.write.dose;
        datalog.write.minuteQ=20u<<4;
        minuteHeader(true);
    } else {
        writeDatalogSessionStart();
        appendDatalogAbsoluteEntry();
    }
}

void stopDatalog(void)
{
    if (datalog.write.active != 1u) return;
    appendDatalogAbsoluteEntry();
    flushDatalogBuffer();

    if (!WRITE_FAULT) datalog.write.active = false;
}

void writeDatalogTimeChange(void)
{
    if (datalog.write.active == 1u)
        appendDatalogAbsoluteEntry();
}

void clearDatalog(void)
{
    if(!minuteFlush()) return;
    flushPacked();
    if (!flushDatalogBuffer() || !writePageStateAndAdvance(PAGESTATE_RESET)) return;
    clearHistory();

    stopDatalogRead();
    if(datalog.write.active==1u && settings.loggingMode==DATALOG_LOGGINGMODE_1_MINUTE) {
        datalog.write.dose=(Dose){.time=getDeviceTime(),.pulseCount=getTubePulseCount()};
        datalog.write.committed=datalog.write.dose;
        minuteHeader(false);
    } else if (datalog.write.active == 1u) appendDatalogAbsoluteEntry();
}

void updateDatalog(void)
{
    uint32_t timeFast = getDeviceTimeFast();
    if (timeFast != datalog.previousTimeFast)
    {
        datalog.previousTimeFast = timeFast;

        if (datalog.write.active == 1u)
        {
            uint32_t time = getDeviceTime();
            uint32_t elapsedTime = time - datalog.write.dose.time;
            uint32_t loggingInterval = loggingModeIntervals[settings.loggingMode];

            if (elapsedTime == loggingInterval)
            {
                if (!appendDatalogIncrementalEntry())
                    appendDatalogAbsoluteEntry();
            }
            else if (elapsedTime > loggingInterval)
                appendDatalogAbsoluteEntry();
        }
    }
}

// Datalog read

static void readPage(void)
{
    datalog.read.page = readFlash(datalog.read.pageBase, DATALOG_PAGE_SIZE);
    datalog.read.pageOffset = 0;
    datalog.read.packedCount = 0;
    datalog.read.minuteCount=0;
    unsigned magic=getWord(datalog.read.page);
    datalog.read.minutePage=(magic==MINUTE_MAGIC||magic==MINUTE_MAGIC+0x100u||datalog.read.page[DATALOG_PAGE_STATE_OFFSET+1]==0x28);
}

static bool setDatalogTail(void)
{
    // Gets most recent datalog page
    uint32_t empty=0;
    for(uint32_t pageBase=DATALOG_BASE;pageBase<DATALOG_END;pageBase+=DATALOG_PAGE_SIZE) {
        if(readPageState(pageBase)!=PAGESTATE_WRITABLE) continue;
        if(!isFlashEmpty(pageBase,DATALOG_PAGE_SIZE)) { datalog.read.pageBase=pageBase; return true; }
        if(!empty) empty=pageBase;
        if(readPageState(getPreviousPage(pageBase))==PAGESTATE_FULL) empty=pageBase;
    }
    if(!empty) return false;
    datalog.read.pageBase=empty;
    return true;
}

static bool setDatalogHead(void)
{
    // Get most recent datalog page
    if (!setDatalogTail())
        return false;

    // Move back to oldest datalog page
    while (true)
    {
        uint32_t previousPageBase = getPreviousPage(datalog.read.pageBase);

        if (readPageState(previousPageBase) != PAGESTATE_FULL)
            return true;

        datalog.read.pageBase = previousPageBase;
    }
}

bool startDatalogRead(void)
{
    if (datalog.read.active)
        return false;

    minuteFlush();
    flushPacked();
    flushDatalogBuffer();
    if (!setDatalogHead())
        return false;

    datalog.read.timeInterval=0;
    datalog.read.anchored=false;
    readPage();

    datalog.read.active = true;

    return true;
}

static void stopDatalogRead(void)
{
    datalog.read.active = false;
    datalog.read.packedCount = 0;
    datalog.read.minuteCount=0;
}

bool readDatalog(DatalogRecord *record)
{
    record->sessionStart = false;
    while (datalog.read.active) {
        uint32_t value;
        if(datalog.read.minutePage) {
            const uint8_t *p=datalog.read.page+datalog.read.pageOffset;
            unsigned left=MINUTE_DATA_END-datalog.read.pageOffset;
            if(!datalog.read.pageOffset) {
                if((getWord(p)!=MINUTE_MAGIC&&getWord(p)!=MINUTE_MAGIC+0x100u)||getWord(p+12)!=minuteCRC(p,12)||
                    (p[DATALOG_PAGE_STATE_OFFSET]!=PAGESTATE_WRITABLE&&getWord(p+MINUTE_DATA_END)!=minuteCRC(p,MINUTE_DATA_END))) { datalog.read.anchored=false; datalog.read.timeInterval=0; goto truncated; }
                Dose d; decodeFixedUInt32(p+2,&d.time); decodeFixedUInt32(p+6,&d.pulseCount);
                datalog.read.minuteQ=(uint32_t)getWord(p+10)<<4;
                datalog.read.pageOffset=MINUTE_HEADER;
                bool session=getWord(p)==MINUTE_MAGIC+0x100u;
                bool emit=session||!datalog.read.anchored||record->dose.time!=d.time||record->dose.pulseCount!=d.pulseCount;
                datalog.read.anchored=true; datalog.read.timeInterval=60;
                record->dose=d; record->sessionStart=session;
                if(emit) return true;
                continue;
            }
            if(datalog.read.minuteCount) {
                value=datalog.read.minutePending[--datalog.read.minuteCount];
            } else {
                if(left<2||getWord(p)==0xffffu) goto page_end;
                unsigned code=getWord(p), base=0;
                datalog.read.pageOffset+=2;
                if(code<MINUTE_SINGLE) {
                    for(unsigned k=4;k>=2;--k) {
                        unsigned size=minuteSizes[k-2], w=minuteWidths[k-2];
                        if(code<base+size) {
                            unsigned rank=code-base, lo=minuteLow(datalog.read.minuteQ,w);
                            for(unsigned j=0;j<k;++j) { unsigned v=lo+rank%w; if(v>65535u) goto truncated; datalog.read.minutePending[j]=(uint16_t)v; rank/=w; }
                            datalog.read.minuteCount=k; break;
                        }
                        base+=size;
                    }
                    continue;
                }
                if(code<MINUTE_ESCAPE) { value=minuteLow(datalog.read.minuteQ,512u)+code-MINUTE_SINGLE; if(value>65535u) goto truncated; }
                else if(code==MINUTE_ESCAPE&&left>=6) { decodeFixedUInt32(p+2,&value); if(value<=65535u) goto truncated; datalog.read.pageOffset+=4; }
                else if(code==MINUTE_SHORT&&left>=4) { value=getWord(p+2); datalog.read.pageOffset+=2; }
                else if((code==MINUTE_ABSOLUTE||code==MINUTE_SESSION)&&left>=10) {
                    record->sessionStart=code==MINUTE_SESSION;
                    decodeFixedUInt32(p+2,&record->dose.time); decodeFixedUInt32(p+6,&record->dose.pulseCount);
                    datalog.read.pageOffset+=8; return true;
                } else goto truncated;
            }
            datalog.read.minuteQ=minuteAdvance(datalog.read.minuteQ,value);
        } else if (datalog.read.packedCount) {
            value = datalog.read.packed & 7u;
            datalog.read.packed >>= 3;
            --datalog.read.packedCount;
        } else {
            uint32_t offset = datalog.read.pageOffset;
            const uint8_t *p = datalog.read.page + offset;
            uint32_t left = DATALOG_PAGE_STATE_OFFSET - offset;
            if (!left || *p == DATALOG_ENTRY_EMPTY) goto page_end;
            unsigned c = *p;
            unsigned count = decodeVariableUInt32(p, &value, left);
            if (count) datalog.read.pageOffset += count;
            else if (c >= DATALOG_ENTRY_ABSOLUTE && c < DATALOG_ENTRY_ABSOLUTE + DATALOG_LOGGINGMODE_NUM - 1) {
                if (left < 9) goto truncated;
                datalog.read.timeInterval = loggingModeIntervals[c - DATALOG_ENTRY_ABSOLUTE + 1];
                Dose d; decodeFixedUInt32(p+1,&d.time); decodeFixedUInt32(p+5,&d.pulseCount);
                bool duplicate=offset==0&&datalog.read.anchored&&!record->sessionStart&&record->dose.time==d.time&&record->dose.pulseCount==d.pulseCount;
                record->dose=d;
                datalog.read.pageOffset += 9;
                datalog.read.anchored=true;
                if(duplicate) continue;
                return true;
            } else if (c >= DATALOG_ENTRY_PACK4 && c <= DATALOG_ENTRY_PACK3 + 1) {
                if (left < 2) goto truncated;
                unsigned bits = p[1];
                if (c == DATALOG_ENTRY_PACK4) {
                    datalog.read.packed = (uint16_t)((bits & 3u) | ((bits & 12u) << 1) | ((bits & 48u) << 2) | ((bits & 192u) << 3));
                    datalog.read.packedCount = 4;
                } else {
                    datalog.read.packed = (uint16_t)(bits | ((c - DATALOG_ENTRY_PACK3) << 8));
                    datalog.read.packedCount = 3;
                }
                datalog.read.pageOffset += 2;
                continue;
            } else {
                if (c <= DATALOG_ENTRY_INCREMENTAL_5BYTES) goto truncated;
                ++datalog.read.pageOffset;
                if (c == DATALOG_ENTRY_SESSION_START) {
                    record->sessionStart = true;
                    datalog.read.timeInterval = 0;
                }
                continue;
            }
        }
        /* Never interpret unanchored increments as absolute measurements. */
        if (!datalog.read.timeInterval) continue;
        record->dose.pulseCount += value;
        record->dose.time += datalog.read.timeInterval;
        return true;
truncated:
        datalog.read.anchored=false;
        datalog.read.timeInterval=0;
        datalog.read.pageOffset = DATALOG_PAGE_STATE_OFFSET;
page_end:
        if (datalog.read.page[DATALOG_PAGE_STATE_OFFSET] == PAGESTATE_WRITABLE) break;
        datalog.read.pageBase = getNextPage(datalog.read.pageBase);
        readPage();
    }
    datalog.read.active = false;
    return false;
}

// Initialization

void initDatalog(void)
{
    // Get most recent datalog page
    if (!setDatalogTail())
    {
        uint32_t page=DATALOG_BASE;
        while(page<DATALOG_END&&!isFlashEmpty(page,DATALOG_PAGE_SIZE)) page+=DATALOG_PAGE_SIZE;
        if(page==DATALOG_END) { failDatalogWrite(); return; }
        datalog.read.pageBase=page;
    }

    // Get most recent record
    datalog.read.anchored=false;
    datalog.read.timeInterval=0;
    readPage();
    uint32_t startPageBase = datalog.read.pageBase;

    DatalogRecord record = {0};
    datalog.read.active = true;
    while (readDatalog(&record))
    {
        // Recover from page rollover
        if (datalog.read.pageBase != startPageBase)
        {
            datalog.read.pageOffset = 0;

            break;
        }
    }

    // Keep the readable prefix if an interrupted operation left a dirty tail.
    datalog.write.pageBase = datalog.read.pageBase;
    datalog.write.pageOffset = alignAddressToFlashWordSize(datalog.read.pageOffset);
    datalog.write.minutePage=datalog.read.minutePage;
    if(datalog.write.minutePage) {
        datalog.write.committed=record.dose;
        datalog.write.minuteQ=datalog.read.minuteQ;
    }
    if ((datalog.write.minutePage&&!datalog.read.anchored) || !isFlashEmpty(datalog.read.pageBase + datalog.read.pageOffset, DATALOG_PAGE_SIZE - datalog.read.pageOffset))
        writePageStateAndAdvance(PAGESTATE_FULL);
    stopDatalogRead();
}

// Logging mode menu

static cstring loggingModeMenuOptions[] = {
    STRING_OFF,
    STRING_EVERY_HOUR,
    STRING_EVERY10_MINUTES,
    STRING_EVERY_MINUTE,
    STRING_EVERY10_SECONDS,
    STRING_EVERY_SECOND,
};

static const char *onDatalogModeMenuGetOption(menu_size_t index, MenuStyle *menuStyle)
{
    *menuStyle = (index == settings.loggingMode);

    return getString(loggingModeMenuOptions[index]);
}

static void onDatalogModeMenuSelect(menu_size_t index)
{
    if (settings.loggingMode == index)
        return;

    /* Finish the old interval before changing the encoding mode. */
    stopDatalog();
    settings.loggingMode = index;
    startDatalog();
}

static MenuState datalogModeMenuState;

static const Menu datalogModeMenu = {
    STRING_LOGGING_MODE,
    &datalogModeMenuState,
    ARRAY_SIZE(loggingModeMenuOptions),
    onDatalogModeMenuGetOption,
    onDatalogModeMenuSelect,
    showDatalogMenu,
};

void showDatalogModeMenuView(void)
{
    showMenu(&datalogModeMenu);
}

// Data log clear confirmation view

static void onDatalogClearConfirmationEvent(ViewEvent event)
{
    switch (event)
    {
    case EVENT_KEY_BACK:
    case EVENT_KEY_SELECT:
        showDatalogMenu();

        break;

    case EVENT_DRAW:
        drawNotification(getString(STRING_RESET), getString(STRING_NOTIFICATION_DATALOG_RESET_SUCCESS));

        break;

    default:
        break;
    }
}

// Data log clear alert view

static void onDatalogClearAlertEvent(ViewEvent event)
{
    switch (event)
    {
    case EVENT_KEY_BACK:
        showDatalogMenu();

        break;

    case EVENT_KEY_SELECT:
        clearDatalog();

        if(WRITE_FAULT) showDatalogMenu();
        else showView(onDatalogClearConfirmationEvent);

        break;

    case EVENT_DRAW:
        drawNotification(getString(STRING_RESET), getString(STRING_NOTIFICATION_DATALOG_RESET_CONFIRM));

        break;

    default:
        break;
    }
}

void showDatalogClearAlertView(void)
{
    showView(onDatalogClearAlertEvent);
}

// Data log menu

static const ViewOption datalogMenuOptions[] = {
    {STRING_LOGGING_MODE, showDatalogModeMenuView},
    {STRING_RESET, showDatalogClearAlertView},
};

static const char *onDatalogMenuGetOption(menu_size_t index, MenuStyle *menuStyle)
{
    *menuStyle = (index == 0) ? MENUSTYLE_SUBMENU : 0;

    if(index==0 && WRITE_FAULT) return "Logging fault";
    return getString(datalogMenuOptions[index].title);
}

static void onDatalogMenuSelect(menu_size_t index)
{
    datalogMenuOptions[index].showView();
}

static MenuState datalogMenuState;

static const Menu datalogMenu = {
    STRING_DATALOG,
    &datalogMenuState,
    ARRAY_SIZE((datalogMenuOptions)),
    onDatalogMenuGetOption,
    onDatalogMenuSelect,
    showSettingsMenu,
};

void showDatalogMenu(void)
{
    showMenu(&datalogMenu);
}
