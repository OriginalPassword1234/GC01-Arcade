# GC01 Rider v1.1 — experimental track and scrolling repair

This revision addresses the user-confirmed v1.0 overcorrection: approximately 73% long flat pieces, a low 180 world px/s cap, little potential airtime, and choppy 20-FPS display movement. These are handcrafted, Rider-inspired pieces, **not** extracted original Rider assets or Box2D physics.

## Changes from v1.0

- Early track cadence uses designed approach/challenge/runout sections with 257 jump/ramp sections, 449 flat sections, 105 boost sections and 100 guaranteed early loops in the 1100-piece seeded initial-window test. A guaranteed ramp at piece 2, boost at piece 4, and closed loop at piece 8 make features visible early; fewer repetitive long straights and no reintroduction of the v0.9 small rolling hills.
- Further advanced geometry (open arcs/vertical walls) and some saws become available by distance as well as earned score. In 100 simulated unscored runs through the first 49 pieces, 84 special sections and 28 saws were still present in their final 12-piece world windows. Original Rider's selection pools were score-based; distance fallback is **our** accessibility change, not a claim of original parity.
- Ground acceleration 16 vs 11 Q8 units/tick; normal cap 240 vs 180 world px/s, temporary boost cap 360 vs 300. Intentional crests produce stronger launch velocity and falling acceleration is slightly reduced to make flips possible at the slower, more controllable airborne angular rate retained from v1.0.
- Screen camera projection is 2/3 world scale at render time (no change to collision coordinates). With 240 world px/s at 20 output FPS, steady camera displacement is ~8 display pixels/frame rather than 12 at full scale. More world is visible, but the camera cannot create intermediate LCD refreshes. This trades some art/vehicle apparent scale for lower scrolling jumps; verify aesthetics and actual FPS on hardware.
- Saw geometry was raised higher above the rail on the difficult piece to avoid unavoidable collisions after a jump. Blade appearance stays bright red; this is not original Rider saw-placement data.
- No added global RAM buffers; renderer still reports 3045 B. No new flash writes, USB/recovery changes, or Rad Pro radiation ISR edits. All existing tests plus v1.1 cadence/projection/progression tests pass on GCC with sanitizers. **Not ARM or hardware verified**.

## Local host verification (2026-11-22)

- 498/500 deterministic novice auto-drive runs reached 35 pieces without crashing; this does not validate all manually driven routes.
- 100/100 scripted novice runs landed a scored stunt using the same button physics. This is not a measured human-control success rate.
- 1000 simulated score-save transactions, original v0.9 and v1.0 physics/renderer tests, framebuffer reconstruction for dirty strip updates, and v1.1 progression/projection tests passed.
- 2/3 scrolling in a 240-world-px/s flat test yields 8 display pixels per 50ms (ideal 20Hz). **Actual GC01 FPS and the display BUS timing remain unmeasured**. The GC01 panel uses a parallel GPIO bus; RAM budget and frame-transfer time are independent issues.

## Critical hardware caution

The same 68-KiB firmware, 2-KiB Rider saves, 1-KiB settings, 41-KiB radiation history experimental partition layout is retained. **No migration** of prior calibration/settings/history. USB updater acceptance and radiation pulse integrity are not tested. Do not flash without preserving your known-good firmware/settings and a recovery plan; experimental GC01 firmware should not be used for radiation safety decisions.

The complete original 95-stage library, true independent articulated wheel joints, moving-platform physics, original textures, and the original game's full Box2D behavior are still missing. Do not describe this revision as a one-to-one copy. Save writes happen only on game exit; if power dies beforehand the new best may be lost.




## Source-continuity repair — 2026-11-23

**This is an incremental repair of the actual uploaded v1.1 source**, which
contains the v1.0 lineage and test suite. It is NOT the discarded independent
v1.1 rewrite from the other branch. The uploaded Rider v1.1 C code (with documented v1.0 ancestry)
was retained as the base, with local changes to `rider_core.c`,
`rider_render.c`, and tests.

### Confirmed fixes and additions

- Fixed the most damaging rendering bug: gems, saws, spikes and saw radius now
  use the SAME 2/3 viewport projection as track and bike. Before this change,
  their X coordinates were zoomed but Y coordinates were not, placing objects
  off the intended road geometry and in some scenes below the rail.
- Added explicit projection-alignment RGB565 pixel regression tests against
  the real C renderer, not a fabricated screenshot.
- Added one flash-only micro-loop geometry variant, real traversal, and tests.
- Added a sparse, time-oscillating detached bridge using the same world-space
  height in wheel physics and rendering, without extra RAM allocations.
- Added controlled late-game saw oscillation and on/off timed spike hazards,
  with shared render/physics positions and no new state allocations.
- Added ramp-associated three-diamond arcs that remain stable after pickups.
- Redesigned saw as a 13-tooth swept silhouette stored in 371 B of flash
  bitmap rather than a chunky symmetric gear; saws rendered larger, placed
  safely above track in tested novice configurations.
- Added per-section green/pink neon palettes and reduced the contrast of the
  excessively repetitive terrain facets. Kept the original v1.0 bike sprite.
- Fixed top-center score formatting; stunt bonus remains beside the rider,
  and BEST appears only when paused/crashed, like the original-style UI.
- Reduced the backdrop facet cache from 160 to 80 bytes while retaining
  320px full-resolution track sampling, **saving 80 additional bytes SRAM**;
  renderer static allocation is **2965 B**, not 3045 B. No heap added.
- All existing user-supplied tests and four new source-level regression areas
  pass on host GCC with ASan/UBSan. Original 500-seed auto-drive remains
  **2/500 failures** in the same novice policy; a scripted test is not a
  guarantee that all generated tracks are human-playable.

### Crucial limitations

The original full Rider stage catalog, contact-triggered/collapsing **platforms**, exact
Box2D physics, authored assets, and real hardware smoothness are STILL NOT
implemented or demonstrated. The procedural moving bridge, animated saw,
and timed spikes are not equivalent to the original platform mechanisms. This is an improved faithful baseline,
not a finished one-to-one replica.

The complete ARM firmware build and on-device verification were NOT run here.
The workflow retains its strict `>=3072` nominal spare-SRAM criterion and
refuses to emit the candidate binary if any build, native test, CRC, or
partition audit fails. The expanded flash layout has **no automatic settings,
calibration or radiation-history migration**, and the USB updater may reject
it. **Do not flash without working firmware, backups and SWD recovery**;
never depend on experimental firmware for radiation safety decisions.
