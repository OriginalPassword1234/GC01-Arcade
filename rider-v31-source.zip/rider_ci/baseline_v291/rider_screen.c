/* GC01 ST7789 update adapter. Bounded 2-row streaming with 2 horizontal
 * changed-region hashes per strip. All memory statically allocated.
 * The first pass hashes all tiles; when exactly one tile differs, compact
 * that rectangle in the renderer's mutable work strip and transfer only it.
 * When more tiles change, send the whole strip in ONE display transaction.
 * No heap, DMA reconfiguration, or changes to Rad Pro interrupt processing.
 */
#if defined(GC01_RIDER)
#include <stdint.h>
#include <string.h>
#include "rider_screen.h"
#include "rider_render.h"
#include "draw.h"

#define ROWS 2
#define WIDTH 320
#define HEIGHT 240
#define STRIPS (HEIGHT/ROWS)
#define TILES 2
static uint32_t previous_hash[STRIPS][TILES]; /* 960 bytes, no framebuffer */
static uint8_t refresh_phase;
static uint8_t cache_valid;

void rider_screen_invalidate(void){cache_valid=0;refresh_phase=0;}

static uint32_t hash_tile(const uint16_t *p,uint16_t begin,uint16_t end)
{
    uint32_t h=2166136261u;
    for(int r=0;r<ROWS;r++)
        for(uint16_t x=begin;x<end;x++){
            uint16_t v=p[r*WIDTH+x];
            h=(h ^ v)*16777619u;
        }
    return h;
}
static void send_rows(int top,int rows,const uint16_t *p,void *unused)
{
    (void)unused;
    if(rows!=ROWS || top<0 || top+rows>HEIGHT || top%ROWS!=0)return;
    const unsigned slot=(unsigned)top/ROWS;
    uint32_t left=hash_tile(p,0,160), right=hash_tile(p,160,320);
    /* Six adjacent strips every fourth draw: still refresh all 240 rows within 80 draws. */
    const int force=!cache_valid || ((refresh_phase&3u)==3u &&
        slot>=(unsigned)(refresh_phase/4u)*6u && slot<(unsigned)(refresh_phase/4u)*6u+6u);
    bool l=force || left!=previous_hash[slot][0];
    bool r=force || right!=previous_hash[slot][1];
    if(!l&&!r)return;
    const uint16_t start=l?0:160;
    const uint16_t width=l&&r?320:160;
    const mr_rectangle_t area={(int16_t)start,(int16_t)top,(int16_t)width,ROWS};
    if(width<WIDTH){
        uint16_t *q=(uint16_t *)(void *)p;
        for(int row=0;row<ROWS;row++)
            memmove(q+row*160,p+row*WIDTH+start,160*sizeof(uint16_t));
        drawImage(&area,q);
    }else drawImage(&area,p);
    previous_hash[slot][0]=left;
    previous_hash[slot][1]=right;
}
void rider_draw_gc01_snapshot(const RiderState *s,const RiderRenderPrevious *prev,uint8_t alpha)
{
    rider_render_snapshot(s,prev,alpha,send_rows,0);
    cache_valid=1;
    refresh_phase=(uint8_t)((refresh_phase+1u)%80u);
}
#endif

#if defined(GC01_RIDER) && defined(RIDER_HOST_TEST)
void rider_draw_gc01(const RiderState *s,const RiderState *prev,uint8_t alpha)
{
    RiderRenderPrevious snapshot;
    if(prev)rider_capture_previous(&snapshot,prev);
    rider_draw_gc01_snapshot(s,prev?&snapshot:0,alpha);
}
#endif
