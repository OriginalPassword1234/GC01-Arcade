#!/usr/bin/env bash
# Compare full linked firmware with the identical v2.6 layout and upstream
# compiler in this runner. Restore all candidate files even if baseline fails.
set -euo pipefail
: "${GITHUB_WORKSPACE:?}"
report="$GITHUB_WORKSPACE/dist/tests"
mkdir -p "$report"
work=$(mktemp -d)
target=fnirsi-gc01_apm32f103rb-en
paths=(platform.io/src/extras/rider_core.c platform.io/src/ui/rider_render.c platform.io/src/ui/rider_screen.c platform.io/src/measurements/datalog.c)
restore() {
  for path in "${paths[@]}"; do
    if test -f "$work/${path##*/}"; then cp "$work/${path##*/}" "$path"; fi
  done
  rm -rf -- "$work"
}
trap restore EXIT
for path in "${paths[@]}"; do cp "$path" "$work/${path##*/}"; done
for version in 26 27; do
  for path in "${paths[@]}"; do cp "rider_ci/baseline_v${version}/${path##*/}" "$path"; done
  pio run -d platform.io -e "$target" -t clean > "$report/V${version}_BASELINE_CLEAN.log" 2>&1
  if ! pio run -d platform.io -e "$target" > "$report/V${version}_BASELINE_BUILD.log" 2>&1; then
    tail -n 70 "$report/V${version}_BASELINE_BUILD.log" >&2; exit 1
  fi
  raw="platform.io/.pio/build/$target/firmware.bin"
  elf="platform.io/.pio/build/$target/firmware.elf"
  test -s "$raw" && test -s "$elf"
  bytes=$(wc -c < "$raw")
  python3 rider_ci/preflight_profile.py "$raw" "$elf" > "$report/V${version}_BASELINE_RAM.txt"
  printf '%s\n' "$bytes" > "$report/V${version}_BASELINE_BYTES.txt"
  echo "Full v2.${version#2} baseline payload: $bytes bytes."
done
# Never exceed either same-run default-toolchain baseline or the partition.
cap=75772
for v in 26 27; do
  bytes=$(cat "$report/V${v}_BASELINE_BYTES.txt")
  if ((bytes<cap)); then cap=$bytes; fi
done
printf '%s\n' "$cap" > "$report/V28_MAX_BYTES.txt"
echo "v2.8 hard cap: $cap B."
