#!/usr/bin/env python3
"""Fail-closed structural validation of Rad Pro 3.1.1 GC01 APM32 English image.

This does not establish safe flashing, runtime performance or bootloader behavior.
"""
import pathlib
import struct
import sys
from elftools.elf.elffile import ELFFile

APP_START = 0x08004000
APP_BYTES = 0xE000               # 56KiB, stock Rad Pro layout
APP_CRC = APP_BYTES - 4
APP_END = APP_START + APP_BYTES
STATES_BASE = 0x08012000
STATES_BYTES = 0x400
LOG_BASE = 0x08012400
FLASH_END = 0x08020000
RAM_START = 0x20000000
RAM_END = 0x20005000
MIN_STACK_HEADROOM = 3072  # conservative static RAM ceiling: not a stack proof


def stm_crc(buf):
    crc = 0xFFFFFFFF
    for i in range(0, len(buf), 4):
        word = struct.unpack_from('<I', buf, i)[0]
        crc ^= word
        for _ in range(32):
            crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def main():
    if len(sys.argv) != 4:
        raise SystemExit('usage: verify_firmware.py raw.bin firmware.elf signed.bin')
    raw, elf, signed = [pathlib.Path(p) for p in sys.argv[1:]]
    assert all(p.is_file() for p in [raw, elf, signed]), 'Missing build outputs'
    payload = raw.read_bytes()
    image = signed.read_bytes()
    if not (0 < len(payload) <= APP_CRC):
        raise RuntimeError(f'FAIL: raw firmware {len(payload)} bytes exceeds stock 56 KiB app limit ({APP_CRC})')
    if len(image) != FLASH_END - APP_START:
        raise RuntimeError(f'FAIL: signed image {len(image)} != 114688 bytes')
    if image[:len(payload)] != payload:
        # Except the metadata in vector table patched by official signing.
        if image[:0x20] != payload[:0x20] or image[0x28:len(payload)] != payload[0x28:]:
            raise RuntimeError('FAIL: signed bytes do not match raw firmware payload')
    sp, handler = struct.unpack_from('<II', image, 0)
    if not (RAM_START < sp <= RAM_END and sp % 8 == 0):
        raise RuntimeError(f'FAIL: vector stack pointer not in GC01 SRAM: {sp:#010x}')
    if not (APP_START <= (handler & ~1) < APP_START+APP_CRC and handler & 1):
        raise RuntimeError(f'FAIL: reset vector not in application: {handler:#010x}')
    states_base, states_size = struct.unpack_from('<II', image, 0x20)
    if (states_base,states_size) != (STATES_BASE,STATES_BYTES):
        raise RuntimeError('FAIL: signed image settings boundary is wrong')
    stored_crc = struct.unpack_from('<I', image, APP_CRC)[0]
    computed_crc = stm_crc(image[:APP_CRC])
    if stored_crc != computed_crc:
        raise RuntimeError(f'FAIL: bad firmware CRC (stored {stored_crc:#x}, computed {computed_crc:#x})')
    if any(x != 0xFF for x in image[APP_BYTES:]):
        raise RuntimeError('FAIL: update image would overwrite settings or history with nonblank data')
    with elf.open('rb') as f:
        e = ELFFile(f)
        sections = []
        for section in e.iter_sections():
            sh = section.header
            if sh['sh_flags'] & 0x2 and sh['sh_size']:
                a, b = int(sh['sh_addr']), int(sh['sh_addr']) + int(sh['sh_size'])
                sections.append((section.name,a,b,int(sh['sh_flags'])))
        ram = [(n,a,b) for n,a,b,_ in sections if RAM_START <= a < RAM_END]
        bad_flash = [(n,a,b) for n,a,b,_ in sections if APP_START <= a < FLASH_END and b > APP_START+APP_CRC]
        if bad_flash:
            raise RuntimeError(f'FAIL: allocated flash section reaches past CRC boundary: {bad_flash}')
        if not ram:
            raise RuntimeError('FAIL: no SRAM sections found in ELF')
        high = max(b for _,_,b in ram)
        if high + MIN_STACK_HEADROOM > RAM_END:
            raise RuntimeError(f'FAIL: estimated SRAM upper bound {high:#x} leaves <{MIN_STACK_HEADROOM} B stack')
        print('SRAM allocated sections:')
        for n,a,b in ram:
            print(f'  {n}: 0x{a:08X} .. 0x{b:08X} ({b-a} bytes)')
        print(f'Estimated SRAM headroom to 20 KiB limit: {RAM_END-high} bytes (not worst-case stack analysis)')
    print(f'PASS: raw app={len(payload)} B / {APP_CRC} B; footer CRC matches; padded USB image={len(image)} B')
    print(f'PASS: bootloader area untouched; settings at {STATES_BASE:#010x}; log at {LOG_BASE:#010x}')
    print('WARNING: static checks do NOT establish safe device flashing or runtime radiation monitoring.')

if __name__ == '__main__':
    main()
