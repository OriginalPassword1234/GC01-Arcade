GC01 Rider v1.0 EXPERIMENTAL, full source / host tests / one-action firmware workflow.

For one GitHub action, create .github/workflows/gc01-rider-v10-ONE-ACTION.yml with the downloaded workflow content. This alone should run tests and build firmware, then provide ONE artifact ZIP containing test logs, 8 C renderer previews, signed firmware candidate and ARM ELF if every check succeeds.

The source ZIP is not a flashable image. Do not flash ELF. GHA ARM build and on-device accuracy/FPS are not verified in this environment.

CRITICAL: Geiger counter safety and radiation pulse accuracy are not proven. Old history/calibration have no layout migration. Save writes deferred until game exit; records may be lost on unexpected power loss. Verify with a known-good radiation source and pulse counter before relying on it; keep original firmware and recovery plan.
