#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flags=(-std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer)
# Fail fast if RAM savings are accidentally reverted, while keeping the
# unchanged 3072 B full-firmware headroom threshold in verify_expanded.py.
cc -std=c11 -O2 -Wall -Wextra -Werror src/rider_core.c src/rider_render.c tests/test_ram.c -o /tmp/rider_v09_ram_guard
/tmp/rider_v09_ram_guard
cc "${flags[@]}" src/rider_core.c tests/test_core.c -o /tmp/rider_v09_core
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_core
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_render_many.c -o /tmp/rider_v09_render
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_render
cc "${flags[@]}" -DGC01_RIDER -DRIDER_HOST_TEST -Isrc -Itests/fake src/rider_core.c src/rider_render.c rider_screen.c tests/test_strip_cache.c -o /tmp/rider_v09_dirty
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_dirty
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/render_scenes.c -o /tmp/rider_v09_preview
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_preview score /tmp/rider_v09_score.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_preview saw /tmp/rider_v09_saw.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_preview loop /tmp/rider_v09_loop.ppm
# Game saves are kept in a separate 2-KiB flash journal. Exercise the *real*
# save source against an emulated flash chip, including interrupted writes.
cc "${flags[@]}" -DGC01_RIDER -DGC01 tests/flash_sim/extras/rider_saves.c tests/flash_sim/test_saves.c -o /tmp/rider_v09_saves
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_saves
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_pause_hud.c -o /tmp/rider_v09_pause
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_pause

# Additional 2D rails, grounded-stability, 270-degree flip and multi-gem checks.
cc "${flags[@]}" src/rider_core.c tests/test_v09.c -o /tmp/rider_v09_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_regression

# Bright overlapping neon rails and original-like emerald diamonds.
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_visual_v09.c -o /tmp/rider_v09_visual
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v09_visual

# v1.0 original-game-inspired track distributions and open arc geometry;
# verify smooth sub-tick visuals and slower airborne input in the REAL core.
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_v10.c -o /tmp/rider_v10_regression
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v10_regression
