#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
static FILE *out;
static int next;
static void sink(int top,int rows,const uint16_t *pix,void *unused)
{
    (void)unused;
    assert(top==next && rows==3);
    for(int i=0;i<rows*320;i++) {
        const uint16_t p=pix[i];
        const uint8_t rgb[3]={(uint8_t)(((p>>11)&31)*255/31),
                              (uint8_t)(((p>>5)&63)*255/63),
                              (uint8_t)((p&31)*255/31)};
        assert(fwrite(rgb,1,3,out)==3);
    }
    next+=rows;
}
int main(int argc,char **argv)
{
    if(argc!=3){fprintf(stderr,"usage: render_scenes [jump|score|saw|loop|pause] output.ppm\n");return 2;}
    RiderState s;rider_init(&s,5u);
    if(argv[1][0]=='j') {
        for(int t=0;t<110;++t)rider_step(&s,s.grounded || s.airborne_ticks<24u);
    } else if(argv[1][0]=='v') {
        rider_init(&s,0x2727u);
        s.track[0].template_id=27u;
        s.phase=RIDER_RUNNING;
        s.vx=4*RIDER_Q;
        s.x=65*RIDER_Q;
        s.y=161*RIDER_Q;
        s.grounded=1;
        for(int t=0;t<30;++t) rider_step(&s,1);
        s.camera_x=-5*RIDER_Q;s.camera_y=-4*RIDER_Q;
    } else if(argv[1][0]=='b') {
        rider_init(&s,0x2727u);
        s.track[0].template_id=28u;
        s.track[0].flags|=1u;
        s.track[0].gem_mask=7u;
        s.phase=RIDER_RUNNING;
        s.vx=4*RIDER_Q;
        s.x=65*RIDER_Q;
        s.y=161*RIDER_Q;
        s.grounded=1;
        for(int t=0;t<20;++t) rider_step(&s,1);
        s.camera_x=-5*RIDER_Q;s.camera_y=-4*RIDER_Q;
    } else if(argv[1][0]=='o') {
        rider_init(&s,0x8181u);
        s.track[0].template_id=46u;
        s.phase=RIDER_RUNNING;
        s.vx=3*RIDER_Q;
        s.x=65*RIDER_Q;
        s.y=161*RIDER_Q;
        s.grounded=1;
        int seen=0;
        for(int t=0;t<100;++t){
            rider_step(&s,1);
            if(s.looping && s.loop_t>2400u){seen=1;break;}
        }
        assert(seen);
        s.camera_x=-5*RIDER_Q;s.camera_y=-4*RIDER_Q;
    } else if(argv[1][0]=='s' && argv[1][1]=='c') {
        rider_init(&s,7u);
        for(int t=0;t<2200;++t){rider_step(&s,s.grounded || s.airborne_ticks<55u);if(s.score>=1)break;}
        assert(s.score>=1);
    } else if(argv[1][0]=='p') {
        for(int t=0;t<120;++t)rider_step(&s,s.grounded!=0);
        s.paused=1;
        s.best=21;
    } else if(argv[1][0]=='l') {
        rider_init(&s,0x4444u);
        /* Fixture selects a known existing loop template so its geometry is
         * deterministic. Rider then traverses it using real core steps. */
        s.track[0].template_id=16u;
        s.phase=RIDER_RUNNING;
        s.vx=4*RIDER_Q;
        s.x=65*RIDER_Q;
        s.y=161*RIDER_Q;
        s.grounded=1;
        int seen=0;
        for(int t=0;t<50;++t){
            rider_step(&s,1);
            if(s.looping && s.loop_t>1300u){seen=1;break;}
        }
        assert(seen && s.looping);
        s.camera_x=-6*RIDER_Q;
        s.camera_y=-4*RIDER_Q;
    } else if(argv[1][0]=='s'){
        rider_init(&s,0x1832u);
        s.track[1].template_id=9u;
        s.track[1].flags|=0x02u;
        s.phase=RIDER_RUNNING;
        s.vx=3*RIDER_Q;
        s.x=220*RIDER_Q;
        s.y=161*RIDER_Q;
        s.camera_x=220*RIDER_Q;
        s.camera_y=0;
    } else return 2;
    out=fopen(argv[2],"wb");assert(out);
    fprintf(out,"P6\n320 240\n255\n");
    rider_render(&s,0,0,sink,0);
    assert(next==240 && fclose(out)==0);
    printf("scene score=%d x=%d y=%d phase=%d\n",s.score,s.x/256,s.y/256,s.phase);
}
