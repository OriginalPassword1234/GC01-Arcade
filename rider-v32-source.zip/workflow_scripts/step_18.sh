set -euo pipefail
mkdir -p dist/tests
# The upstream signer can skip oversized binaries and still return 0.
# Keep the audited 76 KiB partition and reserve 4-byte CRC plus 32 B.
(
  set -euo pipefail
  cd radpro
  RAW=platform.io/.pio/build/fnirsi-gc01_apm32f103rb-en/firmware.bin
  ELF=platform.io/.pio/build/fnirsi-gc01_apm32f103rb-en/firmware.elf
  SIGNED=fnirsi-gc01_apm32f103rb/firmware/radpro-fnirsi-gc01_apm32f103rb-en-3.1.1.bin
  test -s "$RAW" && test -s "$ELF" || { echo 'ERROR: target raw binary or ELF missing'; exit 1; }
  target=$(cat ../dist/tests/V32_MAX_BYTES.txt)
  test "$(wc -c < "$RAW")" -le "$target" || { echo "ERROR: firmware exceeds v3.2 target"; exit 1; }
  python3 - "$RAW" "$ELF" <<'PY'
import pathlib, sys
sys.path.insert(0, 'rider_ci')
from verify_expanded import APP_SIZE, APP_BASE, SETTINGS_BASE, SETTINGS_SIZE, LOG_BASE, LOG_SIZE, extract_metadata
raw, elf = map(pathlib.Path, sys.argv[1:])
size = raw.stat().st_size
limit = APP_SIZE - 4 - 32
print(f'Raw firmware: {size} bytes; maximum payload: {limit} bytes; remaining: {limit-size} bytes', flush=True)
if size > limit:
    raise SystemExit(f'ERROR: firmware exceeds the 76 KiB payload target with 32 B reserve by {size-limit} bytes. Do not enlarge further or truncate the binary.')
if size < 0x28:
    raise SystemExit('ERROR: raw firmware is too short for the settings header')
_, meta = extract_metadata(elf)
print(f'ELF layout metadata: {meta}', flush=True)
expected = dict(FLASH_BASE=0x08000000, FLASH_SIZE=0x20000, FIRMWARE_BASE=APP_BASE, FIRMWARE_SIZE=APP_SIZE, STATES_BASE=SETTINGS_BASE, STATES_SIZE=SETTINGS_SIZE, DATALOG_BASE=LOG_BASE, DATALOG_SIZE=LOG_SIZE)
if any(meta.get(k) != v for k,v in expected.items()):
    raise SystemExit('ERROR: ELF metadata does not match the audited partition layout; refusing to sign.')
PY
  # Remove only the exact expected output, so a stale image cannot pass.
  rm -f -- "$SIGNED"
  python3 tools/sign.py
  if ! test -s "$SIGNED"; then
    echo "ERROR: Rad Pro signer returned without producing $SIGNED"
    echo 'Firmware version in source:'
    grep '^#define FIRMWARE_VERSION ' platform.io/src/system/system.h || true
    echo 'Files actually produced by the signer:'
    if test -d fnirsi-gc01_apm32f103rb/firmware; then
      find fnirsi-gc01_apm32f103rb/firmware -maxdepth 1 -type f -printf '%f %s bytes\n'
    fi
    exit 1
  fi
  echo "PASS: signed image created: $SIGNED ($(wc -c < "$SIGNED") bytes)"
) 2>&1 | tee dist/tests/SIGNING_LOG.txt
cp dist/tests/SIGNING_LOG.txt /tmp/rider_expanded_sign.log
