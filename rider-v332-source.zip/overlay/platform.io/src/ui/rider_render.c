#include "rider_render.h"
#include <limits.h>
#include <stdint.h>
#include <string.h>

#define W 320
#define H 240
#define STRIP_ROWS 3
#define RGB(r,g,b) ((((r)>>3)<<11)|(((g)>>2)<<5)|((b)>>3))

static uint16_t strip[W*STRIP_ROWS] __attribute__((aligned(4)));
static int16_t surface[W];
/* Distant silhouette has no fine detail: cache in four-pixel columns.
 * 240 bytes RAM reclaimed and 75% fewer background hash calculations. */
static uint8_t backdrop[W/8+2]; /* world-aligned samples, including right edge */
/* Body-only fill height for special paths, at four-column resolution. */
static uint8_t facet[W/4+1]; /* world-aligned four-pixel body groups, 255=none */
static int16_t gemx[10], gemy[10];
static uint8_t gem_n;
static int16_t sawx[4], sawy[4], sawr[4];
static uint8_t saw_n;
/* Boost y is obtained from the surface when painting; no unused cache. */
static int16_t boostx0[4], boostx1[4];
static uint8_t boost_n;
/* One visible triangle per normal 3-piece cadence; two for fixture safety. */
static int16_t triangle[2][3];
static uint8_t triangle_n;
static int16_t spikex0[4],spikex1[4],spikey[4];
static uint8_t spike_n;
/* Two visible paths cached from shared FLASH geometry into compact screen offsets. */
#define PATH_CACHE_COUNT 2
#define PATH_POINTS 49
static uint8_t loop_dx[PATH_CACHE_COUNT][PATH_POINTS];
static int8_t loop_dy[PATH_CACHE_COUNT][PATH_POINTS];
/* Two Q2 fractional coordinates per point, packed into one nibble. */
static uint8_t loop_fraction[PATH_CACHE_COUNT][(PATH_POINTS+1)/2];
static int16_t loop_anchor_x[PATH_CACHE_COUNT],loop_anchor_y[PATH_CACHE_COUNT];
static uint8_t loop_n[PATH_CACHE_COUNT];
static int8_t loop_min_dy[PATH_CACHE_COUNT],loop_max_dy[PATH_CACHE_COUNT];
static inline unsigned facet_index(int x,int origin){return ((unsigned)x+((unsigned)origin&3u))>>2;}
/* Q3 screen height, INT16_MAX is a genuine gap. */
#define YQ 8
static inline __attribute__((always_inline)) int rail_y(int x){return surface[x]==INT16_MAX?INT16_MAX:surface[x]/YQ;}
_Static_assert((-4>>2)==-1 && (-1>>2)==-1, "signed arithmetic shift required");
static int floor4(int n){return n>>2;}
/* Independent atmospheric rock silhouettes; 512x66 native-resolution two-bit scanline RLE.
 * Generated from irregular overlapping polygonal rock faces, soft edges,
 * non-grid spacing. Stored in flash; stream runs directly with no decompression buffer or heap. */
/* Exact v2.9 RLE rows, delta-coded against the previous row. Row 0 is
 * implicit (one 512-pixel shade-zero run). Nibbles 0..11 change one
 * preceding run by -6..+5; 12 skips it; 13 inserts a literal byte;
 * 14 replaces it with a literal byte; 15 ends the row. The offline
 * encoder and host exhaustive test validate all bounds and pixels.
 * Only two short scanline buffers are needed; no full texture buffer. */
#define TERRAIN_MAX_RUNS 36
#define TERRAIN_ROWS 54
#define TERRAIN_NIBBLES 1704
static const uint8_t terrain_delta[852]={
    0xd3,0xfd,0x3f,0xd3,0x7d,0xc0,0xd3,0xfd,0x3f,0xd3,0xfd,0x3f,0xd3,0xfd,0x06,0xfd,
    0x18,0xdc,0x06,0x6d,0x1c,0xe8,0x09,0x66,0x66,0x63,0xf4,0xd8,0x19,0x66,0x19,0x96,
    0x66,0x66,0xf5,0x79,0x66,0x27,0x96,0x66,0x63,0xf4,0x89,0x66,0x27,0x76,0x6d,0x06,
    0xdc,0x06,0x6d,0x33,0xf4,0x88,0x66,0x28,0x86,0x63,0xd8,0x07,0x66,0x5f,0x48,0x9d,
    0x11,0xec,0x06,0xe3,0x48,0x66,0x64,0x77,0x66,0x5f,0x57,0x92,0xd8,0x1e,0xc6,0x6e,
    0x2c,0x77,0x66,0xc7,0x86,0x64,0xf4,0x89,0x27,0xec,0xe6,0xe2,0x28,0x86,0x37,0x76,
    0x65,0xf4,0x84,0x78,0x66,0x47,0x76,0x47,0x70,0xdc,0x06,0xaf,0x57,0x47,0x77,0x64,
    0x86,0x64,0x77,0x3d,0x81,0xdd,0x3d,0x1f,0x65,0xf4,0x75,0x78,0x76,0x28,0x76,0x47,
    0x82,0x95,0x5d,0x80,0x75,0xf4,0x85,0x58,0x76,0x47,0x86,0x37,0x73,0x87,0x38,0xdc,
    0x2d,0x33,0x5d,0x07,0xf5,0x74,0x78,0x66,0x47,0x76,0x47,0xed,0x0e,0x28,0x76,0x58,
    0x62,0xd8,0x28,0x4f,0x48,0x47,0x77,0x63,0x96,0x64,0x7e,0xd6,0xe2,0x09,0x63,0x87,
    0x29,0x93,0xf4,0x83,0xd4,0x07,0x86,0x64,0x78,0x64,0x6b,0xd4,0x0e,0x18,0x86,0x57,
    0x81,0x98,0x4f,0xec,0x15,0x48,0x58,0x76,0xd0,0x1e,0xcc,0x77,0x64,0x73,0x94,0x95,
    0x48,0x72,0x97,0xf8,0x45,0x84,0x77,0x4e,0x82,0x48,0x7c,0x0d,0xca,0xd0,0x3d,0x80,
    0xd3,0x37,0x39,0x48,0x74,0x86,0x29,0x6f,0x75,0x48,0x58,0x61,0xa5,0x87,0x3d,0x80,
    0xac,0xa1,0x74,0x84,0x86,0x48,0x72,0x96,0xf8,0x45,0x7d,0x03,0xd8,0x00,0x77,0x28,
    0x76,0x6d,0x40,0x47,0x5a,0x27,0x39,0x58,0x64,0x7b,0xd4,0x0e,0x11,0x96,0xf7,0x5c,
    0x85,0xdc,0x07,0x48,0x61,0xa1,0xb1,0xb5,0x76,0xa1,0x73,0xa3,0x86,0x48,0x57,0x38,
    0x7f,0x84,0x74,0x7c,0xcb,0x81,0x96,0x61,0xe4,0xb3,0x86,0xad,0xc0,0x07,0x39,0x48,
    0x65,0x84,0x74,0x86,0xf8,0x46,0xc6,0x86,0x29,0x76,0x0b,0x57,0x69,0x80,0x73,0x94,
    0x96,0x0d,0x80,0xd0,0x18,0x66,0x39,0x6f,0x75,0x57,0x66,0xd4,0x01,0xa6,0x61,0x4d,
    0x96,0xe0,0xa7,0x5b,0x8e,0x12,0x74,0x84,0xd8,0x8d,0xc1,0xe9,0x36,0x5c,0xec,0x09,
    0x58,0x29,0x6f,0x84,0x57,0x7e,0xcf,0xe4,0x73,0x96,0x6c,0xb7,0x47,0x68,0x90,0x73,
    0x94,0x67,0x86,0x48,0x55,0x73,0x96,0xf7,0x55,0x76,0xec,0x7e,0x4f,0xe1,0x0e,0xa6,
    0x85,0x5d,0xc0,0x83,0x76,0x7a,0x07,0xc9,0x54,0x96,0x66,0x66,0x57,0xc9,0x6f,0x84,
    0x56,0x8c,0xe5,0x65,0xdc,0x06,0x66,0x67,0x64,0x66,0x9a,0xc7,0x64,0x68,0x66,0x58,
    0x65,0x39,0x6f,0x84,0x57,0x58,0x38,0x66,0x66,0x6c,0xce,0xa6,0x68,0x46,0x64,0x67,
    0x8c,0xce,0xd9,0x65,0x49,0xd4,0x05,0xf7,0x55,0x76,0x65,0x76,0x76,0x47,0x66,0x7d,
    0xc5,0xe4,0x57,0x6c,0x68,0x6d,0x40,0xdd,0x0d,0x80,0xec,0x75,0x5c,0x9d,0x49,0xfd,
    0x47,0x04,0x48,0x57,0x48,0x57,0x84,0x66,0x68,0xca,0x64,0x68,0x6e,0x4a,0xec,0x56,
    0x76,0x39,0x6f,0xce,0x50,0xec,0x65,0x67,0x65,0x75,0x73,0x88,0x55,0x94,0x64,0x58,
    0x7a,0xc7,0x7c,0x5e,0x88,0x5f,0x0e,0x80,0xe4,0xc7,0x57,0x3d,0x80,0x85,0x83,0x86,
    0x66,0x75,0x74,0x58,0x56,0x77,0x65,0x6f,0x4d,0xc1,0xb0,0x76,0x62,0x97,0x57,0x39,
    0x66,0x68,0x35,0xdc,0x0d,0x82,0x26,0x86,0x65,0x7d,0xbd,0x86,0x6f,0x49,0xbc,0x75,
    0x6c,0x78,0x57,0x47,0x76,0xd4,0x8e,0xc1,0x94,0x48,0x82,0x68,0x65,0x68,0x38,0x66,
    0xf4,0x85,0x69,0x45,0x75,0x82,0x97,0x55,0x77,0x55,0x78,0x25,0x87,0x65,0x74,0x96,
    0x5f,0x48,0x57,0x92,0x67,0x57,0x48,0x67,0x56,0x76,0x38,0x84,0x48,0x65,0x68,0x38,
    0x66,0xf4,0x94,0x77,0x54,0x84,0xd4,0x07,0x38,0x75,0x66,0xea,0x7e,0x48,0x57,0x83,
    0x58,0x66,0xc7,0x39,0x66,0xfc,0x75,0x71,0xb5,0x74,0x78,0x29,0x6d,0x9b,0xd4,0x9e,
    0x80,0x46,0xe9,0xfe,0x51,0x38,0x83,0xc7,0x67,0x73,0x86,0x5d,0xc0,0xf6,0x56,0x2a,
    0xc8,0x48,0x64,0x78,0xcc,0xe9,0x1e,0x57,0x7e,0x97,0xe5,0x95,0x78,0xc8,0x65,0x74,
    0x87,0x38,0xf7,0x56,0x1a,0x84,0x67,0x39,0x6e,0x88,0xbd,0x80,0xd4,0x26,0xe8,0xee,
    0x62,0x49,0x29,0x65,0x74,0x96,0x38,0xf6,0x57,0x28,0x84,0x78,0x38,0x6c,0xcc,0xe6,
    0x86,0xe8,0x7e,0x6b,0x47,0x47,0x75,0x83,0x87,0xc6,0xf6,0x66,0x1a,0x74,0x77,0xc8,
    0x67,0x6c,0xe7,0x35,0x74,0x8d,0x40,0x55,0x74,0x87,0x5f,0x75,0x52,0x98,0x47,0x76,
    0x64,0xd8,0x08,0x54,0x86,0x7b,0x05,0x83,0x87,0x5f,0x65,0x71,0xa7,0x47,0x67,0x58,
    0xc6,0x74,0x75,0x8b,0x06,0x64,0x87,0x5f,0x66,0x6c,0xa7,0x57,0x65,0x75,0x85,0xc8,
    0x67,0xe5,0x0e,0x85,0x58,0x39,0x65,0xfc,0x6e,0xdf,0x38,0x47,0x67,0x57,0x74,0x76,
    0x7c,0xce,0x5c,0x7e,0x5b,0x97,0xf7,0x55,0x74,0x86,0x57,0x57,0x48,0x58,0x47,0x48,
    0x6f,0x76,0x38,0x48,0x57,0x56,0x84,0x76,0x74,0x65,0x86,0xf7,0x55,0x74,0x86,0x66,
    0x67,0x38,0x67,0x56,0x48,0x6f,0x76,0x38,0x47,0x75,0x66,0x84,0x76,0x74,0x65,0x95,
    0xf6,0xd4,0x06,0x47,0x57,0x57,0x66,0x64,0x85,0x84,0x76,0x66,0xfc,0xe4,0x74,0x48,
    0x48,0x65,0x66,0x84,0x76,0x74,0x75,0x7d,0x4c,0xf8,0x54,0x7c,0x76,0x58,0x58,0x38,
    0x67,0x55,0x76,0x6f,
};

#define WHITE RGB(250,251,255)
#define TRACK_CORE RGB(253,246,255)
#define TRACK_EDGE RGB(248,188,244)
#define TRACK_GLOW RGB(94,23,117)
#define TRACK_FAR RGB(36,15,67)
#define TRACK_UNDER_EDGE RGB(19,12,44)
#define GREEN_CORE RGB(245,255,244)
#define GREEN_EDGE RGB(155,255,176)
#define GREEN_HOT RGB(69,255,126)
#define GREEN_GLOW RGB(18,129,61)
#define GREEN_FAR RGB(7,61,38)
#define TRACK_BOOST RGB(255,180,35)
#define TRACK_BOOST2 RGB(255,249,161)
#define SPIKE_RED RGB(255,97,87)
#define SPIKE_GLOW RGB(172,37,67)
#define PINK_HOT RGB(223,90,207)
#define SHADOW_BG RGB(3,9,26)
#define VIOLET_FILL RGB(7,13,29)
#define VIOLET_FACET1 RGB(10,17,38)
#define VIOLET_FACET2 RGB(8,14,32)
#define VIOLET_FACET3 RGB(7,12,27)
#define CAR_GREEN RGB(52,206,111)
#define CAR_GREEN2 RGB(27,145,79)
#define CAR_HALO RGB(115,255,164)
#define CAR_DARK RGB(5,39,32)
#define WHEEL_HALO RGB(106,255,174)
#define GEM_WHITE RGB(244,255,252)
#define GEM_MID RGB(91,255,183)
#define GEM_BLOOM RGB(28,235,135)
#define GEM_OUTER RGB(13,89,66)
#define SAW_RED RGB(255,97,87)
#define SAW_DARK RGB(124,15,24)
#define SAW_CORE RGB(255,210,214)

/* World-to-screen camera zoom: 2/3. More stage is visible on the small
 * GC01 display, and a faster car does not make the terrain jump 12+ screen
 * pixels between two physical LCD updates. Geometry/physics stay in Q8. */
#define VIEW_NUM 2
#define VIEW_DEN 3
/* Euclidean floor, including the negative camera origin at the start.
 * One projection, not two independently rounded world/screen coordinates. */
/* All divisors are positive. Complement negative inputs before dividing,
 * then complement the quotient: exact Euclidean floor with one division. */
static inline int floor_div(int32_t x,int32_t d){int32_t sign=x>>31;return (int32_t)((uint32_t)(x^sign)/(uint32_t)d)^sign;}
static __attribute__((noinline)) int screen_x(int32_t wx,int32_t camx)
{
    return floor_div(wx-camx,VIEW_DEN*RIDER_Q/VIEW_NUM);
}
#define screen_y screen_x
static __attribute__((noinline)) int32_t view_world_x(int32_t camx,int pixel_x)
{
    return camx + pixel_x*(VIEW_DEN*RIDER_Q/VIEW_NUM);
}
static uint32_t hash32(uint32_t x)
{
    x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;
    return x;
}
static inline __attribute__((always_inline)) int absolute(int n) {return n<0?-n:n;}
/* One rail hue and one blue world for every run. No seed-dependent
 * palette selection. Quarter-pixel falloff: luminous narrow core, soft
 * magenta halo. Same table for terrain, gaps, and every special path. */
static const uint16_t rail_palette[32]={
    RGB(255,250,255),RGB(255,250,255),RGB(255,250,255),RGB(255,250,255),
    RGB(255,250,255),RGB(255,250,255),RGB(255,250,255),RGB(255,250,255),
    RGB(255,244,255),RGB(254,225,254),RGB(251,195,251),RGB(245,140,245),
    RGB(231,95,225),RGB(185,50,175),RGB(128,31,121),RGB(82,20,78),
    RGB(69,17,66),RGB(59,14,56),RGB(50,12,47),RGB(42,10,40),
    RGB(35,8,33),RGB(30,7,28),RGB(25,6,24),RGB(22,5,20),
    RGB(18,5,17),RGB(16,4,15),RGB(12,3,11),RGB(9,2,8),
    RGB(6,2,6),RGB(3,1,3),RGB(1,0,1),RGB(0,0,0)
};
static __attribute__((noinline)) uint16_t sky_color(int y,int dither)
{
    /* Dark blue overhead, nearly black toward the horizon. Ordered
     * quantization is faint rather than a strong checkerboard. */
    return RGB(0,29-y*20/240+dither/2,82-y*61/240+dither);
}
static __attribute__((noinline)) uint16_t max_rgb(uint16_t a,uint16_t b)
{
    unsigned r=(a&0xf800u)>(b&0xf800u)?a&0xf800u:b&0xf800u;
    unsigned g=(a&0x07e0u)>(b&0x07e0u)?a&0x07e0u:b&0x07e0u;
    unsigned bl=(a&31u)>(b&31u)?a&31u:b&31u;
    return (uint16_t)(r|g|bl);
}
typedef struct { const uint8_t *first,*next,*end; unsigned left,shade; } TerrainScan;
/* Frame-local work space, reused for every row. Decode only on row changes,
 * never per pixel. The immutable generated stream is exhaustively tested. */
static unsigned terrain_nibble(unsigned *pos)
{
    unsigned i=(*pos)++, b=terrain_delta[i>>1];
    return (i&1u)?b&15u:b>>4;
}
static __attribute__((noinline)) unsigned terrain_decode(const uint8_t *prev,uint8_t *row,unsigned *pos)
{
    uint8_t *dst=row;
    for(;;){
        unsigned op=terrain_nibble(pos);
        if(op<12u)*dst++=(uint8_t)(*prev++ + op-6u);
        else if(op==12u)++prev;
        else if(op==15u)return (unsigned)(dst-row);
        else{
            if(op==14u)++prev;
            unsigned hi=terrain_nibble(pos);
            *dst++=(uint8_t)((hi<<4)|terrain_nibble(pos));
        }
    }
}
static void terrain_next(TerrainScan *t)
{
    unsigned q=*t->next++;
    if(t->next==t->end)t->next=t->first;
    if(q==127u){t->left=512u;t->shade=0;}else {t->left=(q&63u)+1u;t->shade=q>>6;}
}
static TerrainScan terrain_scan(const uint8_t *row,unsigned len,unsigned x)
{
    TerrainScan t={row,row,row+len,0,0};
    terrain_next(&t);x&=511u;
    while(x>=t.left){x-=t.left;terrain_next(&t);}
    t.left-=x;
    return t;
}
/* Bottom fade is global, not restarted at each rail or discontinuity.
 * Most of the foreground is the same deep solid blue as the reference.
 * Large, softly shaded rocks appear only near the bottom of the view. */
static __attribute__((noinline)) uint16_t ground_color(int y,unsigned t)
{
    if(y<164)return RGB(0,35,94);
    int v=y-164;
    int g=35-v*27/76,b=94-v*77/76;
    if(y>=174){
        int fade=240-y;
        if(y<190)fade=fade*(y-174)/16;
        g+=(int)t*fade/64;
        b+=(int)t*fade/24;
    }
    return RGB(0,g,b);
}
static __attribute__((noinline)) int far_peak(int wx)
{
    uint32_t xx=(uint32_t)(wx+32768);
    uint32_t block=xx/32;
    int t=(int)(xx%32);
    int a=151-(int)(hash32(block^0x91u)%68u);
    int b=151-(int)(hash32((block+1u)^0x91u)%68u);
    return a+(b-a)*t/32;
}
static __attribute__((noinline)) void mark_facet(int a,int b,uint8_t value,int origin)
{
    int first=a<0?0:a,last=b>=W?W-1:b;
    if(first<=last)for(unsigned i=facet_index(first,origin);i<=facet_index(last,origin);++i)facet[i]=value;
}
static __attribute__((noinline)) int build_caches(const RiderState *s,int32_t camx,int32_t camy,int origin,int *sky_limit,int *rail_top)
{
    int min_h=H,min_bg=H,max_h=-32;
    /* Fixed world-grid silhouette and facet groups. As the camera scrolls,
     * the interpolation knots do not change position relative to terrain. */
    int first=floor_div(origin,8)*4;
    for(unsigned i=0;i<sizeof backdrop;++i){
        int f=far_peak(first+(int)i*4);backdrop[i]=(uint8_t)f;if(f<min_bg)min_bg=f;
    }
    memset(facet,255,sizeof facet);
    /* Evaluate the true surface at each LCD column, preserving 1/8-pixel
     * vertical phase. Never interpolate across a gap or independently drawn arc. */
    for(int x=0;x<W;++x){
        int32_t h;
        if(rider_surface_q(s,view_world_x(camx,x),&h)){
            int32_t v=floor_div(h-camy,VIEW_DEN*RIDER_Q/VIEW_NUM/YQ);
            if(v< -16000)v=-16000;
            if(v>16000)v=16000;
            surface[x]=(int16_t)v;
        }else surface[x]=INT16_MAX;
        if(surface[x]!=INT16_MAX){
            int hy=rail_y(x);
            if(hy<min_h)min_h=hy;
            if(hy>max_h)max_h=hy;
        }
    }
    int upper_sky_limit=min_h-16<min_bg?min_h-16:min_bg;
    if(upper_sky_limit<0)upper_sky_limit=0;
    gem_n=0; saw_n=0; boost_n=0; spike_n=0; triangle_n=0; memset(loop_n,0,sizeof(loop_n)); memset(loop_fraction,0,sizeof(loop_fraction));
    unsigned path_count=0;
    uint32_t begin=camx>0?(uint32_t)(camx/(256*RIDER_Q)):0u;
    for(uint32_t k=begin;k<begin+4;++k){
        const RiderPiece *p=&s->track[k%RIDER_TRACK_SLOTS];
        if(k>=s->next_piece||p->number!=k) continue;
        if(path_count<PATH_CACHE_COUNT && (rider_template_properties(p->template_id)&RIDER_T_SPECIAL) && p->template_id!=28u){
            /* Cache the closed 2D loop once per FRAME, not per raster strip. */
            int32_t bx=(int32_t)(k*RIDER_PIECE_WIDTH)*RIDER_Q;
            int anchor=screen_x(bx,camx);
            /* Do not let a fully offscreen arc consume a cache slot. */
            if(anchor<=W+10 && anchor+172>=-10){
                unsigned j=path_count++;
                loop_min_dy[j]=127;loop_max_dy[j]=-128;
                loop_anchor_x[j]=(int16_t)anchor;
                loop_anchor_y[j]=(int16_t)screen_y((int32_t)p->start_y*RIDER_Q,camy);
                for(unsigned i=0;i<PATH_POINTS;++i){
                    int32_t px,py;
                    uint16_t t=(uint16_t)(i*4096u/(PATH_POINTS-1u));
                    if(!rider_track_special_q(s,k,p->template_id,t,&px,&py))break;
                    const int qx=floor_div(px-camx,VIEW_DEN*RIDER_Q/VIEW_NUM/4)-4*loop_anchor_x[j];
                    const int qy=floor_div(py-camy,VIEW_DEN*RIDER_Q/VIEW_NUM/4)-4*loop_anchor_y[j];
                    const int ix=floor4(qx),iy=floor4(qy);
                    if(ix<0||ix>255||iy< -128||iy>127)break; /* no narrowing wrap */
                    loop_dx[j][i]=(uint8_t)ix;
                    loop_dy[j][i]=(int8_t)iy;
                    if(iy<loop_min_dy[j])loop_min_dy[j]=(int8_t)iy;
                    if(iy>loop_max_dy[j])loop_max_dy[j]=(int8_t)iy;
                    loop_fraction[j][i/2]|=(uint8_t)(((qx-4*ix)|((qy-4*iy)<<2))<<((i&1u)*4u));
                    loop_n[j]=(uint8_t)(i+1u);
                }
            }
        }
        if((rider_template_properties(p->template_id)&RIDER_T_CLOSED)){
            /* The solid base beneath the connected rail has no extra stroke.
             * Previously the loop's heightfield hole left a vertical black
             * rectangle through the terrain below its entry and exit. */
            const int32_t bx=(int32_t)(k*RIDER_PIECE_WIDTH)*RIDER_Q;
            const int first=screen_x(bx+(p->template_id==75u?48:68)*RIDER_Q,camx);
            const int last=screen_x(bx+(p->template_id==75u?190:(p->template_id==47u?133:156))*RIDER_Q,camx);
            const int y=screen_y((p->start_y-((p->template_id==52u||p->template_id==65u)?32:0))*RIDER_Q,camy);
            if(y<H)for(int x=first<0?0:first;x<=last&&x<W;++x)
                if(y<facet[facet_index(x,origin)])facet[facet_index(x,origin)]=(uint8_t)(y<0?0:y);
        }
        if(p->template_id==27u){
            /* Wall and bowl are filled terrain, but their stroke is drawn
             * solely from the shared 2D path; no invented heightfield rail. */
            for(unsigned t=0;t<=4096u;t+=32u){
                int32_t ax,ay;
                if(!rider_track_special_q(s,k,p->template_id,(uint16_t)t,&ax,&ay))continue;
                int x=screen_x(ax,camx),y=screen_y(ay,camy);
                if(x>=0&&x<W&&y<H){
                    if(y<0)y=0;
                    if(y<facet[facet_index(x,origin)])facet[facet_index(x,origin)]=(uint8_t)y;
                }
            }
        }
        if(p->template_id==81u){
            int a=screen_x((int32_t)(k*256u+96u)*RIDER_Q,camx);
            int b=screen_x((int32_t)(k*256u+164u)*RIDER_Q,camx);
            mark_facet(a,b,254u,origin);
        }
        int32_t pa,pb,py;
        for(unsigned slot=0;slot<2u;slot++)if(rider_platform_at_q(s,k,slot,&pa,&pb,&py)){
            int a=screen_x(pa,camx),b=screen_x(pb,camx);
            mark_facet(a,b,254u,origin);
            if(p->template_id==80u && a<W && b>=0 && triangle_n<2u){
                triangle[triangle_n][0]=(int16_t)a;triangle[triangle_n][1]=(int16_t)b;
                triangle[triangle_n++][2]=(int16_t)screen_y(py,camy);
            }
        }
        for(uint8_t j=0;j<3u && gem_n<10u;++j){
            int32_t wx,wy;
            if(rider_piece_gem_q(s,k,j,&wx,&wy)){
                int xx=screen_x(wx,camx);
                int yy=screen_y(wy,camy);
                if((unsigned)xx+11u<=W+22u&&(unsigned)yy+13u<=H+26u){
                    gemx[gem_n]=(int16_t)xx;
                    gemy[gem_n]=(int16_t)yy;
                    ++gem_n;
                }
            }
        }
        for(unsigned slot=0;slot<2u && saw_n<4;slot++){
            int32_t sx,sy,sr;
            bool ring=slot==0u && rider_piece_ring_q(s,k,&sx,&sy);
            if(ring)sr=42*RIDER_Q;
            if(ring || rider_piece_saw_at_q(s,k,slot,&sx,&sy,&sr)){
                int xx=screen_x(sx,camx),yy=screen_y(sy,camy);
                if(xx>=-sr/384-8 && xx<=W+sr/384+8 && yy>=-sr/384-8 && yy<=H+sr/384+8){
                    sawx[saw_n]=(int16_t)xx;
                    sawy[saw_n]=(int16_t)yy;
                    sawr[saw_n]=(int16_t)(sr/(VIEW_DEN*RIDER_Q/VIEW_NUM));
                    if(ring)sawr[saw_n]=-sawr[saw_n];
                    ++saw_n;
                }
            }
        }
        if(spike_n<4){
            int32_t x0,x1,tip;
            if(rider_piece_spikes_q(s,k,&x0,&x1,&tip)){
                int px0=screen_x(x0,camx);
                int px1=screen_x(x1,camx);
                if(px1>=0&&px0<W){
                    spikex0[spike_n]=(int16_t)px0;
                    spikex1[spike_n]=(int16_t)px1;
                    spikey[spike_n]=(int16_t)screen_y(tip,camy);
                    ++spike_n;
                }
            }
        }
        if(boost_n<4){
            int32_t x0,x1,yq;
            if(rider_piece_boost_q(s,k,&x0,&x1,&yq)){
                int xx0=screen_x(x0,camx);
                int xx1=screen_x(x1,camx);
                if(xx1>=-12 && xx0<=W+12){
                    boostx0[boost_n]=(int16_t)xx0;
                    boostx1[boost_n]=(int16_t)xx1;
                    (void)yq; /* boost position comes from cached rail */
                    ++boost_n;
                }
            }
        }
    }
    /* Refine sky-only fast path to include the tall wall and deep bowl. */
    for(unsigned x=0;x<sizeof facet;++x)if(facet[x]<254u && facet[x]<upper_sky_limit)upper_sky_limit=facet[x];
    if(upper_sky_limit<0)upper_sky_limit=0;
    *sky_limit=upper_sky_limit;
    *rail_top=min_h-16;
    return max_h+16;
}

static const uint8_t SCORE_FONT[11][9]={
  {0x3e,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x3e},
  {0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18},
  {0x3e,0x03,0x03,0x03,0x3e,0x60,0x60,0x60,0x7f},
  {0x7e,0x03,0x03,0x03,0x3e,0x03,0x03,0x03,0x7e},
  {0x63,0x63,0x63,0x63,0x7f,0x03,0x03,0x03,0x03},
  {0x7f,0x60,0x60,0x60,0x7e,0x03,0x03,0x03,0x7e},
  {0x3e,0x60,0x60,0x60,0x7e,0x63,0x63,0x63,0x3e},
  {0x7f,0x03,0x06,0x06,0x0c,0x0c,0x18,0x18,0x30},
  {0x3e,0x63,0x63,0x63,0x3e,0x63,0x63,0x63,0x3e},
  {0x3e,0x63,0x63,0x63,0x3f,0x03,0x03,0x03,0x3e},
  {0x00,0x00,0x08,0x08,0x3e,0x08,0x08,0x00,0x00},
};

static unsigned number(char *out,uint32_t n)
{
    /* Clamp guarantees at most eight decimal digits. */
    char rev[8];unsigned count=0;
    if(n>99999999u)n=99999999u;
    do{rev[count++]=(char)('0'+n%10u);n/=10u;}while(n);
    for(unsigned i=0;i<count;++i)out[i]=rev[count-i-1];
    out[count]='\0';
    return count;
}
static int glyph_index(char ch)
{
    if(ch>='0'&&ch<='9')return ch-'0';
    return ch=='+'?10:-1;
}
static __attribute__((noinline)) void put(int x,int y,int top,uint16_t c)
{
    if((unsigned)x<W&&(unsigned)y-(unsigned)top<STRIP_ROWS)
        strip[(y-top)*W+x]=c;
}
/* One bitmap drawing primitive for both HUD fonts. */
static void draw_glyph(const uint8_t *glyph,int width,int height,int x,int y,int scale,int top,uint16_t color)
{
    for(int row=0;row<height;++row){
        int py=y+row*scale;
        if(py>=top+STRIP_ROWS || py+scale<=top)continue;
        unsigned b=glyph[row];
        for(int col=0;col<width;++col)if(b&(1u<<(width-1-col)))
            for(int dy=0;dy<scale;++dy)
                for(int dx=0;dx<scale;++dx)
                    put(x+col*scale+dx,py+dy,top,color);
    }
}
static __attribute__((noinline)) void draw_text(const char *txt,int x,int y,int scale,int top,uint16_t color,int labels);
static void draw_digits(const char *txt,int xx,int yy,int scale,int top,uint16_t c)
{draw_text(txt,xx,yy,scale,top,c,0);}
/* Compact letterforms for a real high-score label and pause overlay.
 * Rendered as bitmap glyphs to preserve an angular, legible HUD on 320x240. */
static const uint8_t label_font[][7]={
  /* B */ {30,17,17,30,17,17,30},
  /* E */ {31,16,16,30,16,16,31},
  /* S */ {15,16,16,14,1,1,30},
  /* T */ {31,4,4,4,4,4,4},
  /* P */ {30,17,17,30,16,16,16},
  /* A */ {14,17,17,31,17,17,17},
  /* U */ {17,17,17,17,17,17,14},
  /* H */ {17,17,17,31,17,17,17},
  /* I */ {31,4,4,4,4,4,31},
  /* R */ {30,17,17,30,20,18,17},
  /* F */ {31,16,16,30,16,16,16},
  /* C */ {15,16,16,16,16,16,15},
  /* L */ {16,16,16,16,16,16,31},
  /* M */ {17,27,21,21,17,17,17},
  /* O */ {14,17,17,17,17,17,14},
  /* space */ {0,0,0,0,0,0,0}
};
static int label_index(char ch)
{
    const char *letters="BESTPAUHIRFCLMO ";
    for(int i=0;letters[i];++i)if(letters[i]==ch)return i;
    return 15;
}
static __attribute__((noinline)) void draw_text(const char *txt,int x,int y,int scale,int top,uint16_t color,int labels)
{
    int h=labels?7:9,w=labels?5:7,step=labels?6:9;
    if(y>=top+STRIP_ROWS || y+h*scale<=top)return;
    for(int i=0;txt[i];++i){
        int idx=labels?label_index(txt[i]):glyph_index(txt[i]);
        if(idx>=0)draw_glyph(labels?label_font[idx]:SCORE_FONT[idx],w,h,x+i*step*scale,y,scale,top,color);
    }
}
static void draw_label(const char *txt,int x,int y,int scale,int top,uint16_t color)
{draw_text(txt,x,y,scale,top,color,1);}

static __attribute__((noinline)) uint16_t bike_pixel(int x,int y)
{
    /* Larger body, unchanged physical axle positions. A slightly larger
     * tire is raised one local unit so its contact stays on the rail. */
    int dx=absolute(x)-12,dy=y+1;
    int r=dx*dx+dy*dy;
    if(r<=35){
        if(r<=8)return CAR_DARK;
        if(r<=27)return RGB(235,255,241);
        return WHEEL_HALO;
    }
    /* slimmer, more Rider-like luminous wedge */
    if(x>=-24 && x<=24){
        /* Exact precomputed silhouette, one byte per local column. */
        static const uint8_t profile[49]={22,22,22,23,23,23,24,24,26,26,26,26,26,26,27,27,27,27,27,27,29,29,29,29,29,29,29,29,29,29,29,29,29,29,28,28,28,27,27,27,26,26,26,41,41,57,56,56,71};
        unsigned q=profile[x+24];
        int top=-(int)(q&15u),bottom=-(int)(q>>4);
        if(y>=top && y<=bottom){
            if(y==top || x==24 || x==-24)return CAR_HALO;
            if(y==bottom)return CAR_GREEN2;
            if(y==top+1)return CAR_GREEN;
            if(x>=-2 && x<=9 && y>=top+2 && y<=top+5)return CAR_DARK;
            if(x>=6 && x<=16 && y==top+5)return CAR_HALO;
            if(y>bottom-2 && x>=-10&&x<20)return CAR_GREEN2;
            if(x< -12 && y<bottom-1)return CAR_GREEN2;
            return CAR_GREEN;
        }
    }
    if(x>=-24&&x< -9 && y==-6)return CAR_HALO;
    return 0;
}
static __attribute__((noinline)) uint16_t bike_and_trail(int px,int py,int cx,int cy,int fx,int fy,int sn,int cs,int throttle,uint32_t tick,int ts,int tc)
{
    int dx=px-cx,dy=py-cy;
    if((unsigned)dx+48u>87u||(unsigned)dy+42u>84u)return 0;
    /* One inverse transform, rather than truncating the rotation and then
     * truncating the scale. Keeps the wheels attached as the car rotates. */
    if(dx*dx+dy*dy<=21*21){
    int dx4=dx*4-fx,dy4=dy*4-fy;
    int tx0=(dx4*cs+dy4*sn)*6,ty0=(-dx4*sn+dy4*cs)*6;
    int sx=(absolute(tx0)+2048)/4096,sy=(absolute(ty0)+2048)/4096;
    if(tx0<0)sx=-sx;
    if(ty0<0)sy=-sy;
    if((unsigned)sx+26u<=52u&&(unsigned)sy+20u<=30u){
        uint16_t hit=bike_pixel(sx,sy);
        if(hit)return hit;
    }
    }
    if(!throttle || dx*dx+dy*dy>42*42)return 0;
    /* Exhaust follows movement, not the rotating vehicle body. A flip no
     * longer swings the entire trail around the vehicle. Small taper and
     * fading spark points are generated analytically, with no history RAM. */
    /* Keep the luminous plume attached to the actual rotating rear nozzle. */
    dx+=cs*10/256;dy+=sn*10/256;
    int tx=(dx*tc+dy*ts)/256,ty=(-dx*ts+dy*tc)/256;
    if((unsigned)tx+29u>29u||(unsigned)ty+5u>10u)return 0;
    int tail=tx+29;
    int width=1+tail/9;
    /* Short curved nozzle transition; older plume trails the direction of travel. */
    int bend=(sn*tc-cs*ts)/256;
    int across=absolute(ty-(bend*(tail>20?29-tail:tail/3))/256);
    if(across<width){
        if(across==0)return throttle>1?RGB(218,255,255):(tail>19?RGB(154,255,201):RGB(32,143,95));
        if(across+1==width)return RGB(8,38,29);
        return throttle>1?RGB(37,178,228):(tail>18?RGB(40,186,112):RGB(14,77,50));
    }
    if(across==width && ((unsigned)(tail+(tick>>2))&7u)==0u)return RGB(30,122,78);
    return 0;
}
static uint16_t gem_pixel(int dx,int dy)
{
    int x=absolute(dx),y=absolute(dy);
    if(x>10||y>12)return 0;
    int rank=x*14+y*8;
    if(rank<=24)return GEM_WHITE;
    if(rank<=35)return GEM_MID;
    if(rank<=48)return RGB(30,186,110);
    if(rank<=60)return RGB(16,100,65);
    if(rank<=74)return RGB(7,45,32);
    return 0;
}
/* 22 swept, closely spaced coral teeth, not a starburst. */
/* Lossless scanline spans: identical 65x65 saw mask, no decoded buffer. */
static const uint8_t saw_row[66]={
    0, 2, 4, 7, 11, 15, 19, 21, 24, 27, 29, 31, 33, 34, 36, 37, 39, 41, 42, 43, 44, 45, 46, 47, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 67, 68, 69, 70, 71, 72, 73, 75, 77, 78, 80, 81, 83, 85, 87, 90, 93, 95, 99, 103, 107, 110, 112, 114, 114
};
static const uint8_t saw_spans[][2]={
    {26,26},{35,35},{34,35},{26,26},{33,36},{25,27},{44,44},{33,36},
    {25,27},{43,44},{17,17},{32,35},{17,19},{25,27},{42,44},{24,28},
    {31,35},{40,43},{17,19},{24,43},{17,20},{23,42},{17,20},{52,52},
    {17,42},{49,51},{10,10},{17,51},{10,12},{16,50},{10,13},{16,49},
    {11,14},{11,48},{11,50},{58,58},{11,57},{11,57},{4,6},{11,56},
    {5,7},{5,54},{6,53},{6,54},{7,56},{7,62},{7,61},{7,60},
    {3,3},{0,56},{1,56},{3,57},{4,57},{5,58},{5,60},{6,63},
    {6,62},{1,57},{0,57},{3,58},{5,58},{6,59},{6,60},{7,62},
    {7,63},{3,56},{60,60},{2,56},{1,56},{7,56},{9,57},{10,57},
    {9,58},{7,52},{56,58},{6,52},{57,59},{6,52},{13,52},{5,5},
    {15,52},{14,47},{49,52},{13,47},{50,53},{12,46},{51,53},{21,46},
    {12,14},{53,53},{21,40},{43,46},{11,11},{20,39},{43,46},{28,32},
    {35,39},{20,23},{44,46},{28,31},{19,21},{36,38},{44,46},{27,30},
    {36,38},{19,20},{46,46},{27,30},{36,38},{19,19},{28,29},{37,37},
    {28,28},{37,37}
};

static unsigned saw_mask_at(int u,int v,int denominator)
{
    const int mx=32+u/denominator;
    const int my=32+v/denominator;
    if((unsigned)mx>=65u||(unsigned)my>=65u)return 0;
    for(unsigned i=saw_row[my];i<saw_row[my+1];++i)
        if((unsigned)(mx-saw_spans[i][0])<=(unsigned)(saw_spans[i][1]-saw_spans[i][0]))return 1u;
    return 0u;
}
static __attribute__((noinline)) uint16_t saw_pixel(int dx,int dy,int radius,int sin_rot,int cos_rot,uint16_t bg)
{
    if(radius<1)return bg;
    int r2=dx*dx+dy*dy;
    if(r2>(radius+2)*(radius+2))return bg;
    if(r2*16<radius*radius*9)return SAW_RED;
    /* Four sub-pixel samples only at the swept teeth. Do not turn the
     * solid original coral blade into a jagged white/red starburst. */
    int u=(dx*cos_rot+dy*sin_rot)*4,v=(-dx*sin_rot+dy*cos_rot)*4;
    int a=cos_rot+sin_rot,b=cos_rot-sin_rot,d=32*radius;
    unsigned hit=saw_mask_at(u-a,v-b,d)+saw_mask_at(u+a,v+b,d)
                +saw_mask_at(u-b,v+a,d)+saw_mask_at(u+b,v-a,d);
    if(!hit)return bg;
    if(hit==4)return SAW_RED;
    unsigned rr=(((bg>>11)&31u)*(4-hit)+((SAW_RED>>11)&31u)*hit+2)/4;
    unsigned gg=(((bg>>5)&63u)*(4-hit)+((SAW_RED>>5)&63u)*hit+2)/4;
    unsigned bb=((bg&31u)*(4-hit)+(SAW_RED&31u)*hit+2)/4;
    return (uint16_t)((rr<<11)|(gg<<5)|bb);
}
/* Paint only object bounding boxes after the background. The old renderer
 * tested up to 15 objects for every one of the 76,800 screen pixels, which
 * wasted most cycles on empty sky and terrain. Layer order is unchanged. */
static inline __attribute__((always_inline)) int imin(int a,int b) { return a<b ? a:b; }
static inline __attribute__((always_inline)) int imax(int a,int b) { return a>b ? a:b; }

/* Quarter-pixel endpoints and one normal-distance glow for all paths.
 * Connected endpoints, crossings and detached rails have the same color. */
static void paint_segment_q2(int top,int px,int py,int x,int y)
{
    int dx=x-px,dy=y-py,len2=dx*dx+dy*dy;
    if(imax(y,py)+32<top*4 || imin(y,py)-32>=(top+STRIP_ROWS)*4 ||
       imax(x,px)+32<0 || imin(x,px)-32>=W*4)return;
    int ax=absolute(dx),ay=absolute(dy);
    int len=imax(ax,ay)+imin(ax,ay)*3/8;
    if(!len)len=1;
    unsigned reciprocal=(65535u+(unsigned)len)/(unsigned)len;
    int x0=imax(0,floor4(imin(x,px)-32)),x1=imin(W-1,floor4(imax(x,px)+32));
    int y0=imax(top,floor4(imin(y,py)-32)),y1=imin(top+STRIP_ROWS-1,floor4(imax(y,py)+32));
    for(int sy=y0;sy<=y1;++sy){
      int ey=sy*4-py,ex0=x0*4-px,dot=ex0*dx+ey*dy,cross0=ex0*dy-ey*dx;
      for(int sx=x0;sx<=x1;++sx,dot+=4*dx,cross0+=4*dy){
        int dist;
        if(!len2 || dot<0 || dot>len2){
            int ex=sx*4-(dot>len2?x:px),ey1=sy*4-(dot>len2?y:py);
            int a=absolute(ex),b=absolute(ey1);
            dist=imax(a,b)+imin(a,b)*3/8;
        }else {
            unsigned cross=(unsigned)absolute(cross0);
            if(cross>=32u*(unsigned)len)continue;
            /* len is bounded by the packed path coordinates; cross < 65536.
             * Rounded-up reciprocal plus one correction is exact. */
            unsigned q=(cross*reciprocal)>>16;
            if(q*(unsigned)len>cross)--q;
            dist=(int)q;
        }
        if(dist<32){
            uint16_t *dst=&strip[(sy-top)*W+sx];
            *dst=max_rgb(*dst,rail_palette[dist]);
        }
      }
    }
}
static void paint_loop(int top,const uint16_t *ends,unsigned nends)
{
    /* Inverted triangular structural support: muted outline below rideable
     * deck (not a second collision rail). */
    for(unsigned j=0;j<triangle_n;j++){
        int a=triangle[j][0],b=triangle[j][1],y=triangle[j][2],mid=(a+b)/2;
        if(top+STRIP_ROWS<=y || top>y+26)continue;
        for(int sy=imax(top,y+1);sy<top+STRIP_ROWS && sy<=y+26;sy++){
            int l=a+(mid-a)*(sy-y)/26, r=b-(b-mid)*(sy-y)/26;
            for(int x=imax(0,l);x<=imin(W-1,r);x++){
                uint16_t *dst=&strip[(sy-top)*W+x];
                *dst=max_rgb(*dst,(x-l<=1||r-x<=1)?RGB(245,135,244):RGB(4,23,58));
            }
        }
    }
    for(unsigned j=0;j<PATH_CACHE_COUNT;++j){
      if(loop_n[j]<2 || loop_anchor_y[j]+loop_max_dy[j]+9<top || loop_anchor_y[j]+loop_min_dy[j]-8>=top+STRIP_ROWS)continue;
      for(unsigned i=1;i<loop_n[j];++i){
        int y0=loop_anchor_y[j]+loop_dy[j][i-1],y1=loop_anchor_y[j]+loop_dy[j][i];
        if(imax(y0,y1)+9<top || imin(y0,y1)-8>=top+STRIP_ROWS)continue;
        unsigned f0=(loop_fraction[j][(i-1)/2]>>(((i-1)&1u)*4u))&15u;
        unsigned f1=(loop_fraction[j][i/2]>>((i&1u)*4u))&15u;
        int x=4*(loop_anchor_x[j]+loop_dx[j][i])+(int)(f1&3u);
        int y=4*(loop_anchor_y[j]+loop_dy[j][i])+(int)(f1>>2);
        int px=4*(loop_anchor_x[j]+loop_dx[j][i-1])+(int)(f0&3u);
        int py=4*(loop_anchor_y[j]+loop_dy[j][i-1])+(int)(f0>>2);
        paint_segment_q2(top,px,py,x,y);
      }
    }
    /* Most views have 0–6 endpoints. Discover them once per frame,
     * not once per three-row LCD strip. Overflow is lossless. */
    for(unsigned i=0;i<nends;++i){
        int x=nends<=16u?ends[i]:(int)i;
        if(surface[x]==INT16_MAX || surface[x]<8*(top-8) || surface[x]>=8*(top+STRIP_ROWS+8))continue;
        if(nends<=16u || (x>0&&surface[x-1]==INT16_MAX)||(x+1<W&&surface[x+1]==INT16_MAX))
            paint_segment_q2(top,4*x,surface[x]/2,4*x,surface[x]/2);
    }
}

/* Same Q4 ring test as physics, but precomputed direction and shared radius/projection. */
static inline unsigned ring_pixel(int x,int y,int sn,int cs)
{
    int d2=x*x+y*y;
    if(d2<528*528||d2>704*704)return 0;
    int v=(x*cs+y*sn)/256;int v2=v*v;
    if(d2>=560*560&&d2<=672*672&&v2>=(d2*225/256)*225/256)return 2;
    return v2>=(d2*210/256)*210/256;
}

static void paint_objects(int top, int cx, int cy, int fx, int fy, int sn, int cs, int sin_rot, int cos_rot, int throttle, uint32_t tick,int trail_sn,int trail_cs,const uint16_t *ends,unsigned nends)
{
    const int bottom=top+STRIP_ROWS;
    paint_loop(top,ends,nends);
    /* Four right-facing chevrons above the local rail, aligned to its slope. */
    for(uint8_t i=0;i<boost_n;++i){
        for(int k=0;k<4;++k){
            int x=boostx0[i]+4+k*8;
            if(x>boostx1[i]-3||x<1||x>=W-1||surface[x]==INT16_MAX)continue;
            int y=rail_y(x)-5;
            if(y+3<top || y-3>=bottom)continue;
            for(int dy=-3;dy<=3;++dy){
                int px=x-absolute(dy);
                put(px,y+dy,top,TRACK_BOOST2);
                put(px-1,y+dy,top,TRACK_BOOST);
            }
        }
    }
    /* Saw-style hazard platforms, but embedded BELOW the intentional gap
     * rather than in the rail or at an impossible random height. */
    for(uint8_t i=0;i<spike_n;++i){
        const int xa=imax(0,spikex0[i]);
        const int xb=imin(W,spikex1[i]+1);
        const int depth=12*VIEW_NUM/VIEW_DEN;
        for(int y=imax(top,spikey[i]);y<imin(bottom,spikey[i]+depth+1);++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=xa;x<xb;++x){
                int32_t profile=rider_spike_profile_q((x-spikex0[i])*(VIEW_DEN*RIDER_Q/VIEW_NUM));
                const int tip=spikey[i]+profile/(VIEW_DEN*RIDER_Q/VIEW_NUM);
                if(y>=tip)dst[x]=SPIKE_RED;
            }
        }
    }
    for(uint8_t i=0;i<saw_n;++i){
        const int halo=absolute(sawr[i])+7;
        const int y0=imax(top,sawy[i]-halo);
        const int y1=imin(bottom,sawy[i]+halo+1);
        const int x0=imax(0,sawx[i]-halo);
        const int x1=imin(W,sawx[i]+halo+1);
        if(y0>=y1||x0>=x1)continue;
        if(sawr[i]<0){
            uint8_t angle=(uint8_t)(tick/2u);
            int rs=rider_sin256(angle),rc=rider_sin256((uint8_t)(angle+64u));
            for(int y=y0;y<y1;++y){
                uint16_t *dst=strip+(y-top)*W;
                for(int x=x0;x<x1;++x){
                    unsigned hit=ring_pixel((x-sawx[i])*24,(y-sawy[i])*24,rs,rc);
                    if(hit==2)dst[x]=RGB(255,98,82);
                    else if(hit)dst[x]=max_rgb(dst[x],RGB(89,18,20));
                }
            }
        }else for(int y=y0;y<y1;++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=x0;x<x1;++x)dst[x]=saw_pixel(x-sawx[i],y-sawy[i],sawr[i],sin_rot,cos_rot,dst[x]);
        }
    }
    int tx=throttle?(-trail_cs*29-cs*10)/256:0,ty=throttle?(-trail_sn*29-sn*10)/256:0;
    int bx0=imin(-21,tx-7),bx1=imax(21,tx+7);
    int by0=imin(-21,ty-7),by1=imax(21,ty+7);
    for(int y=imax(top,cy+by0);y<imin(bottom,cy+by1+1);++y){
        uint16_t *dst=strip+(y-top)*W;
        for(int x=imax(0,cx+bx0);x<imin(W,cx+bx1+1);++x){
            const uint16_t c=bike_and_trail(x,y,cx,cy,fx,fy,sn,cs,throttle,tick,trail_sn,trail_cs);
            if(c)dst[x]=c;
        }
    }
    for(uint8_t i=0;i<gem_n;++i){
        for(int y=imax(top,gemy[i]-12);y<imin(bottom,gemy[i]+13);++y){
            uint16_t *dst=strip+(y-top)*W;
            for(int x=imax(0,gemx[i]-10);x<imin(W,gemx[i]+11);++x){
                const uint16_t c=gem_pixel(x-gemx[i],y-gemy[i]);
                if(c)dst[x]=c;
            }
        }
    }
}

uint32_t rider_render_static_ram(void)
{
    return (uint32_t)(sizeof(strip)+sizeof(surface)+sizeof(backdrop)+sizeof(facet)+
                      sizeof(gemx)+sizeof(gemy)+sizeof(gem_n)+sizeof(sawx)+
                      sizeof(sawy)+sizeof(sawr)+sizeof(saw_n)+sizeof(boostx0)+
                      sizeof(boostx1)+sizeof(boost_n)+sizeof(triangle)+sizeof(triangle_n)+
                      sizeof(spikex0)+sizeof(spikex1)+sizeof(spikey)+sizeof(spike_n)+
                      sizeof(loop_dx)+sizeof(loop_dy)+sizeof(loop_fraction)+sizeof(loop_anchor_x)+sizeof(loop_anchor_y)+sizeof(loop_n)+sizeof(loop_min_dy)+sizeof(loop_max_dy));
}
static void paint_crash(const RiderState *s,int top,int cx,int cy)
{
        if(s->phase==RIDER_CRASHED && s->crash_ticks<28u){
            unsigned age=s->crash_ticks+2u;
            for(unsigned i=0;i<20u;++i){
                int a=(int)(i*205u+s->tick_count*31u);
                int len=(int)age*(2+(int)(i%4u))/2;
                int px=cx+rider_sin4096(a)*len/256;
                int py=cy+rider_sin4096(a+1024)*len/256;
                /* Angular wire fragments, not an intact bike plus dots. */
                int size=2+(int)(i%4u);
                uint16_t col=age<12u?RGB(202,226,238):age<21u?RGB(110,148,175):RGB(57,85,118);
                for(int q=0;q<=size;q++){
                    put(px+q,py+q/2,top,col);
                    put(px-q/2,py+q,top,col);
                    put(px+size-q,py+size/2+q/2,top,col);
                }
            }
        }
}

static void paint_hud(const RiderState *s,int top,int cx,int cy,const char *score,const char *high,int score_size,const char *bonus,const char *diamond_count,int diamond_len)
{
        draw_digits(score,(W-score_size)/2,24,2,top,WHITE);
        /* Best score is shown in pause/crash, separate from the live score. */
        if(s->paused || s->phase==RIDER_CRASHED){
            draw_label("BEST",8,34,1,top,WHITE);
            draw_digits(high,8,44,1,top,WHITE);
        }
        /* Diamonds now have visible feedback, even without garage mode. */
        draw_digits(diamond_count,W-15-diamond_len*9,7,1,top,GEM_WHITE);
        for(int dy=-4;dy<=4;++dy){
            for(int dx=-4;dx<=4;++dx){
                int rank=absolute(dx)+absolute(dy);
                if(rank<=4)put(W-8+dx,12+dy,top,rank<3?GEM_WHITE:GEM_MID);
            }
        }
        if(s->pending_score){
            int bonus_x=cx-15;
            if(bonus_x<3)bonus_x=3;
            if(bonus_x>W-55)bonus_x=W-55;
            int by=cy-19-(30-(int)s->pending_ticks)/2;
            draw_digits(bonus,bonus_x,by,s->pending_score>=3u?2:1,top,
                        s->pending_ticks>8u?WHITE:RGB(176,181,194));
        }
        if(s->perfect_ticks && s->phase==RIDER_RUNNING && !s->paused){
            draw_label("PERFECT FLIP",(W-12*12)/2,176,2,top,WHITE);
        }
        if(s->paused){
            /* A play triangle replaces the pause bars when gameplay stops. */
            for(int x=8;x<19;++x)
                for(int y=8;y<20;++y)
                    if(x>=8 && x<=18 && absolute(y-14)<=((18-x)/2))
                        put(x,y,top,WHITE);
            draw_label("PAUSE",115,92,2,top,WHITE);
            /* Real on-device presentation rate, sampled before pausing. */
            if(s->theme && top>=198 && top<216){
                char fps[9];number(fps,1000u/s->theme);
                draw_label("FPS",130,202,1,top,WHITE);
                draw_digits(fps,155,201,1,top,WHITE);
            }
        }else{
            for(int y=8;y<20;++y){
                for(int x=8;x<11;++x)put(x,y,top,RGB(77,110,129));
                for(int x=15;x<18;++x)put(x,y,top,RGB(77,110,129));
            }
        }
        if(s->phase==RIDER_CRASHED){
            for(int y=73;y<75;++y)for(int x=130;x<190;++x)put(x,y,top,WHITE);
        }
}

void rider_render_snapshot(const RiderState *s,const RiderRenderPrevious *prev,uint8_t alpha,
                  RiderPixels out,void *context)
{
    if(!s||!out)return;
    int32_t camx=s->camera_x,camy=s->camera_y;
    int32_t xx=s->x,yy=s->y,a=s->angle;
    if(prev && !s->paused && s->phase==RIDER_RUNNING &&
       prev->phase==RIDER_RUNNING){
        /* Interpolate the two completed simulation states at the fixed-step
         * fraction. A constant one-tick visual lag avoids prediction snaps
         * at ground/air/loop transitions. Camera remains independent of bike. */
        int32_t dcx=camx-prev->camera_x,dcy=camy-prev->camera_y;
        unsigned back=256u-alpha;
        if(absolute(dcx)<=8*RIDER_Q)camx-=dcx*(int32_t)back/256;
        if(absolute(dcy)<=5*RIDER_Q)camy-=dcy*(int32_t)back/256;
        int32_t dx=xx-prev->x,dy=yy-prev->y;
        if(absolute(dx)<=7*RIDER_Q && absolute(dy)<=9*RIDER_Q){
            bool moving_contact=false;
            if(s->grounded && !s->looping && s->x>=0){
                uint32_t pn=(uint32_t)s->x/(256u*RIDER_Q);
                int32_t pa,pb,py;
                for(unsigned slot=0;slot<2;slot++)if(rider_platform_at_q(s,pn,slot,&pa,&pb,&py)&&s->x>=pa&&s->x<=pb){moving_contact=true;break;}
            }
            if(!moving_contact){xx-=dx*(int32_t)back/256; yy-=dy*(int32_t)back/256;}
            int32_t da=(int32_t)(((uint32_t)a-(uint32_t)prev->angle+2048u)&4095u)-2048;
            if(!moving_contact && absolute(da)<=512) a-=da*(int32_t)back/256;
        }
    }
    int origin=screen_x(camx,0),upper_sky_limit,rail_top_limit;
    unsigned rock_phase=(unsigned)(camx-origin*(VIEW_DEN*RIDER_Q/VIEW_NUM))/48u; /* eighth-pixel */
    int lower_rail_limit=build_caches(s,camx,camy,origin,&upper_sky_limit,&rail_top_limit);
    bool simple_fill=true,body_facet=false;
    for(unsigned i=0;i<sizeof facet;i++){
        if(facet[i]!=255u)simple_fill=false;
        if(facet[i]<254u)body_facet=true;
    }
    uint16_t ends[16];unsigned nends=0;
    for(int x=0;x<W;++x)if(surface[x]==INT16_MAX)simple_fill=false;
    else if( ((x>0&&surface[x-1]==INT16_MAX)||(x+1<W&&surface[x+1]==INT16_MAX))){
        simple_fill=false;
        if(nends==16u){nends=W;break;}
        ends[nends++]=(uint16_t)x;
    }
    int sn=rider_sin4096(a),cs=rider_sin4096(a+1024);
    /* Slower, softer decorative motion. The blade remains dangerous even while
     * stationary; animation must never alter the collision geometry. */
    uint8_t saw_ai=(uint8_t)(s->tick_count/3u);
    int sin_rot=rider_sin256(saw_ai), cos_rot=rider_sin256((uint8_t)(saw_ai+64));
    int cx=screen_x(xx,camx),cy=screen_y(yy,camy);
    int fx=((xx-camx)-cx*(VIEW_DEN*RIDER_Q/VIEW_NUM))*4/(VIEW_DEN*RIDER_Q/VIEW_NUM);
    int fy=((yy-camy)-cy*(VIEW_DEN*RIDER_Q/VIEW_NUM))*4/(VIEW_DEN*RIDER_Q/VIEW_NUM);
    int trail_sn=sn,trail_cs=cs;
    if(!s->looping){
        int vx=s->vx,vy=s->vy;
        int ax=absolute(vx),ay=absolute(vy),norm=imax(ax,ay)+imin(ax,ay)*3/8;
        if(norm>0){trail_sn=vy*256/norm;trail_cs=vx*256/norm;}
    }
    /* Eight digits plus terminator, and one extra byte for bonus prefix. */
    char score[9];unsigned score_len=number(score,(uint32_t)(s->score>0?s->score:0));
    char high[9];number(high,(uint32_t)(s->best>0?s->best:0));
    int score_size=(int)score_len*18-4;
    char bonus[10];bonus[0]='+';number(bonus+1,s->pending_score);
    char diamond_count[9];
    int diamond_len=(int)number(diamond_count,(uint32_t)(s->diamonds>0?s->diamonds:0));
    uint8_t terrain_rows[2][TERRAIN_MAX_RUNS];
    terrain_rows[0][0]=127u;
    unsigned terrain_pos=0, terrain_len=1;
    for(int top=0;top<H;top+=STRIP_ROWS){
        for(int row=0;row<STRIP_ROWS;++row){
            int y=top+row;
            /* Keep the previous row current even when sky-only rows skip
             * painting. y=174..186 uses the implicit row 0. */
            if(y>=187){
                unsigned slot=(unsigned)(y-186)&1u;
                terrain_len=terrain_decode(terrain_rows[slot^1u],terrain_rows[slot],&terrain_pos);
            }
            uint16_t bg[2]={sky_color(y,(y&1)?3:0),sky_color(y,(y&1)?1:2)};
            uint16_t *dst=&strip[row*W];
            if(y<upper_sky_limit){
                /* Upper rows are uniform sky for this frame. This removes
                 * most geometry/texture conditionals from blank pixels. */
                /* Alias-safe aligned pair stores: one 32-bit store for two
                 * RGB565 pixels on the GC01's Cortex-M3. */
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
                uint32_t pair=(uint32_t)bg[0]|((uint32_t)bg[1]<<16);
                for(int x=0;x<W;x+=2)__builtin_memcpy(dst+x,&pair,sizeof pair);
#else
                for(int x=0;x<W;x+=2){dst[x]=bg[0];dst[x+1]=bg[1];}
#endif
                continue;
            }
            /* Separate sky/solid rows from rock rows. Hoist the silhouette
             * endpoints out of the inner pixel loop. For positive screen y,
             * h/YQ<=y is exactly equivalent to h<(y+1)*YQ, including negative h. */
            const int threshold=(y+1)*YQ;
            int uniform=(simple_fill && y>=lower_rail_limit-16 && y<208)?1:
                (y>=208 && y>lower_rail_limit && !body_facet)?-1:0;
            if(y<174){
                uint16_t ground=ground_color(y,0),shadow[2][9];
                if(uniform==1){
                    for(int x=0;x<W;++x)dst[x]=ground;
                    continue;
                }
                for(unsigned i=0;i<2u;++i){
                    unsigned g=(bg[i]>>5)&63u,bl=bg[i]&31u;
                    for(unsigned m=0;m<=8u;++m)
                        shadow[i][m]=(uint16_t)(((g*(32u-m)/32u)<<5)|(bl*(32u-m)/32u));
                }
                const int phase=origin&7;
                for(int x=0;x<W;){
                    int block=(x+phase)>>3,j=(x+phase)&7;
                    int f=backdrop[block],g=backdrop[block+1];
                    bool clear=y<imin(f,g),dark=y>=imax(f,g)+8;
                    int end=imin(W,x+8-j);
                    for(;x<end;++x,++j){
                        int h=surface[x],face=facet[facet_index(x,origin)],parity=x&1;
                        if((h!=INT16_MAX && h<threshold && face!=254) ||
                           (h==INT16_MAX && face<254 && y>=face))dst[x]=ground;
                        else if(clear)dst[x]=bg[parity];
                        else if(dark)dst[x]=shadow[parity][8];
                        else {int d=y-f-(g-f)*j/8;dst[x]=d>=0?shadow[parity][imin(8,d)]:bg[parity];}
                    }
                }
            }else{
                uint16_t ground_row[4],back_row[4];
                for(unsigned t=0;t<4u;++t){
                    ground_row[t]=ground_color(y,t*4u);
                    unsigned g=(ground_row[t]>>5)&63u,bl=ground_row[t]&31u;
                    back_row[t]=(uint16_t)(((g*7/8)<<5)|(bl*7/8));
                    if(y<184){
                        unsigned m=(unsigned)(y-174);
                        unsigned sg=((bg[0]>>5)&63u)*3/4,sb=(bg[0]&31u)*3/4;
                        g=sg*(10u-m)+((back_row[t]>>5)&63u)*m;
                        bl=sb*(10u-m)+(back_row[t]&31u)*m;
                        back_row[t]=(uint16_t)(((g/10u)<<5)|(bl/10u));
                    }
                }
                TerrainScan rock=terrain_scan(terrain_rows[y<187?0:((y-186)&1)],terrain_len,(unsigned)origin);
                /* Process each texture run without a per-pixel decoder branch. */
                for(int x=0;x<W;){
                    int boundary=x+(int)rock.left,end=imin(W,boundary);
                    uint16_t fg=ground_row[rock.shade],back=back_row[rock.shade];
                    bool body=uniform==1;
                    if(uniform){
                        uint16_t color=body?fg:back;
                        for(;x<end;++x)dst[x]=color;
                    }else for(;x<end;++x){
                        int h=surface[x],face=facet[facet_index(x,origin)];
                        body=h==INT16_MAX ? face<254 && y>=face :
                            h<threshold && face!=254 && (y<208 || h>=(y-11)*YQ);
                        dst[x]=body?fg:back;
                    }
                    terrain_next(&rock);
                    if(rock_phase && boundary<=W){
                        uint16_t a=dst[x-1],b=body?ground_row[rock.shade]:back_row[rock.shade];
                        /* Separate RGB565 lanes by ten bits; weighted sums cannot carry between lanes. */
                        unsigned aa=(a&31u)|((a&0x7e0u)<<5),bb=(b&31u)|((b&0x7e0u)<<5);
                        unsigned mix=(aa*(8u-rock_phase)+bb*rock_phase+0x1004u)>>3;
                        dst[x-1]=(uint16_t)((mix&31u)|((mix>>5)&0x7e0u)); /* both source colors have red=0 */
                    }
                }
            }
        }
        /* Calculate the local normal once per strip/column, not once per
         * pixel. Preserve exact Q3 distance and RGB565 blending. */
        if(top+STRIP_ROWS>rail_top_limit && top<=lower_rail_limit)for(int x=0;x<W;++x){
            int h=surface[x];
            if(h==INT16_MAX)continue;
            int hy=h/YQ;
            int lo=imax(imax(top,hy-16),upper_sky_limit),hi=imin(top+STRIP_ROWS-1,hy+16);
            if(lo>hi)continue;
            int l=x?surface[x-1]:h,r=x+1<W?surface[x+1]:h;
            if(l==INT16_MAX)l=h;
            if(r==INT16_MAX)r=h;
            int slope=absolute(r-l)/2;
            int norm=imax(8,slope)+imin(8,slope)*3/8;
            for(int y=lo;y<=hi;++y){
                int rank=absolute(y*YQ-h)*4/norm;
                if(rank<32){
                    uint16_t *dst=&strip[(y-top)*W+x];
                    uint16_t rail=rail_palette[rank],c=*dst;
                    *dst=(uint16_t)((rail&0xf800u)|imax(c&0x7e0u,rail&0x7e0u)|imax(c&31u,rail&31u));
                }
            }
        }
        paint_objects(top,s->phase==RIDER_CRASHED?-100:cx,cy,fx,fy,sn,cs,sin_rot,cos_rot,s->phase==RIDER_RUNNING&&s->throttle_active?(s->boost_ticks?2:1):0,s->tick_count,trail_sn,trail_cs,ends,nends);
        paint_crash(s,top,cx,cy);
        paint_hud(s,top,cx,cy,score,high,score_size,bonus,diamond_count,diamond_len);
        out(top,STRIP_ROWS,strip,context);
    }
}

void rider_render(const RiderState *s,const RiderState *prev,uint8_t alpha,RiderPixels out,void *context)
{
    RiderRenderPrevious snapshot;
    if(prev)rider_capture_previous(&snapshot,prev);
    rider_render_snapshot(s,prev?&snapshot:NULL,alpha,out,context);
}
