# v3.3.2 — exact arithmetic and flash fit

The v3.3.1 GitHub diagnostic measured 77,856 B payload and 3,352 B nominal spare SRAM. The unchanged maximum payload is 77,788 B (76 KiB firmware, 4-byte CRC, 32-byte reserve); history remains 33 KiB. Required saving: 68 B.

Only game core/render arithmetic changes: exact sign-folded floor division (one division), arithmetic floor-by-four with compiler assertion, packed independent RGB565 green/blue blending, unsigned bounds preserving endpoints, packed gap start/count metadata, reuse of surface properties and equivalent landing angle arithmetic. No texture/geometry data, mechanics, scoring, buttons, boost, partition, logger, LCD adapter or game saves changed.

Cortex-M3 Clang objects: -Os combined text 28,804 -> 28,355 B (449 B saved); -Oz 25,950 -> 25,687 B (263 B saved), identical BSS at each optimization level. These are object measurements, NOT the actual full GCC-linked firmware size. The nominal SRAM and flash/CRC gates are unchanged.

Both GCC and Clang direct v3.3.1 and historical v3.3 differential tests, full v3.3 release suite, and radiation logger tests passed locally. The direct comparisons covered 768,000 complete states, 42,868,224 surface queries, 145,152 platform/gem queries, 344,148 path queries and 570 exact full rendered frames per compiler. New projection tests covered 1,593,350 cases per compiler and the gap lists for all 84 templates. Matched desktop benchmark 0.259 -> 0.241 ms/frame, identical transfer count and pixels; no physical LCD timing measured.

The full upstream ARM GCC link, actual stack high-water, bootloader acceptance, physical performance and radiation timing are still unverified locally. GitHub must complete the unchanged fit gate and all tests before producing a diagnostic candidate. Do not rely on this experimental build for radiation safety.
