/* Exhaustive small and selected boundary checks for the actual projection. */
#include "../src/rider_render.c"
#include <assert.h>
#include <stdio.h>
static int32_t ref_floor(int32_t x,int32_t d)
{
    return x/d-(x<0 && x%d!=0);
}
int main(void)
{
    unsigned count=0;
    const int32_t ds[]={4,8,48,96,384};
    for(unsigned j=0;j<sizeof ds/sizeof *ds;++j){
        int32_t d=ds[j];
        for(int32_t x=-131072;x<=131072;++x){assert(floor_div(x,d)==ref_floor(x,d));++count;}
        for(int32_t i=0;i<2048;++i){
            assert(floor_div(INT32_MIN+i,d)==ref_floor(INT32_MIN+i,d));
            assert(floor_div(INT32_MAX-i,d)==ref_floor(INT32_MAX-i,d));count+=2;
        }
    }
    for(int32_t x=-131072;x<=131072;++x){assert(floor4(x)==ref_floor(x,4));++count;}
    puts("PASS: signed floor projection, including INT32_MIN/MAX");
    printf("%u exact floor comparisons\n",count);
    return 0;
}
