#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-gcc}
mapfile -t names < <(grep -hE '^(bool|void|int16_t|int32_t|uint8_t|uint32_t) rider_[a-zA-Z0-9_]+\(' baseline_v331/src/*.h | sed -E 's/^[^ ]+ (rider_[a-zA-Z0-9_]+)\(.*/\1/' | sort -u)
rename=(); for n in "${names[@]}"; do rename+=("-D$n=base_$n"); done
flags=(-std=c11 -O2 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer)
for n in rider_core rider_render; do "$cc" "${flags[@]}" "${rename[@]}" -c "baseline_v331/src/$n.c" -o "$work/$n.o"; done
"$cc" "${flags[@]}" -no-pie src/rider_core.c src/rider_render.c tests/test_fit_v332.c "$work/"*.o -o "$work/test"
UBSAN_OPTIONS=halt_on_error=1 ASAN_OPTIONS=detect_leaks=1 "$work/test"
