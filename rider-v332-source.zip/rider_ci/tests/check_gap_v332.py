from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
a=(root/'baseline_v331/src/rider_core.c').read_text()
b=(root/'src/rider_core.c').read_text()
def arr(s,n):
    return re.search(r'\b'+n+r'\[[^]]*\]\s*=\s*\{(.*?)\};',s,re.S)[1]
def nums(s,n): return list(map(int,re.findall(r'\d+',arr(s,n))))
def spans(s): return [tuple(map(int,g)) for g in re.findall(r'\{(\d+),(\d+),(\d+)\}',arr(s,'gaps'))]
a_idx,b_idx=nums(a,'gap_index'),nums(b,'gap_index')
assert len(a_idx)==len(b_idx)==84
old=nums(a,'gap_offsets'); aa,bb=spans(a),spans(b)
assert aa==bb
for i,j in zip(a_idx,b_idx):
    first=j&31;count=j>>5
    assert aa[old[i]:old[i+1]]==bb[first:first+count] if i else count==0
print('PASS: all 84 gap-span lists and their exact Q8 endpoint flags unchanged')
