#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cc=${CC:-gcc}
"$cc" -std=c11 -O2 -Wall -Wextra -Werror -fsanitize=address,undefined -no-pie src/rider_core.c tests/test_math_v332.c -o "$work/test"
UBSAN_OPTIONS=halt_on_error=1 "$work/test"
python3 tests/check_gap_v332.py
