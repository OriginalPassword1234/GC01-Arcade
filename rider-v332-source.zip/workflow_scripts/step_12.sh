set -euo pipefail
cd radpro
export RIDER_V33_MAX_BYTES=77788
printf "%s\n" "$RIDER_V33_MAX_BYTES" > "$GITHUB_WORKSPACE/dist/tests/V33_MAX_BYTES.txt"
bash rider_ci/select_size_profile.sh
raw=platform.io/.pio/build/fnirsi-gc01_apm32f103rb-en/firmware.bin
bytes=$(wc -c < "$raw")
test "$bytes" -le "$RIDER_V33_MAX_BYTES"
printf "Target cap: %s B; v3.3.2: %s B; spare after CRC: %s B; difference vs v3.0 measured ELF: %s B\n" "$RIDER_V33_MAX_BYTES" "$bytes" "$((77820-bytes))" "$((bytes-76244))" | tee "$GITHUB_WORKSPACE/dist/tests/FLASH_BUDGET.txt"
sha256sum -c "$GITHUB_WORKSPACE/dist/tests/size/SELECTED_BUILD_HASHES.txt"
