set -euo pipefail
mkdir -p "$GITHUB_WORKSPACE/dist/tests" "$GITHUB_WORKSPACE/dist/previews"
cd radpro/rider_ci
report="$GITHUB_WORKSPACE/dist/tests"
# The old test fixtures intentionally assert the old fixed opening route and
# 270-degree scoring. They remain in source for history; this gate runs the
# new release tests and exact differential tests on unchanged output.
CC=gcc bash tests/run_v33.sh 2>&1 | tee "$report/GCC_TEST_RESULTS.txt" &
gcc_pid=$!
CC=clang bash tests/run_v33.sh 2>&1 | tee "$report/CLANG_TEST_RESULTS.txt" &
clang_pid=$!
gcc_rc=0; clang_rc=0
wait "$gcc_pid" || gcc_rc=$?
wait "$clang_pid" || clang_rc=$?
printf 'GCC exit=%s; Clang exit=%s\n' "$gcc_rc" "$clang_rc"
((gcc_rc==0 && clang_rc==0))
# Compare the exact previous release against the lossless flash-fit source.
CC=gcc bash tests/run_fit_v331.sh 2>&1 | tee "$report/GCC_LOSSLESS_V331.txt" &
fit_gcc_pid=$!
CC=clang bash tests/run_fit_v331.sh 2>&1 | tee "$report/CLANG_LOSSLESS_V331.txt" &
fit_clang_pid=$!
fit_gcc_rc=0; fit_clang_rc=0
wait "$fit_gcc_pid" || fit_gcc_rc=$?
wait "$fit_clang_pid" || fit_clang_rc=$?
((fit_gcc_rc==0 && fit_clang_rc==0))

# Exact v3.3.1-to-v3.3.2 comparisons plus projection/gap checks.
for cc in gcc clang; do
  CC="$cc" bash tests/run_fit_v332.sh 2>&1 | tee "$report/${cc^^}_LOSSLESS_V332.txt"
  CC="$cc" bash tests/run_math_v332.sh 2>&1 | tee "$report/${cc^^}_MATH_V332.txt"
done
