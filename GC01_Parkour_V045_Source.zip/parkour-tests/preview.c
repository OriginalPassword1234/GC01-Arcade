/* Host-only screenshot writer: uses exact RGB565 compositor, not mock art. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "../platform.io/src/ui/parkour_draw.h"
static uint16_t pixels[320*240];
void pg_test_image(int x,int y,int w,int h,const uint16_t *in) {
    for(int j=0;j<h;j++)memcpy(pixels+(y+j)*320+x,in+j*w,(size_t)w*2);
}
void pg_test_rect(int x,int y,int w,int h,uint16_t col) {
    for(int j=y;j<y+h;j++)for(int i=x;i<x+w;i++)pixels[j*320+i]=col;
}
static void save(const char *name){
    FILE *f=fopen(name,"wb"); if(!f)exit(1);
    fprintf(f,"P6\n320 240\n255\n");
    for(int i=0;i<320*240;i++) {
        uint16_t c=pixels[i];
        unsigned char q[3]={ (unsigned char)(((c>>11)&31)*255/31),
                             (unsigned char)(((c>>5)&63)*255/63),
                             (unsigned char)((c&31)*255/31)};
        fwrite(q,1,3,f);
    }
    fclose(f);
}
int main(int argc,char **argv) {
    if(argc!=3)return 2;
    PG_Game g;pg_new(&g,12);
    if(argv[1][0]=='b') {
        /* Preview an actual 6th-room boss with a telegraphed charge. */
        for(int r=0;r<5;r++) {
            int er=r%3==0?21:3;
            g.x=(int16_t)((18*8-5)*16);
            g.y=(int16_t)((er*8-5)*16);
            pg_tick(&g,0);
        }
        if(g.room!=5)return 3;
        g.theme=1;
        g.x=66*16;g.y=(PG_H-30)*16;
        g.grounded=1;g.cameraY=PG_H-PG_VIEW_H;
        g.enemies[0].phase=1;g.enemies[0].cooldown=18;
    } else if(argv[1][0]=='v') {
        g.x=(18*8-7)*16;g.y=(21*8-22)*16;g.grounded=0;
        g.room=1;g.roomStyle=1;
        /* Build a real second room via actual transition instead. */
        PG_Game original;pg_new(&original,12);
        original.x=(18*8-8)*16;original.y=(20*8)*16;
        pg_tick(&original,0);
        if(original.room==1)g=original;
        g.x=88*16;g.y=45*16;g.cameraY=0;g.grounded=0;
    } else {
        g.x=60*16;g.y=138*16;g.grounded=1;g.cameraY=88;
        g.cells[21*PG_COLS+7]=PG_BOUNCE;
        g.cells[21*PG_COLS+10]=PG_BREAK;
        g.cells[21*PG_COLS+12]=PG_SPIKE;
    }
    pg_draw(&g,1);save(argv[2]);return 0;
}
