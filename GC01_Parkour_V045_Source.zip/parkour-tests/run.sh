#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
passes=0
for profile in full compact; do
  flags=()
  if [ "$profile" = compact ]; then flags=(-DPG_FLASH_COMPACT); fi
  for cc in gcc clang; do
    command -v "$cc" >/dev/null 2>&1 || continue
    for test in logic render; do
      sources=(platform.io/src/extras/parkour_logic.c "parkour-tests/test_${test}.c")
      if [ "$test" = render ]; then
        sources=(platform.io/src/extras/parkour_logic.c
                 platform.io/src/ui/parkour_draw.c
                 parkour-tests/test_render.c)
      fi
      "$cc" -std=c11 -O1 -g -Wall -Wextra -Werror \
        -DPG_DRAW_TEST "${flags[@]}" \
        -fsanitize=address,undefined -fno-omit-frame-pointer \
        "${sources[@]}" -o "$TMP/$profile-$test-$cc"
      echo "TEST: $profile $test $cc"
      ASAN_OPTIONS=detect_leaks=0 "$TMP/$profile-$test-$cc"
      passes=$((passes+1))
    done
  done
done
[ "$passes" -gt 0 ] || { echo 'No GCC/Clang test compiler available'; exit 1; }
echo "PASS: $passes sanitized native test executables"
