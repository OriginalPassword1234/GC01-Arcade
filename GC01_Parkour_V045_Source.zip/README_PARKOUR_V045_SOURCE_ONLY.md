# FNIRSI GC-01 Parkour Gauntlet 0.4.5 — harder parkour and boss encounter edition

**Source overlay only: this ZIP is NOT directly flashable.**

Hardware target: FNIRSI GC-01 / APM32F103RB / English display, Rad Pro **3.1.1** base.
PlatformIO env: `fnirsi-gc01_apm32f103rb-en`.

## Controls and gameplay

- LEFT/RIGHT: only move; no accidental attack, charge, or healing by holding a direction.
- UP: jump and wall-jump; hold UP when descending against a wall for up to 1.2 s of wall grip.
- DOWN: **only upon release**, a tap (< 0.46 s) triggers a 0.22 s parry (2 s cooldown); holding longer triggers a multi-target ground slam (2 s cooldown). Neither action fires on initial press. A slam has less per-target damage than the ordinary sword attack, to prevent overpowering single targets.
- Middle/OK: short tap sword attack; medium hold menu; long hold system shutdown. These paths retain Rad Pro integration.
- HP 100, regeneration 3 HP/s after 3 s without damage; no mana, dash, directional hold attacks, or directional hold healing.
- Randomized horizontal, vertical and mixed parkour rooms with elevated exits, wall gripping, one-way platforms, fragile ledges and hazards.
- **Harder rooms:** later horizontal rooms widen their traversable gaps (24 to 32 logical pixels), add carefully placed optional spikes, and use trickier upper platforms. Vertical rooms use staggered 5–6 tile ledges rather than 10–11 tile-wide easy walkways; successive ledges rise by 24 logical pixels (within the measured ~26.8 pixel maximum jump). The final door still has a deliberately reachable landing.
- **Occasional real boss encounters:** every sixth room has one larger (24×32 logical art) boss. Its two alternating attacks are telegraphed, a low projectile volley and a short charging rush, followed by a vulnerable recovery period. Normal sword attacks remain more effective during recovery; parry and jumping are useful. No boss health bar, no new button, no extra sprite atlas. The exit is visibly barred until the boss is defeated.
- Boss AI is separated from ordinary enemy behavior so normal enemies remain lightweight and movement-specific, and the same procedural effects/pixel-art atlas is shared.

## Distinct, recognizable graphics (0.4.5)

- Three-by-three-tile exit doors (instead of the previous confusing small boxes), with doorframe, inset panels, lintel, window and handle. Horizontal doors and elevated doors retain their physics and working transitions.
- Spring-style cyan bounce pads, cracked and fissured breakable blocks, triangular spikes, metal/stone platforms with visible underside supports.
- Rooftop buildings begin lower down the screen, exposing more sky and a large moon; the factory and cave retain their own palettes and details.
- **15-byte world-column decoration cache** cuts up to roughly 2,065 repeated hash calculations on a 20x13-tile full-screen redraw (performance estimate from loop counts, not hardware measurement).
- Large bosses use 2× nearest-neighbor scaling of the existing full-color pixel-art character, with an orange/red charge warning and cyan recovery glow. The door shows a red lock bar during a boss encounter and clears as soon as the boss falls.
- All graphics are generated within the existing tile compositor; no reduced-res gameplay graphics or new full-screen buffers.

## Graphics and performance

- Preserves the color pixel-art player/enemy sprites, three art themes, full-resolution native RGB565 tile output and indexed sprite compression; no deliberate reduction in game art quality.
- Removes background single-pixel noise in favor of stable skyline windows, factory pipework and clustered crystal formations.
- Bounded camera tracking in 24-row worlds, 13-row viewport; 512-byte tile framebuffer and dirty-tile selective redraw. The full-vs-dirty rendering tests confirm identical pixel output in their tested scenarios.
- Game state runs at fixed 50Hz and avoids floating-point physics. Boss attacks are deterministic/telegraphed, with compact state bits and no extra framebuffer. LCD frame throughput and jitter remain hardware-dependent.

## Rad Pro optimizations

- Keeps the already-stripped optional RNG UI/dice engine excluded; preserves pulse-derived `getRNGByte` used by USB. Removing the entire RNG subsystem would break a core device function and is not attempted.
- The stock chess engine and UI were **already excluded** by GC01_ARCADE; no additional flash can be credited to deleting them again. The ARM workflow checks linked symbols for unexpected chess/RNG-menu remnants. Removing the underlying USB RNG would be unsafe. These original exclusions and their linker flags are retained rather than claiming new fictitious savings.
- Removed an unreachable `shade` sprite-rendering mode (all callers used zero) and reused the same compact asset atlas for the boss. The measured extra linked ARM flash cost, if any, must be determined by GitHub's real build.
- Retains existing statistics and essential settings without changing saved-state layout. Adds target-only dead-section elimination flags (`-ffunction-sections`, `-fdata-sections`, `--gc-sections`) plus no-unwind-tables for smaller firmware if the toolchain has not already enabled them. Any actual savings must be established by the ARM build.
- The **matching workflow** tries full original UI fonts first; if over-size, it progressively substitutes pre-existing upstream 2-bit fonts for symbols, large digits and English small text, preserving glyph dimensions and coverage. Those optional Rad Pro UI font fallbacks may change text edge smoothness, never game artwork. The medium font stays unchanged because its 2-bit alternative is missing some engineering-unit letters.
- Measurement, tube, alarm, power, battery, USB, data-logging, calibration and flash-script sources are protected by preservation audit and must remain unchanged.

## Tests and building

`bash parkour-tests/run.sh` builds sanitized native GCC/Clang logic and pixel-for-pixel rendering tests, including both normal and compact legacy compile switches. Boss tests check both attack patterns, telegraphed recovery, relative damage, exit gating and dirty/full framebuffer equality across 182 frames. This is only a native test, **not an APM32 chip build or physical gameplay qualification**.

The GitHub workflow compiles the actual APM32 firmware and checks the **57,340-byte raw application limit** (strict, never increased), RAM, ELF target and signed-image CRC and metadata. Signed experimental `-install.bin` artifacts are uploaded **only if all software tests and size checks pass**. Separate raw diagnostics must never be flashed. Firmware and alarms must be validated on real hardware; compilation and signature do not establish measurement safety.

1. Upload `GC01_Parkour_V045_Source.zip` (unextracted) to the root of your `GC01-Arcade` repository.
2. Edit, **do not delete**, `.github/workflows/GC01_Dungeon_Prototype_Build.yml` and replace its complete content with the matching 0.4.5 workflow. Commit directly to `main`.
3. Actions -> `GC-01 Parkour Gauntlet 0.4.5 - build, verify and sign EXPERIMENTAL` -> `Run workflow` (new run, not Re-run jobs).
4. If successful, download `GC01-PARKOUR-V045-SIGNED-EXPERIMENTAL-UNTESTED`, review its memory and font-variant reports, and review the output before flashing. Keep known-working firmware for recovery.

## What remains unknown

The source passes host GCC/Clang sanitized tests. Exact ARM flash consumption, precise visual smoothness on ST7789, and correctness of non-game hardware features remain unverified until a real PlatformIO build and controlled hardware tests. If the build is oversized, the workflow refuses to sign. The optional Rad Pro 2-bit fonts can reduce instrument text edge smoothness but never alter game sprites.

## Boss behavior notes

- A boss appears in room 6, 12, 18, and so on. The first is intentionally placed in a mixed vertical room: defeat it below, then climb to the elevated door.
- The orange/rose ring means a rush/volley is being prepared; jump or parry. Two low projectiles are spaced vertically. Cyan eyes indicate recovery and a strong sword-damage window.
- Boss health is 14 hit points, but sword strikes deal 1 point outside recovery and 2 during recovery; a 1-damage ground slam has a crowd-control role, not dominant boss damage. The boss deals 16 contact damage; player regeneration remains slow.
- Although the code uses bounded fixed-point arithmetic and passes native tests, boss timings and visual readability remain experimental until tried on actual hardware.

## Known limitations / nonclaims

- **No full APM32 compile has been run locally.** It may exceed 57,340 raw bytes. The GitHub workflow keeps all game graphics and mechanics, attempts smaller *Rad Pro* UI fonts only if necessary, and refuses to sign an oversized image.
- No claim that all possible room seeds or every actual button-scanning edge case have been proven bug-free. Gameplay validation on hardware and confirmation of radiation alarms/calibration are essential.
