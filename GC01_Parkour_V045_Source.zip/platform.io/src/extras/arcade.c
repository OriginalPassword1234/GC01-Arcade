/* GC-01 Parkour Gauntlet 0.4. Game is isolated from Rad Pro measurements. */
#if defined(GC01_PARKOUR)
#include <stdbool.h>
#include <stdint.h>
#include "parkour_logic.h"
#include "game.h"
#include "../measurements/measurements.h"
#include "../peripherals/keyboard.h"
#include "../system/events.h"
#include "../system/power.h"
#include "../system/settings.h"
#include "../ui/parkour_draw.h"
#include "../ui/menu.h"
#include "../ui/view.h"

static PG_Game gauntlet;
static bool hasGame,active,forceDraw;
static MenuState gameMenuState;
static const Menu gameMenu;
static uint32_t nextSim,nextPaint;
static void showGauntlet(void);

static void leaveGauntlet(void) {
    active=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showGameMenu();
}
static void gameEvent(ViewEvent e) {
    if(e==EVENT_DRAW) {
        pg_draw(&gauntlet,forceDraw);
        forceDraw=false;
        return;
    }
    if(e==EVENT_KEY_GAME_EXIT)return;
    if(e==EVENT_KEY_GAME_MENU) {
        if(gauntlet.phase!=PG_DEAD)pg_toggle_pause(&gauntlet);
        requestViewUpdate();return;
    }
    if(e==EVENT_KEY_GAME_OK) {
        if(gauntlet.phase==PG_PAUSE) {
            if(gauntlet.menuChoice) {leaveGauntlet();return;}
            gauntlet.phase=PG_RUN;
        } else if(gauntlet.phase==PG_DEAD) {
            pg_new(&gauntlet,currentTick^0x81db3c2eu);
            forceDraw=true;
        } else pg_quick_attack(&gauntlet);
        requestViewUpdate();return;
    }
    if(gauntlet.phase==PG_PAUSE) {
        if(e==EVENT_KEY_GAME_UP||e==EVENT_KEY_GAME_DOWN) {
            gauntlet.menuChoice^=1u;
            requestViewUpdate();
        }
    }
}
static const char *option(menu_size_t i,MenuStyle *style) {
    *style=MENUSTYLE_SUBMENU;
    return i==0?"New Gauntlet":hasGame?"Continue":"Continue (unavailable)";
}
static void choose(menu_size_t i) {
    if(i==0) {pg_new(&gauntlet,currentTick^0x72fe931bu);hasGame=true;}
    else if(!hasGame)return;
    showGauntlet();
}
static const Menu gameMenu={
    STRING_GAME,&gameMenuState,2,option,choose,showSettingsMenu
};
static void showGauntlet(void) {
    active=true;forceDraw=true;
    nextSim=currentTick;nextPaint=currentTick;
    setKeyboardMode(KEYBOARD_MODE_GAME);
    showView(gameEvent);
}
void resetGame(void) {
    active=false;hasGame=false;forceDraw=true;
    selectMenuItem(&gameMenu,0);
}
void showGameMenu(void) {
    active=false;
    if(isKeyboardGameMode())setKeyboardMode(KEYBOARD_MODE_MENU);
    showMenu(&gameMenu);
}
void updateGame(void) {
    if(!active)return;
    if(!isPoweredOn()||!isKeyboardGameMode()) {active=false;return;}
    if(getAlertLevel()!=ALERTLEVEL_NONE) {
        active=false;
        setMeasurementView();
        return;
    }
    if(!isCurrentView(gameEvent)) {
        active=false;
        setKeyboardMode(KEYBOARD_MODE_MENU);
        return;
    }
    uint32_t now=currentTick;
    if(gauntlet.phase!=PG_RUN) {nextSim=now;return;}
    /* Fixed 20 ms physics. Maximum two steps per main-loop iteration:
     * never catch up a long rendering delay by starving measurement/USB work. */
    uint8_t steps=0;
    while((int32_t)(now-nextSim)>=20 && steps<2) {
        uint8_t held=0;
        if(isGameKeyHeld(KEY_LEFT))held|=PG_LEFT;
        if(isGameKeyHeld(KEY_RIGHT))held|=PG_RIGHT;
        if(isGameKeyHeld(KEY_UP))held|=PG_UP;
        if(isGameKeyHeld(KEY_DOWN))held|=PG_DOWN;
        pg_tick(&gauntlet,held);
        nextSim+=20;
        steps++;
    }
    if((int32_t)(now-nextSim)>120)nextSim=now;
    if((int32_t)(now-nextPaint)>=40) {
        /* Keep a stable 25 Hz deadline instead of drifting whenever the
         * display or main loop is a few milliseconds late. Skip frames,
         * never simulate/paint a long backlog at the cost of alarms. */
        nextPaint+=40;
        if((int32_t)(now-nextPaint)>80)nextPaint=now;
        requestViewUpdate();
    }
}
#endif
