#ifndef GC01_PARKOUR_DRAW_H
#define GC01_PARKOUR_DRAW_H
#include <stdbool.h>
#include "../extras/parkour_logic.h"
void pg_draw(const PG_Game *g,bool force);
#endif
