/* Parkour Gauntlet 0.4: 4bpp sprites composited in a 512-byte RGB565 tile.
 * No full-screen framebuffer. One drawImage transfer per changed tile.
 * MIT license. */
#if defined(GC01_PARKOUR) || defined(PG_DRAW_TEST)
#include <string.h>
#include "parkour_draw.h"
#include "parkour_art.h"
#if defined(PG_DRAW_TEST)
#include <stdint.h>
typedef uint16_t mr_color_t;
#define RGB(x) ((uint16_t)(((((x)>>19)&31u)<<11) | ((((x)>>10)&63u)<<5) | (((x)>>3)&31u)))
extern void pg_test_image(int x,int y,int w,int h,const mr_color_t *pixels);
extern void pg_test_rect(int x,int y,int w,int h,mr_color_t color);
#else
#include "draw.h"
#define RGB(x) mr_get_color(x)
extern mr_t mr;
#endif
#define SCREEN_TOP 32
#define PHYS_TILE 16
#define PIXELS 256

typedef struct {
    mr_color_t sky, sky2, distant, wall, edge, platform, shade;
    mr_color_t hazard, bounce, breakable, accent, hud;
} Theme;
static const Theme themes[3]={
 {RGB(0x142740),RGB(0x304a6b),RGB(0x253450),RGB(0x515d76),RGB(0x839db3),RGB(0x8d9da8),RGB(0x25384e),RGB(0xff675e),RGB(0x59e0c5),RGB(0xd9aa77),RGB(0xffd17d),RGB(0x0b172a)},
 {RGB(0x2c2537),RGB(0x49364a),RGB(0x383143),RGB(0x66555c),RGB(0xba9985),RGB(0xa48b71),RGB(0x372b36),RGB(0xffac4f),RGB(0x85e2d4),RGB(0xe9c08a),RGB(0xffd87b),RGB(0x221c2c)},
 {RGB(0x101f34),RGB(0x22354f),RGB(0x152944),RGB(0x334868),RGB(0x568aa4),RGB(0x6396ad),RGB(0x15293e),RGB(0xeb5f9b),RGB(0x65ddee),RGB(0xc68ee4),RGB(0xb5f7ff),RGB(0x0a1a2e)},
};
/* Dark outline, cape, armor, skin, hair, visor, energy, etc. */
static const mr_color_t spriteColor[16]={
  RGB(0x000000),RGB(0x101828),RGB(0x532f58),RGB(0x31799e),
  RGB(0x70d5df),RGB(0xedbc91),RGB(0x292841),RGB(0x202a3b),
  RGB(0xffcc63),RGB(0xf9f0d6),RGB(0x83eff0),RGB(0xb56c7a),
  RGB(0xef778b),RGB(0x718e9f),RGB(0xecb16e),RGB(0xd4f4fc)
};
static mr_color_t buffer[PIXELS]; /* 512 bytes SRAM */
static uint8_t dirty[PG_VISIBLE_TILES];
static PG_Game previous; /* snapshot for dirty-object tracking; ~400 bytes */
static uint8_t valid, overlayVisible, previousTheme;
static void rect(int x,int y,int w,int h,mr_color_t color) {
    if(x<0||y<0||w<=0||h<=0||x+w>320||y+h>240)return;
#if defined(PG_DRAW_TEST)
    pg_test_rect(x,y,w,h,color);
#else
    mr_set_fill_color(&mr,color);
    drawRectangle(&(mr_rectangle_t){(int16_t)x,(int16_t)y,(int16_t)w,(int16_t)h});
#endif
}
/* Pixel-art backdrop kept procedural: a moonlit city, illuminated factory
 * and crystalline cavern. A single shared floor/platform drawing path
 * avoids duplicating tile shading for each theme. */
/* Pixel-stable environment artwork: deterministic world-space geometry, no
 * sparkling random dots. Each theme has layered silhouettes and patterns. */
static __attribute__((noinline)) mr_color_t scenery(
        const PG_Game *g,int x,int y,uint8_t v,uint8_t band) {
    const Theme *t=&themes[g->theme];
    int rx=x&7,ry=y&7;
    uint8_t tile=g->cells[(y>>3)*PG_COLS+(x>>3)];
    if(tile==PG_STONE||tile==PG_BREAK) {
        if(tile==PG_BREAK && (rx==4||(ry==4&&(rx==3||rx==5))))return t->breakable;
        if(ry==0)return t->edge;
        if((rx==0&&ry>3)||(ry==5&&rx<4))return t->shade;
        if((v&7)==0 && rx==3&&ry==3)return t->accent;
        return t->wall;
    }
    if(tile==PG_PLATFORM) {
        if(ry==0)return t->accent;
        if(ry==1||(ry==3&&(rx==2||rx==5)))return t->edge;
        return ry<4?t->platform:t->shade;
    }
    mr_color_t bg=y<24?t->sky:y<57?t->sky2:t->distant;
    if(g->theme==0) {
        /* Rooftops: moon, layered skyline, window pairs; no pixel static. */
        int dx=x-121,dy=y-17;
        if(dx*dx+dy*dy<144)bg=t->edge;
        if(dx*dx+dy*dy<125)bg=RGB(0xf5dfb1);
        int tower=67+(int)((x/24*11u)%31u);
        if(y>=tower) {
            /* Rooflines stay coherent when the camera scrolls. */
            bg=t->shade;
            if(y==tower)bg=t->edge;
            if((x%24)==0||(x%24)==23)bg=t->distant;
            if((y%17)>=5&&(y%17)<=8 &&
               (((x%24)>=5&&(x%24)<=7)||((x%24)>=13&&(x%24)<=15)))
                bg=t->accent; /* architectural window clusters, no noise */
            if(y%32==1 && (x%24)>=2 && (x%24)<=21)bg=t->wall;
        }
        if(y>=146 && y<165 && (x%32)>=19 && (x%32)<=29)
            bg=t->distant; /* parapet shadow behind the player */
    } else if(g->theme==1) {
        /* Factory: smoke stacks, connected pipes, warning stripes. */
        if(y>=34+(band%19)&&(x%17)<9) {
            bg=t->distant;
            if(x%17==1||x%17==8)bg=t->wall;
            if(y%16==7&&(x%17)>1&&(x%17)<8)bg=t->edge;
        }
        if(y>=69+(v&7)) {
            bg=t->shade;
            if((y%24==2||y%24==3)&&x%5!=0)bg=t->wall;
        }
    } else {
        /* Broad rock faces and grouped diagonal crystal shards. */
        if(y<6+(band&15)&&(x%17)<13)bg=t->wall;
        if(y>=49+(band%23)&&(x%27)<5)bg=t->shade;
        int shardX=(x+9)%43,shardY=(y+13)%51;
        int ridge=13+shardY/5;
        if(shardY>=9&&shardY<=37 && shardX>=ridge-3&&shardX<=ridge+3) {
            bg=(shardX==ridge-3||shardX==ridge+3)?t->edge:t->wall;
            if(shardX>=ridge-1&&shardX<=ridge+1&&shardY<30)
                bg=t->bounce;
        }
        if(y>=95 && (y%41)==8 && (x%43)>7 && (x%43)<35)bg=t->edge;
    }
    if(tile==PG_SPIKE && ry>2 && ry>=7-((rx&3)<=1?(rx&3):3-(rx&3))*2)
        return t->hazard;
    if(tile==PG_BOUNCE && ry>=5)
        return (ry==5||rx==1||rx==6)?t->accent:t->bounce;
    if(tile==PG_EXIT) {
        /* A clearly outlined doorway with an illuminated center. */
        if(rx==1||rx==6||ry==0||ry==7)return t->accent;
        if((rx==3||rx==4)&&ry>2&&ry<6)return t->bounce;
        return t->shade;
    }
    return bg;
}
/* Opaque background first, then draw *only* sprites intersecting this 8x8
 * logical tile. The 0.4 compositor tested every enemy and projectile on
 * every pixel, even for tiles nowhere near an entity; that caused expensive
 * transfers and could make motion look uneven on the MCU. */
static void put_pixel(int tx,int ty,int x,int y,mr_color_t c) {
    int dx=x-tx,dy=y-ty;
    if((unsigned)dx>=8u || (unsigned)dy>=8u)return;
    int i=dy*32+dx*2;
    buffer[i]=c;buffer[i+1]=c;
    buffer[i+16]=c;buffer[i+17]=c;
}
static void sprite(int tx,int ty,int px,int py,uint8_t frame,uint8_t mirror,
                   uint8_t shade) {
    int xs=tx>px?tx-px:0;
    int ys=ty>py?ty-py:0;
    int xe=tx+8-px<12?tx+8-px:12;
    int ye=ty+8-py<16?ty+8-py:16;
    for(int sy=ys;sy<ye;sy++) {
        const uint8_t *row=pg_art_rows[pg_art_row_index[frame][sy]];
        for(int sx=xs;sx<xe;sx++) {
            int sourceX=mirror?11-sx:sx;
            uint8_t bits=row[sourceX>>1];
            uint8_t idx=(uint8_t)((sourceX&1)?bits&15u:bits>>4);
            if(idx) {
                if(shade && idx!=1)idx=(uint8_t)((idx==9||idx==8)?10:3);
                put_pixel(tx,ty,px+sx,py+sy,spriteColor[idx]);
            }
        }
    }
}
/* Reusable clipped ring effect: all three attacks/healing share one
 * pixel path instead of triplicating expensive draw code in firmware. */
static void effect_ring(int lx,int ly,int cx,int cy,int radius,
                        int low,int high,mr_color_t color,uint8_t sparkle) {
    if(cx+radius<lx || cx-radius>=lx+8 ||
       cy+radius<ly || cy-radius>=ly+8)return;
    for(int yy=0;yy<8;yy++)for(int xx=0;xx<8;xx++) {
        int dx=lx+xx-cx,dy=ly+yy-cy;
        int d2=dx*dx+dy*dy;
        if(d2>=low && d2<high && (!sparkle ||
           ((lx+xx+ly+yy+sparkle)&3)==0))
            put_pixel(lx,ly,lx+xx,ly+yy,color);
    }
}
static void render_tile(const PG_Game *g,int tx,int ty) {
    int lx=tx*8,ly=ty*8;
    int worldY=ly+g->cameraY;
    int worldRow=worldY>>3;
    uint8_t detail0=pg_detail((uint16_t)(tx+worldRow*PG_COLS),0);
    uint8_t detail1=pg_detail((uint16_t)(tx+(worldRow+1)*PG_COLS),0);
    uint8_t bands[8];
    for(int x=0;x<8;x++)bands[x]=pg_detail((uint16_t)((lx+x)/11+23),1);
    for(int y=0;y<8;y++)for(int x=0;x<8;x++) {
        int wy=worldY+y;
        mr_color_t c=scenery(g,lx+x,wy,
             ((wy>>3)==worldRow)?detail0:detail1,bands[x]);
        int i=y*32+x*2;
        buffer[i]=c;buffer[i+1]=c;
        buffer[i+16]=c;buffer[i+17]=c;
    }
    /* Short contact shadow grounds the character and gives a little more
     * depth without requiring another bitmap or a large alpha buffer. */
#if !defined(PG_FLASH_COMPACT)
    if(g->grounded) {
        int footX=g->x/16+PG_PLAYER_W/2;
        int footY=g->y/16+PG_PLAYER_H-g->cameraY;
        for(int dx=-5;dx<=5;dx++)
            if(dx*dx<25)
                put_pixel(lx,ly,footX+dx,footY,
                          themes[g->theme].shade);
    }
#endif
    for(uint8_t i=0;i<g->enemyCount;i++) {
        const PG_Enemy *e=&g->enemies[i];
        if(e->hp<=0 || (unsigned)e->kind>PG_BOSS)continue;
        int px=e->x/16,py=e->y/16-3-g->cameraY;
        if(px>=lx+8||px+12<=lx||py>=ly+8||py+16<=ly)continue;
        sprite(lx,ly,px,py,(uint8_t)(8+e->kind*2+((g->steps/10)&1)),0,0);
    }
    for(uint8_t i=0;i<PG_PROJECTILES;i++) {
        const PG_Bullet *b=&g->shots[i];
        if(!b->live)continue;
        int cx=b->x/16,cy=b->y/16-g->cameraY;
        if(cx+1<lx||cx-1>=lx+8||cy+1<ly||cy-1>=ly+8)continue;
        for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++)
            put_pixel(lx,ly,cx+x,cy+y,spriteColor[(x==0&&y==0)?15:10]);
    }
    if(g->effectTime) {
        int cy=(int)g->effectY-g->cameraY;
        int cx=g->effectX;
        if(g->effectKind==1) {
            cx=g->x/16+(g->facing?15:-4);
            cy=g->y/16+5-g->cameraY;
            effect_ring(lx,ly,cx,cy,7,18,55,
                        spriteColor[(g->effectTime&2)?8:9],0);
        } else {
            int r=g->effectKind==2?24-(g->effectTime):
                  g->effectKind==3?9:7;
            effect_ring(lx,ly,cx,cy,r,r*r-11,r*r+10,
                  spriteColor[g->effectKind==4?12:g->effectKind==3?10:8],0);
        }
    }
    uint8_t animation=0;
    if(g->gripping)animation=4;
    else if(g->attackTime)animation=5;
    else if(g->slamPending)animation=7;
    else if(!g->grounded)animation=g->vy<0?3:4;
    else if(g->vx>5||g->vx< -5)animation=(uint8_t)(1+(g->steps/5)%2);
    int px=g->x/16-1,py=g->y/16-2-g->cameraY;
    if(!(g->invulnerable&&(g->steps&2)) &&
       px<lx+8&&px+12>lx&&py<ly+8&&py+16>ly)
        sprite(lx,ly,px,py,animation,(uint8_t)!g->facing,0);
    /* Wall contact glow is constrained to the character, not random scenery. */
    if(g->gripping)
        put_pixel(lx,ly,px+(g->facing?11:0),py+6,spriteColor[10]);
    if(g->parryTime)
        effect_ring(lx,ly,g->x/16+5,g->y/16+7-g->cameraY,
                    10,83,111,spriteColor[10],0);
    if(g->downHold>=4 && g->downHold<250) {
        int r=g->downHold<23?8:11;
        effect_ring(lx,ly,g->x/16+5,g->y/16+7-g->cameraY,
                    r,r*r-8,r*r+8,spriteColor[8],0);
    }
#if defined(PG_DRAW_TEST)
    pg_test_image(lx*2,ly*2+SCREEN_TOP,16,16,buffer);
#else
    drawImage(&(mr_rectangle_t){(int16_t)(lx*2),(int16_t)(ly*2+SCREEN_TOP),16,16},buffer);
#endif
}
static void mark_rect(int x,int y,int w,int h) {
    if(x<0){w+=x;x=0;}
    if(y<0){h+=y;y=0;}
    if(x>=PG_W||y>=PG_VIEW_H||w<=0||h<=0)return;
    if(x+w>PG_W)w=PG_W-x;
    if(y+h>PG_VIEW_H)h=PG_VIEW_H-y;
    int left=x/8,top=y/8,right=(x+w-1)/8,bottom=(y+h-1)/8;
    for(int a=top;a<=bottom;a++)for(int b=left;b<=right;b++)dirty[a*PG_COLS+b]=1;
}
static void mark_player(const PG_Game *g) {
    int y=g->y/16-g->cameraY;
    mark_rect(g->x/16-1,y-2,12,16);
    if(g->grounded)mark_rect(g->x/16,y+PG_PLAYER_H,PG_PLAYER_W,1);
}
static void mark_fx(const PG_Game *g) {
    int y=g->y/16-g->cameraY;
    if(g->effectTime) {
        int cx=g->effectKind==1?g->x/16+(g->facing?15:-4):g->effectX;
        int cy=g->effectKind==1?y+5:(int)g->effectY-g->cameraY;
        int r=g->effectKind==2?24:12;
        mark_rect(cx-r,cy-r,2*r+1,2*r+1);
    }
    if(g->parryTime||g->downHold>=4)
        mark_rect(g->x/16-8,y-8,26,32);
}
static void mark_changes(const PG_Game *old,const PG_Game *g) {
    /* Invalidate only changed objects. Static enemies, idle character and
     * scenery incur zero sprite transfers between animation frames. */
    int a=(old->attackTime!=0),b=(g->attackTime!=0);
    if(old->x/16!=g->x/16||old->y/16!=g->y/16||
       old->facing!=g->facing||old->gripping!=g->gripping||
       old->grounded!=g->grounded||old->slamPending!=g->slamPending||
       a!=b||((old->steps/5)&1)!=((g->steps/5)&1)||
       (old->invulnerable && (old->steps&2)) !=
         (g->invulnerable && (g->steps&2))||
       ((old->vy<0)!=(g->vy<0)) ||
       ((old->vx>5||old->vx< -5)!=(g->vx>5||g->vx< -5))) {
        mark_player(old);mark_player(g);
    }
    if(old->effectTime!=g->effectTime||old->effectKind!=g->effectKind||
       old->effectX!=g->effectX||old->effectY!=g->effectY||
       old->parryTime!=g->parryTime||old->downHold!=g->downHold) {
        mark_fx(old);mark_fx(g);
    }
    uint8_t frameChanged=(uint8_t)(((old->steps/10)&1)!=((g->steps/10)&1));
    for(uint8_t i=0;i<PG_ENEMIES;i++) {
        const PG_Enemy *a=&old->enemies[i],*b=&g->enemies[i];
        if(a->x!=b->x||a->y!=b->y||a->hp!=b->hp||a->kind!=b->kind||
           (frameChanged&&(a->hp>0||b->hp>0))) {
            if(i<old->enemyCount && a->hp>0)
                mark_rect(a->x/16,a->y/16-3-old->cameraY,12,16);
            if(i<g->enemyCount && b->hp>0)
                mark_rect(b->x/16,b->y/16-3-g->cameraY,12,16);
        }
    }
    for(uint8_t i=0;i<PG_PROJECTILES;i++) {
        const PG_Bullet *a=&old->shots[i],*b=&g->shots[i];
        if(a->live!=b->live||a->x!=b->x||a->y!=b->y) {
            if(a->live)mark_rect(a->x/16-1,a->y/16-1-old->cameraY,3,3);
            if(b->live)mark_rect(b->x/16-1,b->y/16-1-g->cameraY,3,3);
        }
    }
}
static void bar(int x,int y,uint8_t value,mr_color_t fill,mr_color_t shade) {
    rect(x,y,154,14,RGB(0x040d19));
    rect(x+2,y+2,150,10,shade);
    int width=(int)value*150/100;
    if(width)rect(x+2,y+2,width,10,fill);
    if(width>1)rect(x+2,y+2,width,2,RGB(0xffe5df));
}
static const uint16_t nums[10]={0x7b6f,0x2c97,0x73e7,0x73cf,0x5bc9,0x79cf,0x79ef,0x7292,0x7bef,0x7bcf};
static const uint16_t word[26]={0x2bed,0x6bae,0x3923,0x6b6e,0x79a7,0x79a4,0x396b,0x5bed,0x7497,0x126a,0x5bad,0x4927,0x5fed,0x5ffd,0x2b6a,0x6ba4,0x2b7b,0x6bad,0x388e,0x7492,0x5b6f,0x5b6a,0x5bfd,0x5aad,0x5a92,0x72a7};
static void text(const char *s,int x,int y,int scale,mr_color_t c) {
    for(;*s;s++,x+=4*scale){
        uint16_t p=(*s>='0'&&*s<='9')?nums[*s-'0']:
                   (*s>='A'&&*s<='Z')?word[*s-'A']:0;
        for(int row=0;row<5;row++)for(int col=0;col<3;col++)
            if(p&(1u<<(14-row*3-col)))rect(x+col*scale,y+row*scale,scale,scale,c);
    }
}
static void number(uint32_t value,int x,int y,mr_color_t c) {
    char out[12];int n=0;
    do {out[n++]=(char)('0'+value%10u);value/=10u;}while(value&&n<11);
    for(int i=0;i<n/2;i++){char tmp=out[i];out[i]=out[n-1-i];out[n-1-i]=tmp;}
    out[n]=0;text(out,x,y,2,c);
}
static void hud_stats(const PG_Game *g) {
    const Theme *t=&themes[g->theme];
    rect(232,1,88,29,t->hud);
    text("R",237,5,2,t->accent);number(g->room+1u,251,5,RGB(0xf7e4c5));
    number(g->score,237,18,RGB(0xf7e4c5));
}
static void cooldown_icons(const PG_Game *g) {
    const Theme *t=&themes[g->theme];
    rect(178,4,52,25,t->hud);
    rect(179,6,22,19,g->parryCooldown?RGB(0x354559):RGB(0x1b798a));
    rect(205,6,22,19,g->slamCooldown?RGB(0x354559):RGB(0xa56549));
    text("P",184,9,2,RGB(0xf6eddc));
    text("S",210,9,2,RGB(0xf6eddc));
}
static void hud(const PG_Game *g) {
    const Theme *t=&themes[g->theme];
    rect(0,0,320,SCREEN_TOP,t->hud);
    rect(0,SCREEN_TOP-2,320,2,t->edge);
    rect(4,9,12,11,RGB(0xf14e65));
    rect(7,18,6,4,RGB(0xf14e65));
    bar(20,7,g->hp,RGB(0xf05a6b),RGB(0x511d32));
    cooldown_icons(g);
    hud_stats(g);
}
static void overlay(const PG_Game *g) {
    const Theme *t=&themes[g->theme];
    rect(42,77,236,100,t->hud);
    rect(42,77,236,3,t->accent);
    if(g->phase==PG_PAUSE) {
        text("PAUSED",75,93,4,RGB(0xf2e5d4));
        text("RESUME",85,132,2,g->menuChoice==0?t->accent:RGB(0x8c9ba8));
        text("EXIT",85,153,2,g->menuChoice==1?t->accent:RGB(0x8c9ba8));
    } else {
        text("GAME OVER",56,93,3,RGB(0xff738a));
        text("TAP RESTART",69,140,2,t->accent);
    }
}
void pg_draw(const PG_Game *g,bool force) {
    if(!g)return;
    if(!valid||previousTheme!=g->theme||previous.room!=g->room||
       (overlayVisible&&g->phase==PG_RUN)||previous.cameraY!=g->cameraY)force=true;
    memset(dirty,force?1:0,sizeof(dirty));
    if(!force){
        for(unsigned i=0;i<PG_TILES;i++)if(previous.cells[i]!=g->cells[i])
            mark_rect((int)(i%PG_COLS)*8,(int)(i/PG_COLS)*8-g->cameraY,8,8);
        mark_changes(&previous,g);
    }
    for(int ty=0;ty<PG_ROWS;ty++)for(int tx=0;tx<PG_COLS;tx++)
        if(dirty[ty*PG_COLS+tx])render_tile(g,tx,ty);
    if(force)hud(g);
    else {
        if(previous.hp!=g->hp)
            bar(20,7,g->hp,RGB(0xf05a6b),RGB(0x511d32));
        if((!previous.parryCooldown)!=(!g->parryCooldown) ||
           (!previous.slamCooldown)!=(!g->slamCooldown))
            cooldown_icons(g);
        if(previous.score!=g->score||previous.room!=g->room)
            hud_stats(g);
    }
    if(g->phase!=PG_RUN && (force||!overlayVisible||previous.phase!=g->phase||previous.menuChoice!=g->menuChoice))overlay(g);
    overlayVisible=g->phase!=PG_RUN;
    valid=1;previousTheme=g->theme;
    memcpy(&previous,g,sizeof(previous));
}
#endif
