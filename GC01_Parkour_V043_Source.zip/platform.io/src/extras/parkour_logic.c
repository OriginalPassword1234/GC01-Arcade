/* Parkour Gauntlet 0.4.3. Fixed 50 Hz, all integer arithmetic; MIT. */
#include "parkour_logic.h"
#include <string.h>

#define FP 16
#define SPEED 24
#define JUMP (-68)
#define GRAVITY 5
#define FALL_MAX 72
#define DOWN_LONG 23        /* >= 460 ms, only on RELEASE */
#define PARRY_COOLDOWN 100 /* 2 s */
#define SLAM_COOLDOWN 100

static uint32_t rnd(PG_Game *g) {
    uint32_t x=g->rng;
    x^=x<<13;x^=x>>17;x^=x<<5;
    return g->rng=x?x:0x9e3779b9u;
}
uint8_t pg_detail(uint16_t tile,uint8_t salt) {
    uint32_t x=(uint32_t)tile*0x45d9f3bu+(uint32_t)salt*0x119de1f3u;
    x^=x>>16;x*=0x45d9f3bu;
    return (uint8_t)(x>>24);
}
static uint8_t tile(const PG_Game *g,int x,int y) {
    if(x<0||x>=PG_W||y<0)return PG_STONE;
    if(y>=PG_H)return PG_AIR;
    return g->cells[(y>>3)*PG_COLS+(x>>3)];
}
static uint8_t solid(uint8_t t) {return t==PG_STONE||t==PG_BREAK;}
static uint8_t collides(const PG_Game *g,int16_t x,int16_t y) {
    if(x<0||x>(PG_W-PG_PLAYER_W)*FP||y<0)return 1;
    int xl=x/FP,yt=y/FP;
    int xr=((int32_t)x+PG_PLAYER_W*FP-1)/FP;
    int yb=((int32_t)y+PG_PLAYER_H*FP-1)/FP;
    /* The player is wider/taller than an 8px map tile. Checking only
     * corners can miss a central 8px obstacle inside a 3-tile overlap. */
    for(int row=yt>>3;row<=yb>>3;row++)
        for(int col=xl>>3;col<=xr>>3;col++)
            if(solid(tile(g,col<<3,row<<3)))return 1;
    return 0;
}
static uint8_t land_oneway(const PG_Game *g,int16_t oy,int16_t ny,int16_t *surface,uint8_t *bounce) {
    if(ny<=oy)return 0;
    int32_t oldBottom=(int32_t)oy+PG_PLAYER_H*FP;
    int32_t newBottom=(int32_t)ny+PG_PLAYER_H*FP;
    int32_t top=((oldBottom+8*FP-1)/(8*FP))*(8*FP);
    if(newBottom<=top||top>=PG_H*FP)return 0;
    int start=(g->x/FP)>>3;
    int end=(((int32_t)g->x+PG_PLAYER_W*FP-1)/FP)>>3;
    for(int tx=start;tx<=end;tx++) {
        uint8_t t=tile(g,tx*8,(int)top/FP);
        if(t==PG_PLATFORM||t==PG_BOUNCE) {
            *surface=(int16_t)(top-PG_PLAYER_H*FP);
            *bounce=(uint8_t)(t==PG_BOUNCE);
            return 1;
        }
    }
    return 0;
}
static void place(PG_Game *g,int row,int a,int b,uint8_t material) {
    if(row<0||row>=PG_WORLD_ROWS)return;
    if(a<0)a=0;
    if(b>=PG_COLS)b=PG_COLS-1;
    for(int x=a;x<=b;x++)g->cells[row*PG_COLS+x]=material;
}
static void make_room(PG_Game *g) {
    memset(g->cells,PG_AIR,sizeof(g->cells));
    memset(g->enemies,0,sizeof(g->enemies));
    memset(g->shots,0,sizeof(g->shots));
    g->theme=(uint8_t)((g->room/2u)%3u);
    g->roomStyle=(uint8_t)(g->room%3u); /* horizontal, vertical, mixed */
    uint8_t variation=(uint8_t)(rnd(g)%3u);
    place(g,22,0,19,PG_STONE);
    place(g,23,0,19,PG_STONE);
    if(g->roomStyle==0) {
        /* The entry and exit remain connected by proven ordinary jump arcs. */
        if(variation==0) {
            place(g,22,7,9,PG_AIR);place(g,23,7,9,PG_AIR);
            place(g,19,6,10,PG_PLATFORM);
        } else if(variation==1) {
            place(g,18,5,9,PG_PLATFORM);place(g,18,12,16,PG_PLATFORM);
            g->cells[21*PG_COLS+11]=PG_SPIKE;
        } else {
            place(g,21,7,7,PG_BOUNCE);
            place(g,18,10,15,PG_PLATFORM);
            g->cells[21*PG_COLS+14]=PG_SPIKE;
        }
        g->cells[21*PG_COLS+19]=PG_EXIT;
    } else {
        /* Ascending overlapping ledges, each 16-24 pixels above the last.
         * No random unverified jumps; height is achievable with a held jump.
         * Tall rooms reuse the same tiles and sprites as horizontal rooms. */
        place(g,19,2,11,PG_PLATFORM);
        place(g,16,7,17,PG_PLATFORM);
        place(g,13,3,13,PG_PLATFORM);
        place(g,10,7,17,PG_PLATFORM);
        place(g,7,3,13,PG_PLATFORM);
        place(g,4,8,18,PG_PLATFORM);
        /* The exit is on an elevated ledge, not at ground level. */
        g->cells[3*PG_COLS+17]=PG_EXIT;
        if(variation==1) {
            place(g,18,14,14,PG_STONE);
            place(g,17,14,14,PG_STONE);  /* climbable wall section */
            g->cells[12*PG_COLS+5]=PG_BREAK;
        } else if(variation==2) {
            g->cells[18*PG_COLS+5]=PG_BOUNCE;
            g->cells[12*PG_COLS+12]=PG_SPIKE;
            g->cells[9*PG_COLS+9]=PG_BREAK;
        }
        if(g->roomStyle==2) {
            place(g,16,2,5,PG_PLATFORM);
            place(g,10,1,4,PG_PLATFORM);
        }
    }
    g->enemyCount=(uint8_t)(1+(g->room>2)+(g->room>6));
    for(uint8_t i=0;i<g->enemyCount;i++) {
        PG_Enemy *e=&g->enemies[i];
        e->kind=(int8_t)((g->room%6==5&&i==0)?PG_BOSS:(rnd(g)%3u));
        e->hp=(int8_t)(e->kind==PG_BOSS?7:e->kind==PG_FLYER?1:3);
        e->x=(int16_t)((84+i*23)*FP);
        e->y=(int16_t)((PG_H-(e->kind==PG_FLYER?45:30)-
                          (g->roomStyle&&i>0?i*24:0))*FP);
        e->cooldown=(uint8_t)(25+i*20);
    }
    g->x=12*FP;g->y=(PG_H-30)*FP;g->vx=0;g->vy=0;
    g->cameraY=PG_H-PG_VIEW_H;g->grounded=1;
    g->coyote=0;g->jumpBuffer=0;g->previousInput=0;
    g->gripLeft=60;g->gripping=0;g->wallLock=0;
    g->downHold=0;g->slamPending=0;g->upHold=0;g->upWallArmed=0;
    g->parryTime=0;g->parryUsed=0;g->parryCooldown=0;g->slamCooldown=0;
    g->effectTime=0;g->attackTime=0;g->breakTimer=0;g->breakIndex=0;
}
void pg_new(PG_Game *g,uint32_t seed) {
    memset(g,0,sizeof(*g));
    g->rng=seed?seed:0x4deca77bu;
    g->hp=100;g->phase=PG_RUN;g->facing=1;
    make_room(g);
}
void pg_toggle_pause(PG_Game *g) {
    if(g->phase==PG_PAUSE)g->phase=PG_RUN;
    else if(g->phase==PG_RUN){g->phase=PG_PAUSE;g->menuChoice=0;}
}
static void impact(PG_Game *g,int power,int reach,uint8_t radial) {
    for(uint8_t i=0;i<g->enemyCount;i++) {
        PG_Enemy *e=&g->enemies[i];
        if(e->hp<=0)continue;
        int dx=(int)e->x/FP+6-g->x/FP-PG_PLAYER_W/2;
        int dy=(int)e->y/FP+6-g->y/FP-PG_PLAYER_H/2;
        uint8_t hit;
        if(radial)hit=(uint8_t)(dx>=-reach&&dx<=reach&&dy>=-19&&dy<=19);
        else hit=(uint8_t)(dy>-20&&dy<20 &&
            (g->facing?(dx>=-3&&dx<reach):(dx<=3&&dx>-reach)));
        if(!hit)continue;
        e->hp=(int8_t)(e->hp-power);
        if(e->hp<=0)g->score+=20;
        else {
            int displacement=dx>=0?4:-4;
            int newX=e->x+displacement*FP;
            if(newX>=0&&newX<=148*FP)e->x=(int16_t)newX;
        }
    }
    g->effectX=(uint8_t)(g->x/FP+PG_PLAYER_W/2);
    g->effectY=(uint8_t)(g->y/FP+PG_PLAYER_H/2);
    g->effectTime=radial?15:7;
    g->effectKind=radial?2:1;
    if(!radial)g->attackTime=6;
}
void pg_quick_attack(PG_Game *g) {
    if(g->phase==PG_DEAD){pg_new(g,g->rng^0x8c67a0d5u);return;}
    if(g->phase==PG_PAUSE){g->phase=PG_RUN;return;}
    if(g->phase==PG_RUN && !g->attackTime)impact(g,2,21,0);
}
static void slam_land(PG_Game *g) {
    if(!g->slamPending)return;
    g->slamPending=0;
    impact(g,1,23,1);          /* several enemies, less per-target damage */
    int footX=g->x/FP+PG_PLAYER_W/2;
    int footY=g->y/FP+PG_PLAYER_H+1;
    if(footX>=0&&footX<PG_W&&footY>=0&&footY<PG_H) {
        int index=(footY>>3)*PG_COLS+(footX>>3);
        if(g->cells[index]==PG_BREAK)g->cells[index]=PG_AIR;
    }
}
/* Return true if a successful, timed parry deflects this hit. */
static uint8_t hit_player(PG_Game *g,uint8_t damage) {
    if(g->phase!=PG_RUN)return 0;
    if(g->parryTime && !g->parryUsed) {
        g->parryUsed=1;g->invulnerable=12;g->score+=5;
        g->effectTime=9;g->effectKind=3;
        g->effectX=(uint8_t)(g->x/FP+5);g->effectY=(uint8_t)(g->y/FP+7);
        return 1;
    }
    if(g->invulnerable)return 0;
    g->hp=g->hp>damage?(uint8_t)(g->hp-damage):0;
    g->hurtClock=0;g->invulnerable=25;
    g->effectTime=10;g->effectKind=4;
    if(!g->hp)g->phase=PG_DEAD;
    return 0;
}
static void move_axis(PG_Game *g,int16_t amount,uint8_t vertical) {
    int16_t remaining=amount;
    while(remaining) {
        int16_t d=remaining>FP?FP:remaining< -FP?-FP:remaining;
        remaining=(int16_t)(remaining-d);
        int16_t oldX=g->x,oldY=g->y;
        int16_t nx=(int16_t)(oldX+(vertical?0:d));
        int16_t ny=(int16_t)(oldY+(vertical?d:0));
        int16_t surface=0;uint8_t bounce=0;
        if(vertical && land_oneway(g,oldY,ny,&surface,&bounce)) {
            g->y=surface;g->grounded=(uint8_t)!bounce;
            g->vy=bounce?-83:0;
            if(g->grounded)slam_land(g);
            return;
        }
        if(!collides(g,nx,ny)) {
            g->x=nx;g->y=ny;
        } else {
            if(vertical) {
                if(d>0) {
                    int32_t bottom=(int32_t)ny+PG_PLAYER_H*FP-1;
                    g->y=(int16_t)((bottom/(8*FP))*(8*FP)-PG_PLAYER_H*FP);
                    g->grounded=1;
                } else g->y=(int16_t)(ny<0?0:((ny/(8*FP))+1)*(8*FP));
                g->vy=0;
                if(g->grounded)slam_land(g);
            } else {
                if(nx<0)g->x=0;
                else if(nx>(PG_W-PG_PLAYER_W)*FP)g->x=(PG_W-PG_PLAYER_W)*FP;
                else if(d>0)
                    g->x=(int16_t)((((int32_t)nx+PG_PLAYER_W*FP-1)/(8*FP))*(8*FP)-PG_PLAYER_W*FP);
                else g->x=(int16_t)((nx/(8*FP)+1)*(8*FP));
                g->vx=0;
            }
            return;
        }
    }
}
static uint8_t wall_side(const PG_Game *g) {
    /* Left/right solid contact only, not ground; shared by grip and jump. */
    if(collides(g,(int16_t)(g->x-16),g->y))return 1;
    if(collides(g,(int16_t)(g->x+16),g->y))return 2;
    return 0;
}
static void update_camera(PG_Game *g) {
    if(g->roomStyle==0) {g->cameraY=PG_H-PG_VIEW_H;return;}
    int camera=g->cameraY;
    int cy=g->y/FP+PG_PLAYER_H/2;
    int target=camera;
    if(cy<camera+37)target=cy-37;
    else if(cy>camera+72)target=cy-72;
    if(target<0)target=0;
    if(target>PG_H-PG_VIEW_H)target=PG_H-PG_VIEW_H;
    int diff=target-camera;
    if(diff>2)diff=2;
    if(diff< -2)diff=-2;
    g->cameraY=(uint8_t)(camera+diff);
}
static uint8_t reached_exit(const PG_Game *g) {
    int x=g->x/FP,y=g->y/FP;
    /* Exit is solidly placed on a platform; any overlap opens next room. */
    return (uint8_t)(tile(g,x+2,y+3)==PG_EXIT ||
                     tile(g,x+PG_PLAYER_W-2,y+3)==PG_EXIT ||
                     tile(g,x+2,y+PG_PLAYER_H-2)==PG_EXIT ||
                     tile(g,x+PG_PLAYER_W-2,y+PG_PLAYER_H-2)==PG_EXIT);
}
static void player_step(PG_Game *g,uint8_t held) {
    uint8_t pressed=(uint8_t)(held&~g->previousInput);
    uint8_t released=(uint8_t)(g->previousInput&~held);
    g->previousInput=held;
    /* Down is edge-triggered on RELEASE. No short action while charging. */
    if(pressed&PG_DOWN)g->downHold=0;
    if(held&PG_DOWN) {if(g->downHold<250)g->downHold++;}
    if(released&PG_DOWN) {
        if(g->downHold>=DOWN_LONG) {
            if(!g->slamCooldown) {
                g->slamCooldown=SLAM_COOLDOWN;
                g->slamPending=1;
                if(g->grounded)slam_land(g);
                else if(g->vy<42)g->vy=42;
            }
        } else if(g->downHold && !g->parryCooldown) {
            g->parryTime=11;g->parryUsed=0;g->parryCooldown=PARRY_COOLDOWN;
            g->effectX=(uint8_t)(g->x/FP+5);
            g->effectY=(uint8_t)(g->y/FP+7);
        }
        g->downHold=0;
    }
    if(pressed&PG_UP) {
        g->jumpBuffer=6;
        g->upHold=0;
        g->upWallArmed=(uint8_t)(!g->grounded && !g->coyote &&
            wall_side(g)!=0);
    }
    if(held&PG_UP && g->upHold<250)g->upHold++;
    if(released&PG_UP) {
        if(g->upWallArmed && g->upHold<=11 && !g->grounded && !g->wallLock) {
            uint8_t side=wall_side(g);
            if(side) {
                g->vy=JUMP;g->vx=(int16_t)(side==1?45:-45);
                g->wallLock=5;g->coyote=0;g->gripping=0;
            }
        }
        g->upWallArmed=0;g->upHold=0;
    }
    if(g->jumpBuffer)g->jumpBuffer--;
    if(g->grounded) {g->coyote=5;g->gripLeft=60;}
    else if(g->coyote)g->coyote--;
    if(g->jumpBuffer && (g->grounded||g->coyote)) {
        g->vy=JUMP;g->grounded=0;g->coyote=0;g->jumpBuffer=0;
    }
    int target=0;
    if((held&PG_LEFT)&&!(held&PG_RIGHT))target=-SPEED;
    if((held&PG_RIGHT)&&!(held&PG_LEFT))target=SPEED;
    if(g->wallLock)g->wallLock--;
    else {
        if(target==0)g->vx=(int16_t)(g->vx/2);
        else {
            if(g->vx<target) {g->vx+=5;if(g->vx>target)g->vx=target;}
            else if(g->vx>target) {g->vx-=5;if(g->vx<target)g->vx=target;}
        }
        if(target<0)g->facing=0;
        else if(target>0)g->facing=1;
    }
    if(!(held&PG_UP)&&g->vy< -30)g->vy=(int16_t)(g->vy+10);
    g->vy=(int16_t)(g->vy+GRAVITY);
    uint8_t side=0;
    if(!g->grounded && g->vy>0)side=wall_side(g);
    /* Up is not a long-press attack: gripping requires wall contact and
     * descent. An ordinary long jump has no unintended secondary action. */
    g->gripping=0;
    if(side && (held&PG_UP) && g->upHold>=6 && g->gripLeft && !g->wallLock) {
        if(g->vy>5)g->vy=5;
        g->gripLeft--;g->gripping=1;
    } else if(side && g->vy>22)g->vy=22;
    if(g->slamPending&&g->vy<80)g->vy=80;
    if(g->vy>FALL_MAX && !g->slamPending)g->vy=FALL_MAX;
    g->grounded=0;
    move_axis(g,g->vx,0);
    move_axis(g,g->vy,1);
    if(g->grounded && !g->breakTimer) {
        int feet=g->y/FP+PG_PLAYER_H;
        int cx=g->x/FP+PG_PLAYER_W/2;
        if(tile(g,cx,feet)==PG_BREAK) {
            g->breakIndex=(uint16_t)((feet>>3)*PG_COLS+(cx>>3));
            g->breakTimer=20; /* crumble 0.4s after stepping on it */
        }
    }
    int footX=g->x/FP+PG_PLAYER_W/2;
    int footY=g->y/FP+PG_PLAYER_H-1;
    if(g->vy>=0 && tile(g,footX,footY)==PG_BOUNCE) {
        g->vy=-83;g->grounded=0;
    }
    if(tile(g,g->x/FP+2,footY)==PG_SPIKE ||
       tile(g,g->x/FP+PG_PLAYER_W-2,footY)==PG_SPIKE)
        hit_player(g,18);
    if(g->y>(PG_H-PG_PLAYER_H+2)*FP) {
        g->hp=0;g->phase=PG_DEAD;return;
    }
    if(reached_exit(g)) {
        g->score+=100;g->room++;make_room(g);
        return;
    }
    update_camera(g);
}
static void enemy_step(PG_Game *g) {
    for(uint8_t i=0;i<g->enemyCount;i++) {
        PG_Enemy *e=&g->enemies[i];
        if(e->hp<=0)continue;
        if(e->cooldown)e->cooldown--;
        if(e->kind==PG_WALKER||e->kind==PG_BOSS) {
            if(!(g->steps&3)) {
                int newX=e->x+(e->x>g->x?-8:8);
                int x=newX/FP,y=e->y/FP+12;
                if(x>20&&x<145&&tile(g,x+5,y+2)==PG_STONE)e->x=(int16_t)newX;
            }
        } else if(e->kind==PG_FLYER) {
            if(!(g->steps&3))e->x=(int16_t)(e->x+(e->x>g->x?-11:11));
            /* Hover in place: no global y snap when room is vertical. */
            if(g->steps%9==0)e->y+=(int16_t)(((g->steps/9+i)&1)?8:-8);
        } else if(e->kind==PG_SHOOTER && !e->cooldown) {
            for(uint8_t j=0;j<PG_PROJECTILES;j++)if(!g->shots[j].live) {
                PG_Bullet *b=&g->shots[j];
                b->x=e->x;b->y=(int16_t)(e->y+7*FP);
                b->vx=(int16_t)(g->x<e->x?-23:23);
                b->live=1;e->cooldown=65;break;
            }
        }
        int dx=e->x/FP-g->x/FP,dy=e->y/FP-g->y/FP;
        if(dx>-9&&dx<10&&dy>-11&&dy<14) {
            if(hit_player(g,12)) {
                int shift=e->x>=g->x?4:-4;
                int nx=e->x+shift*FP;
                if(nx>=0&&nx<=148*FP)e->x=(int16_t)nx;
            }
        }
    }
    for(uint8_t j=0;j<PG_PROJECTILES;j++) {
        PG_Bullet *b=&g->shots[j];
        if(!b->live)continue;
        b->x=(int16_t)(b->x+b->vx);
        if(b->x<=0||b->x>=PG_W*FP||solid(tile(g,b->x/FP,b->y/FP))) {
            b->live=0;continue;
        }
        int dx=b->x/FP-g->x/FP,dy=b->y/FP-g->y/FP;
        if(dx>=0&&dx<PG_PLAYER_W&&dy>=0&&dy<PG_PLAYER_H) {
            hit_player(g,10);b->live=0;
        }
    }
}
void pg_tick(PG_Game *g,uint8_t held) {
    if(g->phase!=PG_RUN)return;
    g->steps++;
    if(g->invulnerable)g->invulnerable--;
    if(g->attackTime)g->attackTime--;
    if(g->effectTime)g->effectTime--;
    if(g->parryTime)g->parryTime--;
    if(g->parryCooldown)g->parryCooldown--;
    if(g->slamCooldown)g->slamCooldown--;
    if(g->breakTimer && !--g->breakTimer && g->breakIndex<PG_TILES)
        g->cells[g->breakIndex]=PG_AIR;
    player_step(g,held);
    if(g->phase!=PG_RUN)return;
    enemy_step(g);
    if(g->hurtClock<250)g->hurtClock++;
    /* 3 HP/s after 3 seconds without damage: 1 HP every 17 ticks. */
    if(g->hurtClock>=150 && g->hp<100 && g->steps%17==0)g->hp++;
}
