/* Parkour Gauntlet 0.4.3: independent fixed-step gameplay. MIT. */
#ifndef GC01_PARKOUR_LOGIC_H
#define GC01_PARKOUR_LOGIC_H
#include <stdint.h>

#define PG_COLS 20
#define PG_ROWS 13                  /* LCD viewport, logical 160x104 */
#define PG_WORLD_ROWS 24            /* larger world for vertical parkour */
#define PG_TILES (PG_COLS * PG_WORLD_ROWS)
#define PG_VISIBLE_TILES (PG_COLS * PG_ROWS)
#define PG_W 160
#define PG_H (PG_WORLD_ROWS * 8)
#define PG_VIEW_H (PG_ROWS * 8)
#define PG_ENEMIES 5
#define PG_PROJECTILES 4
#define PG_PLAYER_W 10
#define PG_PLAYER_H 14

#define PG_LEFT  1u
#define PG_RIGHT 2u
#define PG_UP    4u
#define PG_DOWN  8u

enum { PG_AIR=0, PG_STONE=1, PG_PLATFORM=2, PG_SPIKE=3,
       PG_BOUNCE=4, PG_BREAK=5, PG_EXIT=6 };
enum { PG_RUN=0, PG_PAUSE=1, PG_DEAD=2 };
enum { PG_WALKER=0, PG_SHOOTER=1, PG_FLYER=2, PG_BOSS=3 };

typedef struct {
    int16_t x,y;                 /* 1/16th logical pixel coordinates */
    int8_t kind,hp;
    uint8_t cooldown,phase;
} PG_Enemy;
typedef struct {
    int16_t x,y,vx;
    uint8_t live;
} PG_Bullet;
typedef struct {
    uint8_t cells[PG_TILES];
    PG_Enemy enemies[PG_ENEMIES];
    PG_Bullet shots[PG_PROJECTILES];
    uint32_t rng,score;
    int16_t x,y,vx,vy;
    uint16_t room,steps,breakIndex;
    uint8_t hp,phase,theme,menuChoice;
    uint8_t enemyCount,grounded,facing,roomStyle,cameraY;
    uint8_t jumpBuffer,coyote,invulnerable,attackTime,wallLock;
    uint8_t gripLeft,gripping,downHold,previousInput;
    uint8_t upHold,upWallArmed;
    uint8_t parryTime,parryUsed,parryCooldown,slamCooldown,slamPending;
    uint8_t effectTime,effectX,effectY,effectKind,hurtClock,breakTimer;
} PG_Game;

void pg_new(PG_Game *g,uint32_t seed);
void pg_tick(PG_Game *g,uint8_t held);
void pg_quick_attack(PG_Game *g);
void pg_toggle_pause(PG_Game *g);
uint8_t pg_detail(uint16_t tile,uint8_t salt);
#endif
