# FNIRSI GC-01 Parkour Gauntlet 0.4.3 — expanded vertical edition

**Source overlay only: this ZIP is NOT directly flashable.**

Hardware target: FNIRSI GC-01 / APM32F103RB / English display, Rad Pro **3.1.1** base.
PlatformIO env: `fnirsi-gc01_apm32f103rb-en`.

## Controls and gameplay

- LEFT/RIGHT: only move; no accidental attack, charge, or healing by holding a direction.
- UP: jump and wall-jump; hold UP when descending against a wall for up to 1.2 s of wall grip.
- DOWN: **only upon release**, a tap (< 0.46 s) triggers a 0.22 s parry (2 s cooldown); holding longer triggers a multi-target ground slam (2 s cooldown). Neither action fires on initial press. A slam has less per-target damage than the ordinary sword attack, to prevent overpowering single targets.
- Middle/OK: short tap sword attack; medium hold menu; long hold system shutdown. These paths retain Rad Pro integration.
- HP 100, regeneration 3 HP/s after 3 s without damage; no mana, dash, directional hold attacks, or directional hold healing.
- Randomized horizontal, vertical and mixed parkour rooms with elevated exits, wall gripping, one-way platforms, fragile ledges, hazards, multiple enemies and bosses.

## Graphics and performance

- Preserves the color pixel-art player/enemy sprites, three art themes, full-resolution native RGB565 tile output and indexed sprite compression; no deliberate reduction in game art quality.
- Removes background single-pixel noise in favor of stable skyline windows, factory pipework and clustered crystal formations.
- Bounded camera tracking in 24-row worlds, 13-row viewport; 512-byte tile framebuffer and dirty-tile selective redraw. The full-vs-dirty rendering tests confirm identical pixel output in their tested scenarios.
- Game state runs at fixed 50Hz and avoids floating-point physics. LCD frame throughput and jitter remain hardware-dependent.

## Rad Pro optimizations

- Removes unused RNG **user interface and dice generator** from the Parkour configuration, while retaining pulse-derived RNG byte output (needed by other subsystems, including USB).
- Excludes stock chess UI assets and original chess program via existing GC01_ARCADE settings.
- Reuses original compact optional statistics display, and removes chess-only color constants in the Parkour configuration.
- The **matching workflow** tries full original UI fonts first; if over-size, it progressively substitutes pre-existing upstream 2-bit fonts for symbols, large digits and English small text, preserving glyph dimensions and coverage. Those optional Rad Pro UI font fallbacks may change text edge smoothness, never game artwork. The medium font stays unchanged because its 2-bit alternative is missing some engineering-unit letters.
- Measurement, tube, alarm, power, battery, USB, data-logging, calibration and flash-script sources are protected by preservation audit and must remain unchanged.

## Tests and building

`bash parkour-tests/run.sh` builds sanitized native GCC/Clang logic and pixel-for-pixel rendering tests, including both normal and compact legacy compile switches. This is only a native test, **not an APM32 chip build or physical gameplay qualification**.

The GitHub workflow compiles the actual APM32 firmware and checks the **57,340-byte raw application limit** (strict, never increased), RAM, ELF target and signed-image CRC and metadata. Signed experimental `-install.bin` artifacts are uploaded **only if all software tests and size checks pass**. Separate raw diagnostics must never be flashed. Firmware and alarms must be validated on real hardware; compilation and signature do not establish measurement safety.

1. Upload `GC01_Parkour_V043_Source.zip` (unextracted) to the root of your `GC01-Arcade` repository.
2. Edit, **do not delete**, `.github/workflows/GC01_Dungeon_Prototype_Build.yml` and replace its complete content with the matching 0.4.3 workflow. Commit directly to `main`.
3. Actions -> `GC-01 Parkour Gauntlet 0.4.3 - build, verify and sign EXPERIMENTAL` -> `Run workflow` (new run, not Re-run jobs).
4. If successful, download `GC01-PARKOUR-V043-SIGNED-EXPERIMENTAL-UNTESTED`, review its memory and font-variant reports, and review the output before flashing. Keep known-working firmware for recovery.
