/* Exact partial vs complete RGB565 render tests, including camera motion. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../platform.io/src/ui/parkour_draw.h"
#define W 320
#define H 240
static uint16_t screen[W*H],compare[W*H];
static uint32_t partialUpdates,fullUpdates,frames;
void pg_test_image(int x,int y,int w,int h,const uint16_t *pixels) {
    assert(x>=0&&y>=0&&x+w<=W&&y+h<=H);
    for(int r=0;r<h;r++)memcpy(&screen[(y+r)*W+x],pixels+r*w,(size_t)w*2);
    partialUpdates++;
}
void pg_test_rect(int x,int y,int w,int h,uint16_t c) {
    assert(x>=0&&y>=0&&x+w<=W&&y+h<=H);
    for(int r=y;r<y+h;r++)for(int col=x;col<x+w;col++)screen[r*W+col]=c;
}
static void compare_frame(const PG_Game *g,const char *label,int i) {
    pg_draw(g,false);
    memcpy(compare,screen,sizeof(screen));
    memset(screen,0,sizeof(screen));
    uint32_t before=partialUpdates;
    pg_draw(g,true);
    fullUpdates+=partialUpdates-before;
    if(memcmp(compare,screen,sizeof(screen))) {
        fprintf(stderr,"FAIL: dirty/full mismatch: %s %d camera=%u\n",label,i,g->cameraY);
        assert(0);
    }
    frames++;
}
int main(void) {
    PG_Game g;pg_new(&g,45);
    memset(screen,0,sizeof(screen));
    pg_draw(&g,true);
    for(int i=0;i<86;i++) {
        pg_tick(&g,(i%7==0)?PG_RIGHT|PG_DOWN:(i%4)?PG_RIGHT:PG_UP);
        if(i%9==0)pg_quick_attack(&g);
        if(g.phase==PG_DEAD)pg_quick_attack(&g);
        compare_frame(&g,"motion",i);
    }
    for(int i=0;i<35;i++) {
        g.roomStyle=(uint8_t)(i%3);
        g.cameraY=(uint8_t)((i*7)%(PG_H-PG_VIEW_H+1));
        g.x=(int16_t)((10+i*3)*16);
        g.y=(int16_t)((28+i*4)*16);
        g.grounded=(uint8_t)(i%2);
        g.attackTime=(uint8_t)(i%3?5:0);
        g.effectTime=(uint8_t)(i%4?7:0);
        g.effectKind=(uint8_t)(i%4+1);
        g.effectX=(uint8_t)(g.x/16+5);
        g.effectY=(uint8_t)(g.y/16+7);
        g.downHold=(uint8_t)(i%3?20:0);
        g.parryTime=(uint8_t)(i%5?6:0);
        g.slamPending=(uint8_t)(i%7==0);
        g.invulnerable=(uint8_t)(i%6?0:8);
        g.gripping=(uint8_t)(i%4==0);
        g.facing=(uint8_t)(i&1);
        g.steps++;
        g.hp=(uint8_t)(100-i*2);
        g.parryCooldown=(uint8_t)(i%2?0:90);
        g.slamCooldown=(uint8_t)(i%3?0:90);
        if(i%4==0)g.enemies[0].hp=(int8_t)(i&4?0:2);
        g.shots[0].live=(uint8_t)(i&1);
        g.shots[0].x=(int16_t)(g.x+15*16);
        g.shots[0].y=(int16_t)(g.y+5*16);
        if(i==10)g.cells[9*PG_COLS+13]=PG_AIR;
        if(i==15)g.theme=(uint8_t)((g.theme+1)%3);
        if(i==20)g.room++;
        g.score+=(uint32_t)(i%4==0?5:0);
        compare_frame(&g,"effects/camera",i);
    }
    pg_toggle_pause(&g);compare_frame(&g,"pause",0);
    g.menuChoice=1;compare_frame(&g,"pause-select",1);
    pg_toggle_pause(&g);compare_frame(&g,"resume",2);
    g.phase=PG_DEAD;compare_frame(&g,"dead",3);
    g.phase=PG_RUN;compare_frame(&g,"restart",4);
    assert(fullUpdates==PG_VISIBLE_TILES*frames);
    assert(partialUpdates>=fullUpdates);
    printf("PASS: %u RGB565 dirty/full frames, camera scrolling, three themes, combat HUD\n",frames);
    return 0;
}
