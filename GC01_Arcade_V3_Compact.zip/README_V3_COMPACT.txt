GC01 Arcade V3 Compact — RECONSTRUCTED SOURCE OVERLAY
======================================================

This is a newly rebuilt source overlay using the uploaded V1-based source tree and
project handover. This is NOT a copy of the unavailable older 48,706-byte ZIP.

FNIRSI GC-01 APM32F103RB EN, Rad Pro source release 3.1.1 ONLY.

Implemented games: Snake, 2048, Flappy Bird, Breakout.
Implemented V3 improvements: 2048 sliding 0/33/67/100ms, shared merge planner,
nonblocking animation and dirty-region redraw; Flappy shield and progressive pipes;
Breakout 23/-68 initial fixed-point ball velocities, 2-hit reinforced and 30-point
bonus bricks, bounded substep collision; OK pause/EXIT without long-Left shortcut;
scissored differential rendering in all Light/Dark/Retro themes.

No full-screen framebuffer is allocated. Base measurement and settings implementations
and original linker/signing scripts have not been edited by this overlay.

Tests available:
  ./arcade-tests/run.sh
  ./arcade-tests/run_v3.sh
  ./arcade-tests/run_graphics.sh
  ./arcade-tests/run_dirty.sh
  python arcade-tests/verify_preservation.py /path/to/clean/radpro-3.1.1
  ORIGINAL=/path/to/clean/radpro-3.1.1 ./arcade-tests/compare_legacy.sh

BUILD STATUS: NOT YET FULLY PLATFORMIO-BUILT OR FLASH-VERIFIED.
Do NOT flash this ZIP or a raw firmware.bin. Application raw limit = 57,340 bytes.
Check the GitHub Actions build log and diagnostics before considering signing.
