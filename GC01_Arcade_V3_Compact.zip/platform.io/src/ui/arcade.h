/* Rad Pro 3.1.1 GC-01 arcade extension; MIT licensed. */
#ifndef ARCADE_DRAW_H
#define ARCADE_DRAW_H
#include "../extras/arcade_logic.h"
void invalidateArcadeDraw(void);
void drawArcade(const ArcadeState *game);
#endif
