/* Rad Pro 3.1.1 GC-01 arcade extension; pure deterministic game logic (MIT). */
#if defined(GC01_ARCADE)
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "arcade_logic.h"

static uint32_t nextRandom(ArcadeState *a)
{
    uint32_t x=a->randomState;
    x^=x<<13; x^=x>>17; x^=x<<5;
    return a->randomState=x;
}
static uint32_t randomBelow(ArcadeState *a, uint32_t bound)
{
    return nextRandom(a)%bound;
}
static void addScore(ArcadeState *a, uint32_t points)
{
    a->score=(UINT32_MAX-a->score<points)?UINT32_MAX:a->score+points;
}
static bool snakeOccupied(const ArcadeSnake *s, uint8_t pos)
{
    return (s->occupied[pos>>3]&(1u<<(pos&7)))!=0;
}
static void setSnakeOccupied(ArcadeSnake *s, uint8_t pos, bool on)
{
    uint8_t mask=(uint8_t)(1u<<(pos&7));
    if(on) s->occupied[pos>>3]|=mask;
    else s->occupied[pos>>3]&=(uint8_t)~mask;
}
static void placeFood(ArcadeState *a)
{
    ArcadeSnake *s=&a->game.snake;
    if(s->length==256){a->phase=ARCADE_WON;return;}
    uint16_t target=(uint16_t)randomBelow(a,256u-s->length);
    for(uint16_t i=0;i<256;++i)
        if(!snakeOccupied(s,(uint8_t)i))
            if(target--==0){s->food=(uint8_t)i;return;}
}
static bool add2048Tile(ArcadeState *a)
{
    Arcade2048 *g=&a->game.puzzle;
    uint8_t available=0;
    for(uint8_t i=0;i<16;++i) if(!g->cells[i]) ++available;
    if(!available)return false;
    uint8_t chosen=(uint8_t)randomBelow(a,available);
    for(uint8_t i=0;i<16;++i) if(!g->cells[i] && chosen--==0){
        g->cells[i]=randomBelow(a,10)==0?2:1;
        return true;
    }
    return false;
}
static bool can2048Move(const Arcade2048 *g)
{
    for(int i=0;i<16;++i){
        if(!g->cells[i]) return true;
        if((i%4<3 && g->cells[i]==g->cells[i+1]) ||
           (i/4<3 && g->cells[i]==g->cells[i+4]))return true;
    }
    return false;
}
static uint8_t tileIndex(ArcadeDirection d, uint8_t line, uint8_t pos)
{
    switch(d){
    case ARCADE_LEFT: return (uint8_t)(4*line+pos);
    case ARCADE_RIGHT:return (uint8_t)(4*line+3-pos);
    case ARCADE_UP:   return (uint8_t)(4*pos+line);
    default:          return (uint8_t)(4*(3-pos)+line);
    }
}
/* Single planner is responsible for BOTH merge logic and animation destinations.
   Each source tile gets a destination, including both halves of merges. */
static void step2048(ArcadeState *a, ArcadeDirection d)
{
    Arcade2048 *g=&a->game.puzzle;
    uint8_t before[16];
    memcpy(before,g->cells,16);
    bool reached=false,changed=false;
    for(uint8_t line=0;line<4;++line){
        uint8_t result[4]={0};
        uint8_t count=0, mergedMask=0;
        for(uint8_t j=0;j<4;++j){
            uint8_t src=tileIndex(d,line,j);
            uint8_t value=before[src];
            g->to[src]=src;
            if(!value)continue;
            if(count && result[count-1]==value && !(mergedMask&(1u<<(count-1)))){
                uint8_t merged=value<30?(uint8_t)(value+1):30;
                result[count-1]=merged;
                mergedMask|=(uint8_t)(1u<<(count-1));
                g->to[src]=tileIndex(d,line,(uint8_t)(count-1));
                addScore(a,1u<<merged);
                if(merged>=11 && !g->wonAlready)reached=true;
            }else{
                g->to[src]=tileIndex(d,line,count);
                result[count++]=value;
            }
        }
        for(uint8_t j=0;j<4;++j){
            uint8_t idx=tileIndex(d,line,j);
            if(before[idx]!=result[j])changed=true;
            g->cells[idx]=result[j];
        }
    }
    if(changed){
        memcpy(g->from,before,16);
        g->animFrame=0;
        add2048Tile(a);
    }
    if(reached){g->wonAlready=true;a->phase=ARCADE_WON;}
    else if(!can2048Move(g))a->phase=ARCADE_LOST;
}

uint8_t arcadeFlappySpeed(uint32_t score)
{
    return score<8?3:score<24?4:5;
}
uint8_t arcadeFlappyHalfGap(uint32_t score)
{
    return score<8?38:score<16?36:score<24?34:32;
}
static void initPipe(ArcadeState *a,uint8_t i)
{
    ArcadeFlappy *f=&a->game.flappy;
    f->pipeGap[i]=(uint8_t)(70+randomBelow(a,100));
    f->pipeHalfGap[i]=arcadeFlappyHalfGap(a->score);
    f->pipeScored[i]=0;
    f->pipeSafe[i]=0;
    f->pipeTaken[i]=0;
    /* No extra saved setting, bitmap asset or new resource allocation. */
    f->pipeShield[i]=(uint8_t)((a->score>=3 && randomBelow(a,5)==0)?1:0);
}
static void serveBreakout(ArcadeBreakout *b)
{
    uint8_t speed=b->level>7?6:(uint8_t)(b->level-1);
    b->ballX=(int16_t)b->paddleX<<4;
    b->ballY=206<<4;
    b->velocityX=(int16_t)(23+2*speed);
    b->velocityY=(int16_t)(-68-5*speed);
    b->lastHitBrick=255;
}
static void initBricks(ArcadeBreakout *b)
{
    for(uint8_t i=0;i<32;++i){
        b->bricks[i]=((i+3*b->level)%13==0)?3:
                     ((i+b->level)%5==0)?2:1;
    }
    b->bricksLeft=32;
    serveBreakout(b);
}
void arcadeStart(ArcadeState *a, ArcadeKind kind,uint32_t seed)
{
    memset(a,0,sizeof(*a));
    a->kind=kind;
    a->randomState=seed?seed:0x6d2b79f5u;
    a->phase=ARCADE_RUNNING;
    switch(kind){
    case ARCADE_SNAKE:{
        ArcadeSnake *s=&a->game.snake;
        s->length=3;s->direction=ARCADE_RIGHT;s->nextDirection=ARCADE_RIGHT;
        s->body[0]=8*16+5;s->body[1]=8*16+6;s->body[2]=8*16+7;
        for(uint8_t i=0;i<3;++i)setSnakeOccupied(s,s->body[i],true);
        placeFood(a);
        break;
    }
    case ARCADE_2048:
        a->game.puzzle.animFrame=3;
        add2048Tile(a);add2048Tile(a);
        break;
    case ARCADE_FLAPPY:{
        ArcadeFlappy *f=&a->game.flappy;
        f->y=115<<4;
        for(uint8_t i=0;i<3;++i){
            f->pipeX[i]=(int16_t)(175+i*100);
            initPipe(a,i);
        }
        a->phase=ARCADE_READY;
        break;
    }
    case ARCADE_BREAKOUT:{
        ArcadeBreakout *b=&a->game.breakout;
        b->paddleX=120;b->lives=3;b->level=1;
        initBricks(b);
        a->phase=ARCADE_READY;
        break;
    }
    default: break;
    }
}
void arcadeMove(ArcadeState *a, ArcadeDirection d)
{
    if(a->phase!=ARCADE_RUNNING && a->phase!=ARCADE_READY)return;
    switch(a->kind){
    case ARCADE_SNAKE:{
        ArcadeSnake *s=&a->game.snake;
        if((s->direction^1)!=d)s->nextDirection=(uint8_t)d;
        break;
    }
    case ARCADE_2048:step2048(a,d);break;
    case ARCADE_FLAPPY:
        if(d==ARCADE_UP){a->phase=ARCADE_RUNNING;a->game.flappy.velocity=-72;}
        break;
    case ARCADE_BREAKOUT:
        if(d==ARCADE_UP && a->phase==ARCADE_READY)a->phase=ARCADE_RUNNING;
        break;
    default:break;
    }
}
void arcadeBreakoutPaddle(ArcadeState *a,int8_t step)
{
    if(a->kind!=ARCADE_BREAKOUT || (a->phase!=ARCADE_RUNNING && a->phase!=ARCADE_READY))return;
    ArcadeBreakout *b=&a->game.breakout;
    int16_t x=(int16_t)b->paddleX+step;
    if(x<21)x=21;
    if(x>218)x=218;
    b->paddleX=(uint8_t)x;
    if(a->phase==ARCADE_READY)b->ballX=x<<4;
}
static void snakeStep(ArcadeState *a)
{
    ArcadeSnake *s=&a->game.snake;
    s->direction=s->nextDirection;
    uint8_t head=s->body[(uint8_t)(s->tail+s->length-1)];
    int x=head&15,y=head>>4;
    if(s->direction==ARCADE_LEFT)--x;
    else if(s->direction==ARCADE_RIGHT)++x;
    else if(s->direction==ARCADE_UP)--y;
    else ++y;
    if(x<0 || x>=16 || y<0 || y>=16){a->phase=ARCADE_LOST;return;}
    uint8_t next=(uint8_t)(y*16+x);
    bool eating=next==s->food;
    if(snakeOccupied(s,next) && (eating || next!=s->body[s->tail])){
        a->phase=ARCADE_LOST;return;
    }
    if(!eating){
        setSnakeOccupied(s,s->body[s->tail],false);
        ++s->tail;--s->length;
    }
    s->body[(uint8_t)(s->tail+s->length)]=next;
    ++s->length;
    setSnakeOccupied(s,next,true);
    if(eating){addScore(a,1);placeFood(a);}
}
static void flappyStep(ArcadeState *a)
{
    ArcadeFlappy *f=&a->game.flappy;
    if(f->velocity<62)f->velocity+=5;
    f->y+=f->velocity;
    int y=f->y>>4;
    if(y<7 || y>232){a->phase=ARCADE_LOST;return;}
    uint8_t speed=arcadeFlappySpeed(a->score);
    for(uint8_t i=0;i<3;++i){
        f->pipeX[i]-=speed;
        int x=f->pipeX[i],middle=f->pipeGap[i],gap=f->pipeHalfGap[i];
        if(!f->pipeScored[i] && x+28<49){addScore(a,1);f->pipeScored[i]=1;}
        if(x < -29){
            int16_t maxX=240;
            for(uint8_t j=0;j<3;++j)if(f->pipeX[j]>maxX)maxX=f->pipeX[j];
            f->pipeX[i]=(int16_t)(maxX+100);
            initPipe(a,i);
            continue;
        }
        bool overlap=x<62 && x+28>43;
        if(!overlap)f->pipeSafe[i]=0;
        if(overlap && f->pipeShield[i] && !f->pipeTaken[i] && !f->shield &&
           y>=middle-12 && y<=middle+12){
            f->shield=1;
            f->pipeTaken[i]=1;
        }
        if(overlap && !f->pipeSafe[i] &&
           (y-7<middle-gap || y+7>middle+gap)){
            if(f->shield){f->shield=0;f->pipeSafe[i]=1;}
            else{a->phase=ARCADE_LOST;return;}
        }
    }
}
static int absi(int value){return value<0?-value:value;}
static void breakoutStep(ArcadeState *a)
{
    ArcadeBreakout *b=&a->game.breakout;
    int16_t dx=b->velocityX,dy=b->velocityY;
    int n=(absi(dx)>absi(dy)?absi(dx):absi(dy))/16+1;
    if(n>12)n=12;
    for(int step=0;step<n;++step){
        int lastY=b->ballY>>4;
        b->ballX+=(int16_t)((int32_t)dx*(step+1)/n-(int32_t)dx*step/n);
        b->ballY+=(int16_t)((int32_t)dy*(step+1)/n-(int32_t)dy*step/n);
        int x=b->ballX>>4,y=b->ballY>>4;
        if(x<5){b->ballX=5<<4;b->velocityX=(int16_t)-b->velocityX;dx=b->velocityX;}
        if(x>234){b->ballX=234<<4;b->velocityX=(int16_t)-b->velocityX;dx=b->velocityX;}
        if(y<5){b->ballY=5<<4;b->velocityY=(int16_t)-b->velocityY;dy=b->velocityY;}
        x=b->ballX>>4;y=b->ballY>>4;
        if(b->velocityY>0 && lastY+5<216 && y+5>=216 &&
           x>=b->paddleX-24 && x<=b->paddleX+24){
            b->ballY=210<<4;
            b->velocityY=(int16_t)-b->velocityY;
            b->velocityX=(int16_t)((x-(int)b->paddleX)*2);
            if(!b->velocityX)b->velocityX=4;
            dx=b->velocityX;dy=b->velocityY;
        }
        if(y>=238){
            if(--b->lives==0)a->phase=ARCADE_LOST;
            else{a->phase=ARCADE_READY;serveBreakout(b);}
            return;
        }
        /* 11px ball footprint against exact visible brick rectangles. */
        bool hitLast=false;
        if(y>=16 && y<=78){
            for(uint8_t i=0;i<32;++i){
                if(!b->bricks[i])continue;
                int left=(i&7)*30+1,top=20+(i>>3)*14+1;
                if(x+5<left || x-5>left+27 || y+5<top || y-5>top+11)continue;
                if(i==b->lastHitBrick){hitLast=true;continue;}
                b->lastHitBrick=i;
                if(b->bricks[i]==2){b->bricks[i]=1;addScore(a,5);}
                else{
                    addScore(a,b->bricks[i]==3?30:10);
                    b->bricks[i]=0;
                    if(b->bricksLeft)--b->bricksLeft;
                }
                /* Reflect on the approach axis; avoid repeated brick hits. */
                if(lastY+5<top || lastY-5>top+11){b->velocityY=(int16_t)-b->velocityY;dy=b->velocityY;}
                else{b->velocityX=(int16_t)-b->velocityX;dx=b->velocityX;}
                if(!b->bricksLeft){
                    if(b->level<255)++b->level;
                    initBricks(b);
                    a->phase=ARCADE_READY;
                }
                return;
            }
        }
        if(!hitLast)b->lastHitBrick=255;
    }
}
void arcadeStep(ArcadeState *a)
{
    if(a->phase!=ARCADE_RUNNING)return;
    switch(a->kind){
    case ARCADE_SNAKE:snakeStep(a);break;
    case ARCADE_FLAPPY:flappyStep(a);break;
    case ARCADE_BREAKOUT:breakoutStep(a);break;
    default:break;
    }
}
void arcadePause(ArcadeState *a)
{
    if(a->phase==ARCADE_PAUSED){a->phase=a->previousPhase;return;}
    if(a->phase==ARCADE_RUNNING || a->phase==ARCADE_READY){
        a->previousPhase=a->phase;a->phase=ARCADE_PAUSED;a->pauseChoice=0;
    }else if(a->phase==ARCADE_LOST || a->phase==ARCADE_WON){
        uint32_t seed=a->randomState;
        ArcadeKind kind=a->kind;
        if(kind==ARCADE_2048 && a->phase==ARCADE_WON)a->phase=ARCADE_RUNNING;
        else arcadeStart(a,kind,seed);
    }
}
void arcadeChoosePause(ArcadeState *a)
{
    if(a->phase!=ARCADE_PAUSED)return;
    if(a->pauseChoice==0)a->phase=a->previousPhase;
    else if(a->pauseChoice==1)arcadeStart(a,a->kind,a->randomState);
    /* Exit choice handled by UI (returns to the original menu). */
}
#endif
