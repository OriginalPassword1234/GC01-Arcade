/* Rad Pro GC-01 arcade extension; pure deterministic game logic (MIT). */
#ifndef ARCADE_LOGIC_H
#define ARCADE_LOGIC_H
#include <stdint.h>
#include <stdbool.h>

typedef enum { ARCADE_SNAKE, ARCADE_2048, ARCADE_FLAPPY, ARCADE_BREAKOUT, ARCADE_COUNT } ArcadeKind;
typedef enum { ARCADE_READY, ARCADE_RUNNING, ARCADE_PAUSED, ARCADE_LOST, ARCADE_WON } ArcadePhase;
typedef enum { ARCADE_LEFT, ARCADE_RIGHT, ARCADE_UP, ARCADE_DOWN } ArcadeDirection;

typedef struct {
    uint8_t body[256], occupied[32];
    uint8_t tail, direction, nextDirection, food;
    uint16_t length;
} ArcadeSnake;
typedef struct {
    uint8_t cells[16];
    uint8_t from[16];       /* Pre-move tile exponents; 0 means empty. */
    uint8_t to[16];         /* Source-index -> final board index for sliding. */
    uint8_t animFrame;      /* 0,1,2 = slide, 3 = final board (100 ms). */
    bool wonAlready;
} Arcade2048;
typedef struct {
    int16_t y, velocity, pipeX[3];
    uint8_t pipeGap[3], pipeHalfGap[3], pipeScored[3];
    uint8_t pipeShield[3], pipeTaken[3], pipeSafe[3];
    uint8_t shield;         /* One-use shield, never stacks. */
} ArcadeFlappy;
typedef struct {
    uint8_t bricks[32];    /* 0=empty, 1=normal, 2=reinforced, 3=bonus. */
    int16_t ballX, ballY, velocityX, velocityY;
    uint8_t paddleX, lives, level, bricksLeft, lastHitBrick;
} ArcadeBreakout;

typedef struct {
    uint8_t kind, phase, previousPhase; /* Internal state only; never persisted. */
    uint8_t pauseChoice;
    uint32_t score, randomState;
    union {
        ArcadeSnake snake;
        Arcade2048 puzzle;
        ArcadeFlappy flappy;
        ArcadeBreakout breakout;
    } game;
} ArcadeState;

void arcadeStart(ArcadeState *game, ArcadeKind kind, uint32_t seed);
void arcadeMove(ArcadeState *game, ArcadeDirection direction);
void arcadeStep(ArcadeState *game);
void arcadeBreakoutPaddle(ArcadeState *game, int8_t step);
void arcadePause(ArcadeState *game);
void arcadeChoosePause(ArcadeState *game);
uint8_t arcadeFlappySpeed(uint32_t score);
uint8_t arcadeFlappyHalfGap(uint32_t score);
#endif
