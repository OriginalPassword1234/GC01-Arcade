/* Independent reference-model tests and board-boundary cases. */
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "arcade_logic.h"
static uint32_t rng=0x5a17c0de;
static uint32_t rnd(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static void referenceLine(const uint8_t input[4],uint8_t output[4],uint32_t *score){
    uint8_t packed[4]={0};int n=0;
    for(int i=0;i<4;++i)if(input[i])packed[n++]=input[i];
    int count=0;
    for(int i=0;i<n;++i){
        if(i+1<n&&packed[i]==packed[i+1]){
            uint8_t e=(uint8_t)(packed[i]+1); if(e>30)e=30;
            output[count++]=e;*score+=1u<<e;++i;
        }else output[count++]=packed[i];
    }
    for(int i=count;i<4;++i)output[i]=0;
}
static void referenceMove(const uint8_t in[16],uint8_t out[16],ArcadeDirection d,uint32_t *score){
    memcpy(out,in,16);
    for(int row=0;row<4;++row){
        uint8_t input[4],result[4];
        for(int j=0;j<4;++j){
            int index=d==ARCADE_LEFT?4*row+j:d==ARCADE_RIGHT?4*row+3-j:d==ARCADE_UP?4*j+row:4*(3-j)+row;
            input[j]=in[index];
        }
        referenceLine(input,result,score);
        for(int j=0;j<4;++j){
            int index=d==ARCADE_LEFT?4*row+j:d==ARCADE_RIGHT?4*row+3-j:d==ARCADE_UP?4*j+row:4*(3-j)+row;
            out[index]=result[j];
        }
    }
}
static void testPuzzleReference(void){
    for(int n=0;n<20000;++n){
        ArcadeState a;arcadeStart(&a,ARCADE_2048,rnd()|1);
        for(int i=0;i<16;++i){uint32_t r=rnd();a.game.puzzle.cells[i]=(r%4)==0?0:(uint8_t)(1+(r%9));}
        uint8_t before[16],expected[16];memcpy(before,a.game.puzzle.cells,16);
        uint32_t score=0;
        ArcadeDirection d=(ArcadeDirection)(rnd()%4);
        referenceMove(before,expected,d,&score);
        bool changed=memcmp(before,expected,16)!=0;
        uint32_t oldRandom=a.randomState;
        arcadeMove(&a,d);
        assert(a.score==score);
        if(changed){
            int newTiles=0;
            for(int i=0;i<16;++i)if(a.game.puzzle.cells[i]!=expected[i]){
                assert(expected[i]==0);assert(a.game.puzzle.cells[i]==1||a.game.puzzle.cells[i]==2);
                ++newTiles;
            }
            assert(newTiles==1);
        }else{
            assert(memcmp(a.game.puzzle.cells,expected,16)==0);
            assert(a.randomState==oldRandom);
        }
    }
}
static void occupied(ArcadeSnake *s,int pos){s->occupied[pos>>3]|=(uint8_t)(1u<<(pos&7));}
static void testSnakeFullBoard(void){
    ArcadeState a; arcadeStart(&a,ARCADE_SNAKE,123);
    ArcadeSnake *s=&a.game.snake;
    memset(s,0,sizeof(*s));
    s->tail=0;s->length=255;s->direction=ARCADE_LEFT;s->nextDirection=ARCADE_LEFT;
    int n=0;
    for(int y=0;y<16;++y){
        if(!(y&1)){for(int x=0;x<16;++x){if(n==255)break;s->body[n++]=(uint8_t)(16*y+x);occupied(s,16*y+x);}}
        else {for(int x=15;x>=0;--x){if(n==255)break;s->body[n++]=(uint8_t)(16*y+x);occupied(s,16*y+x);}}
    }
    assert(n==255 && s->body[254]==(15*16+1));
    s->food=15*16;
    arcadeStep(&a);
    assert(a.phase==ARCADE_WON && s->length==256 && a.score==1);
    for(int i=0;i<32;++i)assert(s->occupied[i]==255);
    arcadeStep(&a);assert(s->length==256);
}
static void testSnakeTailVacate(void){
    ArcadeState a;arcadeStart(&a,ARCADE_SNAKE,456);
    ArcadeSnake *s=&a.game.snake;memset(s,0,sizeof(*s));
    s->body[0]=0;s->body[1]=1;s->body[2]=17;s->body[3]=16;
    for(int i=0;i<4;++i)occupied(s,s->body[i]);
    s->length=4;s->direction=ARCADE_UP;s->nextDirection=ARCADE_UP;s->food=42;
    arcadeStep(&a);
    assert(a.phase==ARCADE_RUNNING && s->length==4 && s->tail==1);
    assert(s->body[4]==0 && (s->occupied[0]&1));
}
int main(void){testPuzzleReference();testSnakeFullBoard();testSnakeTailVacate();puts("PASS: 20,000 2048 oracle comparisons; full-board and tail-vacating Snake cases.");}
