/* Offline renderer harness; exercises the exact ui/arcade.c without hardware. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "mcu-renderer.h"
#include "system/settings.h"
#include "extras/arcade_logic.h"
#include "ui/arcade.h"

mr_t mr;
Settings settings;
static uint16_t pixels[320*240];
static int rects;
static int clipped;

void mr_set_fill_color(mr_t *m, mr_color_t c){m->fill_color=c;}
void mr_draw_rectangle(mr_t *m,const mr_rectangle_t *r){
    assert(r->width>0 && r->height>0);
    assert(r->x>=0 && r->y>=0);
    assert(r->x+r->width<=320 && r->y+r->height<=240);
    for(int y=r->y;y<r->y+r->height;y++)for(int x=r->x;x<r->x+r->width;x++)pixels[y*320+x]=m->fill_color;
    rects++;
}
void drawRectangle(const mr_rectangle_t *r){mr_draw_rectangle(&mr,r);}
void strcatUInt32(char *s, uint32_t value, uint32_t minDigits){
    (void)minDigits;
    sprintf(s+strlen(s),"%u",value);
}
static void ppm(const char *f){
    FILE *p=fopen(f,"wb"); assert(p);
    fputs("P6\n320 240\n255\n",p);
    for(int i=0;i<320*240;i++){
        uint16_t c=pixels[i];
        uint8_t r=(uint8_t)(((c>>11)&31)*255/31),g=(uint8_t)(((c>>5)&63)*255/63),b=(uint8_t)((c&31)*255/31);
        fputc(r,p);fputc(g,p);fputc(b,p);
    }
    fclose(p);
}
int main(int argc,char **argv){
    const char *out=argc>1?argv[1]:NULL;
    ArcadeState a;
    int maxrect=0;
    for(int theme=0;theme<3;theme++){
        settings.displayTheme=theme;
        for(int kind=0;kind<4;kind++){
            arcadeStart(&a,(ArcadeKind)kind,0x12345678u);
            a.score=125;
            a.phase=ARCADE_RUNNING;
            if(kind==ARCADE_SNAKE){
                ArcadeSnake *s=&a.game.snake;
                memset(s->occupied,0,sizeof(s->occupied));
                uint8_t snakeCells[]={148,149,150,151,152,136,120,104,105,106,107,91,75};
                s->length=13;s->tail=0;s->food=54;
                for(unsigned i=0;i<13;i++){
                    s->body[i]=snakeCells[i];
                    s->occupied[snakeCells[i]>>3]|=1u<<(snakeCells[i]&7);
                }
                s->direction=ARCADE_UP;
            } else if(kind==ARCADE_2048){
                static const uint8_t exps[16]={1,2,3,4,5,6,7,8,0,1,2,9,0,3,10,11};
                memcpy(a.game.puzzle.cells,exps,16);
                a.score=20480;
            } else if(kind==ARCADE_FLAPPY){
                a.score=12;
                ArcadeFlappy *f=&a.game.flappy;
                f->y=110<<4;f->pipeX[0]=152;f->pipeX[1]=224;f->pipeX[2]=328;
                f->pipeGap[0]=110;f->pipeGap[1]=125;f->pipeGap[2]=145;
            } else {
                ArcadeBreakout *b=&a.game.breakout;
                a.score=580;b->paddleX=117;b->ballX=161<<4;b->ballY=180<<4;b->lives=3;b->level=2;
                b->bricks[2]=b->bricks[11]=b->bricks[24]=0;
            }
            memset(pixels,0,sizeof(pixels)); rects=0;clipped=0;
            drawArcade(&a);
            if(rects>maxrect)maxrect=rects;
            char name[256];snprintf(name,sizeof(name),"%s/t%d_g%d.ppm",out,theme,kind);
            if(out) ppm(name);
            printf("theme=%d game=%d rects=%d\n",theme,kind,rects);
            a.phase=ARCADE_PAUSED;a.pauseChoice=2;
            drawArcade(&a);
            a.phase=ARCADE_LOST;
            drawArcade(&a);
            a.phase=ARCADE_WON;
            drawArcade(&a);
            if(kind==ARCADE_2048){
                a.phase=ARCADE_RUNNING;a.game.puzzle.cells[0]=30;drawArcade(&a);
                a.game.puzzle.cells[0]=255;drawArcade(&a); /* corrupt tile must not overflow shift */
            }
            if(kind==ARCADE_SNAKE){
                a.game.snake.length=256;
                for(int i=0;i<256;i++){
                    a.game.snake.body[i]=(uint8_t)i;
                    a.game.snake.occupied[i>>3]=0xff;
                }
                a.game.snake.tail=0;
                a.game.snake.food=255;
                drawArcade(&a);
            }
        }
    }
    drawArcade(NULL);
    printf("ALL GRAPHICS TESTS PASS; max sample rectangles/frame=%d\n",maxrect);
    return 0;
}
