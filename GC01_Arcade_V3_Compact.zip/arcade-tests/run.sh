#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
CC=${CC:-gcc}
DIR=$(mktemp -d)
trap 'rm -rf "$DIR"' EXIT
FLAGS='-std=c11 -O1 -g -Wall -Wextra -Werror -DGC01_ARCADE -DGAME -DKEYBOARD_5_KEYS -DKEYBOARD_KEY_POWER_OK -DDISPLAY_320X240 -DDISPLAY_COLOR -DSTRINGS="strings/en.h"'
# Suppress a preexisting original keyboard.c signed/unsigned comparison warning.
$CC -std=c11 -O1 -g -DGC01_ARCADE -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -Iplatform.io/src/extras arcade-tests/test_arcade.c platform.io/src/extras/arcade_logic.c -o "$DIR/logic"
"$DIR/logic"
$CC -std=c11 -O1 -g -DGC01_ARCADE -DKEYBOARD_5_KEYS -DKEYBOARD_KEY_POWER_OK -DDISPLAY_320X240 -DDISPLAY_COLOR '-DSTRINGS="strings/en.h"' -Wall -Wextra -Werror -Wno-sign-compare -fsanitize=undefined -Iplatform.io/src -Iplatform.io/lib/mcu-renderer arcade-tests/test_keyboard.c platform.io/src/peripherals/keyboard.c -o "$DIR/keyboard"
"$DIR/keyboard"
$CC -std=c11 -O1 -g -DGC01_ARCADE -DGAME -DKEYBOARD_5_KEYS -DKEYBOARD_KEY_POWER_OK -DDISPLAY_320X240 -DDISPLAY_COLOR '-DSTRINGS="strings/en.h"' -Wall -Wextra -Werror -fsanitize=address,undefined -Iplatform.io/src -Iplatform.io/lib/mcu-renderer arcade-tests/test_integration.c platform.io/src/extras/arcade.c platform.io/src/extras/arcade_logic.c -o "$DIR/integration"
"$DIR/integration"

$CC -std=c11 -O1 -g -DGC01_ARCADE -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -Iplatform.io/src/extras arcade-tests/test_deep_logic.c platform.io/src/extras/arcade_logic.c -o "$DIR/deep"
"$DIR/deep"
