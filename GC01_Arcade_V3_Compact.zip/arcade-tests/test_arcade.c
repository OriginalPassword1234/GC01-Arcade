#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "arcade_logic.h"

static int count_tiles(const ArcadeState *a) { int n=0; for(int i=0;i<16;++i) n+=a->game.puzzle.cells[i]!=0; return n; }
static void test_2048(void) {
    ArcadeState a; arcadeStart(&a,ARCADE_2048,1); assert(count_tiles(&a)==2);
    /* Tiles stored as exponents: 1=2, 2=4, 3=8. Spawns can occur outside the tested row. */
    memset(a.game.puzzle.cells,0,sizeof(a.game.puzzle.cells));
    a.game.puzzle.cells[0]=1;a.game.puzzle.cells[1]=1;a.game.puzzle.cells[2]=1;
    arcadeMove(&a,ARCADE_LEFT);
    assert(a.game.puzzle.cells[0]==2 && a.game.puzzle.cells[1]==1 && a.score==4);
    memset(a.game.puzzle.cells,0,sizeof(a.game.puzzle.cells)); a.score=0;
    for(int i=0;i<4;++i) a.game.puzzle.cells[i]=1;
    arcadeMove(&a,ARCADE_LEFT);
    assert(a.game.puzzle.cells[0]==2 && a.game.puzzle.cells[1]==2 && a.score==8);
    memset(a.game.puzzle.cells,0,sizeof(a.game.puzzle.cells));a.score=0;
    a.game.puzzle.cells[0]=2;a.game.puzzle.cells[1]=2;a.game.puzzle.cells[2]=3;a.game.puzzle.cells[3]=3;
    arcadeMove(&a,ARCADE_LEFT);
    assert(a.game.puzzle.cells[0]==3&&a.game.puzzle.cells[1]==4 && a.score==24);
    /* invalid moves do not spawn */
    memset(a.game.puzzle.cells,0,sizeof(a.game.puzzle.cells));a.score=0;
    a.game.puzzle.cells[0]=1;a.game.puzzle.cells[1]=2;a.game.puzzle.cells[2]=3;a.game.puzzle.cells[3]=4;
    uint32_t rng=a.randomState;
    arcadeMove(&a,ARCADE_LEFT);
    assert(a.randomState==rng && count_tiles(&a)==4);
    /* Goal triggers win, and OK resumes */
    memset(a.game.puzzle.cells,0,sizeof(a.game.puzzle.cells)); a.game.puzzle.wonAlready=false;
    a.game.puzzle.cells[0]=10; a.game.puzzle.cells[1]=10;
    arcadeMove(&a,ARCADE_LEFT); assert(a.phase==ARCADE_WON);
    arcadePause(&a);assert(a.phase==ARCADE_RUNNING);
    /* Full board with no adjacent pairs must signal loss on an attempted move. */
    for(int y=0;y<4;++y)for(int x=0;x<4;++x)a.game.puzzle.cells[y*4+x]=1+((x+y)%2);
    arcadeMove(&a,ARCADE_LEFT); assert(a.phase==ARCADE_LOST);
}
static void test_snake(void) {
    ArcadeState a; arcadeStart(&a,ARCADE_SNAKE,3);
    assert(a.game.snake.length==3);
    arcadeMove(&a,ARCADE_LEFT); assert(a.game.snake.nextDirection==ARCADE_RIGHT); /* no reversal */
    arcadeStep(&a); assert(a.game.snake.body[3]==8*16+8);
    arcadeMove(&a,ARCADE_UP);arcadeStep(&a);
    assert(a.game.snake.body[4]==7*16+8);
    arcadeMove(&a,ARCADE_DOWN); assert(a.game.snake.nextDirection==ARCADE_UP);
    for(int i=0;i<8;++i)arcadeStep(&a);
    assert(a.phase==ARCADE_LOST); /* north wall */
    arcadeStart(&a,ARCADE_SNAKE,6);
    a.game.snake.food=8*16+8;
    arcadeStep(&a); assert(a.score==1 && a.game.snake.length==4);
    arcadePause(&a);assert(a.phase==ARCADE_PAUSED);
    arcadeStep(&a); assert(a.phase==ARCADE_PAUSED);
    arcadeChoosePause(&a);assert(a.phase==ARCADE_RUNNING);
}
static void test_flappy(void) {
    ArcadeState a; arcadeStart(&a,ARCADE_FLAPPY,5);
    assert(a.phase==ARCADE_READY);
    arcadeMove(&a,ARCADE_UP);assert(a.phase==ARCADE_RUNNING && a.game.flappy.velocity<0);
    for(int i=0;i<600 && a.phase==ARCADE_RUNNING;++i)arcadeStep(&a);
    assert(a.phase==ARCADE_LOST || a.phase==ARCADE_WON);
    arcadePause(&a);assert(a.phase==ARCADE_READY);
}
static void test_breakout(void) {
    ArcadeState a; arcadeStart(&a,ARCADE_BREAKOUT,7);
    assert(a.phase==ARCADE_READY&&a.game.breakout.bricksLeft==32&&a.game.breakout.lives==3);
    arcadeBreakoutPaddle(&a,-127);assert(a.game.breakout.paddleX==21);
    arcadeBreakoutPaddle(&a,127);assert(a.game.breakout.paddleX==148);
    arcadeMove(&a,ARCADE_UP);assert(a.phase==ARCADE_RUNNING);
    arcadePause(&a);assert(a.phase==ARCADE_PAUSED);
    a.pauseChoice=1;arcadeChoosePause(&a);assert(a.phase==ARCADE_READY && a.score==0);
    arcadeMove(&a,ARCADE_UP);
    a.game.breakout.ballY=237<<4; a.game.breakout.velocityY=40;
    arcadeStep(&a);assert(a.game.breakout.lives==2 && a.phase==ARCADE_READY);
}
static void randomized_invariant_test(void) {
    for(int game=0;game<ARCADE_COUNT;++game) {
        for(uint32_t seed=1;seed<151;++seed) {
            ArcadeState a;arcadeStart(&a,(ArcadeKind)game,seed);
            for(int i=0;i<500;++i) {
                arcadeMove(&a,(ArcadeDirection)((i*7+seed)%4));
                if(game==ARCADE_BREAKOUT) arcadeBreakoutPaddle(&a,(i&1)?5:-5);
                arcadeStep(&a);
                if (a.phase==ARCADE_LOST || a.phase==ARCADE_WON) break;
                if(game==ARCADE_SNAKE) {
                    const ArcadeSnake *s=&a.game.snake;
                    assert(s->length>=3 && s->length<=256);
                    int count=0;for(int j=0;j<32;++j) count+=__builtin_popcount(s->occupied[j]);
                    assert(count==s->length);
                }
                if(game==ARCADE_2048)for(int j=0;j<16;++j)assert(a.game.puzzle.cells[j]<=30);
                if(game==ARCADE_BREAKOUT)assert(a.game.breakout.bricksLeft<=32);
            }
        }
    }
}
int main(void) {
    test_2048();test_snake();test_flappy();test_breakout();randomized_invariant_test();
    puts("All arcade logic tests passed.");return 0;
}
