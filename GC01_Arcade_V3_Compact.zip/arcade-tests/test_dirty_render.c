/* Pixel-exact LCD dirty rendering regression tests, no hardware needed. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mcu-renderer.h"
#include "system/settings.h"
#include "extras/arcade_logic.h"
#include "ui/arcade.h"
mr_t mr;
Settings settings;
static uint16_t pixels[320*240],snapshot[320*240];
static uint64_t pixelWrites;
void mr_set_fill_color(mr_t *m,mr_color_t c){m->fill_color=c;}
void mr_draw_rectangle(mr_t *m,const mr_rectangle_t *r){
    assert(r->x>=0&&r->y>=0&&r->width>0&&r->height>0);
    assert(r->x+r->width<=320&&r->y+r->height<=240);
    for(int y=r->y;y<r->y+r->height;y++)for(int x=r->x;x<r->x+r->width;x++)
        pixels[y*320+x]=m->fill_color;
    pixelWrites+=(uint64_t)r->width*r->height;
}
void drawRectangle(const mr_rectangle_t *r){mr_draw_rectangle(&mr,r);}
void strcatUInt32(char *s,uint32_t v,uint32_t minDigits){(void)minDigits;sprintf(s+strlen(s),"%u",v);}
static unsigned randomState=0x7ab91b3du;
static unsigned rng(void){randomState^=randomState<<13;randomState^=randomState>>17;randomState^=randomState<<5;return randomState;}
static int comparisons;
static uint64_t optimizedWrites,fullWrites;
static void compare(const ArcadeState *g,int theme,int kind,int n){
    uint64_t before=pixelWrites;
    drawArcade(g);
    optimizedWrites+=pixelWrites-before;
    memcpy(snapshot,pixels,sizeof(pixels));
    before=pixelWrites;
    invalidateArcadeDraw();
    drawArcade(g);
    fullWrites+=pixelWrites-before;
    if(memcmp(snapshot,pixels,sizeof(pixels))){
        for(int i=0;i<320*240;i++) if(snapshot[i]!=pixels[i]){
            fprintf(stderr,"DIRTY MISMATCH theme=%d game=%d step=%d phase=%d position=%d,%d differential=%04x oracle=%04x\n",
                    theme,kind,n,(int)g->phase,i%320,i/320,snapshot[i],pixels[i]);
            exit(1);
        }
    }
    ++comparisons;
}
int main(void){
 for(int theme=0;theme<3;theme++){
  settings.displayTheme=theme;
  for(int kind=0;kind<4;kind++){
    ArcadeState g;
    arcadeStart(&g,(ArcadeKind)kind,0x641d12u);
    invalidateArcadeDraw();
    memset(pixels,0,sizeof(pixels));
    compare(&g,theme,kind,-1);
    if(kind==ARCADE_FLAPPY || kind==ARCADE_BREAKOUT){
       arcadeMove(&g,ARCADE_UP);
       compare(&g,theme,kind,0);
    }
    for(int step=1;step<=120;step++){
        if(kind==ARCADE_2048){
            if(step%4==1)arcadeMove(&g,(ArcadeDirection)(rng()%4));
            if(g.game.puzzle.animFrame<3) ++g.game.puzzle.animFrame;
        }else if(kind==ARCADE_SNAKE){
            if(step%5==0)arcadeMove(&g,(ArcadeDirection)(rng()%4));
            arcadeStep(&g);
        }else if(kind==ARCADE_FLAPPY){
            if(step%8==1)arcadeMove(&g,ARCADE_UP);
            arcadeStep(&g);
        }else{
            int8_t motion=(int8_t)((rng()%2)?-6:6);
            arcadeBreakoutPaddle(&g,motion);
            arcadeStep(&g);
            if(g.phase==ARCADE_READY)arcadeMove(&g,ARCADE_UP);
        }
        compare(&g,theme,kind,step);
        if(g.phase==ARCADE_LOST||g.phase==ARCADE_WON){
            arcadePause(&g);compare(&g,theme,kind,step+1000);
            if(g.phase==ARCADE_READY)arcadeMove(&g,ARCADE_UP);
        }
        if(step%26==0){
            arcadePause(&g);compare(&g,theme,kind,step+2000);
            if(g.phase==ARCADE_PAUSED){
                g.pauseChoice=(g.pauseChoice+1)%3;
                compare(&g,theme,kind,step+3000);
            }
            arcadePause(&g);compare(&g,theme,kind,step+4000);
        }
    }
  }
 }
 printf("PASS: %d pixel-perfect dirty/full comparisons; optimized writes=%llu full writes=%llu\n",
        comparisons,(unsigned long long)optimizedWrites,(unsigned long long)fullWrites);
 return 0;
}
