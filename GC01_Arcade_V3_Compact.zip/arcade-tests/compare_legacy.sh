#!/bin/sh
set -eu
ROOT=$(cd "$(dirname "$0")/.." && pwd)
ORIGINAL=${ORIGINAL:-/mnt/data/audit_workspace/radpro-3.1.1}
CC=${CC:-gcc}
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
CFLAGS='-std=c11 -O2 -Wall -Wextra -Werror -Wno-sign-compare -DKEYBOARD_5_KEYS -DKEYBOARD_KEY_POWER_OK -DDISPLAY_320X240 -DDISPLAY_COLOR'
$CC $CFLAGS -I"$ORIGINAL/platform.io/src" -I"$ORIGINAL/platform.io/lib/mcu-renderer" "$ROOT/arcade-tests/test_legacy_keyboard_trace.c" "$ORIGINAL/platform.io/src/peripherals/keyboard.c" -o "$D/stock"
$CC $CFLAGS -DGC01_ARCADE -I"$ROOT/platform.io/src" -I"$ROOT/platform.io/lib/mcu-renderer" "$ROOT/arcade-tests/test_legacy_keyboard_trace.c" "$ROOT/platform.io/src/peripherals/keyboard.c" -o "$D/arcade"
"$D/stock" >"$D/stock.txt"
"$D/arcade" >"$D/arcade.txt"
diff -u "$D/stock.txt" "$D/arcade.txt"
echo 'PASS: legacy measurement/menu key-event traces exactly match stock firmware.'
