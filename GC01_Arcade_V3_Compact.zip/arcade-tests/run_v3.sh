#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
${CC:-gcc} -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -DGC01_ARCADE -Iplatform.io/src/extras arcade-tests/test_v3_features.c platform.io/src/extras/arcade_logic.c -o "$TMP/v3"
"$TMP/v3"
