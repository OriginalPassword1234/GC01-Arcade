#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT
CC=${CC:-gcc}
"$CC" -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined \
  -fno-omit-frame-pointer -DGC01_ARCADE -DGAME -DDISPLAY_320X240 -DDISPLAY_COLOR \
  '-DSTRINGS="strings/en.h"' -Iplatform.io/src -Iplatform.io/src/ui \
  -Iplatform.io/lib/mcu-renderer \
  arcade-tests/test_graphics.c platform.io/src/ui/arcade.c \
  platform.io/src/extras/arcade_logic.c -o "$TMP_DIR/graphics"
ASAN_OPTIONS=detect_leaks=0 "$TMP_DIR/graphics"
