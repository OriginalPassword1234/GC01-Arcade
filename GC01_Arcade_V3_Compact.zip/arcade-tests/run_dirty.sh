#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
${CC:-gcc} -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=undefined -DGC01_ARCADE -DDISPLAY_COLOR -DDISPLAY_320X240 '-DSTRINGS="strings/en.h"' -Iplatform.io/src -Iplatform.io/lib/mcu-renderer arcade-tests/test_dirty_render.c platform.io/src/ui/arcade.c platform.io/src/extras/arcade_logic.c -o "$TMP/dirty"
"$TMP/dirty"
