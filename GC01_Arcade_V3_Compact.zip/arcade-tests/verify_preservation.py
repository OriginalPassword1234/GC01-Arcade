#!/usr/bin/env python3
"""Read-only byte-level comparison of arcade work against exact 3.1.1 source.
Usage: python arcade-tests/verify_preservation.py PATH_TO_UNMODIFIED_RADPRO_3.1.1
"""
import hashlib
import sys
from pathlib import Path

modified = Path(__file__).resolve().parents[1]
if len(sys.argv) < 2:
    raise SystemExit('Provide path to untouched radpro-3.1.1 tree')
original = Path(sys.argv[1]).resolve()
allow = {
    'platform.io/platformio.ini',
    'platform.io/src/extras/game.c',
    'platform.io/src/peripherals/keyboard.c',
    'platform.io/src/peripherals/keyboard.h',
    'platform.io/src/ui/game.c',
    'platform.io/src/ui/view.c',
    'platform.io/src/ui/view.h',
}
new = {
    'platform.io/src/extras/arcade.c',
    'platform.io/src/extras/arcade_logic.c',
    'platform.io/src/extras/arcade_logic.h',
    'platform.io/src/ui/arcade.c',
    'platform.io/src/ui/arcade.h',
}
base_files = {x.relative_to(original).as_posix():x for x in original.rglob('*') if x.is_file()}
mod_files = {x.relative_to(modified).as_posix():x for x in modified.rglob('*') if x.is_file()}
missing = sorted(set(base_files)-set(mod_files))
if missing: raise SystemExit(f'FAIL: original files removed: {missing[:30]}')
changed = sorted(k for k in base_files if base_files[k].read_bytes()!=mod_files[k].read_bytes())
unexpected = sorted(set(changed)-allow)
if unexpected: raise SystemExit(f'FAIL: unauthorized edits: {unexpected}')
for r in new:
    if r not in mod_files:raise SystemExit(f'FAIL: expected arcade module absent: {r}')
# Show exact originals survived inside their per-build compiler guards.
for rel in ('platform.io/src/extras/game.c','platform.io/src/ui/game.c'):
    original_text=base_files[rel].read_text().strip()
    current_text=mod_files[rel].read_text().strip()
    assert current_text.startswith('#if !defined(GC01_ARCADE)')
    assert current_text.endswith('#endif /* !GC01_ARCADE */')
    preserved=current_text.split('\n',1)[1].rsplit('#endif /* !GC01_ARCADE */',1)[0].strip()
    assert preserved==original_text, f'FAIL original chess source changed: {rel}'
# No compiler flag changes in any other environment.
ini_old=base_files['platform.io/platformio.ini'].read_text()
ini_new=mod_files['platform.io/platformio.ini'].read_text()
assert ini_new.replace('    -DGC01_ARCADE\n','') == ini_old
assert ini_new.count('    -DGC01_ARCADE')==1
protected_subpaths = ('platform.io/src/measurements/','platform.io/src/stm32/','platform.io/src/system/')
for rel in changed:
    assert not rel.startswith(protected_subpaths),rel
for rel in ('platform.io/scripts/gc01.ld','tools/sign.py'):
    assert base_files[rel].read_bytes()==mod_files[rel].read_bytes(),rel
print(f'PASS: {len(base_files)} original files present; {len(base_files)-len(changed)} byte-identical; {len(changed)} authorized originals changed; {len(new)} added firmware modules.')
print('Original code modules changed (guarded/extended only):')
for rel in changed:print('   ',rel)
