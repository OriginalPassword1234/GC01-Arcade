#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "peripherals/keyboard.h"
#include "system/events.h"
#include "system/power.h"

static bool sleeping;
void initKeyboardHardware(void) {}
void onKeyboardTick(void) {}
void updateKeyboardState(void) {}
void sleep(uint32_t ticks) {(void)ticks;}
bool isPoweredOn(void) {return true;}
bool isDisplayAwake(void) {return !sleeping;}

static void clearKeys(void) {
    for(int i=0;i<KEY_NUM;++i)keyboardKeyDown[i]=0;
    onKeyboardUpdate();
    while(getKeyboardEvent()!=EVENT_NONE){}
}
static void down(Key k) {keyboardKeyDown[k]=(1u<<KEY_TICKS)-1;onKeyboardUpdate();}
static void up(Key k) {keyboardKeyDown[k]=0;onKeyboardUpdate();}
static void hold(int ticks) {for(int i=0;i<ticks;++i)onKeyboardUpdate();}
int main(void) {
    initKeyboard();setKeyboardMode(KEYBOARD_MODE_GAME);
    down(KEY_LEFT);assert(getKeyboardEvent()==EVENT_KEY_GAME_LEFT);
    hold(80); assert(getKeyboardEvent()==EVENT_NONE); /* no long-Left exit */
    assert(isGameKeyHeld(KEY_LEFT));
    up(KEY_LEFT);assert(getKeyboardEvent()==EVENT_NONE);
    clearKeys();down(KEY_LEFT);assert(getKeyboardEvent()==EVENT_KEY_GAME_LEFT);
    hold(8);up(KEY_LEFT);assert(getKeyboardEvent()==EVENT_NONE);
    clearKeys();down(KEY_RIGHT);assert(isGameKeyHeld(KEY_RIGHT));assert(getKeyboardEvent()==EVENT_KEY_GAME_RIGHT);up(KEY_RIGHT);assert(!isGameKeyHeld(KEY_RIGHT));assert(getKeyboardEvent()==EVENT_NONE);
    clearKeys();down(KEY_UP);assert(getKeyboardEvent()==EVENT_KEY_GAME_UP);hold(80);assert(getKeyboardEvent()==EVENT_NONE);
    up(KEY_UP);
    clearKeys();down(KEY_DOWN);assert(getKeyboardEvent()==EVENT_KEY_GAME_DOWN);up(KEY_DOWN);
    clearKeys();down(KEY_OK);hold(8);up(KEY_OK);assert(getKeyboardEvent()==EVENT_KEY_GAME_OK);
    clearKeys();sleeping=true;down(KEY_LEFT);assert(getKeyboardEvent()==EVENT_KEY_TOGGLEBACKLIGHT);
    hold(39);assert(getKeyboardEvent()==EVENT_NONE);up(KEY_LEFT);sleeping=false;
    clearKeys();down(KEY_LEFT);down(KEY_OK);hold(39);assert(getKeyboardEvent()==EVENT_KEY_TOGGLELOCK);
    assert(getKeyboardEvent()==EVENT_KEY_GAME_LEFT);up(KEY_OK);up(KEY_LEFT);
    /* Holding Left even under queue pressure must never exit. */
    clearKeys();
    for (int i=0;i<20;++i) { down(KEY_RIGHT); up(KEY_RIGHT); }
    down(KEY_LEFT);hold(39);
    for(int i=0;i<16;++i)assert(getKeyboardEvent()!=EVENT_KEY_GAME_EXIT);
    up(KEY_LEFT);
    clearKeys();
    for (int i=0;i<20;++i) { down(KEY_RIGHT); up(KEY_RIGHT); }
    down(KEY_OK);hold(39);
    assert(getKeyboardEvent()==EVENT_KEY_POWER);
    up(KEY_OK);
    clearKeys();
    for (int i=0;i<20;++i) {down(KEY_RIGHT);up(KEY_RIGHT);}
    down(KEY_LEFT);down(KEY_OK);hold(39);
    assert(getKeyboardEvent()==EVENT_KEY_TOGGLELOCK);
    up(KEY_OK);up(KEY_LEFT);
    clearKeys();
    assert(!isGameKeyHeld(KEY_NONE));
    puts("PASS: Left hold never exits; power/lock remain urgent under queue pressure.");
    return 0;
}
