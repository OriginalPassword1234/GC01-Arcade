/* GC-01 arcade V3 reconstructed features: deterministic regression checks. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "arcade_logic.h"
static void difficulty(void){
    const uint32_t s[]={0,7,8,15,16,23,24,100};
    const uint8_t speed[]={3,3,4,4,4,4,5,5};
    const uint8_t gap[]={38,38,36,36,34,34,32,32};
    for(int i=0;i<8;i++){
        assert(arcadeFlappySpeed(s[i])==speed[i]);
        assert(arcadeFlappyHalfGap(s[i])==gap[i]);
    }
}
static void shield(void){
    ArcadeState a; arcadeStart(&a,ARCADE_FLAPPY,0x111u);
    ArcadeFlappy *f=&a.game.flappy;
    a.phase=ARCADE_RUNNING;
    /* Isolate the nearest pipe to check acquisition and one-use protection. */
    f->y=110<<4;f->velocity=0;
    f->pipeX[0]=45;f->pipeGap[0]=110;f->pipeHalfGap[0]=38;
    f->pipeShield[0]=1;f->pipeTaken[0]=0;f->pipeSafe[0]=0;
    arcadeStep(&a);
    assert(f->shield==1&&f->pipeTaken[0]==1&&a.phase==ARCADE_RUNNING);
    /* Force an overlap with the top pipe: shield consumed only once. */
    f->y=61<<4;f->velocity=0;
    arcadeStep(&a);
    assert(f->shield==0&&f->pipeSafe[0]==1&&a.phase==ARCADE_RUNNING);
    arcadeStep(&a);
    assert(a.phase==ARCADE_RUNNING); /* still within same pipe */
    /* Unprotected collision with a new pipe must end the round. */
    f->pipeSafe[0]=0;
    arcadeStep(&a);
    assert(a.phase==ARCADE_LOST);
    arcadeStart(&a,ARCADE_FLAPPY,0x161u);
    a.phase=ARCADE_RUNNING;f=&a.game.flappy;
    f->shield=1;f->y=231<<4;f->velocity=62;
    arcadeStep(&a);
    assert(a.phase==ARCADE_LOST); /* shield doesn't protect floor */
}
static void bricks(void){
    ArcadeState a;arcadeStart(&a,ARCADE_BREAKOUT,0x181u);
    ArcadeBreakout *b=&a.game.breakout;
    assert(b->velocityX==23&&b->velocityY==-68);
    int normal=0,reinforced=0,bonus=0;
    for(int i=0;i<32;i++){
        normal+=b->bricks[i]==1;
        reinforced+=b->bricks[i]==2;
        bonus+=b->bricks[i]==3;
    }
    assert(normal>0&&reinforced>0&&bonus>0);
    a.phase=ARCADE_RUNNING;
    memset(b->bricks,0,sizeof(b->bricks));
    b->bricks[0]=2;b->bricksLeft=1;
    b->ballX=15<<4;b->ballY=14<<4;
    b->velocityX=0;b->velocityY=90;
    b->lastHitBrick=255;
    arcadeStep(&a);
    assert(b->bricks[0]==1&&b->bricksLeft==1&&a.score==5);
    /* Second independent impact destroys reinforced brick and starts next level. */
    b->ballX=15<<4;b->ballY=14<<4;
    b->velocityX=0;b->velocityY=90;b->lastHitBrick=255;
    arcadeStep(&a);
    assert(b->level==2&&b->bricksLeft==32&&a.phase==ARCADE_READY);
    arcadeMove(&a,ARCADE_UP);assert(a.phase==ARCADE_RUNNING);
    memset(b->bricks,0,sizeof(b->bricks));
    b->bricks[0]=3;b->bricks[1]=1;b->bricksLeft=2;
    b->ballX=15<<4;b->ballY=14<<4;
    b->velocityX=0;b->velocityY=100;b->lastHitBrick=255;
    uint32_t old=a.score;
    arcadeStep(&a);
    assert(a.score==old+30&&b->bricksLeft==1&&b->bricks[0]==0&&b->bricks[1]==1);
    /* Paddle held movement never changes phase or exits. */
    b->paddleX=120;
    arcadeBreakoutPaddle(&a,-7);
    assert(b->paddleX==113&&a.phase==ARCADE_RUNNING);
    /* Pause menu: 0=resume 1=restart 2=exit, no left-button shortcut. */
    arcadePause(&a);assert(a.phase==ARCADE_PAUSED);
    a.pauseChoice=0;arcadeChoosePause(&a);assert(a.phase==ARCADE_RUNNING);
}
static void animation(void){
    ArcadeState a;arcadeStart(&a,ARCADE_2048,0x197u);
    memset(a.game.puzzle.cells,0,16);
    a.game.puzzle.cells[0]=1;a.game.puzzle.cells[1]=1;
    arcadeMove(&a,ARCADE_LEFT);
    assert(a.game.puzzle.animFrame==0);
    assert(a.game.puzzle.to[0]==0&&a.game.puzzle.to[1]==0);
    assert(a.game.puzzle.from[0]==1&&a.game.puzzle.from[1]==1);
    assert(a.game.puzzle.cells[0]==2&&a.score==4);
    a.game.puzzle.animFrame=3;
    /* A blocked move must not spawn new tiles or replay animation. */
    memset(a.game.puzzle.cells,1,16);
    for(int i=0;i<16;i++)a.game.puzzle.cells[i]=(i%2)?2:1;
    uint8_t before[16];memcpy(before,a.game.puzzle.cells,16);
    arcadeMove(&a,ARCADE_LEFT);
    assert(!memcmp(before,a.game.puzzle.cells,16));
    assert(a.game.puzzle.animFrame==3);
}
int main(void){difficulty();shield();bricks();animation();puts("PASS: V3 animations, shield, difficulty, reinforced and bonus bricks, paddle and pause");return 0;}
