/* Emits a deterministic trace to compare stock and arcade-enabled keyboard. */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "peripherals/keyboard.h"
#include "system/events.h"
#include "system/power.h"
static bool sleeping = false;
void initKeyboardHardware(void) {}
void onKeyboardTick(void) {}
void updateKeyboardState(void) {}
void sleep(uint32_t ticks) { (void)ticks; }
bool isPoweredOn(void) {return true;}
bool isDisplayAwake(void) {return !sleeping;}
static void dump(const char *tag) {
    ViewEvent e;
    while ((e=getKeyboardEvent()) != EVENT_NONE) printf("%s=%d\n",tag,(int)e);
}
static void key(Key k,int held,const char *tag) {
    keyboardKeyDown[k] = (1u<<KEY_TICKS)-1;
    onKeyboardUpdate();dump(tag);
    for(int i=0;i<held;++i) {onKeyboardUpdate();dump(tag);}
    keyboardKeyDown[k] = 0;
    onKeyboardUpdate();dump(tag);
}
static void chord(Key a,Key b,const char *tag) {
    keyboardKeyDown[a] = (1u<<KEY_TICKS)-1;
    keyboardKeyDown[b] = (1u<<KEY_TICKS)-1;
    onKeyboardUpdate();dump(tag);
    for(int i=0;i<48;++i){onKeyboardUpdate();dump(tag);}
    keyboardKeyDown[a]=keyboardKeyDown[b]=0;
    onKeyboardUpdate();dump(tag);
}
static void seq(KeyboardMode mode, const char* tag) {
    setKeyboardMode(mode);
    for(int k=0;k<KEY_NUM;++k)key((Key)k,5,tag);
    for(int k=0;k<KEY_NUM;++k)key((Key)k,45,tag);
    chord(KEY_LEFT,KEY_OK,tag);
    sleeping=true;key(KEY_LEFT,5,tag);key(KEY_OK,5,tag);sleeping=false;
    key(KEY_UP,32,tag);key(KEY_DOWN,34,tag);
}
int main(void) {
    initKeyboard();
    seq(KEYBOARD_MODE_MEASUREMENT,"measurement");
    seq(KEYBOARD_MODE_MENU,"menu");
    return 0;
}
