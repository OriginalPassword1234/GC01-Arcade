# FNIRSI GC-01 / Rad Pro 3.1.1 — Arcade V3 Compact (reconstructed)

**SOURCE OVERLAY ONLY — DO NOT FLASH THIS ZIP.**

This archive was reconstructed from the user's uploaded earlier full arcade source tree, the
V3/V3 Compact feature handover, and regression tests. It is a **new reconstruction** and is
**not proven byte-identical** to the previously lost 48,706-byte V3 Compact ZIP.

Target: `fnirsi-gc01_apm32f103rb-en` (APM32F103RB, 320×240 color display, five buttons).
Base: the *source* of the `3.1.1` tag of `Gissio/radpro`, **not** the precompiled
`radpro-3.1.1.zip` firmware release distribution.

Four games: Snake, animated 2048, Flappy Bird (shield plus progressive difficulty),
Breakout (faster ball, reinforced/bonus bricks and substep collisions).

The source overlay adds five firmware modules and changes seven existing ones, plus the
target build configuration. The original chess sources remain inside `#if !GC01_ARCADE`.
No source files under original radiation measurement, logging, power, hardware, or USB
implementations, linker layout, settings structure, or signing process were modified.
Existing firmware functions may still be affected indirectly by CPU/display load; real
hardware verification is required.

## Use

1. Download the *source archive* for Rad Pro 3.1.1:
   `https://github.com/Gissio/radpro/archive/refs/tags/3.1.1.zip`.
2. Extract the original archive and extract **this overlay** on top of its root folder.
3. Run `./arcade-tests/run.sh`, `./arcade-tests/run_v3.sh`,
   `./arcade-tests/run_graphics.sh`, and `./arcade-tests/run_dirty.sh`.
4. Run the provided GitHub Actions workflow for a full PlatformIO ARM build.

**This source has passed native software tests and Cortex-M3 Clang compilation of the arcade
modules, but it has NOT been validated by the complete PlatformIO / GCC link or by hardware.**
The actual application raw payload may not exceed **57,340 bytes** (56 KiB less CRC).
Do not sign, install, or flash any unsigned/raw/oversized firmware.

## Controls

Directions: move Snake, 2048 tiles, paddle (Breakout) or flap (Up in Flappy).
Breakout: hold Left/Right to move the paddle; Up launches the ball.
During a game: OK opens the pause menu; Up/Down selects RESUME, RESTART or EXIT; OK
confirms. **Holding Left does NOT exit**. Original non-game keyboard controls are preserved.

## Source integrity

The workflow's archive SHA-256 must match this newly generated ZIP, not the checksum
recorded for the now-unavailable earlier archive.
