/* Independent Rider-inspired simulation prototype v0.7.
 * Builds on v0.4 with more section variety, saw/boost piece metadata,
 * small gaps, subpixel track sampling and compact hazard collision checks.
 * Still NOT a Box2D/LiquidFun port and still not full original parity. */
#include "rider_core.h"
#include <limits.h>
#include <string.h>

#define PIECE_FLAG_GEM   0x01u
#define PIECE_FLAG_SAW   0x02u
#define PIECE_FLAG_BOOST 0x04u

/* Compact synthesized geometry. Template 16 is a real non-heightfield
 * loop PATH, guided by the same model used to draw it. Not original game data. */
static const int8_t heights[][RIDER_TRACK_NODES] = {
  {0, 0, 0, 0, 0, 0, 0, 0, 0},
  {0, 0, -5, -20, -29, -18, -4, 0, 0},
  {0, 0, 8, 24, 30, 17, 3, 0, 0},
  {0, -4, -17, -9, 5, 0, -12, -3, 0},
  {0, 0, -9, -28, -16, -3, 9, 0, 0},
  {0, 0, 6, 18, 8, -14, -24, -5, 0},
  {0, 0, -8, -22, -34, -17, -7, 0, 0},
  {0, 0, 5, 14, 24, 10, -8, 0, 0},
  {0, 0, -12, -30, -42, -24, -9, 0, 0},
  {0, 0, 10, 28, 38, 20, 5, 0, 0},
  {0, -2, -10, -5, 12, 3, -14, -5, 0},
  {0, 0, -4, -12, -18, -10, -4, 0, 0},
  {0, 0, -2, -8, -10, -7, -2, 0, 0},
  {0, -6, -21, -32, -35, 12, 22, 8, 0}, /* split ramp and descending landing */
  {0, 0, -10, -29, -43, -8, 12, 1, 0}, /* tall ejector and drop */
  {0, -5, -14, -25, -34, 2, 17, 5, 0}, /* lip to landing gap */
  {0, 0, 0, 0, 0, 0, 0, 0, 0}  /* real closed loop section */
};
#define N_TEMPLATES ((uint32_t)(sizeof(heights)/sizeof(heights[0])))
static const int16_t sine256[256] = {
       0,    6,   13,   19,   25,   31,   38,   44,   50,   56,   62,   68,   74,   80,   86,   92,
      98,  104,  109,  115,  121,  126,  132,  137,  142,  147,  152,  157,  162,  167,  172,  177,
     181,  185,  190,  194,  198,  202,  206,  209,  213,  216,  220,  223,  226,  229,  231,  234,
     237,  239,  241,  243,  245,  247,  248,  250,  251,  252,  253,  254,  255,  255,  256,  256,
     256,  256,  256,  255,  255,  254,  253,  252,  251,  250,  248,  247,  245,  243,  241,  239,
     237,  234,  231,  229,  226,  223,  220,  216,  213,  209,  206,  202,  198,  194,  190,  185,
     181,  177,  172,  167,  162,  157,  152,  147,  142,  137,  132,  126,  121,  115,  109,  104,
      98,   92,   86,   80,   74,   68,   62,   56,   50,   44,   38,   31,   25,   19,   13,    6,
       0,   -6,  -13,  -19,  -25,  -31,  -38,  -44,  -50,  -56,  -62,  -68,  -74,  -80,  -86,  -92,
     -98, -104, -109, -115, -121, -126, -132, -137, -142, -147, -152, -157, -162, -167, -172, -177,
    -181, -185, -190, -194, -198, -202, -206, -209, -213, -216, -220, -223, -226, -229, -231, -234,
    -237, -239, -241, -243, -245, -247, -248, -250, -251, -252, -253, -254, -255, -255, -256, -256,
    -256, -256, -256, -255, -255, -254, -253, -252, -251, -250, -248, -247, -245, -243, -241, -239,
    -237, -234, -231, -229, -226, -223, -220, -216, -213, -209, -206, -202, -198, -194, -190, -185,
    -181, -177, -172, -167, -162, -157, -152, -147, -142, -137, -132, -126, -121, -115, -109, -104,
     -98,  -92,  -86,  -80,  -74,  -68,  -62,  -56,  -50,  -44,  -38,  -31,  -25,  -19,  -13,   -6,
};
int16_t rider_sin256(uint8_t angle_index) { return sine256[angle_index]; }
int16_t rider_sin4096(int32_t angle)
{
    uint32_t a=(uint32_t)angle & (RIDER_ANGLE_TURN-1u);
    uint32_t k=a>>4, f=a&15u;
    int32_t v0=sine256[k], v1=sine256[(k+1u)&255u];
    return (int16_t)(v0+(v1-v0)*(int32_t)f/16);
}
/* A full non-monotonic loop, continuous with flat ground at t=0 and t=4096.
 * x(t)=start+70+60*t+75*sin(t); y(t)=166-60*(1-cos(t)).
 * Coordinates Q8; no dynamic allocation, no float operations in firmware. */
bool rider_loop_point_q(uint32_t pn, uint16_t t, int32_t *xq, int32_t *yq)
{
    if (t>RIDER_ANGLE_TURN || pn>25000u || !xq || !yq) return false;
    *xq=(int32_t)(pn*RIDER_PIECE_WIDTH+70u)*RIDER_Q +
        ((int32_t)60*RIDER_Q*t)/RIDER_ANGLE_TURN + 75*rider_sin4096(t);
    *yq=166*RIDER_Q-60*(RIDER_Q-rider_sin4096((int32_t)t+1024));
    return true;
}
static int32_t angle_from_vector(int32_t dx,int32_t dy)
{
    /* atan2 approximation in 4096 turn units, max error a few degrees. */
    int32_t ax=dx<0?-dx:dx, ay=dy<0?-dy:dy;
    if(!ax && !ay) return 0;
    int32_t oct=(ax>=ay)? (ay*512)/(ax+ay/3+1) :
                              1024-(ax*512)/(ay+ax/3+1);
    if(dx<0) oct=2048-oct;
    if(dy<0) oct=-oct;
    return oct;
}

static uint32_t next_random(RiderState *s)
{
    uint32_t x = s->random_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    s->random_state = x;
    return x;
}

static int32_t clamp_i32(int32_t a,int32_t lo,int32_t hi)
{
    return a<lo ? lo : a>hi ? hi : a;
}

static uint8_t choose_template(RiderState *s, uint32_t n)
{
    static const uint8_t easy[]  = {1,2,3,4,5,6,7,8};
    static const uint8_t mid[]   = {1,2,3,4,5,6,7,8,11,13,15,16};
    static const uint8_t hard[]  = {2,4,5,6,7,8,9,10,11,12,13,15,16};
    static const uint8_t expert[]= {4,5,7,8,9,10,11,12,13,15,16};
    const uint8_t *pool = easy;
    uint32_t pool_n = (uint32_t)(sizeof(easy)/sizeof(easy[0]));
    /* Prefer piece progression because score depends on player skill; this
     * keeps content varied in previews while remaining deterministic. */
    if (n >= 75) { pool = expert; pool_n = (uint32_t)(sizeof(expert)/sizeof(expert[0])); }
    else if (n >= 40) { pool = hard; pool_n = (uint32_t)(sizeof(hard)/sizeof(hard[0])); }
    else if (n >= 15) { pool = mid; pool_n = (uint32_t)(sizeof(mid)/sizeof(mid[0])); }
    uint8_t t = pool[next_random(s) % pool_n];
    if (t == s->last_template) {
        t = pool[(next_random(s) + 1u) % pool_n];
    }
    return t;
}

static void append_piece(RiderState *s)
{
    uint32_t n = s->next_piece++;
    RiderPiece *p = &s->track[n % RIDER_TRACK_SLOTS];
    uint8_t pattern = 0;
    if (n != 0) pattern = choose_template(s, n);
    p->number = n;
    p->template_id = pattern;
    p->start_y = 166;
    p->flags = 0;
    if ((n & 1u) && n != 0u && pattern!=16u) p->flags |= PIECE_FLAG_GEM; /* near every other section */
    /* No disconnected floating saws. Later saws belong only to explicit
     * hazard sections with nearby rail geometry. */
    if (pattern == 9u || pattern == 10u)
        p->flags |= PIECE_FLAG_SAW;
    if (pattern == 11u) p->flags |= PIECE_FLAG_BOOST;
    s->last_template = pattern;
}

/* Hermite curve with slopes derived from adjacent knots; flat end tangents. */
static int32_t sample_curve_q(uint8_t kind, uint32_t local_x_q)
{
    if (kind >= N_TEMPLATES) return 0;
    uint32_t k = local_x_q / (32u*RIDER_Q);
    if (k >= 8) return 0;
    int32_t t = (int32_t)((local_x_q % (32u*RIDER_Q)) / 32u);
    int32_t t2 = t * t / RIDER_Q, t3 = t2 * t / RIDER_Q;
    int32_t a = 2*t3-3*t2+RIDER_Q, b=-2*t3+3*t2;
    int32_t c = t3-2*t2+t, d=t3-t2;
    int32_t v0 = heights[kind][k];
    int32_t v1 = heights[kind][k+1];
    int32_t m0 = k ? ((int32_t)heights[kind][k+1]-heights[kind][k-1])/2 : 0;
    int32_t m1 = k+1<8 ? ((int32_t)heights[kind][k+2]-heights[kind][k])/2 : 0;
    return a*v0 + b*v1 + c*m0 + d*m1;
}

static bool template_gap(uint8_t kind, uint32_t local_x_q)
{
    if (kind == 16u) return local_x_q>=70u*RIDER_Q && local_x_q<=130u*RIDER_Q;
    if (kind == 12u) return local_x_q >= 102u*RIDER_Q && local_x_q <= 152u*RIDER_Q;
    if (kind == 13u || kind == 15u) return local_x_q >= 102u*RIDER_Q && local_x_q <= 154u*RIDER_Q;
    return false;
}

bool rider_surface_q(const RiderState *s, int32_t world_x_q, int32_t *world_y_q)
{
    if (world_x_q < 0) return false;
    uint32_t number = (uint32_t)world_x_q / (RIDER_PIECE_WIDTH*RIDER_Q);
    const RiderPiece *p = &s->track[number % RIDER_TRACK_SLOTS];
    if (p->number != number || number >= s->next_piece) return false;
    uint32_t local_x_q = (uint32_t)world_x_q % (RIDER_PIECE_WIDTH*RIDER_Q);
    if (template_gap(p->template_id, local_x_q)) return false;
    int32_t offset = sample_curve_q(p->template_id, local_x_q);
    *world_y_q = (int32_t)p->start_y*RIDER_Q + offset;
    return true;
}

bool rider_piece_saw_q(const RiderState *s, uint32_t piece_number, int32_t *cx_q, int32_t *cy_q, int32_t *radius_q)
{
    const RiderPiece *p = &s->track[piece_number % RIDER_TRACK_SLOTS];
    if (p->number != piece_number || !(p->flags & PIECE_FLAG_SAW)) return false;
    uint32_t local_px = (p->template_id == 10u) ? 176u : 146u;
    *cx_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + local_px) * RIDER_Q;
    int32_t yq;
    if (!rider_surface_q(s, *cx_q, &yq)) return false;
    /* Place the full blade above the LOCAL rail. Collisions are computed
     * against the same center/radius used by the renderer. */
    /* 18px blade, ~19px clearance under its teeth at the local rail. */
    *cy_q=yq-43*RIDER_Q;
    *radius_q = 18 * RIDER_Q;
    return true;
}

bool rider_piece_boost_q(const RiderState *s, uint32_t piece_number, int32_t *x0_q, int32_t *x1_q, int32_t *y_q)
{
    const RiderPiece *p = &s->track[piece_number % RIDER_TRACK_SLOTS];
    if (p->number != piece_number || !(p->flags & PIECE_FLAG_BOOST)) return false;
    *x0_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 92u) * RIDER_Q;
    *x1_q = (int32_t)(piece_number * RIDER_PIECE_WIDTH + 148u) * RIDER_Q;
    int32_t mid = (*x0_q + *x1_q) / 2;
    return rider_surface_q(s, mid, y_q);
}

void rider_wheel_centers_q(const RiderState *s, int32_t *lx, int32_t *ly,
                           int32_t *rx, int32_t *ry)
{
    int32_t si = rider_sin4096(s->angle), co = rider_sin4096(s->angle+1024);
    int32_t dx = co*12, dy = si*12;
    *lx = s->x-dx; *ly=s->y-dy;
    *rx = s->x+dx; *ry=s->y+dy;
}

void rider_restart(RiderState *s)
{
    uint32_t saved_best = (uint32_t)s->best;
    int32_t saved_diamonds = s->diamonds;
    uint32_t seed = s->random_state ^ 0x9e3779b9u;
    rider_init(s, seed);
    s->best = (int32_t)saved_best;
    s->diamonds = saved_diamonds;
}

void rider_init(RiderState *s, uint32_t seed)
{
    memset(s, 0, sizeof(*s));
    s->random_state = seed ? seed : 0xd88ec19bu;
    for (uint32_t i=0; i<RIDER_TRACK_SLOTS; ++i) append_piece(s);
    s->x = 70*RIDER_Q;
    s->y = 161*RIDER_Q;
    s->camera_x = 0;
    s->camera_y = 0;
    s->phase=RIDER_READY;
    s->grounded=1;
}

static void commit_pending(RiderState *s)
{
    if (s->pending_ticks) {
        --s->pending_ticks;
        if (!s->pending_ticks) {
            s->score+=s->pending_score;
            if(s->score>s->best) s->best=s->score;
            s->pending_score=0;
        }
    }
}

static void crash(RiderState *s)
{
    s->phase=RIDER_CRASHED;
    s->pending_score=0;
    s->pending_ticks=0;
}

static void maybe_collect_gem(RiderState *s, uint32_t piece_number)
{
    RiderPiece *piece=&s->track[piece_number % RIDER_TRACK_SLOTS];
    if (piece->number!=piece_number || !(piece->flags & PIECE_FLAG_GEM)) return;
    int32_t gem_x=(int32_t)(piece_number*RIDER_PIECE_WIDTH+128u)*RIDER_Q;
    int32_t gem_surf;
    if (rider_surface_q(s,gem_x,&gem_surf)) {
        int32_t distx=s->x-gem_x;
        int32_t disty=s->y-(gem_surf-17*RIDER_Q);
        if (distx>-12*RIDER_Q && distx<12*RIDER_Q &&
            disty>-15*RIDER_Q && disty<15*RIDER_Q) {
            piece->flags &= (uint8_t)~PIECE_FLAG_GEM;
            if (s->diamonds<INT32_MAX) ++s->diamonds;
        }
    }
}

static bool saw_hit_q(int32_t px, int32_t py, int32_t cx, int32_t cy, int32_t rr)
{
    int64_t dx = (int64_t)px - cx;
    int64_t dy = (int64_t)py - cy;
    return dx*dx + dy*dy <= (int64_t)rr*rr;
}

/* Loop runs are deliberately guided: a small MCU cannot fit Box2D and the
 * original collision graph alongside Rad Pro. The path itself is a true
 * overlapping loop, not a fake x-height hill. This is NOT rigid-body parity. */
static void step_loop(RiderState *s,bool held)
{
    uint32_t pn=s->loop_piece;
    int32_t travel = s->vx;
    if(held) travel=clamp_i32(travel+6,2*RIDER_Q,6*RIDER_Q);
    else travel=clamp_i32(travel-4,2*RIDER_Q,6*RIDER_Q);
    s->vx=travel;
    uint32_t advance=(uint32_t)(travel*RIDER_ANGLE_TURN/(410*RIDER_Q));
    if(advance<30)advance=30;
    uint32_t nt=(uint32_t)s->loop_t+advance;
    if(nt>=RIDER_ANGLE_TURN) {
        s->loop_t=RIDER_ANGLE_TURN;
        s->looping=0;
        s->x=(int32_t)(pn*RIDER_PIECE_WIDTH+130u)*RIDER_Q;
        s->y=161*RIDER_Q;
        s->angle=-RIDER_ANGLE_TURN;
        s->vy=0;
        s->angular_speed=0;
        s->grounded=1;
        s->airborne_ticks=0;
        s->air_rotation=0;
        return;
    }
    s->loop_t=(uint16_t)nt;
    int32_t xx,yy,xb,yb,xa,ya;
    rider_loop_point_q(pn,s->loop_t,&xx,&yy);
    rider_loop_point_q(pn,(uint16_t)(s->loop_t>8?s->loop_t-8:0),&xb,&yb);
    rider_loop_point_q(pn,(uint16_t)(s->loop_t<4088?s->loop_t+8:4096),&xa,&ya);
    int32_t tangent=angle_from_vector(xa-xb,ya-yb);
    int32_t si=rider_sin4096(tangent),co=rider_sin4096(tangent+1024);
    s->x=xx+si*5;
    s->y=yy-co*5;
    /* Continuous 0..4096 rotation around loop. */
    if(s->loop_t>RIDER_ANGLE_TURN/2 && tangent>0)tangent-=RIDER_ANGLE_TURN;
    s->angle=tangent;
    s->grounded=1;
    s->vy=0;
    s->angular_speed=0;
}

static void update_camera(RiderState *s)
{
    int32_t tx=s->x-94*RIDER_Q;
    int32_t ty=s->y-130*RIDER_Q;
    /* Resist 1px snaps as the vehicle crosses changing slopes. */
    s->camera_x += clamp_i32((tx-s->camera_x)/5,-7*RIDER_Q,7*RIDER_Q);
    s->camera_y += clamp_i32((ty-s->camera_y)/10,-3*RIDER_Q,3*RIDER_Q);
}

void rider_step(RiderState *s, bool held)
{
    if (s->phase==RIDER_CRASHED) {
        if (s->crash_ticks<UINT16_MAX) ++s->crash_ticks;
        return;
    }
    if (s->phase==RIDER_READY) {
        if (!held) return;
        s->phase=RIDER_RUNNING;
    }
    commit_pending(s);
    ++s->tick_count;
    if(s->perfect_ticks) --s->perfect_ticks;
    if(s->boost_ticks) --s->boost_ticks;
    if(s->looping) {
        step_loop(s,held);
        update_camera(s);
        return;
    }
    const bool was_grounded=s->grounded!=0;
    const int32_t old_x=s->x;
    const int32_t old_y=s->y;
    if(was_grounded) {
        int32_t ahead,behind,slope_drive=0;
        if(rider_surface_q(s,s->x+12*RIDER_Q,&ahead) &&
           rider_surface_q(s,s->x-12*RIDER_Q,&behind))
            slope_drive=clamp_i32((ahead-behind)/320,-16,16);
        const int32_t cap=s->boost_ticks?7*RIDER_Q:6*RIDER_Q;
        s->vx=clamp_i32(s->vx+(held?14:-6)+slope_drive,0,cap);
        s->angular_speed=0;
    } else {
        if(s->airborne_ticks<UINT16_MAX) ++s->airborne_ticks;
        s->vy=clamp_i32(s->vy+28,-7*RIDER_Q,8*RIDER_Q);
        if(held && s->airborne_ticks>=5) {
            s->angular_speed=clamp_i32(s->angular_speed+12,0,128);
        } else {
            s->angular_speed=(s->angular_speed*247)/256;
        }
        s->angle+=s->angular_speed;
        s->air_rotation+=(uint32_t)s->angular_speed;
        if(s->air_rotation>16u*RIDER_ANGLE_TURN)s->air_rotation=16u*RIDER_ANGLE_TURN;
    }
    s->x+=s->vx;
    s->y+=s->vy;
    uint32_t piece_number=(uint32_t)(s->x/(RIDER_PIECE_WIDTH*RIDER_Q));
    if(piece_number+7>=s->next_piece)append_piece(s);

    /* Enter a closed loop only on the leading rail and at adequate speed. */
    const RiderPiece *piece=&s->track[piece_number%RIDER_TRACK_SLOTS];
    if(was_grounded && piece->number==piece_number && piece->template_id==16u) {
        int32_t entrance=(int32_t)(piece_number*RIDER_PIECE_WIDTH+70u)*RIDER_Q;
        if(old_x<entrance && s->x>=entrance && s->vx>2*RIDER_Q) {
            s->looping=1;
            s->loop_piece=piece_number;
            s->loop_t=0;
            s->x=entrance;
            s->y=161*RIDER_Q;
            s->angle=0;
            s->angular_speed=0;
            step_loop(s,held);
            update_camera(s);
            return;
        }
    }
    int32_t yl=0,yr=0,xl,xr,wl,wr;
    rider_wheel_centers_q(s,&xl,&wl,&xr,&wr);
    bool left=rider_surface_q(s,xl,&yl),right=rider_surface_q(s,xr,&yr);
    int32_t dl=left?wl+5*RIDER_Q-yl:INT32_MIN/4;
    int32_t dr=right?wr+5*RIDER_Q-yr:INT32_MIN/4;
    bool contact=(left&&dl>=-RIDER_Q/2)||(right&&dr>=-RIDER_Q/2);
    /* Once the wheel has left the track, only descending motion can land. */
    if(contact && (was_grounded || s->vy>=0)) {
        int32_t tangent=0;
        if(left&&right) {
            int32_t difference=yr-yl;
            tangent=clamp_i32((difference*652)/(24*RIDER_Q),-460,460);
        }
        int32_t phase=((s->angle-tangent+2048)&4095)-2048;
        int32_t impact= s->vy;
        /* Small slopes don't kill the car. Serious upside-down impact does. */
        if((phase>1400||phase<-1400) ||
           ((phase>1050||phase<-1050)&&impact>3*RIDER_Q)) {
            crash(s); return;
        }
        if(!was_grounded) {
            /* Count actual in-air rotation rather than comparing snapped
             * start/end angles. Near-complete revolutions get a small margin. */
            uint32_t n=(s->air_rotation+128u)/RIDER_ANGLE_TURN;
            if(n>8)n=8;
            if(n) {
                if(s->pending_ticks) {
                    s->score+=s->pending_score;
                    if(s->score>s->best)s->best=s->score;
                    s->pending_score=0;
                }
                s->pending_score=(uint16_t)n;
                s->pending_ticks=30;
                s->perfect_ticks=(left&&right &&
                    dl-dr<3*RIDER_Q && dr-dl<3*RIDER_Q)?48:0;
            }
        }
        int32_t penetration=dl>dr?dl:dr;
        if(penetration>0)s->y-=penetration;
        /* Never convert a ground-position correction into an upward kick. */
        s->vy=clamp_i32(s->y-old_y,-2*RIDER_Q,2*RIDER_Q);
        if(!was_grounded && impact>0)s->vy=0; /* absorb landing impulse */
        int32_t nearest=(s->angle & ~4095)+tangent;
        if(nearest-s->angle>2048)nearest-=4096;
        if(s->angle-nearest>2048)nearest+=4096;
        int32_t d=nearest-s->angle;
        s->angle+=clamp_i32(d/6,-70,70);
        s->grounded=1;
        s->airborne_ticks=0;
        s->air_rotation=0;
    } else {
        if(was_grounded) {
            s->takeoff_angle=s->angle;
            s->air_rotation=0;
            s->airborne_ticks=0;
        }
        s->grounded=0;
    }
    /* Boost pads only trigger with the bike in ground contact and along the
     * underlying curved surface. They provide an obvious temporary effect. */
    if(s->grounded) {
        int32_t bx0,bx1,by;
        if(rider_piece_boost_q(s,piece_number,&bx0,&bx1,&by) &&
           s->x>=bx0 && s->x<=bx1) {
            if(s->boost_ticks<5)s->vx=clamp_i32(s->vx+100,0,7*RIDER_Q);
            s->boost_ticks=26;
        }
    }
    /* Recalculate wheel positions AFTER penetration correction. */
    rider_wheel_centers_q(s,&xl,&wl,&xr,&wr);
    for(uint32_t pn=piece_number?piece_number-1u:0u;pn<=piece_number+1u;++pn) {
        int32_t cx,cy,r;
        if(!rider_piece_saw_q(s,pn,&cx,&cy,&r))continue;
        if(saw_hit_q(s->x,s->y,cx,cy,r+6*RIDER_Q) ||
           saw_hit_q(xl,wl,cx,cy,r+4*RIDER_Q) ||
           saw_hit_q(xr,wr,cx,cy,r+4*RIDER_Q)) {crash(s);return;}
    }
    maybe_collect_gem(s,piece_number);
    if(piece_number+1u<s->next_piece)maybe_collect_gem(s,piece_number+1u);
    update_camera(s);
    if(s->x>INT32_MAX-150000 || s->y>410*RIDER_Q) crash(s);
}

uint32_t rider_hash(const RiderState *s)
{
    uint32_t x=2166136261u;
#define HASH(v) do { x^=(uint32_t)(v); x*=16777619u; } while(0)
    HASH(s->random_state); HASH(s->next_piece); HASH(s->x); HASH(s->y);
    HASH(s->vx);HASH(s->vy);HASH(s->angle);HASH(s->phase);HASH(s->score);HASH(s->tick_count);HASH(s->air_rotation);HASH(s->loop_t);HASH(s->looping);HASH(s->boost_ticks);
    for (uint32_t i=0;i<RIDER_TRACK_SLOTS;i++) {
        HASH(s->track[i].number);HASH(s->track[i].template_id);HASH(s->track[i].flags);
    }
#undef HASH
    return x;
}
