#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
static FILE *out;
static int next;
static void sink(int top,int rows,const uint16_t *pix,void *unused)
{
    (void)unused;
    assert(top==next && rows==3);
    for(int i=0;i<rows*320;i++) {
        const uint16_t p=pix[i];
        const uint8_t rgb[3]={(uint8_t)(((p>>11)&31)*255/31),
                              (uint8_t)(((p>>5)&63)*255/63),
                              (uint8_t)((p&31)*255/31)};
        assert(fwrite(rgb,1,3,out)==3);
    }
    next+=rows;
}
int main(int argc,char **argv)
{
    if(argc!=3){fprintf(stderr,"usage: render_scenes [jump|score|saw|loop] output.ppm\n");return 2;}
    RiderState s;rider_init(&s,3u);
    if(argv[1][0]=='j') {
        for(int t=0;t<110;++t)rider_step(&s,s.grounded || s.airborne_ticks<24u);
    } else if(argv[1][0]=='s' && argv[1][1]=='c') {
        for(int t=0;t<360;++t){rider_step(&s,s.grounded || s.airborne_ticks<24u);if(s.score>=1)break;}
        assert(s.score>=1);
    } else if(argv[1][0]=='l') {
        rider_init(&s,0x4444u);
        /* Fixture selects a known existing loop template so its geometry is
         * deterministic. Rider then traverses it using real core steps. */
        s.track[0].template_id=16u;
        s.phase=RIDER_RUNNING;
        s.vx=4*RIDER_Q;
        s.x=65*RIDER_Q;
        s.y=161*RIDER_Q;
        s.grounded=1;
        int seen=0;
        for(int t=0;t<50;++t){
            rider_step(&s,1);
            if(s.looping && s.loop_t>1300u){seen=1;break;}
        }
        assert(seen && s.looping);
        s.camera_x=-6*RIDER_Q;
        s.camera_y=-4*RIDER_Q;
    } else if(argv[1][0]=='s'){
        rider_init(&s,0x1832u);
        for(int t=0;t<6000;++t){
            rider_step(&s,s.grounded!=0);
            if(s.phase==RIDER_CRASHED)break;
            uint32_t n=(uint32_t)(s.x/(256*RIDER_Q));
            int32_t x,y,r;
            if(n+1u<s.next_piece && rider_piece_saw_q(&s,n+1u,&x,&y,&r)) {
                int dx=(int)((x-s.camera_x)/RIDER_Q);
                if(dx>265 && dx<300)break;
            }
        }
    } else return 2;
    out=fopen(argv[2],"wb");assert(out);
    fprintf(out,"P6\n320 240\n255\n");
    rider_render(&s,0,0,sink,0);
    assert(next==240 && fclose(out)==0);
    printf("scene score=%d x=%d y=%d phase=%d\n",s.score,s.x/256,s.y/256,s.phase);
}
