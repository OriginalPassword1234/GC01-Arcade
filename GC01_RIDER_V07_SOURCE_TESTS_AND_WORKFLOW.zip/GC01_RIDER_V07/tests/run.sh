#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flags=(-std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer)
cc "${flags[@]}" src/rider_core.c tests/test_core.c -o /tmp/rider_v07_core
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v07_core
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_render_many.c -o /tmp/rider_v07_render
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v07_render
cc "${flags[@]}" -DGC01_RIDER -DRIDER_HOST_TEST -Isrc -Itests/fake src/rider_core.c src/rider_render.c rider_screen.c tests/test_strip_cache.c -o /tmp/rider_v07_dirty
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v07_dirty
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/render_scenes.c -o /tmp/rider_v07_preview
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v07_preview score /tmp/rider_v07_score.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v07_preview saw /tmp/rider_v07_saw.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v07_preview loop /tmp/rider_v07_loop.ppm
