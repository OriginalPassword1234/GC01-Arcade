# GC-01 Rider v2.9 — repository-ready package

This is the original v2.9 source extracted byte-for-byte from `rider-v29.yml`, with the workflow adapted to use separate files in the repository. It is not a new firmware revision.

## Upload to GitHub

1. Extract the ZIP. Its root is the repository root (there is no extra enclosing folder inside the ZIP).
2. Open your repository's Code tab. Choose Add file → Upload files. Drag the extracted root's contents into the upload area, including the `.github` folder, `rider_ci`, `overlay`, `RIDER_SOURCE_SHA256SUMS.txt`, `.gitattributes`, `.gitignore`, and `README.md`. Enable hidden files in your file manager if needed. Commit the files to the default branch. Do not upload the ZIP itself.
3. Confirm `.github/workflows/rider-v29.yml` is present at that exact path in GitHub. If the browser omits `.github`, use Add file → Create new file, enter `.github/workflows/rider-v29.yml` as the name, and paste the extracted YAML contents there. GitHub creates the directories automatically. If the file already exists, edit/replace it instead.
4. Open Actions → GC01 Rider v2.9 - repository build (75 KiB) → Run workflow. Select the branch you committed to. Do not rerun an old v2.8 run. The first step prints `RIDER_V29_75K_REPOSITORY - FRESH RUN`.
5. Download the result artifact or the failure diagnostics ZIP from the run summary.

Alternatively, copy the extracted contents into a local Git clone, including the dotfiles, then commit and push using Git or GitHub Desktop. Keep any unrelated files in your existing repository. If GitHub refuses a workflow update, make sure your account or Git client is authorized to modify Actions workflows.

## Structure

- `.github/workflows/rider-v29.yml`: separate build workflow, no embedded source blob.
- `rider_ci/`: firmware integration scripts, current source, logger, historical baselines, test suites and documentation.
- `overlay/`: modified files applied to pinned Rad Pro 3.1.1 source.
- `RIDER_SOURCE_SHA256SUMS.txt`: exact source integrity manifest for all 122 bundled files. If intentionally changing sources, regenerate the corresponding manifest entries before running CI. The duplicate host/firmware core and renderer copies must also remain consistent.

The workflow still downloads upstream Rad Pro at commit `a9d0f19` and its build dependencies. This package is not a standalone offline build or a ready-to-flash binary. The original v2.9 checks and 75 KiB partition, 300 B flash reserve, and 3328 B nominal RAM headroom targets are preserved. The entire ARM build has not been verified in this packaging environment. The firmware is diagnostic only; do not flash before verifying bootloader compatibility and data migration for the changed partition layout.
