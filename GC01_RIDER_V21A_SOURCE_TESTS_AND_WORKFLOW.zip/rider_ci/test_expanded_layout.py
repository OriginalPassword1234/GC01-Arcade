from pathlib import Path
import os, subprocess, sys, tempfile, shutil
ROOT = Path(__file__).resolve().parents[1]
# This runs after a copied repo is patched, asserts exact layout text + boundaries.
ini=(ROOT/'platform.io/platformio.ini').read_text()
head=(ROOT/'platform.io/src/peripherals/flash.h').read_text()
start=ini.index('[env:fnirsi-gc01_apm32f103rb-en]')
end=ini.find('\n[',start+1)
section=ini[start:end if end!=-1 else None]
assert section.count('-DFIRMWARE_SIZE=0x11000')==1
assert section.count('-DGC01_RIDER')==1
assert '#define RIDER_SAVES_SIZE (2 * FLASH_PAGE_SIZE)' in head
assert '#define STATES_BASE (RIDER_SAVES_BASE + RIDER_SAVES_SIZE)' in head
app_start=0x08004000; app_size=0x11000; page=0x400
saves=app_start+app_size
states=saves+2*page
log=states+page
assert (saves,states,log)==(0x08015000,0x08015800,0x08015C00)
assert (0x08020000-log)//page==41
assert app_start+app_size <= saves < states < log < 0x08020000
print('PASS: Exact 68+2+1+41 KiB partition boundaries; only APM32 English target modified')
