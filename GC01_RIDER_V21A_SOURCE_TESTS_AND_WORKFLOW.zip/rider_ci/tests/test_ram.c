#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    const unsigned render_bytes = (unsigned)rider_render_static_ram();
    const unsigned strip_hash_bytes = 80u * 3u * sizeof(uint32_t);
    /* Strict guard for v1.0 RAM safety: no change to firmware audit threshold. */
    assert(render_bytes <= 3070u);
    assert(strip_hash_bytes == 960u);
    printf("RAMFIX: renderer=%u B, two states=%zu B, dirty hashes=%u B, Rider subtotal=%zu B\n",
           render_bytes, 2*sizeof(RiderState), strip_hash_bytes,
           (size_t)render_bytes + 2*sizeof(RiderState) + strip_hash_bytes);
    return 0;
}
