#!/usr/bin/env python3
"""Structural audit of EXPERIMENTAL 68/2/1/41-KiB GC01 layout.

Not a USB-bootloader compatibility or radiation-safety test.
"""
import pathlib
import ast
import operator
import struct
import sys
from elftools.elf.elffile import ELFFile

FLASH_BASE = 0x08000000
FLASH_END = 0x08020000
APP_BASE = 0x08004000
APP_SIZE = 0x11000            # 68 KiB, footer within this partition
APP_LIMIT = APP_BASE + APP_SIZE
SAVE_BASE = 0x08015000
SAVE_SIZE = 0x800
SETTINGS_BASE = 0x08015800
SETTINGS_SIZE = 0x400
LOG_BASE = 0x08015C00
LOG_SIZE = 0xA400             # 41 KiB
RAM_BASE = 0x20000000
RAM_END = 0x20005000
MIN_STACK_HEADROOM = 3072  # Nominal free RAM needed; real stack use still needs hardware validation


def stm_crc(buf):
    if len(buf) % 4: raise ValueError('CRC input must be word aligned')
    crc=0xffffffff
    for pos in range(0,len(buf),4):
        crc ^= struct.unpack_from('<I',buf,pos)[0]
        for _ in range(32):
            crc=((crc << 1) ^ (0x04c11db7 if crc & 0x80000000 else 0)) & 0xffffffff
    return crc


def parse_constant_expression(expr):
    """Evaluate only literal integers and basic C preprocessor arithmetic."""
    ops={ast.Add:operator.add, ast.Sub:operator.sub, ast.Mult:operator.mul,
         ast.BitOr:operator.or_, ast.BitAnd:operator.and_,
         ast.LShift:operator.lshift,ast.RShift:operator.rshift}
    def walk(n):
        if isinstance(n,ast.Constant) and type(n.value) is int: return n.value
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.UAdd):return walk(n.operand)
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -walk(n.operand)
        if isinstance(n,ast.BinOp) and type(n.op) in ops:
            return ops[type(n.op)](walk(n.left),walk(n.right))
        raise ValueError('Unsafe or unrecognized linker metadata expression: '+expr)
    value=walk(ast.parse(expr,mode='eval').body)
    if value<0 or value>0xffffffff:
        raise ValueError('Metadata address/size outside uint32 range: '+expr)
    return value

def extract_metadata(elf):
    with elf.open('rb') as f:
        e=ELFFile(f)
        section=e.get_section_by_name('.comment')
        if section is None: raise ValueError('No flash layout metadata')
        entries={}
        for part in section.data().split(b'\x00'):
            if b': ' in part:
                k, v=part.split(b': ',1)
                if k.startswith((b'FLASH_',b'FIRMWARE_',b'STATES_',b'DATALOG_')):
                    entries[k.decode()]=parse_constant_expression(v.decode())
        return e, entries   # Only metadata used here; reopen below for sections


def verify(raw_path, elf_path, image_path):
    raw=raw_path.read_bytes()
    image=image_path.read_bytes()
    if not (8 <= len(raw) <= APP_SIZE - 4):
        raise ValueError(f'Image code too large for 68 KiB app: {len(raw)}')
    if len(image) != FLASH_END - APP_BASE:
        raise ValueError(f'Padded image must be 112 KiB, got {len(image)}')
    if (image[0:0x20] != raw[0:0x20] or image[0x28:len(raw)] != raw[0x28:]):
        raise ValueError('Signer changed code bytes outside settings metadata')
    expected={
        'FLASH_BASE':FLASH_BASE, 'FLASH_SIZE':0x20000,
        'FIRMWARE_BASE':APP_BASE,'FIRMWARE_SIZE':APP_SIZE,
        'STATES_BASE':SETTINGS_BASE,'STATES_SIZE':SETTINGS_SIZE,
        'DATALOG_BASE':LOG_BASE,'DATALOG_SIZE':LOG_SIZE,
    }
    _, meta=extract_metadata(elf_path)
    if {k:meta.get(k) for k in expected} != expected:
        raise ValueError(f'Unexpected linker layout metadata: {meta}')
    sp, reset=struct.unpack_from('<II',image,0)
    if not (RAM_BASE < sp <= RAM_END and sp%8==0):
        raise ValueError(f'Invalid stack vector: {sp:#010x}')
    if not (APP_BASE <= (reset & ~1) < APP_LIMIT-4 and reset & 1):
        raise ValueError(f'Invalid app reset vector: {reset:#010x}')
    state_addr, state_bytes=struct.unpack_from('<II',image,0x20)
    if (state_addr,state_bytes)!=(SETTINGS_BASE,SETTINGS_SIZE):
        raise ValueError('Signed header has wrong settings boundary')
    crc_pos=APP_SIZE-4
    computed=stm_crc(image[:crc_pos])
    stored=struct.unpack_from('<I',image,crc_pos)[0]
    if stored!=computed:
        raise ValueError(f'CRC mismatch {stored:#010x} != {computed:#010x}')
    if image[APP_SIZE:] != b'\xff'*(len(image)-APP_SIZE):
        raise ValueError('NONBLANK bytes in saves, settings, or radiation-history partition')
    with elf_path.open('rb') as f:
        e=ELFFile(f)
        ram=[]
        bad=[]
        for sec in e.iter_sections():
            h=sec.header
            if not (h['sh_flags'] & 0x2) or not h['sh_size']:continue
            a=int(h['sh_addr']); b=a+int(h['sh_size'])
            if APP_BASE <= a < FLASH_END and b > APP_LIMIT-4: bad.append((sec.name,a,b))
            if RAM_BASE <= a < RAM_END:ram.append((sec.name,a,b))
        if bad:raise ValueError(f'Linked sections overlap app CRC or data partitions: {bad}')
        if not ram:raise ValueError('No SRAM allocations found')
        hi=max(x[2] for x in ram)
        nominal_headroom=RAM_END-hi
        print(f'SRAM static-high={hi:#010x}, nominal headroom={nominal_headroom} bytes; stack not measured')
        print(f'Minimum nominal free SRAM: {MIN_STACK_HEADROOM} bytes; stack and interrupts not profiled')
        if nominal_headroom < MIN_STACK_HEADROOM:
            raise ValueError(f'SRAM available {nominal_headroom} B is below diagnostic threshold {MIN_STACK_HEADROOM} B; no firmware artifact')
    print(f'PASS: app payload {len(raw)} / {APP_SIZE-4} bytes, CRC {stored:#010x}')
    print(f'PASS: {APP_SIZE//1024} KiB app, {SAVE_SIZE//1024} KiB saves, 1 KiB settings, {LOG_SIZE//1024} KiB log')
    print('NOT VERIFIED: USB bootloader support for expanded application, safe migration, actual GC01 timing/alarm operation')


def main():
    if len(sys.argv)!=4:
        raise SystemExit('usage: verify_expanded.py raw.bin firmware.elf signed.bin')
    verify(*map(pathlib.Path,sys.argv[1:]))

if __name__=='__main__':
    main()
