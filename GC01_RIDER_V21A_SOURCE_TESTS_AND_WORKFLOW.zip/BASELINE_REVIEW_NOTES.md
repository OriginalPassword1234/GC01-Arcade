# GC-01 Rider — independent review checkpoint, 23 November 2026

This is a review of the two supplied archives, not a source release. No game or firmware code was changed. Original files remain intact. Treat unresolved points as open, not completed. Latest user direction overrides earlier speculative feature lists: reproduce the original 2017 Ketchapp Rider base game, not Rider Worlds or invented mechanics. Do not generate code until explicitly requested.

## 1. Independent checks performed

- Opened and extracted both top-level handoffs (397 and 218 ZIP entries respectively); both passed Python ZIP integrity checks.
- Recomputed SHA-256 and sizes for all 389 file records in the earlier handoff's three file inventories and all 211 records in the later handoff's SHA-256 manifest. Zero mismatches.
- Checked nested archives in the two extracted trees. Both Rider v1.1 source packages, the rejected rewrite, v0.5 candidate and preview archives, and older Dungeon/Arcade/Rider diagnostics passed ZIP checks. **Exception:** the two identical copies of `radpro-3.1.1.zip` fail Python ZIP validation due to a central-directory/local-header filename encoding mismatch in an OpenOCD target script (`1986…cfg`). This is not proof that firmware code is corrupt, but neither archive may be called fully validated. Both have SHA-256 `67767f497a41dcbad6c518ef8995b0f52380dbfb11360f44daab86f917beeb03`. Use the exact pinned Rad Pro release for a future build and verify its contents rather than blindly extracting this ZIP.
- Compared the extracted user-uploaded v1.1 and repaired trees by path and bytes: 63 common files, 47 identical, 16 changed, 7 additional files (including the verification report), none removed. The substantive changes are engine/renderer (host and overlay copies), render scenes, test runner, v1.1 README, previews and new regression test/workflow. Game adapter, keyboard, view integration and save journal are unchanged by the repair.
- Independently ran the existing `rider_ci/tests/run.sh` for both user-uploaded and repaired v1.1 trees. Both completed successfully in this environment, including GCC ASan/UBSan test executables. No new firmware was compiled or flashed.
- Visually inspected all 35 directly supplied original-game JPEG frames in labeled contact sheets; compared the original-uploaded, rejected, and repaired preview images and per-scene v1.1 previews. Inspected earlier board photo and build screenshots at contact-sheet resolution. This does not establish a pixel-by-pixel or motion analysis. External galleries in the research document were not revisited in this review.
- Read handoff chronology, source and safety notes, research notes, repaired verification report; examined critical current core, render, screen update, game integration, layout and save-journal code and repair-specific tests. This is not a claim of complete semantic review of every third-party driver, historical binary, embedded workflow member or schematic. Verbatim earlier conversation is not included in the handoffs.

## 2. Source hierarchy — never confuse these versions

| Source | Treatment |
|---|---|
| `GC01_RIDER_V11_SOURCE_TESTS_AND_WORKFLOW(1).zip` | User-uploaded restore point; actual available source with documented v1.0 ancestry. Preserve unchanged. |
| `GC01_RIDER_V11_REPAIRED_SOURCE_TESTS_AND_WORKFLOW.zip` | Derived source candidate; host tests reproduced, not user-approved or hardware-validated. Inspect incremental diff before choosing changes. |
| `GC01_RIDER_V11_SOURCE_ONLY_NOT_FLASHABLE.zip` | Rejected from-scratch rewrite. Do not use as baseline. |
| v0.7 diagnostic ELF | Rejected historical version; do not build from or flash. |
| Earlier v0.6 handoff | Historical reference, not actual editable v0.6 source. |
| v0.5, v0.6 ELF / older v0.2 builds | Diagnostics, not editable source or permission to flash. |
| Earlier Arcade, Parkour, Dungeon | Separate branches. Preserve Geiger functionality, not unrelated games. |

Exact standalone v1.0 and v0.6 editable snapshots are absent. Do not claim a line-by-line comparison against either. Do not reconstruct them and label the reconstruction as the original.

## 3. Reproduced test results

| Metric | User-uploaded v1.1 | Repaired v1.1 |
|---|---:|---:|
| Existing host test suite | PASS | PASS |
| Renderer static allocation | 3045 B | 2965 B |
| Two Rider states | 472 B | 472 B |
| Dirty-tile hashes | 480 B | 480 B |
| Listed subtotal | 3997 B | 3917 B |
| Scripted novice crashes | 2/500 | 2/500 |
| Sample stunt runs scored | 100/100 | 100/100 |
| Render survey | 7 seeds x 800 ticks | 7 seeds x 800 ticks |
| Emulated save records | 1000 | 1000 |
| Sample changed-region update | 42 transactions, 34260 pixels | 44 transactions, 33294 pixels |
| Sample early flat/smooth sections | 449/1100 | 449/1100 |
| Sample early ramp/jump sections | 257/1100 | 250/1100 |
| Sample early boost sections | 105/1100 | 113/1100 |
| Sample advanced loop/wall and saw counts | 82, 28 | 80, 24 |
| Projected flat-track scroll | 8 px/50 ms | 8 px/50 ms |
| Repair-specific tests | Not part of original runner | PASS |

These are deterministic host tests, not independent comparisons with original Rider dynamics. The number of successful automated runs cannot prove good challenge design. The sample strip update does not prove LCD throughput or artifact-free output. The listed RAM subtotal is not total firmware RAM. The repair-specific placement test counts colored pixels near expected coordinates in one staged scene; it cannot prove all diamond positions or reachability. Bridge tests confirm changing surface height and gaps, not human playability. Micro-loop test confirms completion of a guided path, not realistic free-body physics.

## 4. Original-game visual observations by source image

| Filename stem | Visible geometry / effect |
|---|---|
| 70347 | Airborne vehicle, flat runway, yellow chevrons. |
| 70353, 70978 | Separate rising rails and deep gap, independent surfaces. |
| 70355 | Flat rail, sparse clean presentation. |
| 70357 | Red spike row, gap and luminous diamonds along air path. |
| 70359, 71006 | Sharp V with rounded/small bottom, steep exit, gems or bonus effects. |
| 70361 | Tall curved-to-vertical rail and vertically arranged diamonds. |
| 70363 | High vertical lip and separate curved arc/landing. |
| 70365 | Smooth descending transition into long flat section; +2. |
| 70367 | Long curved descent and airborne gems. |
| 70371 | Multiple differently sized circular arcs. |
| 70980 | Airborne moment above lower independent flat rail. |
| 70982 | Deep smooth U/bowl. |
| 70984 | Elevated loop/arc and valley. |
| 70986 | Compound S-like spiral and independent bowl. |
| 70988 | Bowl and separate sharp descending wedge. |
| 70990 | Bright triangular particle burst over chevrons and curved rail. |
| 70992, 70994 | Mixed pink/green compound open circular arcs, crossing/overlap. |
| 70996 | Bright particle burst over sloping green rail. |
| 70998 | Oversized flat coral saw beside/above a curved dip. |
| 71000 | Angular V followed by separate right rail. |
| 71002 | Small open arc above a peaked hill, gems around loop. |
| 71004 | Sharp peak into smooth concave runout. |
| 71008 | Low sharp wedge and flat approach/runout. |
| 71010 | Rising curved lip and large coral saw. |
| 71012 | Long smooth bowl with steeper rising exit; +4. |
| 71014 | Long approach, airborne vehicle above smooth hump. |
| 71016 | Long steep green rail and many aligned gems. |
| 71036, 71038 | Large saw beside steep descending rail, then flat road. |
| 71040 | Diamonds along arch above deep gap between curved rails. |
| 71042 | Particle burst, rising lip, coral spikes. |
| 71044 | Green open arc, airborne gems and detached lower landing rail. |

Visual priority: very thin bright neon core, softly fading halo, dark irregular suspended polygon underside, dark blue/purple/teal background, small vehicle relative to structures, white geometric centered score, unobtrusive diamond counter, original coral swept-tooth hazards, distinct yellow chevrons, particles and paths. The source frames are portrait mobile images; the 320x240 GC-01 landscape screen requires an intentional field-of-view adaptation, not stretching or just shrinking every object. Preserve the existing recognizable car. Compare body silhouette, wheel proportions, rail thickness, glow width, relative saw radius and HUD independently.

## 5. Specific source problems that remain despite passing tests

### A. Level generation remains heavily constrained
- `rider_core.c` uses 49 height templates with 9 knots and fixed 256-world-pixel pieces; special 2D paths supplement ordinary heightfields.
- `append_piece()` sets `start_y=166` for every piece. Ordinary template endpoints return to the same height. This explains repeating level baselines instead of long connected elevation changes.
- `choose_template()` forces a recovery pool for most pieces divisible by 3 and a fully flat template for most pieces whose index modulo 3 is 1. Thus adding more stunt templates without altering the cadence cannot resolve the complaint about frequent long straight sections.
- The first eight pieces are partly fixed. Compare original opening rhythm rather than blindly preserving or discarding it.
- Ordinary single-valued surface sampling is insufficient for arbitrary overlapping independent track paths, compound spirals, and vertical collision surfaces. Special cases currently cover only a narrow set of structures.

### B. Loop physics is still explicitly guided
- `rider_step()` enters a special path at a fixed entrance if sufficiently fast, snapping position to the path entrance.
- `step_loop()` advances a parametric path, clamps speed to a minimum of 2 world px/tick even on release, imposes angle/grounded position, sets vertical velocity and angular speed to zero and uses scripted exits. Applies to closed loop, micro-loop, wall, bowl and open-loop special path.
- Therefore the shared visual/collision geometry is an improvement, but it is not unrestricted two-wheel physics. A passing traversal test does not prove momentum, gravity, slow-loop failure, or authentic loop movement.
- Special traversal returns before ordinary saw/spike collision checks. Audit collision coverage before adding composite hazards.
- Current loop previews still show circles on flat baselines; original references include arcs attached to peaks, multi-level overlaps and disconnected destinations. The difference is structural, not just palette.

### C. Rendering and camera
- Fixed-point Q8 simulation at 60 Hz; main-loop adapter requests running draws every 33 ms and caps catch-up at 100 ms / six simulation steps. Actual SPI/render duration can reduce achievable update cadence; no device measurement exists.
- Renderer extrapolates bounded movement using prior state and accumulator; coordinates then quantize to integer pixels with shared 2:3 projection (384 Q8 units per screen pixel). Good correction of mixed object transform but not proof against whole-frame jumps, especially after long display operations or special path transitions.
- Screen uses three-row RGB565 strips and three horizontal 16-bit dirty hashes per strip. Hash collision could theoretically skip a changed tile; test coverage and repeated invalidation need review. No full framebuffer: 320x240x2 would exceed physical SRAM.
- Actual repaired previews are materially closer than rejected rewrite, but still use a noticeably wide multiband glow, repetitive dark faceting, small gear-like saw relative to original oversize hazards, limited elevation and generic HUD. Assess before changing; preserve the improved car and common projection.
- Renderer still has a main per-column surface cache supplemented with separate loop drawing. Audit underside silhouettes, overlap order, and moving rail gaps. Main color palette is fixed blue/pink/green rather than a demonstrated full original theme system.
- Current HUD supports score, diamond count, pause/best and pending +points. Full original-style stunt messages, reward effects, unlock/garage, level/challenge and theme menus are not demonstrated by current adapter (single Rider menu entry). Crash UI is minimal. Do not represent planned features as implemented.
- Current repaired generator excludes gems from many special paths, including closed/open/micro loops and vertical wall. Original references show gems along inner arcs and vertical ascents. Cluster positioning and special geometry need explicit evidence-based tests.

### D. Original feature evidence boundary
- Direct image evidence: ramps, gaps, loops and open arcs, spikes, coral saws, boosts, gems, bonus text, particles, multiple colors and themes, HUD. Images alone cannot establish dynamics or scoring rules.
- Handoff reports original trailer listed 100 challenges, 40 bikes (4 secret), 32 levels, 10 themes, daily rewards and worldwide highscores; later listings differ. Treat this as previously recorded research pending direct version-specific verification. Offline hardware cannot claim worldwide highscores without an actual service.
- Moving/collapsing/rotating or touch-triggered structures are partly community-reported in the handoff. The existence of a specific oscillating bridge or periodic spike implementation is not proof that its behavior is original. Confirm via actual base-game footage before expanding or retaining speculative variants.
- Do not add generic powerups, weapons, unrelated obstacles, enemies, or mechanics from Rider Worlds merely to fill flash space.

## 6. Non-negotiable hardware gates

- Target: FNIRSI GC-01 APM32F103RBT6, 72 MHz, 128 KiB flash, 20 KiB SRAM, 320x240 RGB565, five buttons; Rad Pro 3.1.1, `fnirsi-gc01_apm32f103rb-en`; user-replaced M4011 tube. Hardware facts are from handoff, not a new measurement.
- Preserve radiation pulse counting, calibration, history/logging, graphs, alarms, USB/updater, power/battery, normal themes, RNG/coin/dice and USB RNG. Do not change bootloader or sacrifice essential safety functionality.
- Existing app is 56 KiB according to layout patch. Proposed expanded partitions: boot 16 KiB (`0x08000000–0x08003FFF`); app 68 KiB (`0x08004000–0x08014FFF`); saves 2 KiB (`0x08015000–0x080157FF`); settings 1 KiB (`0x08015800–0x08015BFF`); logs 41 KiB (`0x08015C00–0x0801FFFF`). Maximum raw app payload 69628 bytes after four-byte CRC. The old settings/history map is displaced. This is experimental, not proven compatible with USB bootloader.
- Current verifier checks CRC, vectors, metadata, padded image, nominal RAM margin >=3072 B, and linked sections; it does not prove stack depth, interrupt latency, actual updater erase policy or data migration. No SWD programmer available according to handoff.
- Adapter checks alarm and returns to measurement view; that does not verify alarm response during blocking LCD or flash calls. Current save is on explicit exit, not game over despite some older comments. Journal uses two pages, 20-byte records, CRC16 and final commit marker. Power-fail host test does not establish actual erase/write interrupt behavior or calibration preservation.
- No new ARM compile, device measurements, calibration test, USB update, stack profiling, radiation timing or recovery testing occurred here. DO NOT FLASH any archive on the strength of these notes. Do not claim any candidate safe for radiation-safety use.

## 7. Future work order — only on explicit request

1. Preserve and hash the user-uploaded source; compare any candidate incrementally. Never fall back to rejected v0.7 or unrelated rewrite.
2. Complete unreviewed source/integration portions and inspect exact workflow payload against source/CI copies. Resolve Rad Pro archive encoding issue with pinned release. Review the actual tests, not just PASS lines.
3. Verify original 2017 mechanics through timestamped gameplay and original-release references. Separate measured behavior, direct visual observation, community claim, and proposed approximation. Do not invent facts or earlier user requests.
4. Design against the actual source and visual references; address track elevation/geometry/cadence, physics and collision, shared transforms, HUD/texture, and camera without undoing good existing car/renderer/integration work.
5. Once code explicitly requested: make auditable incremental changes; generate genuine previews from the exact C renderer; regression test across seeds and input sequences, collisions, camera discontinuities and actual visual output. Test failure cases, not only auto-drive success.
6. Build exact ARM target and inspect linked flash/SRAM, stack and ISR budget; verify original feature preservation. Separate any experimental build artifact from installable release.
7. Establish safe updater, settings/history migration, backups and practical recovery before installation; then hardware tests for gameplay and radiation functions. Until proven, no flashing recommendation.

## 8. Remaining limitations of this review

Archive integrity and manifests were checked exhaustively for the listed file records; semantic review of every historical binary, vendor library, hardware document, old screenshot at full resolution and nested source member was not completed. Original-game video frames have not been timed, and the complete verbatim earlier prompt history is not available. These are explicit open items, not reasons to invent details. Keep this review alongside the original archives and update it with actual evidence rather than replacing earlier notes.
