/* GC01/Rad Pro Rider v0.9 integration. Main-loop rendering and game logic.
 * Two-page Rider score journal is written on game-over/exit, NOT in ISRs.
 * Original pulse IRQ handling and USB updater code are not edited here. */
#if defined(GC01_RIDER)
#include <stdbool.h>
#include <stdint.h>
#include "rider_core.h"
#include "rider_saves.h"
#include "../measurements/measurements.h"
#include "../peripherals/keyboard.h"
#include "../system/events.h"
#include "../system/power.h"
#include "../system/settings.h"
#include "../ui/menu.h"
#include "../ui/view.h"
#include "../ui/rider_screen.h"
#include "game.h"

static RiderState rider;
static RiderState previous;
static bool game_active;
static bool paused;
static uint32_t last_tick;
static uint32_t last_draw;
static uint8_t draw_interval_ms=17;
static uint32_t last_awake;
static uint32_t step_accumulator; /* scaled by 60, denominator 1000 */
static uint32_t last_saved_best;
static uint32_t last_saved_diamonds;
static MenuState rider_menu_state;
static const Menu rider_menu;

static void save_if_changed(void)
{
    uint32_t best=(uint32_t)rider.best;
    uint32_t diamonds=(uint32_t)rider.diamonds;
    if(best!=last_saved_best || diamonds!=last_saved_diamonds){
        if(rider_saves_store(best,diamonds)){
            last_saved_best=best;
            last_saved_diamonds=diamonds;
        }
    }
}
static void leave_rider(void)
{
    save_if_changed();
    game_active=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showMenu(&rider_menu);
}
static void on_rider_event(ViewEvent event)
{
    switch(event) {
    case EVENT_KEY_GAME_EXIT:
        leave_rider();
        break;
    case EVENT_KEY_GAME_OK:
        paused=!paused;
        rider.paused=paused?1u:0u;
        rider_screen_invalidate();
        last_tick=currentTick;
        requestViewUpdate();
        break;
    case EVENT_KEY_GAME_RIGHT:
    case EVENT_KEY_GAME_UP:
        if(rider.phase==RIDER_CRASHED) {
            rider_restart(&rider);
            previous=rider;
            last_tick=currentTick;
            step_accumulator=0;
            requestViewUpdate();
        }
        break;
    case EVENT_DRAW: {
        uint32_t draw_start=currentTick;
        rider_draw_gc01(&rider,&previous,(uint8_t)((step_accumulator*255u)/1000u));
        /* Request up to 60 fps; allow a non-render interval for Rad Pro
         * main-loop measurement/alarm processing. Never increase work in ISRs. */
        uint32_t cost=(uint32_t)(currentTick-draw_start);
        uint32_t period=cost>=92u?100u:cost+8u;
        draw_interval_ms=(uint8_t)(period<17u?17u:period);
        last_draw=draw_start;
        break;
    }
    case EVENT_HEARTBEAT:
        /* Preserve the user's normal display sleep setting everywhere else.
         * Re-arm only during the game, including when paused. */
        if(game_active)requestBacklightTrigger();
        break;
    default:
        break;
    }
}
static const char *rider_option(menu_size_t index,MenuStyle *style)
{
    *style=MENUSTYLE_SUBMENU;
    return index==0?"Rider":"";
}
static void rider_select(menu_size_t index)
{
    if(index!=0)return;
    /* The source device's radiation random numbers are not consumed. */
    rider_init(&rider, currentTick ^ 0x5a17d10bu);
    uint32_t saved_best=0,saved_diamonds=0;
    if(rider_saves_load(&saved_best,&saved_diamonds)){
        rider.best=(int32_t)(saved_best>0x7fffffffu?0x7fffffffu:saved_best);
        rider.diamonds=(int32_t)(saved_diamonds>0x7fffffffu?0x7fffffffu:saved_diamonds);
    }
    last_saved_best=(uint32_t)rider.best;
    last_saved_diamonds=(uint32_t)rider.diamonds;
    rider_screen_invalidate();
    previous=rider;
    last_tick=currentTick;
    last_draw=currentTick;
    draw_interval_ms=17u;
    last_awake=currentTick;
    step_accumulator=0;
    paused=false;
    game_active=true;
    requestBacklightTrigger();
    setKeyboardMode(KEYBOARD_MODE_GAME);
    showView(on_rider_event);
}
static const Menu rider_menu={
    STRING_GAME,&rider_menu_state,1,rider_option,rider_select,showSettingsMenu
};
void resetGame(void)
{
    game_active=false;
    selectMenuItem(&rider_menu,0);
}
void showGameMenu(void)
{
    game_active=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showMenu(&rider_menu);
}
void updateGame(void)
{
    if(!game_active)return;
    if(!isPoweredOn()||!isKeyboardGameMode()) {game_active=false;return;}
    if(getAlertLevel()!=ALERTLEVEL_NONE) {
        game_active=false;
        setKeyboardMode(KEYBOARD_MODE_MENU);
        setMeasurementView(); /* Geiger alarm has unconditional priority. */
        return;
    }
    if(!isCurrentView(on_rider_event)) {
        game_active=false;
        setKeyboardMode(KEYBOARD_MODE_MENU);
        return;
    }
    uint32_t now=currentTick;
    /* Refresh independently of the heartbeat, including while paused. */
    if((uint32_t)(now-last_awake)>=400u){
        requestBacklightTrigger();
        last_awake=now;
    }
    if(!isDisplayAwake()||paused) {
        if(!isDisplayAwake()) rider_screen_invalidate();
        last_tick=now;
        step_accumulator=0;
        return;
    }
    uint32_t elapsed=now-last_tick; /* uint32 subtraction handles tick wrap */
    last_tick=now;
    if(elapsed>100) elapsed=100; /* capped catch-up; don't starve measurements */
    step_accumulator += elapsed*60u;
    uint8_t steps=0;
    while(step_accumulator>=1000u&&steps<6) {
        step_accumulator-=1000u;
        previous=rider;
        bool held=isGameKeyHeld(KEY_RIGHT)||isGameKeyHeld(KEY_UP);
        rider_step(&rider,held);
        ++steps;
    }
    /* Never program internal flash during active Rider gameplay, including
     * a crash: an erase/write could suspend CPU/IRQ service and lose radiation
     * pulses. Save on explicit exit instead. The latest unsaved record is
     * therefore at risk after sudden power loss; we prioritize counting. */
    if(rider.phase==RIDER_RUNNING && now-last_draw>=draw_interval_ms){
        last_draw=now;
        requestViewUpdate();
    } else if(rider.phase==RIDER_CRASHED && now-last_draw>=250u){
        last_draw=now;
        requestViewUpdate(); /* slow decorative death-screen motion */
    }
}
#endif
