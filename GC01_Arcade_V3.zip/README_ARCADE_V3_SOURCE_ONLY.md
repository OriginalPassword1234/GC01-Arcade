# GC-01 Arcade V3 — source only, NOT FLASHABLE

Target: **Gissio Rad Pro 3.1.1**, `fnirsi-gc01_apm32f103rb-en` (APM32F103RB only).

This archive overlays the untouched official Rad Pro 3.1.1 source tree. It is **NOT** a firmware update image and MUST NOT be copied to the GC-01's USB bootloader.

## V3 implementation

- **2048:** shared move planner for gameplay and display, nonblocking 0/33/67/100-ms slide stages, change-region painting rather than a full-board wipe for every intermediate frame, unchanged board rules and win/lose detection. Static tiles are no longer painted twice.
- **Flappy Bird:** collectible one-hit shield; protected pipe cannot immediately kill the bird again; shield does not prevent a floor/ceiling collision; difficulty stages at 0, 8, 16, and 24 points adjust pipe speed (3/4/4/5 pixels per 80-ms update) and gap width (76/72/68/64 pixels). Shield icon in sidebar.
- **Breakout:** initial ball velocities from `(18,-52)` to `(23,-68)` in 4-bit fixed point (about 30% faster), with consistent life reset and level progression; normal, two-hit reinforced, and 30-point bonus bricks, reused in the same 32-byte array; bounded substep physics checks paddle and visible brick geometry to avoid tunneling. Paddle speed and controls unchanged.
- **Rendering:** preserve pixel artwork and all three themes, repaint only affected board cells and changed sidebar regions; avoid unnecessary paddle drawing when stationary. No large sprites, framebuffer, saved high scores, or new flash writes.
- **Controls:** Left held controls Breakout paddle. **No long-Left exit shortcut**; press OK then choose EXIT to leave any game. The original keyboard lock and power controls remain intact.

## What was tested (on source code)

Run in a copy of Rad Pro 3.1.1 with the overlay extracted into the project root:

```sh
./arcade-tests/run.sh
./arcade-tests/run_v3.sh
./arcade-tests/run_graphics.sh
./arcade-tests/run_dirty.sh
ORIGINAL=/path/to/clean/radpro-3.1.1 ./arcade-tests/compare_legacy.sh
python arcade-tests/verify_preservation.py /path/to/clean/radpro-3.1.1
```

**Local results:** all above passed in this preparation environment. Includes 20,000 reference-checked 2048 moves, V3 feature assertions, 738 intermediate 2048-frame comparisons in all three themes (all matched complete reference frames), existing game/menu/keyboard regressions and an exact original source comparison. In these simulated intermediate frames, region redraw issued 106,068,075 pixel writes versus 173,955,816 for complete redraws; this is *not* measured hardware frame time.

Native code also compiled under AddressSanitizer/UndefinedBehaviorSanitizer. The new firmware modules were separately compiled for an ARMv7-M/Cortex-M3 target with Clang using freestanding header stubs. This is **not a successful complete PlatformIO ARM GCC link**.

## Unresolved, mandatory before flashing

1. Run the full GitHub Actions/PlatformIO APM32 build, and enforce **raw payload <= 57,340 bytes** before firmware CRC. V1's previous 2,588-byte headroom **does not apply to V3**; V3 may be too large and need further optimization.
2. Record exact linked ELF flash, static RAM, and stack headroom. Per-module code sizes from Clang cannot be added to predict the final ARM GCC LTO-linked size.
3. Review signed image metadata, checksums, partition/storage addresses, and whether the bootloader erases saved settings/logs. Do not rename raw `firmware.bin` and attempt to install it.
4. Test the candidate on the real GC-01, including display artifacts, power/keyboard shortcuts, alarms, measurement/logging/USB timing, and M4011 tube calibration. Unchanged measurement source does not guarantee unchanged runtime measurement behavior.
5. Preserve the original known-working 3.1.1 firmware and a backup of settings and important measurement logs.

## Preservation report

Compared to the original 3.1.1 archive: **604/604** original files present; **597/604** are byte-identical. The seven authorized modifications are `platform.io/platformio.ini`, `src/extras/game.c`, `src/peripherals/keyboard.c/.h`, `src/ui/game.c`, and `src/ui/view.c/.h`. The five new firmware source modules are the arcade code under `src/extras` and `src/ui`. **All stock measurement, USB, logging, hardware driver, power, linker, and signing files remain unchanged.**

No compiled/signed V3 `.bin` is provided here. This is a source-only development package.
