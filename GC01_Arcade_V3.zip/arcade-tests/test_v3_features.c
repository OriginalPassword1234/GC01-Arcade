/* V3 feature regression: shield, progression, special bricks, high-speed physics,
 * and 2048 move-plan invariants. Executes without GC-01 hardware. */
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "arcade_logic.h"

static void testFlappyStages(void) {
    static const uint32_t scores[]={0,7,8,15,16,23,24,10000};
    static const uint8_t stages[]={0,0,1,1,2,2,3,3};
    static const uint8_t gaps[]={38,38,36,36,34,34,32,32};
    static const uint8_t speeds[]={3,3,4,4,4,4,5,5};
    for(int i=0;i<8;++i) {
        assert(arcadeFlappyStage(scores[i])==stages[i]);
        assert(arcadeFlappyHalfGap(scores[i])==gaps[i]);
        assert(arcadeFlappyPipeSpeed(scores[i])==speeds[i]);
        ArcadeState a;arcadeStart(&a,ARCADE_FLAPPY,100);
        a.phase=ARCADE_RUNNING;a.score=scores[i];
        ArcadeFlappy *f=&a.game.flappy;
        f->y=120<<4;f->velocity=0;
        f->pipeX[0]=200;f->pipeX[1]=310;f->pipeX[2]=420;
        for(int j=0;j<3;++j)f->pipeGap[j]=120;
        arcadeStep(&a);
        assert(a.phase==ARCADE_RUNNING);
        assert(f->pipeX[0]==200-speeds[i]);
    }
}

static void testShield(void) {
    ArcadeState a;arcadeStart(&a,ARCADE_FLAPPY,200);
    ArcadeFlappy *f=&a.game.flappy;
    a.phase=ARCADE_RUNNING;a.score=5;
    f->y=120<<4;f->velocity=0;
    f->pipeX[0]=35;f->pipeGap[0]=120;f->pipeScored[0]=2;
    f->pipeX[1]=300;f->pipeX[2]=400;
    arcadeStep(&a);
    assert(a.phase==ARCADE_RUNNING && f->shield==1);
    assert(!(f->pipeScored[0]&2u));
    /* First collision is absorbed, and repeated collisions on this one pipe
       must not consume a second charge or cause immediate death. */
    f->pipeX[0]=55;f->pipeGap[0]=80;
    f->y=120<<4;f->velocity=0;
    arcadeStep(&a);
    assert(a.phase==ARCADE_RUNNING && f->shield==0 && f->protectedPipe==0);
    for(int i=0;i<14;++i) {
        f->y=120<<4;f->velocity=0;
        arcadeStep(&a);
        assert(a.phase==ARCADE_RUNNING);
    }
    assert(f->protectedPipe==255);
    f->pipeX[0]=50;f->y=120<<4;f->velocity=0;
    arcadeStep(&a);
    assert(a.phase==ARCADE_LOST);
    /* The shield must NEVER prevent death by hitting the ground. */
    arcadeStart(&a,ARCADE_FLAPPY,300);
    f=&a.game.flappy; a.phase=ARCADE_RUNNING;f->shield=1;
    f->y=234<<4;f->velocity=30;
    arcadeStep(&a);
    assert(a.phase==ARCADE_LOST);
}

static void testBreakoutTypes(void) {
    ArcadeState a;arcadeStart(&a,ARCADE_BREAKOUT,123);
    ArcadeBreakout *b=&a.game.breakout;
    assert(b->velocityX==23 && b->velocityY==-68);
    int normal=0,reinforced=0,bonus=0;
    uint8_t initial[32];memcpy(initial,b->bricks,32);
    for(int i=0;i<32;++i) {
        normal+=b->bricks[i]==1;
        reinforced+=b->bricks[i]==2;
        bonus+=b->bricks[i]==3;
    }
    assert(normal+reinforced+bonus==32);
    assert(reinforced==4 && bonus==2);
    b->level=2;
    arcadeStart(&a,ARCADE_BREAKOUT,456);
    b=&a.game.breakout;
    b->level=2;
    /* Score and brick state, not seeded random state, drive level layout. */
    /* Test reinforced damage in isolation, then its destruction. */
    memset(b->bricks,0,32);
    b->bricks[19]=2;b->bricks[0]=1;b->bricksLeft=2;
    a.phase=ARCADE_RUNNING;a.score=0;
    b->ballX=105<<4;b->ballY=67<<4;
    b->velocityX=0;b->velocityY=-68;
    arcadeStep(&a);
    assert(b->bricks[19]==1 && b->bricksLeft==2 && a.score==5);
    b->ballX=105<<4;b->ballY=67<<4;
    b->velocityX=0;b->velocityY=-68;
    arcadeStep(&a);
    assert(b->bricks[19]==0 && b->bricksLeft==1 && a.score==15);
    b->bricks[19]=3;b->bricksLeft=2;
    b->ballX=105<<4;b->ballY=67<<4;
    b->velocityX=0;b->velocityY=-68;
    arcadeStep(&a);
    assert(b->bricks[19]==0 && b->bricksLeft==1 && a.score==45);
    /* Fast ball catches paddle even if it would cross the surface in a tick. */
    b->ballX=(int16_t)b->paddleX<<4;b->ballY=209<<4;
    b->velocityX=0;b->velocityY=104;
    arcadeStep(&a);
    assert(a.phase==ARCADE_RUNNING && b->velocityY<0);
    /* Losing a life must restore the faster serve speed, not the V1 speed. */
    b->ballX=160<<4;b->ballY=237<<4;
    b->velocityX=0;b->velocityY=100;
    arcadeStep(&a);
    assert(a.phase==ARCADE_READY && b->lives==2);
    assert(b->velocityX==26 && b->velocityY==-74); /* Level 2 */
    (void)initial;
}

static void test2048Plan(void) {
    ArcadeState a;arcadeStart(&a,ARCADE_2048,991);
    uint8_t board[16]={0};
    board[0]=1;board[1]=1;board[2]=1;board[3]=1;
    uint8_t targets[16],result[16];uint32_t gain=0;
    bool moved=arcade2048Plan(board,ARCADE_LEFT,targets,result,&gain);
    assert(moved && gain==8 && result[0]==2 && result[1]==2);
    assert(targets[0]==0 && targets[1]==0 && targets[2]==1 && targets[3]==1);
    /* A single sliding tile can be mapped without changing its exponent. */
    memset(board,0,sizeof(board));board[3]=7;
    moved=arcade2048Plan(board,ARCADE_LEFT,targets,result,&gain);
    assert(moved && gain==0 && result[0]==7 && targets[3]==0);
    memset(board,0,sizeof(board));board[0]=4;
    moved=arcade2048Plan(board,ARCADE_LEFT,targets,result,&gain);
    assert(!moved && gain==0 && targets[0]==0);
}

int main(void) {
    testFlappyStages();testShield();testBreakoutTypes();test2048Plan();
    puts("PASS: V3 shield/progression, Breakout variants/speed and 2048 plan tests.");
}
