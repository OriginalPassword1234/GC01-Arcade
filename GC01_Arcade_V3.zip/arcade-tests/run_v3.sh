#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
DIR=$(mktemp -d)
trap 'rm -rf "$DIR"' EXIT
${CC:-gcc} -std=c11 -O1 -g -Wall -Wextra -Werror -DGC01_ARCADE \
    -fsanitize=address,undefined -fno-omit-frame-pointer \
    -Iplatform.io/src/extras arcade-tests/test_v3_features.c \
    platform.io/src/extras/arcade_logic.c -o "$DIR/v3"
ASAN_OPTIONS=detect_leaks=0 "$DIR/v3"
