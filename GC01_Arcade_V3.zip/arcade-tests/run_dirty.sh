#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
DIR=$(mktemp -d)
trap 'rm -rf "$DIR"' EXIT
${CC:-gcc} -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined \
 -fno-omit-frame-pointer -DGC01_ARCADE -DGAME -DDISPLAY_320X240 -DDISPLAY_COLOR \
 '-DSTRINGS="strings/en.h"' -Iplatform.io/src -Iplatform.io/lib/mcu-renderer \
 arcade-tests/test_dirty_render.c platform.io/src/ui/arcade.c \
 platform.io/src/extras/arcade_logic.c -o "$DIR/test_dirty"
ASAN_OPTIONS=detect_leaks=0 "$DIR/test_dirty"
