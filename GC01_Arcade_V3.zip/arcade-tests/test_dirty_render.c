/* Compare every incremental LCD update pixel-for-pixel to a full repaint.
 * This catches stale sprites, missing overlays and damaged score panels. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "mcu-renderer.h"
#include "system/settings.h"
#include "extras/arcade_logic.h"
#include "ui/arcade.h"

mr_t mr;
Settings settings;
static uint16_t pixels[320*240];
static uint16_t saved[320*240];
static uint32_t drawnArea;
static unsigned fullBackgroundDraws;
static uint64_t animationDirtyWrites, animationFullWrites;
static unsigned animationSamples;
void mr_set_fill_color(mr_t *m,mr_color_t c){m->fill_color=c;}
void mr_draw_rectangle(mr_t *m,const mr_rectangle_t *r){
    assert(r->width>0 && r->height>0);
    assert(r->x>=0 && r->y>=0 && r->x+r->width<=320 && r->y+r->height<=240);
    drawnArea+=(uint32_t)r->width*r->height;
    if(r->width==240 && r->height==240)++fullBackgroundDraws;
    for(int y=r->y;y<r->y+r->height;++y)
        for(int x=r->x;x<r->x+r->width;++x) pixels[y*320+x]=m->fill_color;
}
void drawRectangle(const mr_rectangle_t *r){mr_draw_rectangle(&mr,r);}
void strcatUInt32(char *s,uint32_t value,uint32_t minDigits){
    (void)minDigits; sprintf(s+strlen(s),"%u",value);
}
static void compare(ArcadeState *a,int theme,int step,const uint8_t *from,
                    ArcadeDirection dir,uint8_t progress){
    /* Draw incrementally, save result, then reconstruct the same full frame. */
    drawnArea=0;fullBackgroundDraws=0;
    if(from)drawArcade2048Slide(a,from,dir,progress); else drawArcade(a);
    uint32_t incrementalArea=drawnArea;
    unsigned fullClear=fullBackgroundDraws;
    memcpy(saved,pixels,sizeof(saved));
    invalidateArcadeDrawing();
    if(from)drawArcade2048Slide(a,from,dir,progress);else drawArcade(a);
    if(from) {
        animationDirtyWrites+=incrementalArea;
        animationFullWrites+=drawnArea-incrementalArea;
        ++animationSamples;
    }
    for(int i=0;i<320*240;++i)if(saved[i]!=pixels[i]) {
        fprintf(stderr,"ERROR: pixels differ: theme=%d game=%d step=%d x=%d y=%d got=%04x ref=%04x\n",
             theme,a->kind,step,i%320,i/320,saved[i],pixels[i]);
        exit(1);
    }
    /* Full repaints are valid on start/restart and pause transitions. */
    /* Heartbeats never repaint unchanged pixels. */
    drawnArea=0;
    if(from)drawArcade2048Slide(a,from,dir,progress);else drawArcade(a);
    assert(drawnArea==0);
    (void)incrementalArea; (void)fullClear;
}
int main(void){
    for(int theme=0;theme<3;++theme){
        settings.displayTheme=theme;
        for(int kind=0;kind<4;++kind){
            ArcadeState a;arcadeStart(&a,(ArcadeKind)kind,0xcab12679u);
            memset(pixels,0,sizeof(pixels));invalidateArcadeDrawing();
            compare(&a,theme,0,NULL,ARCADE_LEFT,0);
            for(int step=1;step<=85;++step){
                if(a.phase==ARCADE_WON || a.phase==ARCADE_LOST){
                    arcadePause(&a);
                    compare(&a,theme,step,NULL,ARCADE_LEFT,0);
                    a.pauseChoice=2;
                    compare(&a,theme,step,NULL,ARCADE_LEFT,0);
                    a.pauseChoice=1;arcadeChoosePause(&a);
                }
                if(kind==ARCADE_2048){
                    uint8_t before[16];memcpy(before,a.game.puzzle.cells,16);
                    ArcadeDirection dir=(ArcadeDirection)(step%4);
                    if(step==4){arcadePause(&a);compare(&a,theme,step,NULL,dir,0);}
                    if(step==5){a.pauseChoice=2;compare(&a,theme,step,NULL,dir,0);}
                    if(step==6){a.pauseChoice=0;arcadeChoosePause(&a);}
                    arcadeMove(&a,dir);
                    if(memcmp(before,a.game.puzzle.cells,16)) {
                        compare(&a,theme,step,before,dir,0);
                        compare(&a,theme,step,before,dir,1);
                        compare(&a,theme,step,before,dir,2);
                    }
                    compare(&a,theme,step,NULL,dir,0);
                } else {
                    if(kind==ARCADE_FLAPPY && a.phase==ARCADE_READY)arcadeMove(&a,ARCADE_UP);
                    if(kind==ARCADE_BREAKOUT) {
                        arcadeBreakoutPaddle(&a,(int8_t)((step%3-1)*8));
                        if(a.phase==ARCADE_READY)arcadeMove(&a,ARCADE_UP);
                    }
                    if(kind==ARCADE_SNAKE){
                        if(step%4==0)arcadeMove(&a,ARCADE_UP);
                        if(step%4==2)arcadeMove(&a,ARCADE_RIGHT);
                    }
                    if(a.phase==ARCADE_RUNNING)arcadeStep(&a);
                    compare(&a,theme,step,NULL,ARCADE_LEFT,0);
                }
            }
        }
    }
    assert(animationSamples>50);
    printf("V3 animation writes: %llu dirty vs %llu full (%u frames)\n",
        (unsigned long long)animationDirtyWrites,
        (unsigned long long)animationFullWrites,animationSamples);
    puts("Dirty-render pixel equality: all simulated frames match full repaint in all themes.");
    return 0;
}
