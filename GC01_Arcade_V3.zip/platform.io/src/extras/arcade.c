/* Rad Pro 3.1.1 GC-01 arcade extension; MIT licensed. UI and scheduling. */
#if defined(GC01_ARCADE)
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "arcade_logic.h"
#include "game.h"
#include "../measurements/measurements.h"
#include "../peripherals/keyboard.h"
#include "../system/events.h"
#include "../system/power.h"
#include "../system/settings.h"
#include "../ui/arcade.h"
#include "../ui/menu.h"
#include "../ui/view.h"

static ArcadeState arcade;
static bool arcadeActive;
static uint32_t lastStepTick;
/* Minimal nonblocking transition state for 2048 (not persisted). */
static uint8_t slideFrom[16];
static ArcadeDirection slideDirection;
static uint32_t slideStarted;
static bool slideActive;
static uint8_t slideProgress;
static MenuState arcadeMenuState;
static const Menu arcadeMenu;

static void leaveArcade(void)
{
    arcadeActive=false;
    slideActive=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showGameMenu();
}

/* One shared 2048 input path: logic and animation always use the same board. */
static void movePuzzle2048(ArcadeDirection direction)
{
    if(slideActive)return;
    uint8_t before[16];
    memcpy(before,arcade.game.puzzle.cells,16);
    arcadeMove(&arcade,direction);
    if(memcmp(before,arcade.game.puzzle.cells,16)!=0){
        memcpy(slideFrom,before,16);
        slideDirection=direction;
        slideStarted=currentTick;
        slideProgress=0;
        slideActive=true;
    }
}

static void onArcadeViewEvent(ViewEvent event)
{
    switch(event) {
    case EVENT_KEY_GAME_OK:
        slideActive=false;
        if (arcade.phase == ARCADE_PAUSED && arcade.pauseChoice == 2) leaveArcade();
        else if (arcade.phase == ARCADE_PAUSED) arcadeChoosePause(&arcade);
        else arcadePause(&arcade);
        lastStepTick=currentTick;
        requestViewUpdate();
        break;
    case EVENT_KEY_GAME_UP:
    case EVENT_KEY_GAME_DOWN:
        if (arcade.phase == ARCADE_PAUSED) {
            arcade.pauseChoice = (uint8_t)((arcade.pauseChoice +
                (event==EVENT_KEY_GAME_UP ? 2 : 1)) % 3);
        } else {
            ArcadeDirection dir=event==EVENT_KEY_GAME_UP ? ARCADE_UP : ARCADE_DOWN;
            if(arcade.kind==ARCADE_2048)movePuzzle2048(dir);
            else arcadeMove(&arcade,dir);
        }
        requestViewUpdate();
        break;
    case EVENT_KEY_GAME_LEFT:
    case EVENT_KEY_GAME_RIGHT:
        if (arcade.phase != ARCADE_PAUSED) {
            /* Support short taps as well as held-button paddle movement. */
            if (arcade.kind == ARCADE_BREAKOUT)
                arcadeBreakoutPaddle(&arcade, event==EVENT_KEY_GAME_LEFT ? -8 : 8);
            else if (arcade.kind == ARCADE_2048)
                movePuzzle2048(event==EVENT_KEY_GAME_LEFT ? ARCADE_LEFT : ARCADE_RIGHT);
            else
                arcadeMove(&arcade, event==EVENT_KEY_GAME_LEFT ? ARCADE_LEFT : ARCADE_RIGHT);
        }
        requestViewUpdate();
        break;
    case EVENT_DRAW:
        if (slideActive && arcade.kind==ARCADE_2048)
            drawArcade2048Slide(&arcade,slideFrom,slideDirection,slideProgress);
        else
            drawArcade(&arcade);
        break;
    case EVENT_KEY_TOGGLEBACKLIGHT:
        invalidateArcadeDrawing();
        break;
    default:
        break;
    }
}

static const char *getArcadeOption(menu_size_t index, MenuStyle *style)
{
    static const char *const titles[ARCADE_COUNT] = {"Snake", "2048", "Flappy Bird", "Breakout"};
    *style = MENUSTYLE_SUBMENU;
    return (index < ARCADE_COUNT) ? titles[index] : "";
}

static void selectArcadeOption(menu_size_t index)
{
    if (index >= ARCADE_COUNT) return;
    arcadeStart(&arcade, (ArcadeKind)index, currentTick ^ 0xa12e24f3u);
    arcadeActive=true;
    slideActive=false;
    invalidateArcadeDrawing();
    lastStepTick=currentTick;
    setKeyboardMode(KEYBOARD_MODE_GAME);
    showView(onArcadeViewEvent);
}

static const Menu arcadeMenu = {
    STRING_GAME,
    &arcadeMenuState,
    ARCADE_COUNT,
    getArcadeOption,
    selectArcadeOption,
    showSettingsMenu,
};

void resetGame(void)
{
    arcadeActive=false;
    slideActive=false;
    selectMenuItem(&arcadeMenu,0);
}

void showGameMenu(void)
{
    if (isKeyboardGameMode()) setKeyboardMode(KEYBOARD_MODE_MENU);
    arcadeActive=false;
    slideActive=false;
    showMenu(&arcadeMenu);
}

/* Called only by the main loop, never from the 1kHz timer interrupt. */
void updateGame(void)
{
    if (!arcadeActive) return;
    if (!isPoweredOn() || !isKeyboardGameMode()) { arcadeActive=false; return; }
    /* Active radiation alarms take priority over all game transitions. */
    if (getAlertLevel() != ALERTLEVEL_NONE) {
        arcadeActive=false;
        setMeasurementView();
        return;
    }
    /* Never continue game execution after another module replaces this view. */
    if (!isCurrentView(onArcadeViewEvent)) {
        arcadeActive = false;
        setKeyboardMode(KEYBOARD_MODE_MENU);
        return;
    }
    uint32_t now=currentTick;
    if (!isDisplayAwake()) {
        lastStepTick=now;
        invalidateArcadeDrawing();
        /* No hidden animation or gameplay while the display is asleep. */
        slideActive=false;
        return;
    }
    if (slideActive) {
        uint32_t elapsed=(uint32_t)(now-slideStarted);
        uint8_t nextProgress=elapsed>=100 ? 3 : elapsed>=67 ? 2 : elapsed>=33 ? 1 : 0;
        if (nextProgress!=slideProgress) {
            slideProgress=nextProgress;
            if (nextProgress==3) slideActive=false;
            requestViewUpdate();
        }
    }

    uint32_t period;
    switch (arcade.kind) {
    case ARCADE_SNAKE: period=(uint32_t)(220 - (arcade.score < 12 ? arcade.score*10 : 120)); break;
    case ARCADE_FLAPPY: period=80; break;
    case ARCADE_BREAKOUT: period=80; break;
    default: return;
    }
    if ((uint32_t)(now-lastStepTick)<period) return;
    lastStepTick=now;
    if (arcade.phase != ARCADE_RUNNING &&
        !(arcade.kind == ARCADE_BREAKOUT && arcade.phase == ARCADE_READY)) return;
    bool movedPaddle = false;
    if (arcade.kind==ARCADE_BREAKOUT) {
        /* Sample held paddle keys; all game exits use the pause menu. */
        bool left=isGameKeyHeld(KEY_LEFT);
        bool right=isGameKeyHeld(KEY_RIGHT);
        if (left!=right) {
            arcadeBreakoutPaddle(&arcade,left ? -5 : 5);
            movedPaddle=true;
        }
    }
    ArcadePhase beforePhase=arcade.phase;
    if (arcade.phase == ARCADE_RUNNING) arcadeStep(&arcade);
    /* Draw the game-over overlay immediately, not at the next heartbeat. */
    if (beforePhase != arcade.phase || arcade.phase == ARCADE_RUNNING || movedPaddle)
        requestViewUpdate();
}
#endif
