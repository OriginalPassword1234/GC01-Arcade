/* Rad Pro 3.1.1 GC-01 arcade extension; MIT licensed. Pure deterministic game logic. */
#if defined(GC01_ARCADE)
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "arcade_logic.h"

static uint32_t nextRandom(ArcadeState *a)
{
    uint32_t x = a->randomState;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    a->randomState = x;
    return x;
}

static uint32_t randomBelow(ArcadeState *a, uint32_t max)
{
    return nextRandom(a) % max; /* games only, not security or statistical RNG */
}

static bool snakeOccupied(const ArcadeSnake *s, uint8_t position)
{
    return (s->occupied[position >> 3] & (1u << (position & 7))) != 0;
}

static void setSnakeOccupied(ArcadeSnake *s, uint8_t position, bool value)
{
    uint8_t mask = (uint8_t)(1u << (position & 7));
    if (value) s->occupied[position >> 3] |= mask;
    else s->occupied[position >> 3] &= (uint8_t)~mask;
}

static void placeFood(ArcadeState *a)
{
    ArcadeSnake *s = &a->game.snake;
    if (s->length == 256) { a->phase = ARCADE_WON; return; }
    uint16_t available = 256u - s->length;
    uint16_t index = (uint16_t)randomBelow(a, available);
    for (uint16_t i = 0; i < 256; ++i)
        if (!snakeOccupied(s, (uint8_t)i))
            if (index-- == 0) { s->food = (uint8_t)i; return; }
}

static bool add2048Tile(ArcadeState *a)
{
    Arcade2048 *g = &a->game.puzzle;
    uint8_t freeCount = 0;
    for (uint8_t i = 0; i < 16; ++i) if (!g->cells[i]) ++freeCount;
    if (!freeCount) return false;
    uint8_t emptyIndex = (uint8_t)randomBelow(a, freeCount);
    for (uint8_t i = 0; i < 16; ++i)
        if (!g->cells[i] && emptyIndex-- == 0) {
            g->cells[i] = (randomBelow(a, 10) == 0) ? 2 : 1;
            return true;
        }
    return false;
}

static bool can2048Move(const Arcade2048 *g)
{
    for (int i = 0; i < 16; ++i) {
        if (!g->cells[i]) return true;
        if ((i % 4 < 3 && g->cells[i] == g->cells[i+1]) ||
            (i / 4 < 3 && g->cells[i] == g->cells[i+4])) return true;
    }
    return false;
}

static uint8_t cell2048(ArcadeDirection dir, uint8_t line, uint8_t j)
{
    return (uint8_t)(dir==ARCADE_LEFT ? 4*line+j :
        dir==ARCADE_RIGHT ? 4*line+3-j :
        dir==ARCADE_UP ? 4*j+line : 4*(3-j)+line);
}

bool arcade2048Plan(const uint8_t cells[16], ArcadeDirection dir,
                    uint8_t target[16], uint8_t result[16], uint32_t *gain)
{
    uint8_t local[16]={0};
    uint32_t points=0;
    bool changed=false;
    if (target) memset(target,255,16);
    for (uint8_t line=0;line<4;++line) {
        uint8_t values[4]={0}, count=0;
        bool merged[4]={false};
        for (uint8_t j=0;j<4;++j) {
            uint8_t pos=cell2048(dir,line,j);
            uint8_t v=cells[pos];
            if (!v) continue;
            if (count && v<30 && values[count-1]==v && !merged[count-1]) {
                uint8_t exponent = v<30 ? (uint8_t)(v+1) : 30;
                values[count-1]=exponent;
                merged[count-1]=true;
                if (UINT32_MAX-points < (1u<<exponent)) points=UINT32_MAX;
                else points+=(1u<<exponent);
                if (target)target[pos]=cell2048(dir,line,(uint8_t)(count-1));
            } else {
                values[count]=v;
                merged[count]=false;
                if (target)target[pos]=cell2048(dir,line,count);
                ++count;
            }
        }
        for(uint8_t j=0;j<4;++j) {
            uint8_t idx=cell2048(dir,line,j);
            local[idx]=values[j];
            if(local[idx]!=cells[idx])changed=true;
        }
    }
    if(result)memcpy(result,local,16);
    if(gain)*gain=points;
    return changed;
}

static void step2048(ArcadeState *a, ArcadeDirection dir)
{
    Arcade2048 *g=&a->game.puzzle;
    uint8_t result[16];
    uint32_t gained=0;
    bool changed=arcade2048Plan(g->cells,dir,NULL,result,&gained);
    bool firstWin=false;
    for(int i=0;i<16;++i)
        if (result[i]>=11 && !g->wonAlready) firstWin=true;
    memcpy(g->cells,result,16);
    if (UINT32_MAX-a->score < gained) a->score=UINT32_MAX;
    else a->score+=gained;
    if(changed)add2048Tile(a);
    if(firstWin){g->wonAlready=true; a->phase=ARCADE_WON;}
    else if(!can2048Move(g)) a->phase=ARCADE_LOST;
}

uint8_t arcadeFlappyStage(uint32_t score)
{
    return score>=24 ? 3 : score>=16 ? 2 : score>=8 ? 1 : 0;
}
uint8_t arcadeFlappyHalfGap(uint32_t score)
{
    return (uint8_t)(38-2*arcadeFlappyStage(score));
}
uint8_t arcadeFlappyPipeSpeed(uint32_t score)
{
    static const uint8_t speeds[4]={3,4,4,5};
    return speeds[arcadeFlappyStage(score)];
}

static void resetBreakoutBall(ArcadeBreakout *b)
{
    uint8_t speedLevel=b->level>7 ? 6 : (uint8_t)(b->level-1);
    b->ballX=(int16_t)b->paddleX<<4;
    b->ballY=206<<4;
    b->velocityX=(int16_t)(23+3*speedLevel);
    b->velocityY=(int16_t)(-68-6*speedLevel);
}

static void initBricks(ArcadeBreakout *b)
{
    for(uint8_t i=0;i<32;++i)b->bricks[i]=1;
    for(uint8_t j=0;j<4;++j)b->bricks[(j*7+b->level*3u)%32u]=2;
    for(uint8_t j=0;j<2;++j){
        uint8_t idx=(uint8_t)((j*13+b->level*5u+1)%32u);
        if(b->bricks[idx]==2) idx=(uint8_t)((idx+1)%32);
        if(b->bricks[idx]==2) idx=(uint8_t)((idx+1)%32);
        b->bricks[idx]=3;
    }
    b->bricksLeft=32;
    resetBreakoutBall(b);
}

void arcadeStart(ArcadeState *a, ArcadeKind kind, uint32_t seed)
{
    memset(a, 0, sizeof(*a));
    a->kind = kind;
    a->randomState = seed ? seed : 0x6d2b79f5u;
    a->phase = ARCADE_RUNNING;
    if (kind == ARCADE_SNAKE) {
        ArcadeSnake *s = &a->game.snake;
        s->tail = 0; s->length = 3; s->direction = ARCADE_RIGHT; s->nextDirection = ARCADE_RIGHT;
        s->body[0] = 8 * 16 + 5; s->body[1] = 8 * 16 + 6; s->body[2] = 8 * 16 + 7;
        for (uint8_t i=0;i<3;++i) setSnakeOccupied(s,s->body[i],true);
        placeFood(a);
    } else if (kind == ARCADE_2048) {
        add2048Tile(a); add2048Tile(a);
    } else if (kind == ARCADE_FLAPPY) {
        ArcadeFlappy *f = &a->game.flappy;
        f->y = 115 << 4;
        f->protectedPipe=255;
        for (int i=0;i<3;++i) {
            f->pipeX[i] = (int16_t)(175+i*100);
            f->pipeGap[i] = (uint8_t)(70+randomBelow(a,100));
        }
        a->phase = ARCADE_READY;
    } else if (kind == ARCADE_BREAKOUT) {
        ArcadeBreakout *b = &a->game.breakout;
        b->paddleX = 120; b->lives=3; b->level=1;
        initBricks(b);
        a->phase = ARCADE_READY;
    }
}

void arcadeMove(ArcadeState *a, ArcadeDirection direction)
{
    if (a->phase != ARCADE_RUNNING && a->phase != ARCADE_READY) return;
    if (a->kind == ARCADE_SNAKE) {
        ArcadeSnake *s = &a->game.snake;
        if ((s->direction ^ 1) != direction) s->nextDirection = (uint8_t)direction;
    } else if (a->kind == ARCADE_2048) {
        step2048(a, direction);
    } else if (a->kind == ARCADE_FLAPPY) {
        if (direction == ARCADE_UP) { a->phase = ARCADE_RUNNING; a->game.flappy.velocity = -72; }
    } else if (a->kind == ARCADE_BREAKOUT && direction == ARCADE_UP && a->phase == ARCADE_READY) {
        a->phase = ARCADE_RUNNING;
    }
}

void arcadeBreakoutPaddle(ArcadeState *a, int8_t step)
{
    if (a->kind != ARCADE_BREAKOUT || (a->phase != ARCADE_RUNNING && a->phase != ARCADE_READY)) return;
    ArcadeBreakout *b = &a->game.breakout;
    int16_t x = (int16_t)b->paddleX + step;
    if (x<21) x=21;
    if (x>218) x=218;
    b->paddleX=(uint8_t)x;
    if (a->phase == ARCADE_READY) b->ballX = x << 4;
}

static void snakeStep(ArcadeState *a)
{
    ArcadeSnake *s = &a->game.snake;
    s->direction = s->nextDirection;
    uint8_t head = s->body[(uint8_t)(s->tail+s->length-1)];
    int x = head & 15, y = head >> 4;
    if (s->direction == ARCADE_LEFT) --x;
    else if (s->direction == ARCADE_RIGHT) ++x;
    else if (s->direction == ARCADE_UP) --y;
    else ++y;
    if (x<0 || x>=16 || y<0 || y>=16) { a->phase=ARCADE_LOST; return; }
    uint8_t next = (uint8_t)(y*16+x);
    bool eating = next == s->food;
    if (snakeOccupied(s,next) && (eating || next != s->body[s->tail])) {
        a->phase=ARCADE_LOST; return;
    }
    if (!eating) {
        setSnakeOccupied(s,s->body[s->tail],false);
        ++s->tail;
        --s->length;
    }
    s->body[(uint8_t)(s->tail+s->length)]=next;
    ++s->length;
    setSnakeOccupied(s,next,true);
    if (eating) { ++a->score; placeFood(a); }
}

static void flappyStep(ArcadeState *a)
{
    ArcadeFlappy *f=&a->game.flappy;
    if(f->velocity<62)f->velocity+=5;
    f->y+=f->velocity;
    int birdY=f->y>>4;
    /* A shield never saves the bird from the floor or ceiling. */
    if(birdY<7 || birdY>232){a->phase=ARCADE_LOST;return;}
    int halfGap=arcadeFlappyHalfGap(a->score);
    int step=arcadeFlappyPipeSpeed(a->score);
    for(uint8_t i=0;i<3;++i) {
        f->pipeX[i]-=step;
        if(!(f->pipeScored[i]&1u) && f->pipeX[i]+28<43){
            if(a->score<UINT32_MAX)++a->score;
            f->pipeScored[i]|=1u;
        }
        if(f->pipeX[i]<-29){
            int16_t maxX=240;
            for(int j=0;j<3;++j)if(f->pipeX[j]>maxX)maxX=f->pipeX[j];
            f->pipeX[i]=(int16_t)(maxX+100);
            f->pipeGap[i]=(uint8_t)(70+randomBelow(a,100));
            if(f->protectedPipe==i)f->protectedPipe=255;
            f->pipeScored[i]=0;
            bool pickupPresent=false;
            for(int j=0;j<3;++j)
                if(f->pipeScored[j]&2u)pickupPresent=true;
            if(!pickupPresent && !f->shield && a->score>=3 && (a->score%5u)==0)
                f->pipeScored[i]|=2u;
        }
        /* Pickup at the pipe's center: it is collectible only inside the gap. */
        int pickupX=f->pipeX[i]+14;
        if((f->pipeScored[i]&2u) && pickupX>=43 && pickupX<=62 &&
           birdY>=f->pipeGap[i]-12 && birdY<=f->pipeGap[i]+12) {
            f->shield=1;
            f->pipeScored[i]&=(uint8_t)~2u;
        }
        bool overlap=f->pipeX[i]<62 && f->pipeX[i]+28>43;
        if(f->protectedPipe==i && !overlap)f->protectedPipe=255;
        if(overlap && f->protectedPipe!=i &&
           (birdY-7<(int)f->pipeGap[i]-halfGap ||
            birdY+7>(int)f->pipeGap[i]+halfGap)) {
            if(f->shield){
                f->shield=0;
                f->protectedPipe=i;
            }else{a->phase=ARCADE_LOST;return;}
        }
    }
}

static int breakoutAbs(int x){return x<0?-x:x;}
static void breakoutStep(ArcadeState *a)
{
    ArcadeBreakout *b=&a->game.breakout;
    /* Subpixel stepping checks swept movement against the actual 28x12
       visible brick rectangles. At least one check per screen pixel moved. */
    int vx=b->velocityX,vy=b->velocityY;
    int maxV=breakoutAbs(vx)>breakoutAbs(vy)?breakoutAbs(vx):breakoutAbs(vy);
    int parts=(maxV+15)/16;
    if(parts<1)parts=1;
    /* Paddle bounce is bounded so this remains at most eight substeps. */
    if(parts>8)parts=8;
    bool hitBrick=false;
    for(int n=0;n<parts;++n){
        int sx=(breakoutAbs(b->velocityX)*(n+1))/parts-
               (breakoutAbs(b->velocityX)*n)/parts;
        int sy=(breakoutAbs(b->velocityY)*(n+1))/parts-
               (breakoutAbs(b->velocityY)*n)/parts;
        b->ballX+=(int16_t)(b->velocityX<0?-sx:sx);
        b->ballY+=(int16_t)(b->velocityY<0?-sy:sy);
        int x=b->ballX>>4,y=b->ballY>>4;
        if(x<4){b->ballX=4<<4;b->velocityX=(int16_t)-b->velocityX;x=4;}
        if(x>235){b->ballX=235<<4;b->velocityX=(int16_t)-b->velocityX;x=235;}
        if(y<5){b->ballY=5<<4;b->velocityY=(int16_t)-b->velocityY;y=5;}
        if(b->velocityY>0 && y+4>=216 && y-4<=222 &&
           x+4>=b->paddleX-20 && x-4<=b->paddleX+20){
            b->velocityY=(int16_t)-b->velocityY;
            int16_t bounce=(int16_t)((x-(int)b->paddleX)*3);
            if(bounce>112)bounce=112;
            if(bounce<-112)bounce=-112;
            b->velocityX=bounce?bounce:5;
            b->ballY=211<<4;
            y=211;
        }
        if(y>=238){
            if(--b->lives==0)a->phase=ARCADE_LOST;
            else{a->phase=ARCADE_READY;resetBreakoutBall(b);}
            return;
        }
        if(!hitBrick && y+4>=21 && y-4<=74){
            for(int i=0;i<32;++i){
                int left=(i&7)*30+1,top=20+(i>>3)*14+1;
                if(!b->bricks[i] || x+4<left || x-4>left+27 ||
                   y+4<top || y-4>top+11)continue;
                uint8_t state=b->bricks[i];
                if(state==2){
                    b->bricks[i]=1;
                    if(a->score<=UINT32_MAX-5)a->score+=5;
                }else{
                    b->bricks[i]=0;
                    --b->bricksLeft;
                    uint32_t award=state==3?30u:10u;
                    a->score=UINT32_MAX-a->score<award?UINT32_MAX:a->score+award;
                }
                b->velocityY=(int16_t)-b->velocityY;
                hitBrick=true;
                if(!b->bricksLeft){
                    if(b->level<255)++b->level;
                    initBricks(b);
                    a->phase=ARCADE_READY;
                    return;
                }
                break;
            }
        }
    }
}

void arcadeStep(ArcadeState *a)
{
    if (a->phase != ARCADE_RUNNING) return;
    switch (a->kind) {
    case ARCADE_SNAKE: snakeStep(a); break;
    case ARCADE_FLAPPY: flappyStep(a); break;
    case ARCADE_BREAKOUT: breakoutStep(a); break;
    default: break;
    }
}

void arcadePause(ArcadeState *a)
{
    if (a->phase==ARCADE_PAUSED) { a->phase=a->previousPhase; return; }
    if (a->phase==ARCADE_RUNNING || a->phase==ARCADE_READY) {
        a->previousPhase=a->phase; a->phase=ARCADE_PAUSED; a->pauseChoice=0;
    } else if (a->phase==ARCADE_LOST || a->phase==ARCADE_WON) {
        /* Exit must still be available after a loss or victory. */
        a->previousPhase=a->phase;
        a->phase=ARCADE_PAUSED;
        a->pauseChoice=1; /* Restart is the natural default. */
    }
}

void arcadeChoosePause(ArcadeState *a)
{
    if (a->phase!=ARCADE_PAUSED) return;
    if (a->pauseChoice==0) {
        /* After the 2048 victory, the first option continues play. */
        if (a->previousPhase==ARCADE_WON && a->kind==ARCADE_2048)
            a->phase=ARCADE_RUNNING;
        else
            a->phase=a->previousPhase;
    }
    else if (a->pauseChoice==1) arcadeStart(a,a->kind,a->randomState);
    /* Exit choice handled by UI to restore keyboard mode. */
}

#endif /* GC01_ARCADE */
