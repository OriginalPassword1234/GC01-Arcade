/* Rad Pro 3.1.1 GC-01 arcade: procedural, zero-bitmap graphics.
 * Only compiled for GC01_ARCADE. No graphics heap or framebuffer.
 * Gameplay, timing, measurement, display driver and stored settings untouched.
 * License: MIT
 */
#if defined(GC01_ARCADE)
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "arcade.h"
#include "draw.h"
#include "../system/settings.h"
#include "../system/cstring.h"

/* Direct RGB565 is supported by the existing mcu-renderer used by Rad Pro. */
extern mr_t mr;
#define RGB(hex) mr_get_color(hex)
#define FIELD_SIZE 240
#define PANEL_X 240
#define PANEL_W 80

/* These colors are ROM constants (3 themes, no runtime allocation). */
typedef struct {
    mr_color_t field, grid, panel, panelEdge, text, muted, accent;
    mr_color_t mint, mintDark, mintLight, red, redLight, gold;
    mr_color_t sky, skyTop, cloud, pipe, pipeLight, pipeDark;
} ArcadeColors;
static const ArcadeColors palettes[3] = {
    /* Light Rad Pro UI: restrained navy arcade screen, pale status panel. */
    { RGB(0x173340),RGB(0x244653),RGB(0xe9f2f5),RGB(0xb3c7d0),RGB(0x183946),RGB(0x567884),RGB(0x0b827c),
      RGB(0x38c8a3),RGB(0x19876d),RGB(0x8af1ce),RGB(0xe65b68),RGB(0xffadab),RGB(0xf1bf55),
      RGB(0x497fa0),RGB(0x5a94b2),RGB(0xaad0da),RGB(0x239475),RGB(0x82e3a7),RGB(0x126658) },
    /* Dark Rad Pro UI. */
    { RGB(0x102733),RGB(0x1b3845),RGB(0x0d1c27),RGB(0x294453),RGB(0xeaf7f8),RGB(0x96b6c3),RGB(0x55d6c4),
      RGB(0x45cfae),RGB(0x157a69),RGB(0x9cf2d8),RGB(0xf06e7b),RGB(0xffafb0),RGB(0xf4c869),
      RGB(0x305e7a),RGB(0x3c7796),RGB(0x77aac0),RGB(0x24916d),RGB(0x80e1a3),RGB(0x135848) },
    /* Retro Rad Pro UI: warmer palette and amber status. */
    { RGB(0x202a20),RGB(0x304233),RGB(0x141d17),RGB(0x435a3d),RGB(0xf0c878),RGB(0xc6a46a),RGB(0xf4c36e),
      RGB(0x79c786),RGB(0x397f4b),RGB(0xafe5a0),RGB(0xeb7971),RGB(0xffbba2),RGB(0xf3cd74),
      RGB(0x516e62),RGB(0x627e68),RGB(0x8ea38a),RGB(0x56865b),RGB(0xa3c588),RGB(0x345e45) },
};

/* Per-rectangle clipping lets us redraw only moving objects. On this LCD,
 * repainting the entire playfield for every 80ms frame visibly flashes.
 * The ST7789 has its own display memory; no RAM framebuffer is required. */
static int16_t clipX0,clipY0,clipX1=DISPLAY_WIDTH,clipY1=DISPLAY_HEIGHT;
static void setClip(int x,int y,int w,int h)
{
    clipX0=(int16_t)(x<0?0:x);
    clipY0=(int16_t)(y<0?0:y);
    int right=x+w,bottom=y+h;
    clipX1=(int16_t)(right>DISPLAY_WIDTH?DISPLAY_WIDTH:right);
    clipY1=(int16_t)(bottom>DISPLAY_HEIGHT?DISPLAY_HEIGHT:bottom);
}
/* Every rectangle is clipped to both the physical LCD and the dirty region. */
static void block(int16_t x, int16_t y, int16_t w, int16_t h, mr_color_t color)
{
    if (w <= 0 || h <= 0) return;
    int32_t x2=(int32_t)x+w, y2=(int32_t)y+h;
    if (x<clipX0) x=clipX0;
    if (y<clipY0) y=clipY0;
    if (x2>clipX1) x2=clipX1;
    if (y2>clipY1) y2=clipY1;
    if (x>=x2 || y>=y2) return;
    mr_set_fill_color(&mr,color);
    drawRectangle(&(mr_rectangle_t){x,y,(int16_t)(x2-x),(int16_t)(y2-y)});
}

/* 3x5 pixel alphabet: 72 bytes total, reused by tiles, sidebar and overlays.
 * Unlike the stock 30px font, it fits 4-10 digit 2048 tiles into 56px.
 */
static const uint16_t digitBits[10] = { 0x7b6f, 0x2c97, 0x73e7, 0x73cf, 0x5bc9, 0x79cf, 0x79ef, 0x7292, 0x7bef, 0x7bcf };
static const uint16_t letterBits[26] = { 0x2bed, 0x6bae, 0x3923, 0x6b6e, 0x79a7, 0x79a4, 0x396b, 0x5bed, 0x7497, 0x126a, 0x5bad, 0x4927, 0x5fed, 0x5ffd, 0x2b6a, 0x6ba4, 0x2b7b, 0x6bad, 0x388e, 0x7492, 0x5b6f, 0x5b6a, 0x5bfd, 0x5aad, 0x5a92, 0x72a7 };

static uint16_t glyph(char ch)
{
    if (ch>='0' && ch<='9') return digitBits[(uint8_t)(ch-'0')];
    if (ch>='A' && ch<='Z') return letterBits[(uint8_t)(ch-'A')];
    return 0;
}

static int textWidth(const char *s, int scale)
{
    int length=0;
    while (*s++) ++length;
    return length ? length*4*scale-scale : 0;
}

/* Render contiguous runs in a row as one rectangle instead of per-pixel calls. */
static void textAt(const char *s, int x, int y, int scale, mr_color_t color)
{
    for (;*s;s++,x+=4*scale) {
        uint16_t bits=glyph(*s);
        for (int row=0;row<5;++row) {
            int col=0;
            while(col<3) {
                while(col<3 && !(bits & (1u << (14-(row*3+col))))) ++col;
                int first=col;
                while(col<3 && (bits & (1u << (14-(row*3+col))))) ++col;
                if(col>first) block((int16_t)(x+first*scale),
                    (int16_t)(y+row*scale),(int16_t)((col-first)*scale),
                    (int16_t)scale,color);
            }
        }
    }
}
static void textCenter(const char *s,int x,int y,int width,int scale,mr_color_t color)
{
    textAt(s,x+(width-textWidth(s,scale))/2,y,scale,color);
}
static void numberCenter(uint32_t n,int x,int y,int width,int scale,mr_color_t color)
{
    char t[16];
    strclr(t);
    strcatUInt32(t,n,0);
    textCenter(t,x,y,width,scale,color);
}

static void sidebar(const ArcadeState *a, const ArcadeColors *p)
{
    static const char *const titles[ARCADE_COUNT]={"SNAKE","2048","FLAPPY","BREAKOUT"};
    block(PANEL_X,0,PANEL_W,DISPLAY_HEIGHT,p->panel);
    block(PANEL_X,0,2,DISPLAY_HEIGHT,p->panelEdge);
    block(PANEL_X+7,9,66,2,p->accent);
    textCenter(titles[a->kind],PANEL_X,16,PANEL_W,2,p->text);
    block(PANEL_X+9,36,62,1,p->panelEdge);
    textCenter("SCORE",PANEL_X,51,PANEL_W,2,p->muted);
    uint32_t shown=a->score>999999 ? 999999 : a->score;
    int scale=shown>999 ? 2 : 3;
    numberCenter(shown,PANEL_X,70,PANEL_W,scale,p->text);
    block(PANEL_X+9,114,62,1,p->panelEdge);
    if(a->kind==ARCADE_BREAKOUT) {
        textCenter("LIVES",PANEL_X,132,PANEL_W,2,p->muted);
        numberCenter(a->game.breakout.lives,PANEL_X,153,PANEL_W,3,p->text);
        textCenter("LEVEL",PANEL_X,181,PANEL_W,2,p->muted);
        numberCenter(a->game.breakout.level,PANEL_X,200,PANEL_W,2,p->text);
    } else if(a->kind==ARCADE_FLAPPY) {
        textCenter("SHIELD",PANEL_X,132,PANEL_W,2,p->muted);
        textCenter(a->game.flappy.shield?"ON":"OFF",PANEL_X,155,PANEL_W,3,
                   a->game.flappy.shield?p->accent:p->muted);
        textCenter("STAGE",PANEL_X,188,PANEL_W,2,p->muted);
        numberCenter((uint32_t)arcadeFlappyStage(a->score)+1u,PANEL_X,208,PANEL_W,2,p->accent);
    } else if(a->phase==ARCADE_READY) {
        textCenter("READY",PANEL_X,205,PANEL_W,2,p->accent);
    } else if(a->kind==ARCADE_2048) {
        textCenter("GOAL",PANEL_X,159,PANEL_W,2,p->muted);
        numberCenter(2048,PANEL_X,178,PANEL_W,2,p->accent);
    }
}

static void snake(const ArcadeState *a, const ArcadeColors *p)
{
    const ArcadeSnake *s=&a->game.snake;
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->field);
    /* Sparse grid: 30 strips instead of 256 colored cell backgrounds. */
    for(int i=1;i<16;++i) {
        block(i*15,0,1,FIELD_SIZE,p->grid);
        block(0,i*15,FIELD_SIZE,1,p->grid);
    }
    for(int i=0;i<256;++i) {
        if(s->occupied[i>>3] & (1u << (i&7))) {
            int x=(i&15)*15, y=(i>>4)*15;
            block(x+1,y+1,13,13,((i^(i>>4))&1)?p->mint:p->mintDark);
        }
    }
    /* Head and eyes are on top of body, respecting the existing 15px cells. */
    uint8_t head=s->body[(uint8_t)(s->tail+s->length-1)];
    int hx=(head&15)*15, hy=(head>>4)*15;
    block(hx+1,hy+1,13,13,p->mintLight);
    if(s->direction==ARCADE_LEFT || s->direction==ARCADE_RIGHT) {
        int eyeX=hx+(s->direction==ARCADE_RIGHT?10:3);
        block(eyeX,hy+3,2,2,p->field);
        block(eyeX,hy+10,2,2,p->field);
    } else {
        int eyeY=hy+(s->direction==ARCADE_DOWN?10:3);
        block(hx+3,eyeY,2,2,p->field);
        block(hx+10,eyeY,2,2,p->field);
    }
    /* A completely filled board has no remaining food cell. */
    if (s->length<256) {
        int fx=(s->food&15)*15, fy=(s->food>>4)*15;
        block(fx+3,fy+4,9,9,p->red);
        block(fx+4,fy+4,6,2,p->redLight);
        block(fx+7,fy+1,2,4,p->mintLight);
    }
}

/* Tile color is a compact RGB565 constant, not an image asset. */
static const mr_color_t tileColors[] = {
    RGB(0x2d4350),RGB(0xb6e3d9),RGB(0x89d8ca),RGB(0x67c8d4),
    RGB(0x51b7d4),RGB(0x4c94d0),RGB(0x777dca),RGB(0x9d77c6),
    RGB(0xc07eae),RGB(0xdd8e8b),RGB(0xe2aa6e),RGB(0xe7c762),
    RGB(0x8bd1ad)
};
static void tile2048(int x,int y,uint8_t exp,const ArcadeColors *p)
{
    if(exp>30) exp=30;
    mr_color_t color=tileColors[exp<12 ? exp : 12];
    block(x+3,y+4,55,55,p->panelEdge);
    block(x+2,y+2,55,54,color);
    if(exp) {
        block(x+5,y+4,49,2,exp<5?RGB(0xeafff9):RGB(0xf6e2c9));
        char t[16];strclr(t);
        strcatUInt32(t,1u<<exp,0);
        int digits=0; for(const char *q=t;*q;++q)++digits;
        int scale=digits<=4?3:(digits<=6?2:1);
        mr_color_t fg=exp<=4?RGB(0x203745):RGB(0xfffaf2);
        textCenter(t,x+2,y+30-(5*scale)/2,55,scale,fg);
    }
}
static void puzzleBase(const ArcadeColors *p)
{
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->field);
    for(int i=0;i<16;++i)
        tile2048((i&3)*60,(i>>2)*60,0,p);
}
static void puzzle2048(const ArcadeState *a,const ArcadeColors *p)
{
    /* Each static cell is painted once, not empty then covered by its tile. */
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->field);
    for(int i=0;i<16;++i)
        tile2048((i&3)*60,(i>>2)*60,a->game.puzzle.cells[i],p);
}
/* 2048 tile motion uses the same merge planner as the actual game logic.
 * progress=0 is the original board; 1/2 are intermediate thirds. */
static void puzzle2048Slide(const uint8_t from[16],ArcadeDirection dir,
                            uint8_t progress,const ArcadeColors *p)
{
    uint8_t target[16];
    arcade2048Plan(from,dir,target,NULL,NULL);
    puzzleBase(p);
    for(int src=0;src<16;++src) {
        if(!from[src] || target[src]>=16) continue;
        int dest=target[src];
        int x=(((src&3)*(3-progress)+(dest&3)*progress)*60)/3;
        int y=(((src>>2)*(3-progress)+(dest>>2)*progress)*60)/3;
        tile2048(x,y,from[src],p);
    }
}

static void flappy(const ArcadeState *a, const ArcadeColors *p)
{
    const ArcadeFlappy *f=&a->game.flappy;
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->sky);
    block(0,0,FIELD_SIZE,56,p->skyTop);
    /* Three small stationary clouds; no bitmap storage or scrolling state. */
    static const uint8_t clouds[][2]={{16,34},{123,67},{192,21}};
    for(int i=0;i<3;++i) {
        int x=clouds[i][0],y=clouds[i][1];
        block(x,y+5,29,5,p->cloud);
        block(x+7,y,15,12,p->cloud);
    }
    int halfGap=arcadeFlappyHalfGap(a->score);
    for(int i=0;i<3;++i) {
        int x=f->pipeX[i], center=f->pipeGap[i];
        int top=center-halfGap, bottom=center+halfGap;
        /* All pipe decorations remain INSIDE the collision width (28px). */
        block(x,0,28,top,p->pipeDark);
        block(x+3,0,22,top,p->pipe);
        block(x+4,0,3,top,p->pipeLight);
        block(x,top-7,28,7,p->pipeDark);
        block(x+2,top-6,24,3,p->pipeLight);
        block(x,bottom,28,FIELD_SIZE-bottom,p->pipeDark);
        block(x+3,bottom,22,FIELD_SIZE-bottom,p->pipe);
        block(x+4,bottom,3,FIELD_SIZE-bottom,p->pipeLight);
        block(x,bottom,28,7,p->pipeDark);
        block(x+2,bottom+1,24,2,p->pipeLight);
        if(f->pipeScored[i]&2u) {
            /* Glowing shield pickup, drawn inside the traversable gap. */
            block(x+10,center-5,8,10,p->mintLight);
            block(x+11,center-4,6,8,p->accent);
            block(x+13,center-2,2,4,p->text);
        }
    }
    int y=f->y>>4;
    if(f->shield) {
        /* A small bright halo, not an extra image or framebuffer. */
        block(43,y-9,19,2,p->mintLight);
        block(43,y+8,19,2,p->mintLight);
        block(43,y-7,2,15,p->mintLight);
        block(60,y-7,2,15,p->mintLight);
    }
    /* Bird pixel art fits the original x=43..62, y-7..y+7 collision box. */
    block(46,y-7,13,13,p->gold);
    block(47,y-6,11,3,RGB(0xffe69a));
    block(44,y+1,8,6,RGB(0xe8a746)); /* wing */
    block(45,y+2,6,3,RGB(0xffd66f));
    block(58,y-1,4,4,RGB(0xef9356)); /* beak */
    block(54,y-4,4,4,RGB(0xfffaf2));
    block(56,y-3,2,2,RGB(0x183342)); /* eye */
    block(0,237,FIELD_SIZE,3,p->pipeDark);
}

static void breakout(const ArcadeState *a, const ArcadeColors *p)
{
    const ArcadeBreakout *b=&a->game.breakout;
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->field);
    block(2,7,236,2,p->grid);
    static const mr_color_t brickColors[4] = {
        RGB(0xed777f),RGB(0xf0bd68),RGB(0x55c3ab),RGB(0x619fd2)
    };
    for(int i=0;i<32;++i) if(b->bricks[i]) {
        int x=(i&7)*30, y=20+(i>>3)*14;
        /* Existing 28x12 collision footprint remains unchanged. */
        block(x+1,y+1,28,12,p->panelEdge);
        mr_color_t face=b->bricks[i]==3 ? p->gold : brickColors[i>>3];
        block(x+1,y+1,28,10,face);
        block(x+3,y+2,24,2,RGB(0xf4f6ee));
        if(b->bricks[i]==2) {
            block(x+4,y+6,20,2,p->mintLight); /* reinforced */
            block(x+24,y+4,2,5,p->pipeDark);
        } else if(b->bricks[i]==3) {
            block(x+6,y+5,4,4,RGB(0xfff3bc)); /* bonus glint */
        }
    }
    block(b->paddleX-20,216,40,7,p->pipeDark);
    block(b->paddleX-18,216,36,4,p->mint);
    block(b->paddleX-16,216,32,1,p->mintLight);
    int bx=(b->ballX>>4),by=(b->ballY>>4);
    block(bx-5,by-5,11,11,p->grid);
    block(bx-3,by-3,7,7,RGB(0xfff5c6));
    block(bx-2,by-2,4,4,RGB(0xffffff));
}

static void statusOverlay(const ArcadeState *a, const ArcadeColors *p)
{
    if(a->phase!=ARCADE_PAUSED && a->phase!=ARCADE_LOST &&
       a->phase!=ARCADE_WON && a->phase!=ARCADE_READY) return;
    if(a->phase==ARCADE_READY && a->kind==ARCADE_SNAKE) return;
    if(a->phase==ARCADE_READY) {
        block(32,99,176,42,p->panel);
        block(32,99,176,2,p->accent);
        textCenter(a->kind==ARCADE_FLAPPY ? "UP TO FLAP":"UP TO LAUNCH",
                   32,115,176,2,p->text);
    } else if(a->phase==ARCADE_PAUSED) {
        block(24,46,192,149,p->panel);
        block(24,46,192,2,p->accent);
        textCenter("PAUSED",24,59,192,3,p->text);
        const char *first=(a->previousPhase==ARCADE_LOST ||
                            a->previousPhase==ARCADE_WON)
            ? (a->previousPhase==ARCADE_WON && a->kind==ARCADE_2048 ? "CONTINUE" : "BACK")
            : "RESUME";
        const char *const options[]={first,"RESTART","EXIT"};
        for(int i=0;i<3;++i) {
            int y=92+i*31;
            if(a->pauseChoice==i) block(43,y-2,154,28,p->panelEdge);
            textCenter(options[i],43,y+4,154,2,a->pauseChoice==i?p->accent:p->text);
        }
    } else {
        block(28,91,184,63,p->panel);
        block(28,91,184,2,p->accent);
        textCenter(a->phase==ARCADE_WON?"YOU WIN":"GAME OVER",28,103,184,3,p->text);
        textCenter("OK OPTIONS",28,135,184,2,p->muted);
    }
}

/* Keep one previous state (< 350 bytes of SRAM) for dirty-region repaint.
 * The games remain isolated: none of this changes settings, measurements,
 * display driver behavior, or firmware flash storage. */
static ArcadeState previous;
static bool previousValid;
static bool previousSlide;
static uint8_t previousSlideProgress;
static uint8_t previousSlideFrom[16];
static ArcadeDirection previousSlideDirection;
static uint8_t previousTheme;

void invalidateArcadeDrawing(void)
{
    previousValid=false;
}

static void scene(const ArcadeState *a,const ArcadeColors *p,
                  const uint8_t *slideFrom,ArcadeDirection direction,uint8_t progress)
{
    /* Never draw off-screen pipes or moving tiles over the 80px sidebar. */
    int16_t oldRight=clipX1;
    if(clipX1>FIELD_SIZE)clipX1=FIELD_SIZE;
    switch(a->kind) {
    case ARCADE_SNAKE: snake(a,p); break;
    case ARCADE_2048:
        if(slideFrom) puzzle2048Slide(slideFrom,direction,progress,p);
        else puzzle2048(a,p);
        break;
    case ARCADE_FLAPPY: flappy(a,p); break;
    case ARCADE_BREAKOUT: breakout(a,p); break;
    default: break;
    }
    clipX1=oldRight;
}
static void repaint(const ArcadeState *a,const ArcadeColors *p,
                    int x,int y,int w,int h)
{
    setClip(x,y,w,h);
    scene(a,p,NULL,ARCADE_LEFT,0);
}
static int minInt(int a,int b){return a<b?a:b;}
static int maxInt(int a,int b){return a>b?a:b;}

/* Mark all board cells swept by a moving 2048 tile. This preserves
 * correctly overlapped sprites without a full-screen animation wipe. */
static void markSlideCells(bool dirty[16],const uint8_t from[16],
                           ArcadeDirection direction)
{
    uint8_t targets[16];
    arcade2048Plan(from,direction,targets,NULL,NULL);
    for(int i=0;i<16;++i) {
        if(!from[i] || targets[i]==i || targets[i]>=16)continue;
        int dest=targets[i];
        int x0=minInt(i&3,dest&3),x1=maxInt(i&3,dest&3);
        int y0=minInt(i>>2,dest>>2),y1=maxInt(i>>2,dest>>2);
        for(int y=y0;y<=y1;++y)
            for(int x=x0;x<=x1;++x)dirty[y*4+x]=true;
    }
}

static void drawInternal(const ArcadeState *a,const uint8_t *slideFrom,
                         ArcadeDirection direction,uint8_t progress)
{
    if(!a || a->kind>=ARCADE_COUNT)return;
    uint8_t theme=(uint8_t)settings.displayTheme;
    const ArcadeColors *p=&palettes[theme<3?theme:1];
    bool sliding=slideFrom && a->kind==ARCADE_2048;
    /* A heartbeat or redundant redraw must not repaint an unchanged game. */
    if(previousValid && previousTheme==theme && previousSlide==sliding &&
       (!sliding || (previousSlideProgress==progress &&
        previousSlideDirection==direction &&
        memcmp(previousSlideFrom,slideFrom,16)==0)) &&
       memcmp(&previous,a,sizeof(*a))==0)
        return;
    bool whole=!previousValid || previous.kind!=a->kind ||
        previousTheme!=theme || previous.phase!=a->phase;
    if(whole) {
        setClip(0,0,DISPLAY_WIDTH,DISPLAY_HEIGHT);
        scene(a,p,sliding?slideFrom:NULL,direction,progress);
        sidebar(a,p);
        statusOverlay(a,p);
    } else if(a->phase==ARCADE_PAUSED && previous.pauseChoice!=a->pauseChoice) {
        repaint(a,p,24,46,192,149);
        statusOverlay(a,p);
    } else if(a->phase!=ARCADE_PAUSED) {
        switch(a->kind) {
        case ARCADE_SNAKE: {
            const ArcadeSnake *old=&previous.game.snake,*now=&a->game.snake;
            uint8_t oldHead=old->body[(uint8_t)(old->tail+old->length-1)];
            uint8_t newHead=now->body[(uint8_t)(now->tail+now->length-1)];
            /* Only head/tail/food can change during a normal Snake step. */
            uint8_t cells[6]={oldHead,newHead,old->body[old->tail],
                              now->body[now->tail],old->food,now->food};
            int count=old->food==now->food?4:6;
            for(int j=0;j<count;++j) {
                bool seen=false;
                for(int k=0;k<j;++k) if(cells[k]==cells[j]) {seen=true;break;}
                if(!seen) {
                    int i=cells[j];
                    repaint(a,p,(i&15)*15,(i>>4)*15,15,15);
                }
            }
            break;
        }
        case ARCADE_2048:
            if(sliding || previousSlide) {
                bool dirty[16]={false};
                if(sliding)markSlideCells(dirty,slideFrom,direction);
                if(previousSlide)markSlideCells(dirty,previousSlideFrom,
                                                previousSlideDirection);
                /* Include new tile spawn and other final board differences. */
                for(int i=0;i<16;++i)
                    if(previous.game.puzzle.cells[i]!=a->game.puzzle.cells[i])
                        dirty[i]=true;
                if(previousSlide && !sliding) {
                    uint8_t finalBeforeSpawn[16];
                    arcade2048Plan(previousSlideFrom,previousSlideDirection,
                                   NULL,finalBeforeSpawn,NULL);
                    for(int i=0;i<16;++i)
                        if(finalBeforeSpawn[i]!=a->game.puzzle.cells[i])dirty[i]=true;
                }
                /* Coalesce adjacent cells per row, avoiding 240x240 clears. */
                for(int row=0;row<4;++row) {
                    for(int col=0;col<4;) {
                        if(!dirty[row*4+col]){++col;continue;}
                        int start=col;
                        while(col<4 && dirty[row*4+col])++col;
                        setClip(start*60,row*60,(col-start)*60,60);
                        scene(a,p,sliding?slideFrom:NULL,direction,progress);
                    }
                }
            } else {
                for(int i=0;i<16;++i)
                    if(previous.game.puzzle.cells[i]!=a->game.puzzle.cells[i])
                        repaint(a,p,(i&3)*60,(i>>2)*60,60,60);
            }
            break;
        case ARCADE_FLAPPY: {
            const ArcadeFlappy *old=&previous.game.flappy,*now=&a->game.flappy;
            int y0=minInt(old->y>>4,now->y>>4)-10;
            int y1=maxInt(old->y>>4,now->y>>4)+11;
            repaint(a,p,42,y0,24,y1-y0);
            for(int i=0;i<3;++i) {
                int x0=minInt(old->pipeX[i],now->pipeX[i]);
                int x1=maxInt(old->pipeX[i],now->pipeX[i])+28;
                if(x1-x0<64)
                    repaint(a,p,x0,0,x1-x0,FIELD_SIZE);
                else {
                    repaint(a,p,old->pipeX[i],0,28,FIELD_SIZE);
                    repaint(a,p,now->pipeX[i],0,28,FIELD_SIZE);
                }
            }
            break;
        }
        case ARCADE_BREAKOUT: {
            const ArcadeBreakout *old=&previous.game.breakout,*now=&a->game.breakout;
            int oldX=old->ballX>>4,oldY=old->ballY>>4;
            int newX=now->ballX>>4,newY=now->ballY>>4;
            int x0=minInt(oldX,newX)-6,y0=minInt(oldY,newY)-6;
            repaint(a,p,x0,y0,maxInt(oldX,newX)-x0+7,
                    maxInt(oldY,newY)-y0+7);
            if(old->paddleX!=now->paddleX) {
                x0=minInt(old->paddleX,now->paddleX)-22;
                repaint(a,p,x0,214,maxInt(old->paddleX,now->paddleX)-x0+22,12);
            }
            for(int i=0;i<32;++i)
                if(old->bricks[i]!=now->bricks[i])
                    repaint(a,p,(i&7)*30,20+(i>>3)*14,30,14);
            break;
        }
        default: break;
        }
        if(a->score!=previous.score) {
            setClip(PANEL_X+2,65,PANEL_W-2,45);
            sidebar(a,p);
        }
        if((a->kind==ARCADE_BREAKOUT &&
            (a->game.breakout.lives!=previous.game.breakout.lives ||
             a->game.breakout.level!=previous.game.breakout.level)) ||
           (a->kind==ARCADE_FLAPPY &&
            (a->game.flappy.shield!=previous.game.flappy.shield ||
             arcadeFlappyStage(a->score)!=arcadeFlappyStage(previous.score)))) {
            setClip(PANEL_X+2,117,PANEL_W-2,123);
            sidebar(a,p);
        }
    }
    setClip(0,0,DISPLAY_WIDTH,DISPLAY_HEIGHT);
    previous=*a;
    previousValid=true;
    previousTheme=theme;
    previousSlide=sliding;
    if(sliding) {
        previousSlideProgress=progress;
        previousSlideDirection=direction;
        memcpy(previousSlideFrom,slideFrom,16);
    }
}

void drawArcade(const ArcadeState *a)
{
    drawInternal(a,NULL,ARCADE_LEFT,0);
}
void drawArcade2048Slide(const ArcadeState *a,const uint8_t from[16],
                         ArcadeDirection direction,uint8_t progress)
{
    drawInternal(a,from,direction,progress>2?2:progress);
}
#endif /* GC01_ARCADE */
