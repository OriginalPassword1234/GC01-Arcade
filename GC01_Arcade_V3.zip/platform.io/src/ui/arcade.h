/* Rad Pro 3.1.1 GC-01 arcade extension; MIT licensed. */
#ifndef ARCADE_DRAW_H
#define ARCADE_DRAW_H
#include "../extras/arcade_logic.h"
void drawArcade(const ArcadeState *game);
/* One nonblocking 2048 transition frame, progress 0, 1 or 2 of three steps. */
void drawArcade2048Slide(const ArcadeState *game, const uint8_t from[16], ArcadeDirection direction, uint8_t progress);
/* Call when changing view or waking the LCD to force a complete repaint. */
void invalidateArcadeDrawing(void);
#endif
