# Rider v0.7 local host test results

- GCC 12+ core tests: PASS (determinism, random-input/restarts, novice reachability, score from generated gameplay, loop traversal/inversion/exit, saw clearance, diamond count, speed pad, angle resolution)
- Clang core tests with AddressSanitizer and UndefinedBehaviorSanitizer: PASS
- GCC and Clang renderer tests: PASS on 7 seeds × 800 ticks
- Partial redraw cache: PASS; 37/80 three-row strips transferred in one sample moving scene; 0/80 for identical frame
- Static renderer RAM: **3,412 bytes**
- Two state structures: **368 bytes**
- Screen strip-hash cache: **320 bytes**
- Identified core+renderer+cache static RAM: **4,100 bytes** (excludes Rad Pro, MCU stack, runtime scratch, interrupts)
- A full 2D loop fixture completes at the rail exit with a reversed X segment and inverted car orientation
- Generated-score test: the car performs a full airborne flip, lands, and reaches score ≥1 in a procedural run
- Host renderer benchmark: 160 frames, ~0.16–0.21 ms per frame on the test PC across runs. **This is not GC01 FPS.**
- All four 320×240 PNG previews generated from real C renderer output
- Embedded workflow archive reproduced and retested byte-for-byte against this source

NOT VERIFIED:
- Actual ARM compilation/link against pinned upstream Rad Pro; that happens in GitHub Actions.
- Display/GPIO transfer speed and FPS on the physical GC01.
- USB bootloader flashing and post-flash operation of v0.7.
- Original 95 Rider track pieces / moving platforms / exact Box2D physics.
- Complete random track reachability beyond the novice sections; serious hazards can require player timing.
- Compression and migration of preexisting radiation settings/history.

Do not treat these host checks as proof that the firmware is completely bug-free or flash-safe.
