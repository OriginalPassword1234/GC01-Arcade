# Rider v0.8 — changes

* Loop painting now culls out-of-strip segments (pixel-equivalent to the older painter).
* More varied connected hills and hazard sections; not extracted original chunks.
* Damped air rotation and stronger grounded alignment; no artificial vertical kick from penetration correction.
* Track-tangent launch velocity and extended generated scoring regression.
* Gentler single attached exhaust plume and slower saw animation.
* Pause/play HUD, high-score display, and game-only backlight heartbeat refresh.
* CRC-protected two-page flash high-score journal, tested in a flash simulator.
* Expanded host suite and a one-action source+firmware+test workflow.

Not original Box2D, not 95 original chunks, not certified on GC01.
