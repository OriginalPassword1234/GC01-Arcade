/* Experimental GC01 ST7789 output adapter for Rider.
 * Skips unchanged 320x3 RGB565 strips to avoid redundant SPI transfers.
 * A 320-byte strip-hash table is kept in static RAM; no heap or DMA ownership.
 */
#if defined(GC01_RIDER)
#include <stdint.h>
#include "rider_screen.h"
#include "rider_render.h"
#include "draw.h"

#define ROWS 3
#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 240
#define STRIP_PIXELS (ROWS*SCREEN_WIDTH)
#define STRIP_COUNT (SCREEN_HEIGHT/ROWS)
static uint32_t previous_hash[STRIP_COUNT];
static uint8_t cache_valid;

void rider_screen_invalidate(void)
{
    cache_valid=0;
}

static uint32_t hash_pixels(const uint16_t *pixels)
{
    /* Full-strip FNV-1a; possible collision can suppress one redraw, not
     * corrupt memory. The next changed strip usually repairs it. */
    uint32_t h=2166136261u;
    for(unsigned i=0;i<STRIP_PIXELS;++i){
        h=(h ^ pixels[i])*16777619u;
    }
    return h;
}

static void send_rows(int top,int rows,const uint16_t *pixels,void *unused)
{
    (void)unused;
    if(rows!=ROWS || top<0 || top+rows>SCREEN_HEIGHT || top%ROWS!=0) return;
    const unsigned slot=(unsigned)top/ROWS;
    const uint32_t digest=hash_pixels(pixels);
    if(cache_valid && previous_hash[slot]==digest)return;
    const mr_rectangle_t area={0,(int16_t)top,SCREEN_WIDTH,(int16_t)rows};
    drawImage(&area,pixels);
    previous_hash[slot]=digest;
}

void rider_draw_gc01(const RiderState *state,const RiderState *prev,uint8_t alpha)
{
    rider_render(state,prev,alpha,send_rows,0);
    cache_valid=1;
}
#endif
