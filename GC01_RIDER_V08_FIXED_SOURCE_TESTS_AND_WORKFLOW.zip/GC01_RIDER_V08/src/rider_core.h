/*
 * Independent Rider-style endless-mode engine, revision 0.1.
 * No assets or source code from Ketchapp or the prior Rider attempts.
 * MIT license. Pre-hardware prototype: NOT a claim of physics parity.
 */
#ifndef RIDER_CORE_H
#define RIDER_CORE_H
#include <stdbool.h>
#include <stdint.h>

#define RIDER_Q 256
#define RIDER_PIECE_WIDTH 256
#define RIDER_TRACK_SLOTS 12
#define RIDER_TRACK_NODES 9
#define RIDER_ANGLE_TURN 4096

typedef enum {
    RIDER_READY = 0,
    RIDER_RUNNING = 1,
    RIDER_CRASHED = 2
} RiderPhase;

typedef struct {
    uint32_t number;             /* absolute segment index */
    int16_t start_y;              /* y in world pixels */
    uint8_t template_id;         /* immutable geometry template */
    uint8_t flags;               /* bit0 gem_taken, bit1 saw, bit2 boost */
} RiderPiece;

typedef struct {
    RiderPiece track[RIDER_TRACK_SLOTS];
    uint32_t next_piece;
    uint32_t random_state;
    uint32_t tick_count;          /* supports deterministic hazard animation */
    int32_t x;                    /* world X, Q8 */
    int32_t y;                    /* world Y, Q8: positive down */
    int32_t camera_x;             /* Q8 */
    int32_t camera_y;             /* Q8 */
    int32_t vx;                   /* Q8 pixels per 1/60 s */
    int32_t vy;
    int32_t angle;                /* 4096 == one clockwise rotation */
    int32_t angular_speed;        /* angle units per simulation tick */
    int32_t takeoff_angle;
    int32_t score;
    int32_t best;                 /* RAM only; no flash writes */
    int32_t diamonds;             /* RAM only */
    uint32_t air_rotation;       /* unwrapped rotation completed while airborne */
    uint32_t loop_piece;
    uint16_t loop_t;             /* 0..4096 path parameter for a true loop shape */
    uint8_t looping;             /* explicitly guided compact loop traversal */
    uint8_t boost_ticks;         /* short, visible effect after crossing blue strip */
    uint16_t pending_score;
    uint16_t pending_ticks;
    uint16_t airborne_ticks;
    uint16_t crash_ticks;
    uint8_t grounded;
    uint8_t perfect_ticks;
    uint8_t paused;               /* UI state; simulation controlled by adapter */
    uint8_t last_template;
    RiderPhase phase;
} RiderState;

/* One simulation step ALWAYS means 1/60 second; independent of render speed. */
void rider_init(RiderState *s, uint32_t seed);
void rider_restart(RiderState *s);
void rider_step(RiderState *s, bool one_button_down);

/* Return false if this coordinate has been evicted from the fixed-size window. */
bool rider_surface_q(const RiderState *s, int32_t world_x_q, int32_t *world_y_q);
void rider_wheel_centers_q(const RiderState *s, int32_t *lx, int32_t *ly,
                           int32_t *rx, int32_t *ry);
/* Lightweight metadata helpers for rendering and collision. */
bool rider_piece_saw_q(const RiderState *s, uint32_t piece_number, int32_t *cx_q, int32_t *cy_q, int32_t *radius_q);
bool rider_piece_boost_q(const RiderState *s, uint32_t piece_number, int32_t *x0_q, int32_t *x1_q, int32_t *y_q);
int16_t rider_sin256(uint8_t angle_index);
int16_t rider_sin4096(int32_t angle);
bool rider_loop_point_q(uint32_t piece_number, uint16_t t, int32_t *xq, int32_t *yq);
uint32_t rider_hash(const RiderState *s); /* deterministic regression fingerprint */
#endif
