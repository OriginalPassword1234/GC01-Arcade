/* GC01/Rad Pro integration adapter, prototype. No flash writes, no ISR game work.
 * Intended for the archived pre-Rider Arcade source ONLY after applying patch.
 * Original Geiger event loop/pulse IRQs/USB update path are not modified here. */
#if defined(GC01_RIDER)
#include <stdbool.h>
#include <stdint.h>
#include "rider_core.h"
#include "rider_saves.h"
#include "../measurements/measurements.h"
#include "../peripherals/keyboard.h"
#include "../system/events.h"
#include "../system/power.h"
#include "../system/settings.h"
#include "../ui/menu.h"
#include "../ui/view.h"
#include "../ui/rider_screen.h"
#include "game.h"

static RiderState rider;
static RiderState previous;
static bool game_active;
static bool paused;
static uint32_t last_tick;
static uint32_t last_draw;
static uint32_t step_accumulator; /* scaled by 60, denominator 1000 */
static uint32_t last_saved_best;
static uint32_t last_saved_diamonds;
static MenuState rider_menu_state;
static const Menu rider_menu;

static void save_if_changed(void)
{
    uint32_t best=(uint32_t)rider.best;
    uint32_t diamonds=(uint32_t)rider.diamonds;
    if(best!=last_saved_best || diamonds!=last_saved_diamonds){
        if(rider_saves_store(best,diamonds)){
            last_saved_best=best;
            last_saved_diamonds=diamonds;
        }
    }
}
static void leave_rider(void)
{
    save_if_changed();
    game_active=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showMenu(&rider_menu);
}
static void on_rider_event(ViewEvent event)
{
    switch(event) {
    case EVENT_KEY_GAME_EXIT:
        leave_rider();
        break;
    case EVENT_KEY_GAME_OK:
        paused=!paused;
        rider.paused=paused?1u:0u;
        rider_screen_invalidate();
        last_tick=currentTick;
        requestViewUpdate();
        break;
    case EVENT_KEY_GAME_RIGHT:
    case EVENT_KEY_GAME_UP:
        if(rider.phase==RIDER_CRASHED) {
            rider_restart(&rider);
            previous=rider;
            last_tick=currentTick;
            step_accumulator=0;
            requestViewUpdate();
        }
        break;
    case EVENT_DRAW:
        rider_draw_gc01(&rider,&previous,(uint8_t)((step_accumulator*255u)/1000u));
        break;
    case EVENT_HEARTBEAT:
        /* Preserve the user's normal display sleep setting everywhere else.
         * Re-arm only during the game, including when paused. */
        if(game_active)requestBacklightTrigger();
        break;
    default:
        break;
    }
}
static const char *rider_option(menu_size_t index,MenuStyle *style)
{
    *style=MENUSTYLE_SUBMENU;
    return index==0?"Rider":"";
}
static void rider_select(menu_size_t index)
{
    if(index!=0)return;
    /* The source device's radiation random numbers are not consumed. */
    rider_init(&rider, currentTick ^ 0x5a17d10bu);
    uint32_t saved_best=0,saved_diamonds=0;
    if(rider_saves_load(&saved_best,&saved_diamonds)){
        rider.best=(int32_t)(saved_best>0x7fffffffu?0x7fffffffu:saved_best);
        rider.diamonds=(int32_t)(saved_diamonds>0x7fffffffu?0x7fffffffu:saved_diamonds);
    }
    last_saved_best=(uint32_t)rider.best;
    last_saved_diamonds=(uint32_t)rider.diamonds;
    rider_screen_invalidate();
    previous=rider;
    last_tick=currentTick;
    last_draw=currentTick;
    step_accumulator=0;
    paused=false;
    game_active=true;
    requestBacklightTrigger();
    setKeyboardMode(KEYBOARD_MODE_GAME);
    showView(on_rider_event);
}
static const Menu rider_menu={
    STRING_GAME,&rider_menu_state,1,rider_option,rider_select,showSettingsMenu
};
void resetGame(void)
{
    game_active=false;
    selectMenuItem(&rider_menu,0);
}
void showGameMenu(void)
{
    game_active=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showMenu(&rider_menu);
}
void updateGame(void)
{
    if(!game_active)return;
    if(!isPoweredOn()||!isKeyboardGameMode()) {game_active=false;return;}
    if(getAlertLevel()!=ALERTLEVEL_NONE) {
        game_active=false;
        setKeyboardMode(KEYBOARD_MODE_MENU);
        setMeasurementView(); /* Geiger alarm has unconditional priority. */
        return;
    }
    if(!isCurrentView(on_rider_event)) {
        game_active=false;
        setKeyboardMode(KEYBOARD_MODE_MENU);
        return;
    }
    uint32_t now=currentTick;
    if(!isDisplayAwake()||paused) {
        if(!isDisplayAwake()) rider_screen_invalidate();
        last_tick=now;
        step_accumulator=0;
        return;
    }
    uint32_t elapsed=now-last_tick; /* uint32 subtraction handles tick wrap */
    last_tick=now;
    if(elapsed>100) elapsed=100; /* capped catch-up; don't starve measurements */
    step_accumulator += elapsed*60u;
    uint8_t steps=0;
    while(step_accumulator>=1000u&&steps<6) {
        step_accumulator-=1000u;
        previous=rider;
        bool held=isGameKeyHeld(KEY_RIGHT)||isGameKeyHeld(KEY_UP);
        rider_step(&rider,held);
        ++steps;
    }
    /* Writing at the end of a run avoids mid-game flash stalls. */
    if(rider.phase==RIDER_CRASHED && previous.phase!=RIDER_CRASHED)
        save_if_changed();
    if(now-last_draw>=33u) {
        last_draw=now;
        requestViewUpdate(); /* display work stays in main loop */
    }
}
#endif
