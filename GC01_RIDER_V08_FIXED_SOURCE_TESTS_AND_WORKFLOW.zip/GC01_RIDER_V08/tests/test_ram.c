#include "../src/rider_render.h"
#include <stdio.h>
int main(void){printf("render_static=%u two_states=%zu strip_hash=%u sum=%zu\n",(unsigned)rider_render_static_ram(),2*sizeof(RiderState),320u,(size_t)rider_render_static_ram()+2*sizeof(RiderState)+320u);return 0;}
