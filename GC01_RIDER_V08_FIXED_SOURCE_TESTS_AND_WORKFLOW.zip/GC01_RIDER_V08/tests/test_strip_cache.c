#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static uint32_t sent;
void rider_screen_invalidate(void);
void rider_draw_gc01(const RiderState *s,const RiderState *p,uint8_t alpha);
typedef struct { int16_t x,y,width,height; } mr_rectangle_t;
void drawImage(const mr_rectangle_t *a,const uint16_t *pixels)
{
    assert(a->x==0 && a->width==320 && a->height==3 && a->y%3==0 && pixels);
    ++sent;
}
int main(void)
{
    RiderState s;rider_init(&s,0x1aeu);
    rider_screen_invalidate();
    rider_draw_gc01(&s,0,0);
    assert(sent==80);              /* initial entire display */
    sent=0;
    rider_draw_gc01(&s,0,0);
    assert(sent==0);               /* identical scene: no SPI traffic */
    RiderState before=s;
    for(int i=0;i<15;++i)rider_step(&s,1);
    sent=0;
    rider_draw_gc01(&s,&before,180);
    assert(sent>0 && sent<80);      /* changed region only */
    printf("dirty: %u / 80 strips transferred in moving scene\n",sent);
    rider_screen_invalidate();
    sent=0;rider_draw_gc01(&s,0,0);
    assert(sent==80);              /* menu and re-entry clean redraw */
    puts("strip-cache tests passed");
}
