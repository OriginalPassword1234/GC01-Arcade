#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flags=(-std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer)
cc "${flags[@]}" src/rider_core.c tests/test_core.c -o /tmp/rider_v08_core
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_core
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_render_many.c -o /tmp/rider_v08_render
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_render
cc "${flags[@]}" -DGC01_RIDER -DRIDER_HOST_TEST -Isrc -Itests/fake src/rider_core.c src/rider_render.c rider_screen.c tests/test_strip_cache.c -o /tmp/rider_v08_dirty
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_dirty
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/render_scenes.c -o /tmp/rider_v08_preview
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_preview score /tmp/rider_v08_score.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_preview saw /tmp/rider_v08_saw.ppm
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_preview loop /tmp/rider_v08_loop.ppm
# Game saves are kept in a separate 2-KiB flash journal. Exercise the *real*
# save source against an emulated flash chip, including interrupted writes.
cc "${flags[@]}" -DGC01_RIDER -DGC01 tests/flash_sim/extras/rider_saves.c tests/flash_sim/test_saves.c -o /tmp/rider_v08_saves
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_saves
cc "${flags[@]}" src/rider_core.c src/rider_render.c tests/test_pause_hud.c -o /tmp/rider_v08_pause
ASAN_OPTIONS=detect_leaks=1 /tmp/rider_v08_pause
