/* A deliberately staged source-renderer fixture to exercise HUD/rotation. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static FILE *file;
static int next_row;
static void sink(int top,int n,const uint16_t *pix,void *unused)
{
    (void)unused;
    assert(top==next_row&&n==3);
    for(int i=0;i<n*320;++i){
        uint16_t p=pix[i];
        uint8_t rgb[3]={(uint8_t)(((p>>11)&31)*255/31),
                        (uint8_t)(((p>>5)&63)*255/63),
                        (uint8_t)((p&31)*255/31)};
        assert(fwrite(rgb,1,3,file)==3);
    }
    next_row+=n;
}
int main(int argc,char **argv)
{
    RiderState s;
    rider_init(&s,0x19772106u);
    for(int i=0;i<90;i++)rider_step(&s,s.grounded!=0);
    s.phase=RIDER_RUNNING;
    s.score=17;
    s.pending_score=2;
    s.y-=28*RIDER_Q;
    s.angle=384; /* for visual coverage only, not a recorded game run */
    file=fopen(argc>1?argv[1]:"staged.ppm","wb");assert(file);
    fprintf(file,"P6\n320 240\n255\n");
    rider_render(&s,0,0,sink,0);
    assert(next_row==240);
    assert(fclose(file)==0);
    return 0;
}
