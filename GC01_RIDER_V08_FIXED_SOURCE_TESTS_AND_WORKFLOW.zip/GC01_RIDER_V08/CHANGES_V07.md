# v0.7 changes

## Direct answers to GC01 device feedback

| Problem reported | Change | Verified by |
| --- | --- | --- |
| Excessive bouncing / random tipping | Absorb landing velocity, slow angle settling, widen safe landing range | seeded simulation and no early-course crashes |
| Only 256 wheel angles | Interpolate trig table at 4096 positions/turn | angle test |
| Too fast / uncontrolled rotation | 6 px/tick normal cap, 128 angle units/tick cap | game tests |
| Completed flips not scored | Integrate actual airborne turns and display pending score | generated-run scoring test |
| Diamond icons don't do anything | Collectible counter visible top-right; persist through in-game restart | collection test |
| Blue line pads don't work | Curved pads and temporary acceleration boost | boost test |
| Saws buried in terrain | Larger blades and positive terrain clearance | clearance test |
| Two disconnected exhaust lines | Single short fading streak | actual renderer preview |
| No loops | True parametric loop rail and guided traversal | entry/invert/exit test |
| Slow renderer | Fast uniform-sky fill + existing 3-row dirty caching | multi-seed render tests; ON-DEVICE FPS UNTESTED |

**No claim of perfect fidelity, bug-free firmware, safe flashing, or a measured FPS improvement on real hardware.**
