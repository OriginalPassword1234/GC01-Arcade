#!/usr/bin/env bash
# Invoked from the radpro checkout. Never change partition sizes, trim output,
# strip program bytes, or disable an existing feature to meet the size limit.
set -euo pipefail
: "${GITHUB_WORKSPACE:?GITHUB_WORKSPACE is required}"
REPORT="$GITHUB_WORKSPACE/dist/tests/size"
mkdir -p "$REPORT"
TARGET=fnirsi-gc01_apm32f103rb-en
INI=platform.io/platformio.ini
BUILD=platform.io/.pio/build/$TARGET
cp "$INI" "$REPORT/platformio-original.ini"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
printf 'profile\tresult\traw_bytes\tremaining\tnominal_spare_sram\n' > "$REPORT/SIZE_RESULTS.tsv"
apply_flags() {
  python3 - "$INI" "$REPORT/platformio-original.ini" "$1" <<'PY'
import pathlib,sys
out,base=map(pathlib.Path,sys.argv[1:3]); flags=sys.argv[3]
s=base.read_text(); marker='[env:fnirsi-gc01_apm32f103rb-en]'
assert s.count(marker)==1
start=s.index(marker); end=s.find('\n[',start+len(marker)); end=len(s) if end<0 else end
block=s[start:end]; anchor='    -DGC01_RIDER\n'
assert block.count(anchor)==1 and '-DFIRMWARE_SIZE=0x11000' in block
if flags: block=block.replace(anchor,anchor+''.join('    '+flag+'\n' for flag in flags.split()),1)
out.write_text(s[:start]+block+s[end:])
PY
}
# Keep actual binary/ELF out of failure diagnostic artifacts. Preserve maps and
# symbol tables for further optimization if no candidate can satisfy all gates.
best_size=999999
best_profile=''
run_profile() {
  local name="$1" flags="$2" dir="$REPORT/$1" bytes spare result
  mkdir -p "$dir"
  apply_flags "$flags" || return 2
  cp "$INI" "$dir/platformio.ini" || return 2
  printf '%s\n' "$flags" > "$dir/extra_flags.txt"
  echo "=== Size profile $name: ${flags:-pinned defaults} ==="
  if ! pio run -d platform.io -e "$TARGET" -t clean > "$dir/clean.log" 2>&1; then
    printf '%s\tclean_failed\t-\t-\t-\n' "$name" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  rm -f -- "$BUILD/firmware.bin" "$BUILD/firmware.elf"
  if ! pio run -v -d platform.io -e "$TARGET" > "$dir/build.log" 2>&1; then
    tail -n 30 "$dir/build.log"
    printf '%s\tcompile_failed\t-\t-\t-\n' "$name" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  if ! test -s "$BUILD/firmware.bin" || ! test -s "$BUILD/firmware.elf"; then
    printf '%s\tmissing_output\t-\t-\t-\n' "$name" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  bytes=$(wc -c < "$BUILD/firmware.bin")
  size -A -d "$BUILD/firmware.elf" > "$dir/sections.txt" 2>&1 || true
  nm -S --size-sort --radix=d --defined-only -C "$BUILD/firmware.elf" > "$dir/symbols-by-size.txt" 2>&1 || true
  readelf -W -S -l "$BUILD/firmware.elf" > "$dir/sections-and-segments.txt" 2>&1 || true
  readelf -p .comment "$BUILD/firmware.elf" > "$dir/layout-and-compiler.txt" 2>&1 || true
  if test -f "$BUILD/firmware.map"; then cp "$BUILD/firmware.map" "$dir/firmware.map" || return 2; fi
  # Same constants as the independent final CRC audit. Check layout and RAM
  # before signing, not just raw length. Actual stack usage remains unmeasured.
  if ! spare=$(python3 rider_ci/preflight_profile.py "$BUILD/firmware.bin" "$BUILD/firmware.elf" 2> "$dir/preflight.log"); then
    cat "$dir/preflight.log"
    printf '%s\tpreflight_failed\t%s\t%s\t-\n' "$name" "$bytes" "$((69628-bytes))" >> "$REPORT/SIZE_RESULTS.tsv"; return 1
  fi
  if (( bytes > 69628 )); then result=oversize
  elif (( spare < 3072 )); then result=insufficient_sram
  else result=fits; fi
  printf '%s\t%s\t%s\t%s\t%s\n' "$name" "$result" "$bytes" "$((69628-bytes))" "$spare" >> "$REPORT/SIZE_RESULTS.tsv"
  echo "Raw $bytes B; remaining $((69628-bytes)) B; nominal SRAM spare $spare B; $result"
  if [[ "$result" == fits ]] && (( bytes < best_size )); then
    cp "$BUILD/firmware.bin" "$WORK/firmware.bin" || return 2
    cp "$BUILD/firmware.elf" "$WORK/firmware.elf" || return 2
    cp "$INI" "$WORK/platformio.ini" || return 2
    best_size=$bytes; best_profile=$name
  fi
  # Prefer the first less intrusive profile with at least 256 bytes of
  # optional margin. If no such profile exists, use best fitting result.
  return 0
}
try_profile() {
  local rc=0
  run_profile "$1" "$2" || rc=$?
  if ((rc==2)); then echo 'Internal workflow error; refusing signing.' >&2; exit 1; fi
}
# The original target uses LTO. First try the optimized source with its exact
# default flags, then progressively more size-oriented GCC choices.
try_profile optimized_default ''
if ((best_size>69372)); then try_profile restrained_inline '-Os -fno-inline-functions-called-once -fno-ipa-cp-clone'; fi
if ((best_size>69372)); then try_profile oz '-Oz'; fi
if ((best_size>69372)); then try_profile oz_restrained '-Oz -fno-inline-functions-called-once -fno-ipa-cp-clone'; fi
if ((best_size>69372)); then try_profile limited_inline '-Os -fno-inline-functions -fno-inline-small-functions -fno-inline-functions-called-once -fno-partial-inlining -fno-ipa-cp-clone'; fi
if ((best_size>69372)); then try_profile oz_limited '-Oz -fno-inline-functions -fno-inline-small-functions -fno-inline-functions-called-once -fno-partial-inlining -fno-ipa-cp-clone'; fi
if ((best_size>69372)); then try_profile compact_ipa '-Os -fno-inline-functions -fno-inline-small-functions -fno-inline-functions-called-once -fno-partial-inlining -fno-ipa-cp -fno-ipa-sra'; fi
cat "$REPORT/SIZE_RESULTS.tsv"
if [[ -z "$best_profile" ]]; then
  echo 'NO PROFILE FITS. Upload SIZE_RESULTS.tsv and symbols-by-size.txt to continue optimizing. No binary will be signed.' >&2
  exit 1
fi
# Restore the exact successful paired binary, ELF and configuration; later
# profiles may have overwritten the build tree. Do not rebuild a different one.
cp "$WORK/firmware.bin" "$BUILD/firmware.bin"
cp "$WORK/firmware.elf" "$BUILD/firmware.elf"
cp "$WORK/platformio.ini" "$INI"
cp "$REPORT/$best_profile/build.log" "$GITHUB_WORKSPACE/dist/tests/PLATFORMIO_BUILD_LOG.txt"
cp "$REPORT/$best_profile/build.log" /tmp/rider_expanded_build.log
printf 'Selected %s: raw %s B, remaining %s B. Hardware timing and bootloader still unverified.\n' "$best_profile" "$best_size" "$((69628-best_size))" | tee "$REPORT/SELECTED_PROFILE.txt"
sha256sum "$BUILD/firmware.bin" "$BUILD/firmware.elf" > "$REPORT/SELECTED_BUILD_HASHES.txt"
