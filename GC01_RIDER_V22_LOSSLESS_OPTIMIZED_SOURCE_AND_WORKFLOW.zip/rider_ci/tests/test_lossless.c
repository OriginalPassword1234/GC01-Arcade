/* Differential test against exact v2.1a engine; reference objects are renamed. */
#include "../src/rider_render.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
extern void base_rider_init(RiderState*,uint32_t);
extern void base_rider_step(RiderState*,bool);
extern void base_rider_restart(RiderState*);
extern int16_t base_rider_sin256(uint8_t);
extern int16_t base_rider_sin4096(int32_t);
extern bool base_rider_surface_q(const RiderState*,int32_t,int32_t*);
extern bool base_rider_special_point_q(uint32_t,uint8_t,uint16_t,int32_t*,int32_t*);
extern void base_rider_render(const RiderState*,const RiderState*,uint8_t,RiderPixels,void*);
static uint16_t frames[2][320*240];
static void sink(int top,int rows,const uint16_t *p,void *ctx){
 unsigned k=*(const unsigned*)ctx;assert(top>=0&&top+rows<=240);
 memcpy(frames[k]+top*320,p,(size_t)rows*320*sizeof(uint16_t));
}
static unsigned compared;
static void compare_frame(const RiderState *s,const RiderState *prev,uint8_t a){
 unsigned k=0;rider_render(s,prev,a,sink,&k);k=1;base_rider_render(s,prev,a,sink,&k);
 assert(memcmp(frames[0],frames[1],sizeof(frames[0]))==0);compared++;
}
static uint32_t random32(uint32_t *s){uint32_t x=*s;x^=x<<13;x^=x>>17;x^=x<<5;return *s=x;}
int main(void){
 for(int a=0;a<256;a++)assert(rider_sin256((uint8_t)a)==base_rider_sin256((uint8_t)a));
 for(int a=-8192;a<8192;a++)assert(rider_sin4096(a)==base_rider_sin4096(a));
 puts("Exact sine values and interpolation: PASS");
 unsigned long long samples=0,paths=0,ticks=0;
 for(unsigned k=0;k<RIDER_TEMPLATE_COUNT;k++){
  RiderState s;rider_init(&s,1);s.track[0].template_id=(uint8_t)k;s.track[0].start_y=166;
  s.track[0].flags=15;s.track[0].gem_mask=7;
  for(int x=0;x<65536;x++){
   int32_t a=0,b=0;bool ok=rider_surface_q(&s,x,&a),old=base_rider_surface_q(&s,x,&b);
   assert(ok==old&&(!ok||a==b));samples++;
  }
  for(unsigned t=0;t<=4096;t++){
   int32_t x=0,y=0,a=0,b=0;bool ok=rider_special_point_q(1,k,t,&x,&y),old=base_rider_special_point_q(1,k,t,&a,&b);
   assert(ok==old&&(!ok||(x==a&&y==b)));paths++;
  }
  for(unsigned i=0;i<12;i++){
   s.tick_count=i*13u;s.track[0].start_y=(int16_t)(108+9*i);s.track[0].flags=(uint8_t)(i&1u?31:15);s.track[0].fall_tick=0;
   for(int x=0;x<65536;x+=97){int32_t a=0,b=0;bool ok=rider_surface_q(&s,x,&a),old=base_rider_surface_q(&s,x,&b);assert(ok==old&&(!ok||a==b));samples++;}
  }
  s.camera_x=-20*RIDER_Q;s.camera_y=-20*RIDER_Q;s.x=90*RIDER_Q;s.y=130*RIDER_Q;s.phase=RIDER_RUNNING;
  s.grounded=0;s.angle=800;s.throttle_active=1;compare_frame(&s,NULL,0);
 }
 printf("%llu exact surface queries, %llu special-path queries: PASS\n",samples,paths);
 for(unsigned seed=1;seed<=500;seed++){
  RiderState a,b,prev;uint32_t rng=seed;rider_init(&a,seed);base_rider_init(&b,seed);assert(!memcmp(&a,&b,sizeof(a)));
  for(unsigned t=0;t<10500;t++){
   prev=a;bool held=seed<=400?a.grounded:(random32(&rng)&7u)!=0u;
   rider_step(&a,held);base_rider_step(&b,held);ticks++;
   assert(!memcmp(&a,&b,sizeof(a)));
   if(t%701u==0&&seed<=60)compare_frame(&a,&prev,(uint8_t)(t+seed));
   if(a.phase==RIDER_CRASHED){if(seed<=400)break;rider_restart(&a);base_rider_restart(&b);assert(!memcmp(&a,&b,sizeof(a)));}
  }
 }
 printf("%llu identical simulation steps, %u pixel-identical complete RGB565 frames: PASS\n",ticks,compared);
 return 0;
}
