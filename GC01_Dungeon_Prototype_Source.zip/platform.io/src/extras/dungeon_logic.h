/* Dungeon Lite: portable game state and rules. No firmware hardware dependencies.
 * MIT license, 2026. Unverified experimental software. */
#ifndef GC01_DUNGEON_LOGIC_H
#define GC01_DUNGEON_LOGIC_H
#include <stdint.h>
#include <stdbool.h>

#define DG_SIZE 31u
#define DG_MAP_CELLS (DG_SIZE * DG_SIZE)
#define DG_SEEN_BYTES ((DG_MAP_CELLS + 7u) / 8u)
#define DG_ENEMY_MAX 12u
#define DG_ITEM_MAX 12u

typedef enum { DG_WALL, DG_FLOOR, DG_STAIRS, DG_TRAP, DG_SHRINE } DG_Tile;
typedef enum { DG_POTION, DG_WEAPON, DG_ARMOR, DG_GOLD } DG_ItemKind;
typedef enum { DG_PLAYING, DG_PAUSED, DG_DEAD, DG_LEVELUP, DG_EQUIP } DG_Phase;
typedef enum { DG_SWORD, DG_DAGGER, DG_AXE, DG_BOW } DG_Weapon;
typedef enum { DG_NORTH, DG_SOUTH, DG_WEST, DG_EAST, DG_WAIT, DG_HEAL, DG_GUARD,
               DG_SHOOT_NORTH, DG_SHOOT_SOUTH, DG_SHOOT_WEST, DG_SHOOT_EAST } DG_Action;
typedef enum { DG_MSG_NONE, DG_MSG_HIT, DG_MSG_HURT, DG_MSG_LOOT,
               DG_MSG_STAIRS, DG_MSG_POISON, DG_MSG_HEAL, DG_MSG_LEVEL,
               DG_MSG_BLOCKED, DG_MSG_GUARD, DG_MSG_AIM, DG_MSG_SHOT,
               DG_MSG_MISS, DG_MSG_BOSS, DG_MSG_LOCKED, DG_MSG_COUNTER, DG_MSG_BLESS, DG_MSG_CURSE } DG_Message;

typedef struct {
    uint16_t pos;
    uint8_t hp, kind;
} DG_Enemy;

typedef struct {
    uint16_t pos;
    uint8_t kind, amount;
} DG_Item;

typedef struct {
    uint8_t cells[DG_MAP_CELLS];
    uint8_t seen[DG_SEEN_BYTES];
    uint8_t visible[DG_SEEN_BYTES];
    DG_Enemy enemies[DG_ENEMY_MAX];
    DG_Item items[DG_ITEM_MAX];
    uint32_t rng, score;
    uint16_t position, floor, xp, gold, turns;
    uint8_t hp, maxHp, attack, defense, level, potions, poison;
    uint8_t enemyCount, itemCount, phase, message, menuChoice;
    uint8_t weapon, arrows, guard, riposte, stunnedEnemy, pendingWeapon;
} DG_Game;

void dg_start(DG_Game *g, uint32_t seed);
void dg_generate_floor(DG_Game *g);
bool dg_action(DG_Game *g, DG_Action action);
bool dg_choose_upgrade(DG_Game *g, uint8_t choice);
bool dg_choose_weapon(DG_Game *g, uint8_t equip);
int dg_enemy_at(const DG_Game *g, uint16_t position);
int dg_item_at(const DG_Game *g, uint16_t position);
bool dg_seen(const DG_Game *g, uint16_t position);
bool dg_visible(const DG_Game *g, uint16_t position);
#if defined(DG_NATIVE_TEST)
bool dg_floor_reachable(const DG_Game *g);
#endif
#endif
