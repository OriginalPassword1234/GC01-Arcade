#include "dungeon_logic.h"
#if defined(GC01_DUNGEON) || defined(DG_NATIVE_TEST)
#include <string.h>

/* All random choices are game-local and reproducible. Never consume USB RNG. */
static uint32_t rnd(DG_Game *g) {
    uint32_t x=g->rng;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return g->rng=x;
}
static uint16_t roll(DG_Game *g, uint16_t n) { return (uint16_t)(rnd(g)%n); }
static uint16_t posxy(uint8_t x,uint8_t y) { return (uint16_t)(y*DG_SIZE+x); }
static uint8_t px(uint16_t pos) { return (uint8_t)(pos%DG_SIZE); }
static uint8_t py(uint16_t pos) { return (uint8_t)(pos/DG_SIZE); }
static void seen_set(DG_Game *g, uint16_t p) {g->seen[p>>3] |= (uint8_t)(1u << (p&7u));}
bool dg_seen(const DG_Game *g, uint16_t p) {
    return p<DG_MAP_CELLS && (g->seen[p>>3] & (1u << (p&7u)))!=0;
}
static bool passable(const DG_Game *g,uint16_t p) {
    return p<DG_MAP_CELLS && g->cells[p]!=DG_WALL;
}
int dg_enemy_at(const DG_Game *g,uint16_t p) {
    for(uint8_t i=0;i<g->enemyCount;i++) if(g->enemies[i].hp && g->enemies[i].pos==p) return i;
    return -1;
}
int dg_item_at(const DG_Game *g,uint16_t p) {
    for(uint8_t i=0;i<g->itemCount;i++) if(g->items[i].pos==p) return i;
    return -1;
}
static void reveal(DG_Game *g) {
    int x=px(g->position),y=py(g->position);
    for(int dy=-5;dy<=5;dy++) for(int dx=-5;dx<=5;dx++) {
        int nx=x+dx,ny=y+dy;
        if(nx>0&&ny>0&&nx<(int)DG_SIZE-1&&ny<(int)DG_SIZE-1 &&
           dx*dx+dy*dy<=32) seen_set(g,posxy((uint8_t)nx,(uint8_t)ny));
    }
}
static void carve(DG_Game *g,int x,int y) {
    if(x>0&&y>0&&x<(int)DG_SIZE-1&&y<(int)DG_SIZE-1)
        g->cells[posxy((uint8_t)x,(uint8_t)y)]=DG_FLOOR;
}
static void hall(DG_Game *g,int x,int y,int tx,int ty) {
    while(x!=tx) {carve(g,x,y);x+=x<tx?1:-1;}
    while(y!=ty) {carve(g,x,y);y+=y<ty?1:-1;}
    carve(g,x,y);
}
static uint8_t distance_from_player(const DG_Game *g,uint16_t p) {
    int dx=(int)px(p)-(int)px(g->position);
    int dy=(int)py(p)-(int)py(g->position);
    if(dx<0)dx=-dx;
    if(dy<0)dy=-dy;
    return (uint8_t)(dx+dy);
}
static bool place(DG_Game *g,uint16_t *out,uint8_t minDistance) {
    for(unsigned tries=0;tries<160;tries++) {
        uint8_t x=(uint8_t)(1+roll(g,DG_SIZE-2));
        uint8_t y=(uint8_t)(1+roll(g,DG_SIZE-2));
        uint16_t p=posxy(x,y);
        if(g->cells[p]!=DG_FLOOR || distance_from_player(g,p)<minDistance ||
           dg_enemy_at(g,p)>=0 || dg_item_at(g,p)>=0) continue;
        *out=p;return true;
    }
    /* A bounded sequential fallback makes very crowded floors still valid. */
    for(uint16_t p=0;p<DG_MAP_CELLS;p++) {
        if(g->cells[p]==DG_FLOOR&&distance_from_player(g,p)>=minDistance&&
           dg_enemy_at(g,p)<0&&dg_item_at(g,p)<0) {
            *out=p;return true;
        }
    }
    return false;
}
void dg_generate_floor(DG_Game *g) {
    memset(g->cells,0,sizeof(g->cells));
    memset(g->seen,0,sizeof(g->seen));
    g->enemyCount=0;g->itemCount=0;
    int previousX=0,previousY=0;
    uint8_t count=(uint8_t)(7+roll(g,4));
    for(uint8_t room=0;room<count;room++) {
        int w=3+roll(g,5),h=3+roll(g,5);
        int x=1+roll(g,(uint16_t)(DG_SIZE-w-2));
        int y=1+roll(g,(uint16_t)(DG_SIZE-h-2));
        for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++)carve(g,xx,yy);
        int cx=x+w/2, cy=y+h/2;
        if(room==0) g->position=posxy((uint8_t)cx,(uint8_t)cy);
        else if(roll(g,2)) {hall(g,previousX,previousY,cx,previousY);hall(g,cx,previousY,cx,cy);}
        else {hall(g,previousX,previousY,previousX,cy);hall(g,previousX,cy,cx,cy);}
        previousX=cx;previousY=cy;
    }
    uint16_t stairs=posxy((uint8_t)previousX,(uint8_t)previousY);
    /* Do not generate trivially short floors when rooms overlap. */
    if(distance_from_player(g,stairs)<8) {
        int bestDistance=0;
        for(uint16_t p=0;p<DG_MAP_CELLS;p++) {
            if(g->cells[p]!=DG_FLOOR)continue;
            int distance=distance_from_player(g,p);
            if(distance>bestDistance) {bestDistance=distance;stairs=p;}
        }
    }
    g->cells[stairs]=DG_STAIRS;
    uint8_t countEnemies=(uint8_t)(4+(g->floor<10?g->floor:10));
    if(countEnemies>DG_ENEMY_MAX) countEnemies=DG_ENEMY_MAX;
    for(uint8_t i=0;i<countEnemies;i++) {
        uint16_t p;
        if(!place(g,&p,5))break;
        uint8_t kind=(uint8_t)roll(g,(uint16_t)(g->floor<3?3:6));
        g->enemies[g->enemyCount++]=(DG_Enemy){p,(uint8_t)(2+kind+(g->floor/6>8?8:g->floor/6)),kind};
    }
    for(uint8_t i=0;i<7;i++) {
        uint16_t p;
        if(!place(g,&p,1))break;
        uint8_t k=(uint8_t)roll(g,8);
        DG_ItemKind type=k<3?DG_GOLD:k<5?DG_POTION:k<7?DG_WEAPON:DG_ARMOR;
        g->items[g->itemCount++]=(DG_Item){p,(uint8_t)type,(uint8_t)(1+roll(g,3))};
    }
    for(unsigned n=0;n<4;n++) {
        uint16_t p;
        if(place(g,&p,3))g->cells[p]=DG_TRAP;
    }
    g->message=DG_MSG_STAIRS;
    reveal(g);
}
void dg_start(DG_Game *g,uint32_t seed) {
    memset(g,0,sizeof(*g));
    g->rng=seed?seed:0x9e3779b9u;
    g->floor=1;g->level=1;
    g->maxHp=24;g->hp=24;g->attack=3;g->defense=0;g->potions=2;
    g->phase=DG_PLAYING;
    dg_generate_floor(g);
}
static void heal(DG_Game *g,uint8_t value) {
    unsigned hp=g->hp+value;
    g->hp=(uint8_t)(hp>g->maxHp?g->maxHp:hp);
}
static void player_damage(DG_Game *g,uint8_t damage) {
    if(damage==0)return;
    if(damage>=g->hp) {g->hp=0;g->phase=DG_DEAD;}
    else g->hp=(uint8_t)(g->hp-damage);
    g->message=DG_MSG_HURT;
}
static void add_score(DG_Game *g,uint16_t amount) {
    g->score=(uint32_t)(amount>UINT32_MAX-g->score?UINT32_MAX:g->score+amount);
}
static void award_xp(DG_Game *g,uint8_t kind) {
    if(g->xp<60000u) {
        uint16_t gain=(uint16_t)(2u+kind);
        g->xp=(uint16_t)(gain>60000u-g->xp?60000u:g->xp+gain);
    }
    add_score(g,(uint16_t)(10u+kind*3u));
    if(g->level<40 && g->xp >= (uint16_t)(g->level*12)) {
        g->xp=(uint16_t)(g->xp-g->level*12);
        g->level++;g->maxHp=(uint8_t)(g->maxHp<230?g->maxHp+2:g->maxHp);
        g->attack=(uint8_t)(g->attack<35?g->attack+1:g->attack);
        heal(g,6);g->message=DG_MSG_LEVEL;
    }
}
static void pickup(DG_Game *g) {
    int i=dg_item_at(g,g->position);
    if(i<0)return;
    DG_Item item=g->items[i];
    switch(item.kind) {
      case DG_POTION: if(g->potions<9)g->potions++;break;
      case DG_WEAPON: {
          uint8_t bonus=(uint8_t)(item.amount>2?2:item.amount);
          g->attack=(uint8_t)(bonus>35u-g->attack?35u:g->attack+bonus);
          break;
      }
      case DG_ARMOR: if(g->defense<12)g->defense++;break;
      case DG_GOLD:
          {
              uint16_t gain=(uint16_t)(item.amount*5u);
              g->gold=(uint16_t)(gain>UINT16_MAX-g->gold?UINT16_MAX:g->gold+gain);
              add_score(g,gain);
          }
          break;
    }
    g->items[i]=g->items[--g->itemCount];
    g->message=DG_MSG_LOOT;
}
static void attack_enemy(DG_Game *g,uint8_t i) {
    DG_Enemy *e=&g->enemies[i];
    uint8_t damage=(uint8_t)(1+g->attack/2+roll(g,(uint16_t)(g->attack+1)));
    g->message=DG_MSG_HIT;
    if(damage>=e->hp) {e->hp=0;award_xp(g,e->kind);}
    else e->hp-=damage;
}
static uint16_t neighbor(uint16_t p, DG_Action action) {
    int x=px(p),y=py(p);
    if(action==DG_NORTH) y--;
    if(action==DG_SOUTH) y++;
    if(action==DG_WEST) x--;
    if(action==DG_EAST) x++;
    if(x<0||x>=(int)DG_SIZE||y<0||y>=(int)DG_SIZE)return DG_MAP_CELLS;
    return posxy((uint8_t)x,(uint8_t)y);
}
static bool ray_clear(const DG_Game *g,uint16_t a,uint16_t b) {
    int x=px(a), y=py(a), tx=px(b), ty=py(b);
    if(x!=tx&&y!=ty)return false;
    while(x!=tx||y!=ty) {
        if(x<tx)x++; else if(x>tx)x--;
        if(y<ty)y++; else if(y>ty)y--;
        if(x==tx&&y==ty)break;
        if(!passable(g,posxy((uint8_t)x,(uint8_t)y)))return false;
    }
    return true;
}
static void enemies_turn(DG_Game *g) {
    for(uint8_t i=0;i<g->enemyCount&&g->phase==DG_PLAYING;i++) {
        DG_Enemy *e=&g->enemies[i];
        if(!e->hp)continue;
        int x=px(e->pos),y=py(e->pos);
        int dx=(int)px(g->position)-x,dy=(int)py(g->position)-y;
        int adx=dx<0?-dx:dx,ady=dy<0?-dy:dy;
        if(adx+ady>8)continue; /* dormant enemies avoid expensive global pathfinding */
        if((e->kind==0||e->kind==5) && ((g->turns+i)&1u))continue;
        if((adx+ady)==1 || (e->kind==4 && (adx+ady)<=4 && ray_clear(g,e->pos,g->position))) {
            uint8_t raw=(uint8_t)(1+e->kind/2+(g->floor>15?2:g->floor/8));
            uint8_t damage=(uint8_t)(raw>g->defense?raw-g->defense:1);
            player_damage(g,damage);
            if(g->phase==DG_PLAYING && e->kind==3 && roll(g,3)==0) {
                g->poison=3;g->message=DG_MSG_POISON;
            }
            continue;
        }
        DG_Action first,second;
        if(adx>=ady) {first=dx<0?DG_WEST:DG_EAST;second=dy<0?DG_NORTH:DG_SOUTH;}
        else {first=dy<0?DG_NORTH:DG_SOUTH;second=dx<0?DG_WEST:DG_EAST;}
        if(e->kind==2 && roll(g,2)==0) { DG_Action t=first;first=second;second=t; }
        uint16_t next=neighbor(e->pos,first);
        if(!passable(g,next) || next==g->position || dg_enemy_at(g,next)>=0)
            next=neighbor(e->pos,second);
        if(passable(g,next) && next!=g->position && dg_enemy_at(g,next)<0)e->pos=next;
    }
}
bool dg_action(DG_Game *g,DG_Action action) {
    if(g->phase!=DG_PLAYING || (unsigned)action>(unsigned)DG_HEAL)return false;
    if(action==DG_HEAL) {
        if(!g->potions||g->hp==g->maxHp)return false;
        g->potions--;heal(g,10);g->message=DG_MSG_HEAL;
    } else if(action!=DG_WAIT) {
        uint16_t target=neighbor(g->position,action);
        if(!passable(g,target)) {g->message=DG_MSG_BLOCKED;return false;}
        int enemy=dg_enemy_at(g,target);
        if(enemy>=0)attack_enemy(g,(uint8_t)enemy);
        else {
            g->position=target;
            pickup(g);
            if(g->cells[target]==DG_STAIRS) {
                if(g->floor<65535)g->floor++;
                dg_generate_floor(g);
                return true; /* enemies on a new floor do not move immediately */
            }
            if(g->cells[target]==DG_TRAP) {
                g->cells[target]=DG_FLOOR;
                player_damage(g,(uint8_t)(2+roll(g,3)));
            }
        }
    }
    /* This counter also controls alternating enemy turns: wrapping is essential. */
    g->turns++;
    if(g->phase==DG_PLAYING) {
        if(g->poison && (g->turns%2u)==0) {
            g->poison--;
            player_damage(g,1);
        }
        if(g->phase==DG_PLAYING)enemies_turn(g);
        reveal(g);
    }
    return true;
}
/* Host-testable BFS; excluded from firmware to protect stack and flash. */
#if defined(DG_NATIVE_TEST)
bool dg_floor_reachable(const DG_Game *g) {
    uint8_t seen[DG_SEEN_BYTES]={0};
    uint16_t queue[DG_MAP_CELLS];
    unsigned front=0,back=0;
    if(!passable(g,g->position))return false;
    queue[back++]=g->position;
    seen[g->position>>3]|=(uint8_t)(1u<<(g->position&7u));
    while(front<back) {
        uint16_t p=queue[front++];
        if(g->cells[p]==DG_STAIRS)return true;
        for(DG_Action dir=DG_NORTH;dir<=DG_EAST;dir=(DG_Action)(dir+1)) {
            uint16_t n=neighbor(p,dir);
            if(!passable(g,n) || (seen[n>>3] & (1u<<(n&7u))))continue;
            seen[n>>3]|=(uint8_t)(1u<<(n&7u));queue[back++]=n;
        }
    }
    return false;
}
#endif /* DG_NATIVE_TEST */

#endif /* GC01_DUNGEON || DG_NATIVE_TEST */
