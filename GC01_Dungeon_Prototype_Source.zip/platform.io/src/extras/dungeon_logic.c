#include "dungeon_logic.h"
#if defined(GC01_DUNGEON) || defined(DG_NATIVE_TEST)
#include <string.h>

/* All random choices are game-local and reproducible. Never consume USB RNG. */
static uint32_t rnd(DG_Game *g) {
    uint32_t x=g->rng;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return g->rng=x;
}
static uint16_t roll(DG_Game *g, uint16_t n) { return (uint16_t)(rnd(g)%n); }
static uint16_t posxy(uint8_t x,uint8_t y) { return (uint16_t)(y*DG_SIZE+x); }
static uint8_t px(uint16_t pos) { return (uint8_t)(pos%DG_SIZE); }
static uint8_t py(uint16_t pos) { return (uint8_t)(pos/DG_SIZE); }
static void seen_set(DG_Game *g, uint16_t p) {
    uint8_t mask=(uint8_t)(1u<<(p&7u));
    g->seen[p>>3]|=mask;g->visible[p>>3]|=mask;
}
bool dg_seen(const DG_Game *g, uint16_t p) {
    return p<DG_MAP_CELLS && (g->seen[p>>3] & (1u << (p&7u)))!=0;
}
bool dg_visible(const DG_Game *g, uint16_t p) {
    return p<DG_MAP_CELLS && (g->visible[p>>3] & (1u << (p&7u)))!=0;
}
static bool passable(const DG_Game *g,uint16_t p) {
    return p<DG_MAP_CELLS && g->cells[p]!=DG_WALL;
}
int dg_enemy_at(const DG_Game *g,uint16_t p) {
    for(uint8_t i=0;i<g->enemyCount;i++) if(g->enemies[i].hp && g->enemies[i].pos==p) return i;
    return -1;
}
int dg_item_at(const DG_Game *g,uint16_t p) {
    for(uint8_t i=0;i<g->itemCount;i++) if(g->items[i].pos==p) return i;
    return -1;
}
/* Small line-of-sight check; walls are visible but block anything behind them. */
static bool can_see(const DG_Game *g,int x,int y,int tx,int ty) {
    int dx=tx-x,dy=ty-y;
    int ax=dx<0?-dx:dx,ay=dy<0?-dy:dy;
    int sx=dx<0?-1:1,sy=dy<0?-1:1;
    int error=ax-ay;
    while(x!=tx || y!=ty) {
        int step=error*2;
        if(step>-ay){error-=ay;x+=sx;}
        if(step<ax){error+=ax;y+=sy;}
        if(x==tx && y==ty)break;
        if(g->cells[posxy((uint8_t)x,(uint8_t)y)]==DG_WALL)return false;
    }
    return true;
}
static void reveal(DG_Game *g) {
    memset(g->visible,0,sizeof(g->visible));
    int x=px(g->position),y=py(g->position);
    for(int dy=-5;dy<=5;dy++) for(int dx=-5;dx<=5;dx++) {
        int nx=x+dx,ny=y+dy;
        if(nx>0&&ny>0&&nx<(int)DG_SIZE-1&&ny<(int)DG_SIZE-1 &&
           dx*dx+dy*dy<=32 && can_see(g,x,y,nx,ny))
            seen_set(g,posxy((uint8_t)nx,(uint8_t)ny));
    }
}
static void carve(DG_Game *g,int x,int y) {
    if(x>0&&y>0&&x<(int)DG_SIZE-1&&y<(int)DG_SIZE-1)
        g->cells[posxy((uint8_t)x,(uint8_t)y)]=DG_FLOOR;
}
static void hall(DG_Game *g,int x,int y,int tx,int ty) {
    while(x!=tx) {carve(g,x,y);x+=x<tx?1:-1;}
    while(y!=ty) {carve(g,x,y);y+=y<ty?1:-1;}
    carve(g,x,y);
}
static uint8_t distance_from_player(const DG_Game *g,uint16_t p) {
    int dx=(int)px(p)-(int)px(g->position);
    int dy=(int)py(p)-(int)py(g->position);
    if(dx<0)dx=-dx;
    if(dy<0)dy=-dy;
    return (uint8_t)(dx+dy);
}
static bool place(DG_Game *g,uint16_t *out,uint8_t minDistance) {
    for(unsigned tries=0;tries<160;tries++) {
        uint8_t x=(uint8_t)(1+roll(g,DG_SIZE-2));
        uint8_t y=(uint8_t)(1+roll(g,DG_SIZE-2));
        uint16_t p=posxy(x,y);
        if(g->cells[p]!=DG_FLOOR || distance_from_player(g,p)<minDistance ||
           dg_enemy_at(g,p)>=0 || dg_item_at(g,p)>=0) continue;
        *out=p;return true;
    }
    /* A bounded sequential fallback makes very crowded floors still valid. */
    for(uint16_t p=0;p<DG_MAP_CELLS;p++) {
        if(g->cells[p]==DG_FLOOR&&distance_from_player(g,p)>=minDistance&&
           dg_enemy_at(g,p)<0&&dg_item_at(g,p)<0) {
            *out=p;return true;
        }
    }
    return false;
}
void dg_generate_floor(DG_Game *g) {
    memset(g->cells,0,sizeof(g->cells));
    memset(g->seen,0,sizeof(g->seen));
    memset(g->visible,0,sizeof(g->visible));
    g->enemyCount=0;g->itemCount=0;
    int previousX=0,previousY=0;
    uint8_t count=(uint8_t)(7+roll(g,4));
    for(uint8_t room=0;room<count;room++) {
        int w=3+roll(g,5),h=3+roll(g,5);
        int x=1+roll(g,(uint16_t)(DG_SIZE-w-2));
        int y=1+roll(g,(uint16_t)(DG_SIZE-h-2));
        for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++)carve(g,xx,yy);
        int cx=x+w/2, cy=y+h/2;
        if(room==0) g->position=posxy((uint8_t)cx,(uint8_t)cy);
        else if(roll(g,2)) {hall(g,previousX,previousY,cx,previousY);hall(g,cx,previousY,cx,cy);}
        else {hall(g,previousX,previousY,previousX,cy);hall(g,previousX,cy,cx,cy);}
        previousX=cx;previousY=cy;
    }
    uint16_t stairs=posxy((uint8_t)previousX,(uint8_t)previousY);
    /* Do not generate trivially short floors when rooms overlap. */
    if(distance_from_player(g,stairs)<8) {
        int bestDistance=0;
        for(uint16_t p=0;p<DG_MAP_CELLS;p++) {
            if(g->cells[p]!=DG_FLOOR)continue;
            int distance=distance_from_player(g,p);
            if(distance>bestDistance) {bestDistance=distance;stairs=p;}
        }
    }
    g->cells[stairs]=DG_STAIRS;
    uint8_t countEnemies=(uint8_t)(4+(g->floor<10?g->floor:10));
    if(countEnemies>DG_ENEMY_MAX) countEnemies=DG_ENEMY_MAX;
    for(uint8_t i=0;i<countEnemies;i++) {
        uint16_t p;
        if(!place(g,&p,5))break;
        uint8_t kind=(uint8_t)roll(g,(uint16_t)(g->floor<3?3:6));
        uint16_t scaled=(uint16_t)(g->floor/4);
        if(scaled>24)scaled=24;
        g->enemies[g->enemyCount++]=(DG_Enemy){p,(uint8_t)(2+kind+scaled),kind};
    }
    /* Every fifth floor has a distinct, far-away guardian. Defeat it to descend. */
    if(g->floor%5u==0 && g->enemyCount) {
        uint8_t far=0;
        for(uint8_t i=1;i<g->enemyCount;i++)
            if(distance_from_player(g,g->enemies[i].pos)>
               distance_from_player(g,g->enemies[far].pos))far=i;
        DG_Enemy *boss=&g->enemies[far];
        uint16_t scaled=(uint16_t)(g->floor/2);
        if(scaled>34)scaled=34;
        boss->kind=6;boss->hp=(uint8_t)(17+scaled);
    }
    for(uint8_t i=0;i<7;i++) {
        uint16_t p;
        if(!place(g,&p,1))break;
        uint8_t k=(uint8_t)roll(g,8);
        DG_ItemKind type=k<3?DG_GOLD:k<5?DG_POTION:k<7?DG_WEAPON:DG_ARMOR;
        g->items[g->itemCount++]=(DG_Item){p,(uint8_t)type,(uint8_t)(1+roll(g,3))};
    }
    for(unsigned n=0;n<4;n++) {
        uint16_t p;
        if(place(g,&p,3))g->cells[p]=DG_TRAP;
    }
    /* Optional risk/reward encounter; only placed on even-numbered floors. */
    if((g->floor&1u)==0u) {
        uint16_t p;
        if(place(g,&p,6))g->cells[p]=DG_SHRINE;
    }
    g->message=DG_MSG_STAIRS;
    reveal(g);
}
void dg_start(DG_Game *g,uint32_t seed) {
    memset(g,0,sizeof(*g));
    g->rng=seed?seed:0x9e3779b9u;
    g->floor=1;g->level=1;
    g->maxHp=24;g->hp=24;g->attack=3;g->defense=0;g->potions=2;
    g->weapon=DG_SWORD;g->arrows=4;g->stunnedEnemy=0xff;
    g->phase=DG_PLAYING;
    dg_generate_floor(g);
}
static void heal(DG_Game *g,uint8_t value) {
    unsigned hp=g->hp+value;
    g->hp=(uint8_t)(hp>g->maxHp?g->maxHp:hp);
}
static void player_damage(DG_Game *g,uint8_t damage,bool defendable) {
    if(damage==0)return;
    if(defendable && g->guard) {
        damage=damage>3?(uint8_t)(damage-3):1;
        g->riposte=1;
    }
    if(damage>=g->hp) {g->hp=0;g->phase=DG_DEAD;}
    else g->hp=(uint8_t)(g->hp-damage);
    g->message=DG_MSG_HURT;
}
static void add_score(DG_Game *g,uint16_t amount) {
    g->score=(uint32_t)(amount>UINT32_MAX-g->score?UINT32_MAX:g->score+amount);
}
static void award_xp(DG_Game *g,uint8_t kind) {
    if(g->xp<60000u) {
        uint16_t gain=(uint16_t)(2u+kind);
        g->xp=(uint16_t)(gain>60000u-g->xp?60000u:g->xp+gain);
    }
    add_score(g,(uint16_t)(10u+kind*3u));
    if(g->level<40 && g->xp >= (uint16_t)(g->level*12)) {
        g->xp=(uint16_t)(g->xp-g->level*12);
        g->level++;
        g->phase=DG_LEVELUP;g->menuChoice=0;
        g->message=DG_MSG_LEVEL;
    }
}
bool dg_choose_upgrade(DG_Game *g,uint8_t choice) {
    if(g->phase!=DG_LEVELUP || choice>2)return false;
    if(choice==0) { /* sturdy: more max health and recovery */
        if(g->maxHp<=226)g->maxHp=(uint8_t)(g->maxHp+4);
        heal(g,8);
    } else if(choice==1) { /* power: stronger attacks */
        if(g->attack<35)g->attack=(uint8_t)(g->attack+1);
        else heal(g,8);
    } else { /* armor: reduces damage from later enemies */
        if(g->defense<12)g->defense++;
        else heal(g,8);
    }
    g->phase=DG_PLAYING;g->message=DG_MSG_LEVEL;
    return true;
}
bool dg_choose_weapon(DG_Game *g,uint8_t equip) {
    if(g->phase!=DG_EQUIP || equip>1)return false;
    if(equip) {
        g->weapon=g->pendingWeapon;
        if(g->weapon==DG_BOW)g->arrows=9;
        if(g->attack<35)g->attack++;
    }
    g->pendingWeapon=0;g->phase=DG_PLAYING;
    g->message=DG_MSG_LOOT;
    return true;
}
static void shrine(DG_Game *g) {
    uint8_t result=(uint8_t)roll(g,4);
    if(result==0)heal(g,8);
    else if(result==1) {
        if(g->potions<9)g->potions++;
    } else if(result==2) {
        if(g->maxHp<=228)g->maxHp=(uint8_t)(g->maxHp+2);
        heal(g,2);
    } else {player_damage(g,4,false);g->message=DG_MSG_CURSE;return;}
    g->message=DG_MSG_BLESS;
}
static void pickup(DG_Game *g) {
    int i=dg_item_at(g,g->position);
    if(i<0)return;
    DG_Item item=g->items[i];
    switch(item.kind) {
      case DG_POTION: if(g->potions<9)g->potions++;break;
      case DG_WEAPON:
          g->pendingWeapon=(uint8_t)(1+(item.amount-1)%3);
          g->phase=DG_EQUIP;g->menuChoice=1;
          break;
      case DG_ARMOR: if(g->defense<12)g->defense++;break;
      case DG_GOLD:
          {
              uint16_t gain=(uint16_t)(item.amount*5u);
              g->gold=(uint16_t)(gain>UINT16_MAX-g->gold?UINT16_MAX:g->gold+gain);
              add_score(g,gain);
          }
          break;
    }
    g->items[i]=g->items[--g->itemCount];
    g->message=DG_MSG_LOOT;
}
static void attack_enemy(DG_Game *g,uint8_t i,bool ranged) {
    DG_Enemy *e=&g->enemies[i];
    uint8_t damage;
    uint16_t spread=(uint16_t)(g->attack/2+1);
    if(ranged) damage=(uint8_t)(2+g->attack/2+roll(g,spread));
    else if(g->weapon==DG_DAGGER) {
        damage=(uint8_t)(1+g->attack/3+roll(g,spread));
        if(roll(g,4)==0)damage=(uint8_t)(damage*2u);
    } else if(g->weapon==DG_AXE) {
        damage=(uint8_t)(3+g->attack/2+roll(g,spread));
        if(roll(g,3)==0)g->stunnedEnemy=i;
    } else if(g->weapon==DG_BOW) {
        damage=(uint8_t)(1+g->attack/3+roll(g,spread));
    } else damage=(uint8_t)(1+g->attack/2+roll(g,spread));
    if(g->riposte && !ranged) {
        damage=(uint8_t)(damage+4u);
        g->riposte=0;g->message=DG_MSG_COUNTER;
    } else g->message=ranged?DG_MSG_SHOT:DG_MSG_HIT;
    if(damage>=e->hp) {e->hp=0;award_xp(g,e->kind);}
    else e->hp-=damage;
}
static uint16_t neighbor(uint16_t p, DG_Action action) {
    int x=px(p),y=py(p);
    if(action==DG_NORTH) y--;
    if(action==DG_SOUTH) y++;
    if(action==DG_WEST) x--;
    if(action==DG_EAST) x++;
    if(x<0||x>=(int)DG_SIZE||y<0||y>=(int)DG_SIZE)return DG_MAP_CELLS;
    return posxy((uint8_t)x,(uint8_t)y);
}
static bool ray_clear(const DG_Game *g,uint16_t a,uint16_t b) {
    int x=px(a), y=py(a), tx=px(b), ty=py(b);
    if(x!=tx&&y!=ty)return false;
    while(x!=tx||y!=ty) {
        if(x<tx)x++; else if(x>tx)x--;
        if(y<ty)y++; else if(y>ty)y--;
        if(x==tx&&y==ty)break;
        if(!passable(g,posxy((uint8_t)x,(uint8_t)y)))return false;
    }
    return true;
}
static void enemies_turn(DG_Game *g) {
    for(uint8_t i=0;i<g->enemyCount&&g->phase==DG_PLAYING;i++) {
        DG_Enemy *e=&g->enemies[i];
        if(!e->hp || i==g->stunnedEnemy)continue;
        int x=px(e->pos),y=py(e->pos);
        int dx=(int)px(g->position)-x,dy=(int)py(g->position)-y;
        int adx=dx<0?-dx:dx,ady=dy<0?-dy:dy;
        unsigned distance=(unsigned)(adx+ady);
        if(distance>8)continue;
        if((e->kind==0||e->kind==5) && ((g->turns+i)&1u))continue;
        /* A boss signals its powerful strike one turn beforehand. */
        if(e->kind==6 && ((g->turns+i)&3u)==2u && distance<=3) {
            g->message=DG_MSG_BOSS;continue;
        }
        bool ranged=e->kind==4 && distance<=5 && ray_clear(g,e->pos,g->position);
        if(distance==1 || ranged || (e->kind==6 && distance<=2 &&
                                        ((g->turns+i)&3u)==3u && ray_clear(g,e->pos,g->position))) {
            unsigned scaled=g->floor/5u;
            if(scaled>17u)scaled=17u;
            unsigned raw=1u+e->kind/2u+scaled;
            if(e->kind==6 && ((g->turns+i)&3u)==3u)raw+=3;
            uint8_t damage=(uint8_t)(raw>g->defense?raw-g->defense:1u);
            player_damage(g,damage,true);
            if(g->phase==DG_PLAYING && e->kind==3 && roll(g,3)==0) {
                g->poison=3;g->message=DG_MSG_POISON;
            }
            continue;
        }
        DG_Action first,second;
        if(adx>=ady) {first=dx<0?DG_WEST:DG_EAST;second=dy<0?DG_NORTH:DG_SOUTH;}
        else {first=dy<0?DG_NORTH:DG_SOUTH;second=dx<0?DG_WEST:DG_EAST;}
        if(e->kind==2 && roll(g,2)==0) { DG_Action t=first;first=second;second=t; }
        /* Archers retreat when pressured rather than volunteering for melee. */
        if(e->kind==4 && distance<=2) {
            first=(first==DG_NORTH)?DG_SOUTH:(first==DG_SOUTH)?DG_NORTH:
                  (first==DG_EAST)?DG_WEST:DG_EAST;
            second=(second==DG_NORTH)?DG_SOUTH:(second==DG_SOUTH)?DG_NORTH:
                   (second==DG_EAST)?DG_WEST:DG_EAST;
        }
        uint16_t next=neighbor(e->pos,first);
        if(!passable(g,next) || next==g->position || dg_enemy_at(g,next)>=0)
            next=neighbor(e->pos,second);
        if(passable(g,next) && next!=g->position && dg_enemy_at(g,next)<0)e->pos=next;
    }
    g->stunnedEnemy=0xff;
    g->guard=0;
}
static bool boss_alive(const DG_Game *g) {
    for(uint8_t i=0;i<g->enemyCount;i++)
        if(g->enemies[i].hp && g->enemies[i].kind==6)return true;
    return false;
}
static bool shoot(DG_Game *g,DG_Action direction) {
    if(g->weapon!=DG_BOW || !g->arrows) {
        g->message=DG_MSG_MISS;return false;
    }
    g->arrows--;
    uint16_t pos=g->position;
    for(uint8_t step=0;step<5;step++) {
        pos=neighbor(pos,(DG_Action)(direction-DG_SHOOT_NORTH));
        if(!passable(g,pos))break;
        int e=dg_enemy_at(g,pos);
        if(e>=0){attack_enemy(g,(uint8_t)e,true);return true;}
    }
    g->message=DG_MSG_MISS;
    return true;
}
bool dg_action(DG_Game *g,DG_Action action) {
    if(g->phase!=DG_PLAYING || (unsigned)action>(unsigned)DG_SHOOT_EAST)return false;
    if(action>=DG_SHOOT_NORTH) {
        if(!shoot(g,action))return false;
    } else if(action==DG_GUARD) {
        g->guard=1;g->message=DG_MSG_GUARD;
    } else if(action==DG_HEAL) {
        if(!g->potions||g->hp==g->maxHp)return false;
        g->potions--;heal(g,10);g->message=DG_MSG_HEAL;
    } else if(action!=DG_WAIT) {
        uint16_t target=neighbor(g->position,action);
        if(!passable(g,target)) {g->message=DG_MSG_BLOCKED;return false;}
        int enemy=dg_enemy_at(g,target);
        if(enemy>=0)attack_enemy(g,(uint8_t)enemy,false);
        else {
            if(g->cells[target]==DG_STAIRS && boss_alive(g)) {
                g->message=DG_MSG_LOCKED;return false;
            }
            g->position=target;
            pickup(g);
            if(g->cells[target]==DG_STAIRS) {
                if(g->floor<65535)g->floor++;
                dg_generate_floor(g);
                return true; /* enemies on a new floor do not move immediately */
            }
            if(g->cells[target]==DG_TRAP) {
                g->cells[target]=DG_FLOOR;
                player_damage(g,(uint8_t)(2+roll(g,3)),false);
            } else if(g->cells[target]==DG_SHRINE) {
                g->cells[target]=DG_FLOOR;shrine(g);
            }
        }
    }
    /* This counter also controls alternating enemy turns: wrapping is essential. */
    g->turns++;
    if(g->phase==DG_PLAYING) {
        if(g->poison && (g->turns%2u)==0) {
            g->poison--;
            player_damage(g,1,false);
        }
        if(g->phase==DG_PLAYING)enemies_turn(g);
        reveal(g);
    }
    return true;
}
/* Host-testable BFS; excluded from firmware to protect stack and flash. */
#if defined(DG_NATIVE_TEST)
bool dg_floor_reachable(const DG_Game *g) {
    uint8_t seen[DG_SEEN_BYTES]={0};
    uint16_t queue[DG_MAP_CELLS];
    unsigned front=0,back=0;
    if(!passable(g,g->position))return false;
    queue[back++]=g->position;
    seen[g->position>>3]|=(uint8_t)(1u<<(g->position&7u));
    while(front<back) {
        uint16_t p=queue[front++];
        if(g->cells[p]==DG_STAIRS)return true;
        for(DG_Action dir=DG_NORTH;dir<=DG_EAST;dir=(DG_Action)(dir+1)) {
            uint16_t n=neighbor(p,dir);
            if(!passable(g,n) || (seen[n>>3] & (1u<<(n&7u))))continue;
            seen[n>>3]|=(uint8_t)(1u<<(n&7u));queue[back++]=n;
        }
    }
    return false;
}
#endif /* DG_NATIVE_TEST */

#endif /* GC01_DUNGEON || DG_NATIVE_TEST */
