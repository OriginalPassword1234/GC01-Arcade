/* GC-01 Dungeon Edition: isolates the game from Rad Pro measurement code. */
#if defined(GC01_DUNGEON)
#include <stdbool.h>
#include <stdint.h>
#include "dungeon_logic.h"
#include "game.h"
#include "../measurements/measurements.h"
#include "../peripherals/keyboard.h"
#include "../system/events.h"
#include "../system/power.h"
#include "../system/settings.h"
#include "../ui/dungeon_draw.h"
#include "../ui/menu.h"
#include "../ui/view.h"

static DG_Game dungeon;
static bool hasGame,active,needsFullRedraw,aiming;
static MenuState dungeonMenuState;
static const Menu dungeonMenu;
static void showDungeon(void);

static void leaveDungeon(void) {
    active=false;aiming=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showGameMenu();
}
static void applyAction(DG_Action action) {
    (void)dg_action(&dungeon,action);
    requestViewUpdate(); /* Also update the HUD for rejected moves. */
}
static void onDungeonEvent(ViewEvent event) {
    if(event==EVENT_DRAW) {
        drawDungeon(&dungeon,needsFullRedraw);
        needsFullRedraw=false;
        return;
    }
    if(event==EVENT_KEY_GAME_EXIT) return; /* Long-Left must never exit the game. */
    if(event==EVENT_KEY_GAME_OK) {
        if(aiming) {aiming=false;dungeon.message=DG_MSG_NONE;requestViewUpdate();return;}
        if(dungeon.phase==DG_DEAD) {
            dg_start(&dungeon,currentTick^0x617b8d2au);
            aiming=false;needsFullRedraw=true;
        } else if(dungeon.phase==DG_LEVELUP) {
            (void)dg_choose_upgrade(&dungeon,dungeon.menuChoice);
        } else if(dungeon.phase==DG_EQUIP) {
            (void)dg_choose_weapon(&dungeon,dungeon.menuChoice);
        } else if(dungeon.phase==DG_PLAYING) {
            dungeon.phase=DG_PAUSED;
            dungeon.menuChoice=0;
        } else {
            switch(dungeon.menuChoice) {
              case 0: dungeon.phase=DG_PLAYING;break;
              case 1: dungeon.phase=DG_PLAYING;
                      if(!dg_action(&dungeon,DG_HEAL))dungeon.phase=DG_PAUSED;
                      break;
              case 2: dungeon.phase=DG_PLAYING;applyAction(DG_GUARD);break;
              case 3: dungeon.phase=DG_PLAYING;aiming=true;
                      dungeon.message=DG_MSG_AIM;break;
              case 4: dungeon.phase=DG_PLAYING;applyAction(DG_WAIT);break;
              case 5: leaveDungeon();return;
            }
        }
        requestViewUpdate();return;
    }
    if(dungeon.phase==DG_PAUSED || dungeon.phase==DG_LEVELUP || dungeon.phase==DG_EQUIP) {
        uint8_t count=(uint8_t)(dungeon.phase==DG_LEVELUP?3:
                                dungeon.phase==DG_EQUIP?2:6);
        if(event==EVENT_KEY_GAME_UP) {
            dungeon.menuChoice=(uint8_t)((dungeon.menuChoice+count-1)%count);
            requestViewUpdate();
        }
        if(event==EVENT_KEY_GAME_DOWN) {
            dungeon.menuChoice=(uint8_t)((dungeon.menuChoice+1)%count);
            requestViewUpdate();
        }
        return;
    }
    if(dungeon.phase!=DG_PLAYING)return;
    if(aiming) {
        DG_Action shot;
        switch(event) {
          case EVENT_KEY_GAME_UP:shot=DG_SHOOT_NORTH;break;
          case EVENT_KEY_GAME_DOWN:shot=DG_SHOOT_SOUTH;break;
          case EVENT_KEY_GAME_LEFT:shot=DG_SHOOT_WEST;break;
          case EVENT_KEY_GAME_RIGHT:shot=DG_SHOOT_EAST;break;
          default:return;
        }
        aiming=false;applyAction(shot);return;
    }
    switch(event) {
      case EVENT_KEY_GAME_UP: applyAction(DG_NORTH);break;
      case EVENT_KEY_GAME_DOWN:applyAction(DG_SOUTH);break;
      case EVENT_KEY_GAME_LEFT:applyAction(DG_WEST);break;
      case EVENT_KEY_GAME_RIGHT:applyAction(DG_EAST);break;
      default:break;
    }
}
static const char *getDungeonOption(menu_size_t index,MenuStyle *style) {
    *style=MENUSTYLE_SUBMENU;
    return index==0?"New dungeon":hasGame?"Continue":"Continue (unavailable)";
}
static void selectDungeonOption(menu_size_t index) {
    if(index==0) {dg_start(&dungeon,currentTick^0xb13e64e5u);hasGame=true;aiming=false;}
    else if(!hasGame)return;
    showDungeon();
}
static const Menu dungeonMenu={
    STRING_GAME,&dungeonMenuState,2,getDungeonOption,selectDungeonOption,showSettingsMenu
};
static void showDungeon(void) {
    active=true;needsFullRedraw=true;
    setKeyboardMode(KEYBOARD_MODE_GAME);
    showView(onDungeonEvent);
}
void resetGame(void) {
    active=false;hasGame=false;aiming=false;needsFullRedraw=true;
    selectMenuItem(&dungeonMenu,0);
}
void showGameMenu(void) {
    if(isKeyboardGameMode())setKeyboardMode(KEYBOARD_MODE_MENU);
    active=false;aiming=false;
    showMenu(&dungeonMenu);
}
void updateGame(void) {
    if(!active)return;
    if(!isPoweredOn()||!isKeyboardGameMode()) {active=false;return;}
    if(getAlertLevel()!=ALERTLEVEL_NONE) {
        active=false;setMeasurementView();return;
    }
    if(!isCurrentView(onDungeonEvent)) {
        active=false;setKeyboardMode(KEYBOARD_MODE_MENU);return;
    }
    /* No timer-driven game updates: drawing cannot advance game state. */
}
#endif
