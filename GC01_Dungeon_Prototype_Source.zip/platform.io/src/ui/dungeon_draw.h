#ifndef GC01_DUNGEON_DRAW_H
#define GC01_DUNGEON_DRAW_H
#include "../extras/dungeon_logic.h"
void drawDungeon(const DG_Game *game, bool force);
#endif
