/* Dungeon Lite compact RGB565 graphics. No framebuffer or bitmap assets. */
#if defined(GC01_DUNGEON) || defined(DG_DRAW_NATIVE_TEST)
#include "dungeon_draw.h"
#include <string.h>
#if defined(DG_DRAW_NATIVE_TEST)
#include <stdio.h>
typedef uint16_t mr_color_t;
#define RGB(x) (((((x)>>16)&255u)>>3)<<11 | (((((x)>>8)&255u)>>2)<<5) | ((((x)&255u)>>3)))
extern unsigned dg_test_theme;
extern void dg_test_fill_rect(int x,int y,int w,int h,mr_color_t color);
#else
#include "draw.h"
#include "../system/settings.h"
#include "../system/cstring.h"
#define RGB(x) mr_get_color(x)
extern mr_t mr;
#endif
#define VIEW 15
#define TS 16
#define BOARD 240

typedef struct {
    mr_color_t wall, floor, shadow, text, accent, panel, edge;
    mr_color_t player, enemy, item, stairs, gold, danger;
} Palette;
static const Palette palettes[3]={
    {RGB(0x405c66),RGB(0x24353c),RGB(0x17272c),RGB(0x14323d),RGB(0x057870),RGB(0xdfeaec),RGB(0xa8bcc4), RGB(0x008f8c),RGB(0xbc5051),RGB(0x276f8f),RGB(0xa88432),RGB(0xc58e29),RGB(0xc25137)},
    {RGB(0x56606d),RGB(0x262b37),RGB(0x161923),RGB(0xd7e3ef),RGB(0x66cfb4),RGB(0x15212f),RGB(0x324559), RGB(0x79b9ef),RGB(0xe07f77),RGB(0x80d88f),RGB(0xb6a8ea),RGB(0xf2bf6a),RGB(0xe18a69)},
    {RGB(0x5a5340),RGB(0x29271f),RGB(0x181b14),RGB(0xefd7a1),RGB(0xd7b85f),RGB(0x1b2018),RGB(0x4b5941), RGB(0xb9d478),RGB(0xd48972),RGB(0x9eb68b),RGB(0xcdad74),RGB(0xc9a05f),RGB(0xcd735a)}
};
static int16_t camX,camY;
static uint16_t previous[VIEW*VIEW];
static uint8_t valid,previousPhase,previousTheme;
static uint16_t prevHud[7];
static uint32_t prevOverlayScore;
static uint8_t prevMsg,prevMenuChoice,overlayShown;
static void fill(int x,int y,int w,int h,mr_color_t color) {
    if(x<0 || y<0 || x+w>320 || y+h>240 || w<=0 || h<=0)return;
#if defined(DG_DRAW_NATIVE_TEST)
    dg_test_fill_rect(x,y,w,h,color);
#else
    mr_set_fill_color(&mr,color);
    drawRectangle(&(mr_rectangle_t){(int16_t)x,(int16_t)y,(int16_t)w,(int16_t)h});
#endif
}
/* Small uppercase glyphs reuse the design language of the original arcade. */
static const uint16_t digits[10]={0x7b6f,0x2c97,0x73e7,0x73cf,0x5bc9,0x79cf,0x79ef,0x7292,0x7bef,0x7bcf};
static const uint16_t letters[26]={0x2bed,0x6bae,0x3923,0x6b6e,0x79a7,0x79a4,0x396b,0x5bed,0x7497,0x126a,0x5bad,0x4927,0x5fed,0x5ffd,0x2b6a,0x6ba4,0x2b7b,0x6bad,0x388e,0x7492,0x5b6f,0x5b6a,0x5bfd,0x5aad,0x5a92,0x72a7};
static void text(const char *str,int x,int y,int scale,mr_color_t color) {
    while(*str) {
        char c=*str++;
        uint16_t bits=(c>='0'&&c<='9')?digits[c-'0']:(c>='A'&&c<='Z')?letters[c-'A']:0;
        for(int row=0;row<5;row++) for(int col=0;col<3;col++)
            if(bits & (1u << (14-(row*3+col))))
                fill(x+col*scale,y+row*scale,scale,scale,color);
        x+=4*scale;
    }
}
static void number(uint32_t n,int x,int y,int scale,mr_color_t color) {
    char str[12];
#if defined(DG_DRAW_NATIVE_TEST)
    (void)snprintf(str,sizeof(str),"%lu",(unsigned long)n);
#else
    strclr(str);strcatUInt32(str,n,0);
#endif
    text(str,x,y,scale,color);
}
static void tile(int x,int y,uint16_t token, const Palette *p) {
    mr_color_t base=p->floor;
    switch(token&0xffu) {
      case DG_WALL: base=p->wall;break;
      case DG_STAIRS:base=p->floor;break;
      case DG_TRAP:base=p->floor;break;
      default:break;
    }
    if(token==0xffffu) {fill(x,y,TS,TS,p->shadow);return;}
    if(token&0x8000u) {
        fill(x,y,TS,TS,p->shadow);
        if((token&0xffu)==DG_WALL)fill(x,y,TS,2,p->wall);
        return;
    }
    fill(x,y,TS,TS,base);
    if((token&0xff)==DG_WALL) {
        fill(x,y,TS,2,p->edge);fill(x+7,y+8,1,6,p->shadow);
    } else {
        fill(x+1,y+14,3,1,p->shadow);
        if((token&0xff)==DG_STAIRS) {
            fill(x+3,y+4,10,2,p->stairs);fill(x+5,y+7,8,2,p->stairs);fill(x+7,y+10,6,2,p->stairs);
        } else if((token&0xff)==DG_TRAP) {
            fill(x+5,y+5,6,6,p->danger);
        } else if((token&0xff)==DG_SHRINE) {
            fill(x+5,y+4,6,8,p->stairs);fill(x+3,y+8,10,2,p->accent);
        }
    }
    if(token&0x100u) { // player: head, armor and eyes
        fill(x+4,y+3,8,5,p->player); fill(x+3,y+9,10,5,p->accent);
        fill(x+5,y+5,2,1,p->shadow);fill(x+9,y+5,2,1,p->shadow);
    } else if(token&0x200u) { // enemy kinds use different readable silhouettes
        uint8_t kind=(token>>10)&7u;
        mr_color_t color=(kind==3||kind==0)?p->item:(kind==4)?p->gold:p->enemy;
        fill(x+3,y+5,10,8,color);fill(x+5,y+3,6,3,color);
        fill(x+5,y+7,2,1,p->shadow);fill(x+9,y+7,2,1,p->shadow);
        if(kind==5)fill(x+2,y+9,12,3,p->edge);
        if(kind==6) {fill(x+1,y+2,3,5,p->danger);fill(x+12,y+2,3,5,p->danger);}
    } else if(token&0x400u) {
        uint8_t kind=(token>>11)&7u;
        mr_color_t color=kind==DG_GOLD?p->gold:(kind==DG_POTION)?p->enemy:p->item;
        fill(x+5,y+4,6,9,color);fill(x+6,y+2,4,3,p->edge);
    }
}
static uint16_t appearance(const DG_Game *g,int x,int y) {
    if(x<0||y<0||x>=(int)DG_SIZE||y>=(int)DG_SIZE)return 0xffffu;
    uint16_t idx=(uint16_t)(y*DG_SIZE+x);
    if(!dg_seen(g,idx))return 0xffffu;
    uint16_t token=g->cells[idx];
    if(!dg_visible(g,idx))return token|0x8000u;
    if(g->position==idx)return token|0x100u;
    int e=dg_enemy_at(g,idx);
    if(e>=0) return token|0x200u|((uint16_t)g->enemies[e].kind<<10);
    int it=dg_item_at(g,idx);
    if(it>=0)return token|0x400u|((uint16_t)g->items[it].kind<<11);
    return token;
}
static const char *message(uint8_t m) {
    switch(m) {
      case DG_MSG_HIT:return "HIT";case DG_MSG_HURT:return "OUCH";
      case DG_MSG_LOOT:return "LOOT";case DG_MSG_STAIRS:return "NEW FLOOR";
      case DG_MSG_POISON:return "POISON";case DG_MSG_HEAL:return "HEALED";
      case DG_MSG_LEVEL:return "LEVEL UP";case DG_MSG_BLOCKED:return "WALL";
      case DG_MSG_GUARD:return "GUARD";case DG_MSG_AIM:return "AIM WITH DIR";
      case DG_MSG_SHOT:return "SHOT";case DG_MSG_MISS:return "NO SHOT";
      case DG_MSG_BOSS:return "BOSS WINDUP";case DG_MSG_LOCKED:return "BOSS FIRST";
      case DG_MSG_COUNTER:return "COUNTER";
      case DG_MSG_BLESS:return "BLESSING";
      case DG_MSG_CURSE:return "CURSE";
      default:return "DUNGEON";
    }
}
static void hudMessage(const DG_Game *g,const Palette *p) {
    fill(243,226,77,14,p->panel);
    text(message(g->message),245,229,1,p->accent);
}
static void hudHp(const DG_Game *g,const Palette *p) {
    fill(246,76,68,7,p->edge);
    int width=g->maxHp?(64*g->hp/g->maxHp):0;
    fill(248,77,width,5,g->hp<g->maxHp/3?p->enemy:p->item);
    fill(246,85,72,12,p->panel);
    number(g->hp,248,86,2,p->text);
}
static void hudValue(uint32_t value,int y,int scale,const Palette *p) {
    fill(246,y-1,73,scale*5+2,p->panel);
    number(value,248,y,scale,p->text);
}
static void hudWeapon(const DG_Game *g,const Palette *p) {
    fill(265,200,54,10,p->panel);
    const char *weapon[4]={"SWORD","DAG","AXE","BOW"};
    text(weapon[g->weapon<4?g->weapon:0],265,201,1,p->text);
    if(g->weapon==DG_BOW)number(g->arrows,296,201,1,p->gold);
}
static void hudGold(const DG_Game *g,const Palette *p) {
    fill(265,212,54,10,p->panel);
    number(g->gold,265,213,1,p->text);
}
static void hud(const DG_Game *g,const Palette *p) {
    fill(BOARD,0,80,240,p->panel);
    fill(BOARD,0,2,240,p->edge);
    text("DUNGEON",245,6,2,p->accent);
    text("FLOOR",248,27,2,p->text);hudValue(g->floor,40,2,p);
    text("HP",248,62,2,p->text);hudHp(g,p);
    text("LVL",248,107,2,p->text);hudValue(g->level,120,2,p);
    text("ATK",248,140,2,p->text);hudValue(g->attack,153,2,p);
    text("POT",248,172,2,p->text);hudValue(g->potions,185,2,p);
    text("WEAP",245,201,1,p->accent);hudWeapon(g,p);
    text("GOLD",245,213,1,p->gold);hudGold(g,p);
    hudMessage(g,p);
}
static void overlayChoice(const DG_Game *g,const Palette *p,uint8_t i,bool selected) {
    if(g->phase==DG_LEVELUP) {
        static const char *const choices[3]={"HEALTH","POWER","ARMOR"};
        if(i>=3)return;
        fill(40,91+i*26,150,22,selected?p->edge:p->panel);
        text(choices[i],47,96+i*26,2,p->text);
    } else if(g->phase==DG_EQUIP) {
        static const char *const choices[2]={"KEEP OLD","EQUIP"};
        if(i>=2)return;
        fill(40,131+i*26,150,22,selected?p->edge:p->panel);
        text(choices[i],47,136+i*26,2,p->text);
    } else {
        static const char *const choices[6]={"RESUME","POTION","GUARD","AIM","WAIT","EXIT"};
        if(i>=6)return;
        fill(40,85+i*18,150,17,selected?p->edge:p->panel);
        text(choices[i],47,88+i*18,2,p->text);
    }
}
static void overlay(const DG_Game *g,const Palette *p) {
    fill(26,40,190,160,p->panel);fill(26,40,190,2,p->accent);
    if(g->phase==DG_DEAD) {
        text("YOU DIED",42,60,3,p->enemy);
        text("SCORE",41,112,2,p->text);
        number(g->score,124,112,2,p->accent);
        text("OK RESTART",43,160,2,p->text);
        return;
    }
    if(g->phase==DG_LEVELUP) {
        text("LEVEL UP",40,52,3,p->accent);
        for(uint8_t i=0;i<3;i++)overlayChoice(g,p,i,g->menuChoice==i);
    } else if(g->phase==DG_EQUIP) {
        text("NEW WEAPON",40,52,2,p->accent);
        const char *weapon[4]={"SWORD","DAGGER","AXE","BOW"};
        text(weapon[g->pendingWeapon<4?g->pendingWeapon:0],47,88,3,p->text);
        for(uint8_t i=0;i<2;i++)overlayChoice(g,p,i,g->menuChoice==i);
    } else {
        text("PAUSED",40,52,3,p->accent);
        for(uint8_t i=0;i<6;i++)overlayChoice(g,p,i,g->menuChoice==i);
    }
}
void drawDungeon(const DG_Game *g,bool force) {
    if(!g)return;
#if defined(DG_DRAW_NATIVE_TEST)
    uint8_t theme=(uint8_t)dg_test_theme;
#else
    uint8_t theme=(uint8_t)settings.displayTheme;
#endif
    if(theme>=3)theme=1;
    const Palette *p=&palettes[theme];
    if(previousTheme!=theme)force=true;
    /* The old pause overlay must be erased on return to gameplay. */
    if(overlayShown && g->phase==DG_PLAYING)force=true;
    int x=(int)(g->position%DG_SIZE),y=(int)(g->position/DG_SIZE);
    if(!valid || force) {
        camX=(int16_t)(x-7);camY=(int16_t)(y-7);
    } else {
        if(x<camX+3)camX=(int16_t)(x-5);
        if(x>camX+11)camX=(int16_t)(x-9);
        if(y<camY+3)camY=(int16_t)(y-5);
        if(y>camY+11)camY=(int16_t)(y-9);
    }
    if(camX<0)camX=0;
    if(camY<0)camY=0;
    if(camX>(int)DG_SIZE-VIEW)camX=DG_SIZE-VIEW;
    if(camY>(int)DG_SIZE-VIEW)camY=DG_SIZE-VIEW;
    static int16_t prevCamX,prevCamY;
    if(camX!=prevCamX||camY!=prevCamY)force=true;
    prevCamX=camX;prevCamY=camY;
    if(force||!valid)memset(previous,0xff,sizeof(previous));
    for(int sy=0;sy<VIEW;sy++) for(int sx=0;sx<VIEW;sx++) {
        int i=sy*VIEW+sx;
        uint16_t appearanceNow=appearance(g,camX+sx,camY+sy);
        if(force||!valid||appearanceNow!=previous[i])tile(sx*TS,sy*TS,appearanceNow,p);
        previous[i]=appearanceNow;
    }
    /* Turns and score aren't displayed in the HUD: don't repaint it every turn. */
    const uint16_t newHud[7]={g->floor,g->hp,g->maxHp,g->level,
                              (uint16_t)(g->attack|((uint16_t)g->weapon<<8)),
                              (uint16_t)(g->potions|((uint16_t)g->arrows<<8)),g->gold};
    if(!valid||force||newHud[0]!=prevHud[0])hud(g,p);
    else {
        if(newHud[1]!=prevHud[1]||newHud[2]!=prevHud[2])hudHp(g,p);
        if(newHud[3]!=prevHud[3])hudValue(g->level,120,2,p);
        if(newHud[4]!=prevHud[4]){
            hudValue(g->attack,153,2,p);hudWeapon(g,p);
        } else if((newHud[5]>>8)!=(prevHud[5]>>8))hudWeapon(g,p);
        if((newHud[5]&255u)!=(prevHud[5]&255u))hudValue(g->potions,185,2,p);
        if(newHud[6]!=prevHud[6])hudGold(g,p);
        if(prevMsg!=g->message)hudMessage(g,p);
    }
    memcpy(prevHud,newHud,sizeof(prevHud));prevMsg=g->message;
    valid=1;
    if(g->phase!=DG_PLAYING) {
        if(!force && overlayShown && previousPhase==g->phase &&
           g->phase!=DG_DEAD && prevMenuChoice!=g->menuChoice) {
            overlayChoice(g,p,prevMenuChoice,false);
            overlayChoice(g,p,g->menuChoice,true);
        } else if(force||!overlayShown||previousPhase!=g->phase||
                  (g->phase==DG_DEAD && prevOverlayScore!=g->score))
            overlay(g,p);
        overlayShown=1;
    } else overlayShown=0;
    previousPhase=g->phase;previousTheme=theme;
    prevMenuChoice=g->menuChoice;prevOverlayScore=g->score;
}
#endif

#if defined(DG_DRAW_NATIVE_TEST)
/* Independent full-frame reference using the same exact sprite operations.
 * This bypasses the optimized tile/HUD caches and keeps camera position. */
void dg_test_reference_frame(const DG_Game *g) {
    uint8_t theme=(uint8_t)dg_test_theme;
    if(theme>=3) theme=1;
    const Palette *p=&palettes[theme];
    for(int sy=0;sy<VIEW;sy++) for(int sx=0;sx<VIEW;sx++)
        tile(sx*TS,sy*TS,appearance(g,camX+sx,camY+sy),p);
    hud(g,p);
    if(g->phase!=DG_PLAYING)overlay(g,p);
}
#endif
