# GC-01 Dungeon Edition — Gameplay Upgrade 0.3 (SOURCE ONLY)

**EXPERIMENTAL. NOT FLASHABLE. DO NOT INSTALL THE ZIP OR RAW `firmware.bin`.**

Target: FNIRSI GC-01 / APM32F103RBT6 / English Rad Pro **3.1.1**,
`fnirsi-gc01_apm32f103rb-en`. This is a source overlay for the original Rad Pro
3.1.1 tree, not a complete source distribution or installable firmware.

## New since the audited 0.2 prototype

- Distinct weapon playstyles: balanced sword, critical-hit dagger, heavy axe
  with occasional stagger, and limited-ammunition bow with aimed shots.
- Weapon pickups offer **KEEP OLD / EQUIP**; no forced loss of a preferred build.
- Level-ups offer **HEALTH / POWER / ARMOR** instead of an automatic upgrade.
- **GUARD** reduces incoming enemy damage for one turn and rewards a successful
  block with a stronger counterattack on the next melee hit.
- Smarter archers try to maintain distance; their shots require a clear line.
- Guardian bosses every 5 floors with a telegraphed powerful strike. Stairs
  remain locked until that floor's boss is defeated.
- Optional risk/reward shrine on even floors: a random benefit or a curse.
- Fog-of-war visibility now respects blocking walls, while previously explored
  rooms stay mapped. Monsters in unseen locations are not displayed.
- Smaller screen updates for HP, gold, weapon/ammunition, and pause-menu
  selection, preserving all three visual themes.
- Deeper floors scale enemy damage and health instead of eventually becoming
  trivial when the player's defense improves.
- Added targeted tests for new controls, equipment choices, upgrades, bosses,
  line-of-sight, shrines, overflow limits and optimized graphics.
- Tightened ELF flash-load validation while allowing GNU ld's conventional
  segment-header alignment to 0x08000000; allocated sections remain restricted
  to the application flash and SRAM regions.

## How to play

On the dungeon view: directional buttons move or melee-attack adjacent monsters.
Press OK for **RESUME / POTION / GUARD / AIM / WAIT / EXIT**. GUARD and WAIT
consume turns. AIM enters directional bow targeting (up to five tiles); OK
cancels aiming without firing. Aimed misses consume an arrow and a turn.
If you are not wielding a bow or have no arrows, aiming does not fire.
When you find a weapon or gain a level, use Up/Down and OK to select an option.
Bosses must be defeated before using their floor's stairs. Upon death,
OK restarts a new run. Progress persists only while the device remains on:
**there is no permanent game save or persistent leaderboard.**

## Existing features retained

- 31×31 connected procedural floors and a scrolling 15×15 viewport.
- Six regular enemy kinds, basic poison and traps, items, gold and scores.
- Six-button-equivalent control through five physical keys via menu/aim modes.
- Pause/exit system, procedural encounters, color themes and no framebuffer.
- The RNG *user interface* is removed but underlying USB-used RNG remains.
- Original source fonts remain **unchanged**; statistics screen remains present.
- Original measurement, alarm, tube calibration, logging, USB, power, signing
  and bootloader source modules are not changed by this overlay.

## Testing and limitations

The overlay passes GCC and Clang native logic/regression/render tests with
AddressSanitizer and UndefinedBehaviorSanitizer. They include 6,000 deterministic
seeds and 42,000 floor connectivity checks *per compiler*, as well as 7,500
pixel-comparison frames per compiler across Light/Dark/Retro themes.
The extra gameplay tests exercise weapon selection, bow rays, guarding, bosses,
level-up options, sight and shrines. This confirms software invariants only.

The previous 0.2 **GitHub** build used 54,288 bytes of the maximum 57,340-byte
raw application partition. **This upgraded 0.3 build's actual ARM GCC size is
not yet known.** ARM Clang object-size estimates cannot establish a final link
size. The workflow will reject an oversized image and does not sign anything.

The new gameplay has NOT yet been verified on the actual GC-01. Neither
compilation, source preservation nor simulated tests prove hardware radiation
measurement performance, alarm response time, safe flashing, or data retention.
Keep your working V3 Compact firmware available for recovery.

## Compile

Upload `GC01_Dungeon_Prototype_Source.zip` (unchanged) to the root of your
GitHub repository. Place the matching `GC01_Dungeon_Prototype_Build.yml` under:

    .github/workflows/GC01_Dungeon_Prototype_Build.yml

Run the action: **GC-01 Dungeon Gameplay Upgrade 0.3 - test and compile ONLY**.
It checks exact source and upstream SHA-256 hashes, ZIP member safety,
source preservation, sanitized native tests and full APM32 ARM GCC compilation.
It then verifies the unsigned firmware's physical flash loading, SRAM bounds
and raw size. The downloadable action artifact is explicitly **DO NOT FLASH**.
