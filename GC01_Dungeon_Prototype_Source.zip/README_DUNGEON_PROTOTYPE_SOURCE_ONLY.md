# GC-01 Dungeon Edition — Audited Prototype 0.2 (SOURCE ONLY)

**EXPERIMENTAL, UNVERIFIED ON THE DEVICE. THIS ZIP IS NOT FLASHABLE.**

Hardware: FNIRSI GC-01, APM32F103RBT6, Rad Pro **3.1.1** English,
PlatformIO environment `fnirsi-gc01_apm32f103rb-en`.

## Current gameplay prototype

- Connected, procedural 31×31 floors and 15×15 scrolling viewport
- Simple pixel-art tiles, three visual themes, fog of war
- Six enemy kinds (some behaviors remain basic), melee and archer attacks
- Turn-based combat, poison, traps, gold, potions, score and experience
- Direct weapon and armor pickups, increasing difficulty and stairs
- Pause menu (Resume / Potion / Wait / Exit), restart on death
- Continue within the same powered-on session; **no persistent save**

This is an early playable prototype, **not** the complete proposed roguelike.
Bosses, weapon selection/inventory, final progression balancing and detailed
hardware performance testing remain future work.

## Important source audit fixes in 0.2

- Do not redraw the entire sidebar on each turn; turns and score are not HUD
  fields, and message-only changes now update the message area only
- Preserve the tile cache and underlying display while changing pause options;
  erase the overlay with a proper redraw on resume
- Fix attack upgrade cap, score and gold saturation and XP upper-bound behavior
- Update the combat message when the player kills an enemy without leveling
- Ensure alternating-speed enemies continue working after the turn counter wraps
- Reject unknown action IDs without consuming a turn or changing game state
- Keep enemies away from the initial spawn, and prevent trivially short floors
- Remove unused enemy `cooldown` storage and reuse small helper routines
- Add targeted logic tests and a three-theme cached-vs-full-frame pixel test
- Make the source-preservation check reject *new* unauthorized files too
- Add a standalone ELF/binary validator (address ranges, vectors, flash, SRAM)

## Original firmware preservation

The source overlay changes only the narrowly reviewed Rad Pro integration,
settings-menu RNG entry, and statistics presentation. It does not modify the
original pulse measurement, tube calibration, radiation alarm, datalog, power,
USB communication, flash signing or bootloader sources. The RNG user interface
is removed on the Dungeon target, **not** the USB-used RNG functionality.
The original fonts are still unmodified, so their appearance is identical.

This is checked against a downloaded **clean Rad Pro 3.1.1** source tree by
`dungeon-tests/verify_preservation.py`. Static source preservation is not a
substitute for actual hardware measurement and alarm timing tests.

## Native tests

Run from the overlaid source root:

    ./dungeon-tests/run.sh

On environments with GCC and Clang, this runs both compilers with AddressSanitizer
and UndefinedBehaviorSanitizer, and fails on warnings. It checks deterministic
floor generation, reachability, randomized play, targeted combat/stat edge cases,
and 7,500 graphics frame comparisons including pause/resume in three themes.

## GitHub Actions compile

Use `GC01_Dungeon_Prototype_Build.yml` at:

    .github/workflows/GC01_Dungeon_Prototype_Build.yml

Upload this overlay ZIP **unchanged** into the repository root. The workflow
verifies the ZIP SHA-256 and exact members, retrieves upstream Rad Pro 3.1.1,
overlays these source files, checks source preservation, runs sanitized native
regressions, compiles the exact APM32 English target and checks both the ELF
memory layout and the unsigned application's 57,340-byte maximum payload.

It uploads diagnostic files only. **Never flash `firmware.bin` or this ZIP.**
Only a separately validated and correctly signed release candidate could be
considered for controlled hardware testing.

## What is NOT yet verified

- Full ARM GCC/PlatformIO build of **this updated** 0.2 source
- Actual flash headroom, RAM/stack margin or display timing on this build
- Radiation counting or alarm timing while the game is active
- Safe installation, electrical recovery or preservation of saved measurement
  history during a future firmware upgrade
- Complete gameplay balance, intuitive button feel and extended physical play

Keep the user's **previously working V3 Compact firmware** for recovery.
