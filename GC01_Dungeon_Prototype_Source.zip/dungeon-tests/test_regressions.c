/* Targeted edge-case regressions for the portable dungeon rules. */
#include <assert.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../platform.io/src/extras/dungeon_logic.h"

static uint16_t at(unsigned x,unsigned y) { return (uint16_t)(y*DG_SIZE+x); }
static void empty_arena(DG_Game *g) {
    dg_start(g,0x12345678u);
    memset(g->cells,DG_WALL,sizeof(g->cells));
    g->position=at(15,15);
    for(unsigned y=13;y<=17;y++) for(unsigned x=13;x<=17;x++)g->cells[at(x,y)]=DG_FLOOR;
    g->enemyCount=0;
    g->itemCount=0;
    g->poison=0;
    g->message=DG_MSG_NONE;
    g->turns=0;
}
int main(void) {
    DG_Game g,old;
    empty_arena(&g);
    old=g;
    assert(!dg_action(&g,(DG_Action)255));
    assert(memcmp(&g,&old,sizeof(g))==0);
    assert(!dg_action(&g,(DG_Action)-1));
    assert(memcmp(&g,&old,sizeof(g))==0);

    /* Weapon pickups must honor the documented attack cap. */
    empty_arena(&g);
    g.attack=34;
    g.items[0]=(DG_Item){at(16,15),DG_WEAPON,3};
    g.itemCount=1;
    assert(dg_action(&g,DG_EAST));
    assert(g.attack==35 && g.itemCount==0);

    /* Currency/score must saturate rather than wrap on pickup. */
    empty_arena(&g);
    g.gold=65533;
    g.score=UINT32_MAX-2u;
    g.items[0]=(DG_Item){at(16,15),DG_GOLD,3};
    g.itemCount=1;
    assert(dg_action(&g,DG_EAST));
    assert(g.gold==UINT16_MAX && g.score==UINT32_MAX);

    /* Killing an enemy must always update the combat message. */
    empty_arena(&g);
    g.level=10;
    g.xp=0;
    g.enemies[0]=(DG_Enemy){at(16,15),1,2};
    g.enemyCount=1;
    assert(dg_action(&g,DG_EAST));
    assert(g.enemies[0].hp==0 && g.message==DG_MSG_HIT);
    assert(g.position==at(15,15));

    /* The turn number controls alternating enemy actions; it must wrap. */
    empty_arena(&g);
    g.enemies[0]=(DG_Enemy){at(16,15),5,0};
    g.enemyCount=1;
    g.turns=UINT16_MAX;
    uint8_t startHp=g.hp;
    assert(dg_action(&g,DG_WAIT));
    assert(g.turns==0 && g.hp<startHp);
    startHp=g.hp;
    assert(dg_action(&g,DG_WAIT));
    assert(g.turns==1 && g.hp==startHp);

    /* Potion use at full health is a free, rejected action. */
    empty_arena(&g);
    old=g;
    assert(!dg_action(&g,DG_HEAL));
    assert(memcmp(&g,&old,sizeof(g))==0);
    g.hp=3;
    assert(dg_action(&g,DG_HEAL));
    assert(g.potions==1 && g.hp==13);

    /* Poison ticks on every second consumed turn, and eventually expires. */
    empty_arena(&g);
    g.poison=3;
    assert(dg_action(&g,DG_WAIT));
    assert(g.poison==3);
    assert(dg_action(&g,DG_WAIT));
    assert(g.poison==2 && g.hp==23);

    /* A wall blocks ranged attacks, but an unobstructed row does not. */
    empty_arena(&g);
    g.enemies[0]=(DG_Enemy){at(17,15),8,4};
    g.enemyCount=1;
    g.cells[at(16,15)]=DG_WALL;
    startHp=g.hp;
    assert(dg_action(&g,DG_WAIT));
    assert(g.hp==startHp);
    empty_arena(&g);
    g.enemies[0]=(DG_Enemy){at(17,15),8,4};
    g.enemyCount=1;
    startHp=g.hp;
    assert(dg_action(&g,DG_WAIT));
    assert(g.hp<startHp);

    /* Degenerate zero seed is defined and produces a reachable floor. */
    dg_start(&g,0);
    assert(g.rng!=0 && dg_floor_reachable(&g));
    puts("PASS: targeted combat, overflow, potion, status, input and AI regressions");
    return 0;
}
