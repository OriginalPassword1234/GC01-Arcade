#!/usr/bin/env python3
"""Static safety checks for raw (unsigned) APM32 firmware and linked ARM ELF.

Checks the application partition, actual load addresses, size and RAM boundaries.
Does NOT sign or create installable firmware. Uses only Python's standard library.
"""
from pathlib import Path
import struct
import sys

APP_START = 0x08004000
CRC_START = 0x08011FFC
RAW_LIMIT = CRC_START - APP_START
RAM_START = 0x20000000
RAM_END = 0x20005000


def read_struct(fmt, blob, pos, what):
    size = struct.calcsize(fmt)
    if pos < 0 or pos + size > len(blob):
        raise ValueError(f'Truncated {what}')
    return struct.unpack_from(fmt, blob, pos)


def verify(raw_path, elf_path):
    raw = raw_path.read_bytes()
    elf = elf_path.read_bytes()
    if not 8 <= len(raw) <= RAW_LIMIT:
        raise ValueError(f'Raw firmware size {len(raw)} violates 8..{RAW_LIMIT} limit')
    stack, reset = struct.unpack_from('<II', raw)
    if not RAM_START <= stack <= RAM_END or stack & 3:
        raise ValueError(f'Initial stack pointer 0x{stack:08x} out of range')
    if reset & 1 == 0 or not APP_START <= (reset & ~1) < CRC_START:
        raise ValueError(f'Reset vector 0x{reset:08x} is not Thumb code in application')
    if len(elf) < 52 or elf[:4] != b'\x7fELF' or elf[4] != 1 or elf[5] != 1:
        raise ValueError('Expected a little-endian ELF32')
    hdr = read_struct('<16sHHIIIIIHHHHHH', elf, 0, 'ELF header')
    _, elf_type, machine, version, entry, phoff, shoff, _, ehsize, phentsize, phnum, shentsize, shnum, _ = hdr
    if elf_type != 2 or machine != 40 or version != 1 or ehsize != 52:
        raise ValueError('Expected a 32-bit ARM executable')
    if entry & 1 == 0 or not APP_START <= (entry & ~1) < CRC_START:
        raise ValueError('ELF entry point is not in the Thumb application')
    if reset != entry:
        raise ValueError('Firmware reset vector disagrees with ELF entry point')
    if phentsize < 32 or phnum == 0 or shentsize < 40 or shnum == 0:
        raise ValueError('Invalid ELF program or section table')
    flash_end = APP_START
    for i in range(phnum):
        pos = phoff + i*phentsize
        p_type, off, vaddr, phys, filesize, memsize, _, _ = read_struct(
            '<IIIIIIII', elf, pos, f'program header {i}')
        if p_type != 1:
            continue
        if filesize > memsize or off + filesize > len(elf):
            raise ValueError(f'Invalid load segment {i}')
        if 0x08000000 <= phys < CRC_START:
            if phys + filesize > CRC_START:
                raise ValueError(f'Load segment {i} overlaps CRC or settings flash')
            flash_end = max(flash_end, phys+filesize)
        elif RAM_START <= phys <= RAM_END and not filesize:
            pass
        else:
            raise ValueError(f'Unexpected load segment {i} physical address 0x{phys:08x}')
    has_vector = False
    ram_top = RAM_START
    for i in range(shnum):
        pos = shoff + i*shentsize
        name, typ, flags, addr, offset, size, link, info, align, entsize = read_struct(
            '<IIIIIIIIII', elf, pos, f'section header {i}')
        if not (flags & 0x2) or not size:
            continue
        if addr == APP_START and size >= 8 and typ != 8:
            if offset + 8 > len(elf) or elf[offset:offset+8] != raw[:8]:
                raise ValueError('Raw vector table does not match linked ELF')
            has_vector = True
        if APP_START <= addr < CRC_START:
            if addr + size > CRC_START:
                raise ValueError(f'Section {i} overlaps reserved flash')
        elif RAM_START <= addr < RAM_END:
            if addr + size > RAM_END:
                raise ValueError(f'Section {i} extends beyond SRAM')
            ram_top = max(ram_top, addr+size)
        else:
            raise ValueError(f'Allocated section {i} outside allowed memory: 0x{addr:08x}')
    if not has_vector:
        raise ValueError('No application vector section at 0x08004000')
    expected = flash_end - APP_START
    if expected != len(raw):
        raise ValueError(f'ELF load image {expected} bytes disagrees with raw {len(raw)} bytes')
    print('PASS: executable ARM ELF, entrypoint, vector table, load addresses and SRAM bounds')
    print(f'PASS: raw {len(raw)} / {RAW_LIMIT} bytes; application flash headroom {RAW_LIMIT-len(raw)} bytes')
    print(f'RAM allocated through 0x{ram_top:08x}; SRAM ends 0x{RAM_END:08x}')
    print('NOTE: no stack-depth, timing, alarm, display, bootloader or hardware tests were performed.')


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: verify_firmware.py RAW_FIRMWARE.bin FIRMWARE.elf')
    try:
        verify(Path(sys.argv[1]), Path(sys.argv[2]))
    except (ValueError, OSError) as exc:
        raise SystemExit('FAIL: ' + str(exc)) from exc
