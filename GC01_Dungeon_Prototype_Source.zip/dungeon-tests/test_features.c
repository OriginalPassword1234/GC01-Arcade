/* New mechanics and boundaries: independent targeted tests for Dungeon Edition. */
#include <assert.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../platform.io/src/extras/dungeon_logic.h"

static uint16_t at(unsigned x,unsigned y){return (uint16_t)(y*DG_SIZE+x);}
static void arena(DG_Game *g){
    dg_start(g,0x14681d2au);
    memset(g->cells,DG_WALL,sizeof(g->cells));
    for(unsigned y=10;y<=20;y++)for(unsigned x=10;x<=20;x++)g->cells[at(x,y)]=DG_FLOOR;
    g->position=at(15,15);g->enemyCount=0;g->itemCount=0;
    g->phase=DG_PLAYING;g->poison=0;g->guard=0;g->riposte=0;
    g->message=DG_MSG_NONE;g->turns=0;g->stunnedEnemy=0xff;
}
static void weapon_pickup(unsigned amount,unsigned expected){
    DG_Game g;
    arena(&g);
    g.items[0]=(DG_Item){at(16,15),DG_WEAPON,(uint8_t)amount};g.itemCount=1;
    assert(dg_action(&g,DG_EAST));
    assert(g.phase==DG_EQUIP && g.itemCount==0);
    assert(g.pendingWeapon==expected);
    assert(dg_choose_weapon(&g,1));
    assert(g.weapon==expected && g.attack==4);
    if(expected==DG_BOW)assert(g.arrows==9);
}
static void level_choice(unsigned option){
    DG_Game g;
    arena(&g);
    g.xp=11;g.enemies[0]=(DG_Enemy){at(16,15),1,0};g.enemyCount=1;
    assert(dg_action(&g,DG_EAST));
    assert(g.phase==DG_LEVELUP && g.level==2);
    DG_Game before=g;
    assert(!dg_choose_upgrade(&g,5));
    assert(memcmp(&before,&g,sizeof(g))==0);
    assert(dg_choose_upgrade(&g,(uint8_t)option));
    assert(g.phase==DG_PLAYING);
    if(option==0) assert(g.maxHp==28 && g.hp==28);
    if(option==1) assert(g.attack==4);
    if(option==2) assert(g.defense==1);
    assert(!dg_choose_upgrade(&g,(uint8_t)option));
}
static void shoot_test(void){
    DG_Game g;
    arena(&g);
    assert(!dg_action(&g,DG_SHOOT_EAST));
    assert(g.turns==0 && g.arrows==4);
    g.weapon=DG_BOW;g.arrows=2;
    g.enemies[0]=(DG_Enemy){at(18,15),20,1};g.enemyCount=1;
    uint8_t hp=g.enemies[0].hp;
    assert(dg_action(&g,DG_SHOOT_EAST));
    assert(g.arrows==1 && g.enemies[0].hp<hp && g.turns==1);
    arena(&g);g.weapon=DG_BOW;g.arrows=1;
    g.cells[at(16,15)]=DG_WALL;
    g.enemies[0]=(DG_Enemy){at(18,15),20,1};g.enemyCount=1;
    hp=g.enemies[0].hp;
    assert(dg_action(&g,DG_SHOOT_EAST));
    assert(g.enemies[0].hp==hp && g.arrows==0);
    uint16_t turns=g.turns;
    assert(!dg_action(&g,DG_SHOOT_EAST));assert(g.turns==turns);
}
static void guard_test(void){
    DG_Game guarded,normal;
    arena(&guarded);
    guarded.enemies[0]=(DG_Enemy){at(16,15),18,1};guarded.enemyCount=1;
    guarded.floor=30;
    normal=guarded;
    assert(dg_action(&normal,DG_WAIT));
    assert(dg_action(&guarded,DG_GUARD));
    assert(guarded.hp>normal.hp && guarded.riposte==1 && guarded.guard==0);
    assert(dg_action(&guarded,DG_EAST));
    assert(guarded.riposte==0);
}
static void boss_test(void){
    DG_Game g;
    dg_start(&g,0x94193u);
    g.floor=5;dg_generate_floor(&g);
    int boss=-1;uint16_t stairs=DG_MAP_CELLS;
    for(unsigned i=0;i<g.enemyCount;i++)if(g.enemies[i].kind==6)boss=(int)i;
    for(uint16_t i=0;i<DG_MAP_CELLS;i++)if(g.cells[i]==DG_STAIRS)stairs=i;
    assert(boss>=0 && stairs<DG_MAP_CELLS && dg_floor_reachable(&g));
    /* A controlled adjacent stairs tile is not available until the boss dies. */
    arena(&g);
    g.cells[at(16,15)]=DG_STAIRS;
    g.enemies[0]=(DG_Enemy){at(20,20),20,6};g.enemyCount=1;
    DG_Game before=g;
    assert(!dg_action(&g,DG_EAST));
    assert(g.position==before.position && g.turns==before.turns);
    g.enemies[0].hp=0;
    assert(dg_action(&g,DG_EAST));
    assert(g.floor==2 && dg_floor_reachable(&g));
}
static void shrine_test(void){
    DG_Game g;
    for(uint32_t seed=1;seed<64;seed++){
        arena(&g);
        g.hp=10;g.potions=0;
        g.rng=seed;
        g.cells[at(16,15)]=DG_SHRINE;
        assert(dg_action(&g,DG_EAST));
        assert(g.cells[at(16,15)]==DG_FLOOR);
        assert(g.message==DG_MSG_BLESS || g.message==DG_MSG_CURSE);
        if(g.message==DG_MSG_CURSE)assert(g.hp==6);
    }
}
static void sight_test(void){
    DG_Game g;
    arena(&g);
    /* Adjacent wall is visible; the square directly behind it is hidden. */
    g.cells[at(16,15)]=DG_WALL;
    assert(dg_action(&g,DG_WAIT));
    assert(dg_visible(&g,at(16,15)));
    assert(!dg_visible(&g,at(17,15)));
    /* Previously seen tiles remain mapped after moving out of sight. */
    g.cells[at(16,15)]=DG_FLOOR;
    assert(dg_action(&g,DG_WAIT));
    assert(dg_seen(&g,at(17,15)) && dg_visible(&g,at(17,15)));
    g.cells[at(16,15)]=DG_WALL;
    assert(dg_action(&g,DG_WAIT));
    assert(dg_seen(&g,at(17,15)) && !dg_visible(&g,at(17,15)));
}
int main(void){
    weapon_pickup(1,DG_DAGGER);
    weapon_pickup(2,DG_AXE);
    weapon_pickup(3,DG_BOW);
    {DG_Game g;arena(&g);g.weapon=DG_BOW;
     g.items[0]=(DG_Item){at(16,15),DG_WEAPON,1};g.itemCount=1;
     assert(dg_action(&g,DG_EAST));
     assert(!dg_choose_weapon(&g,2));
     assert(dg_choose_weapon(&g,0));assert(g.weapon==DG_BOW);
    }
    for(unsigned choice=0;choice<3;choice++)level_choice(choice);
    shoot_test();guard_test();boss_test();sight_test();shrine_test();
    DG_Game g;dg_start(&g,111);
    g.floor=UINT16_MAX;dg_generate_floor(&g);
    assert(dg_floor_reachable(&g) && g.enemyCount<=DG_ENEMY_MAX);
    puts("PASS: weapons, level-up choices, bows, guarding, bosses, stairs, fog and depth limits");
    return 0;
}
