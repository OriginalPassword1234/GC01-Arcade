#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
LOGIC=platform.io/src/extras/dungeon_logic.c
DRAW=platform.io/src/ui/dungeon_draw.c
for compiler in gcc clang; do
    if ! command -v "$compiler" >/dev/null 2>&1; then
        echo "SKIP: $compiler unavailable"
        continue
    fi
    echo "Testing with $compiler"
    for test in test_dungeon test_regressions; do
        "$compiler" -DDG_NATIVE_TEST -std=c11 -O1 -g -Wall -Wextra -Werror \
            -fsanitize=address,undefined -fno-omit-frame-pointer \
            "$LOGIC" "dungeon-tests/$test.c" -o "$TMP/$test-$compiler"
        ASAN_OPTIONS=detect_leaks=0 "$TMP/$test-$compiler"
    done
    "$compiler" -DDG_NATIVE_TEST -DDG_DRAW_NATIVE_TEST -std=c11 -O1 -g \
        -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer \
        "$LOGIC" "$DRAW" dungeon-tests/test_render.c -o "$TMP/test_render-$compiler"
    ASAN_OPTIONS=detect_leaks=0 "$TMP/test_render-$compiler"
done
