#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../platform.io/src/extras/dungeon_logic.h"

static void check(const DG_Game *g) {
    assert(g->position < DG_MAP_CELLS);
    assert(g->cells[g->position]!=DG_WALL);
    assert(g->enemyCount<=DG_ENEMY_MAX && g->itemCount<=DG_ITEM_MAX);
    assert(g->hp<=g->maxHp && g->level>=1 && g->floor>=1);
    assert(g->phase<=DG_EQUIP && dg_seen(g,g->position));
    for(unsigned i=0;i<g->enemyCount;i++) {
        const DG_Enemy *e=&g->enemies[i];
        assert(e->pos<DG_MAP_CELLS && g->cells[e->pos]!=DG_WALL);
        if(!e->hp)continue;
        assert(e->pos!=g->position);
        for(unsigned j=i+1;j<g->enemyCount;j++)
            assert(!g->enemies[j].hp || e->pos!=g->enemies[j].pos);
    }
    for(unsigned i=0;i<g->itemCount;i++) {
        assert(g->items[i].pos<DG_MAP_CELLS);
        assert(g->cells[g->items[i].pos]!=DG_WALL);
        for(unsigned j=i+1;j<g->itemCount;j++) assert(g->items[j].pos!=g->items[i].pos);
    }
}
int main(void) {
    DG_Game a,b;
    for(unsigned seed=1;seed<=6000;seed++) {
        dg_start(&a,seed);dg_start(&b,seed);
        assert(memcmp(&a,&b,sizeof(a))==0);
        assert(dg_floor_reachable(&a));check(&a);
        for(unsigned i=0;i<a.enemyCount;i++) {
            int dx=(int)(a.enemies[i].pos%DG_SIZE)-(int)(a.position%DG_SIZE);
            int dy=(int)(a.enemies[i].pos/DG_SIZE)-(int)(a.position/DG_SIZE);
            if(dx<0)dx=-dx;
            if(dy<0)dy=-dy;
            assert(dx+dy>=5);
        }
        for(unsigned f=0;f<6;f++) {
            a.floor++;dg_generate_floor(&a);
            assert(dg_floor_reachable(&a));check(&a);
        }
    }
    dg_start(&a,1234);
    unsigned invalid=0,acted=0;
    for(unsigned run=0;run<120;run++) {
        dg_start(&a,(run+9)*781u);
        for(unsigned step=0;step<2000;step++) {
            DG_Action action=(DG_Action)((step*23u+run*7u)%6u);
            DG_Game previous=a;
            bool changed=dg_action(&a,action);
            if(!changed) {
                invalid++;
                /* An invalid attempt changes only the informative message. */
                previous.message=a.message;
                assert(memcmp(&a,&previous,sizeof(a))==0);
            } else acted++;
            if(a.phase==DG_LEVELUP)assert(dg_choose_upgrade(&a,(uint8_t)(step%3u)));
            if(a.phase==DG_EQUIP)assert(dg_choose_weapon(&a,(uint8_t)(step%2u)));
            check(&a);
            if(a.phase==DG_DEAD)break;
            if((step%211u)==0) {
                a.floor++;dg_generate_floor(&a);
                assert(dg_floor_reachable(&a));check(&a);
            }
        }
    }
    /* Player cannot leave the map or consume a turn by running into a wall. */
    dg_start(&a,42);
    memset(a.cells,0,sizeof(a.cells));
    a.position=(uint16_t)(DG_SIZE+1u);
    a.cells[a.position]=DG_FLOOR;
    a.enemyCount=0;a.itemCount=0;a.turns=10;
    assert(!dg_action(&a,DG_NORTH));
    assert(!dg_action(&a,DG_WEST));
    assert(a.turns==10);
    /* Potion is a resource and has no effect when already at full HP. */
    assert(!dg_action(&a,DG_HEAL));
    assert(a.potions==2);
    a.hp=4;
    assert(dg_action(&a,DG_HEAL));
    assert(a.potions==1 && a.hp>=4 && a.hp<=a.maxHp);
    /* Stairs advance once; the new map is connected. */
    dg_start(&a,842);
    uint16_t at=a.position;
    uint16_t right=(uint16_t)(at+1);
    a.cells[right]=DG_STAIRS;
    for(unsigned i=0;i<a.enemyCount;i++) a.enemies[i].hp=0;
    a.itemCount=0;
    uint16_t oldfloor=a.floor;
    assert(dg_action(&a,DG_EAST));
    assert(a.floor==oldfloor+1);
    assert(dg_floor_reachable(&a));
    printf("PASS: 6,000 deterministic dungeon seeds; 42,000 connectivity checks; "
           "120 simulated runs; %u valid actions; %u rejected actions.\n",acted,invalid);
    return 0;
}
