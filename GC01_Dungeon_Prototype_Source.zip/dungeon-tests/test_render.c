/* Pixel-comparison test for cached/dirtied dungeon rendering. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../platform.io/src/extras/dungeon_logic.h"

unsigned dg_test_theme;
static uint16_t framebuffer[320*240];
static uint16_t selected[320*240];
static unsigned long pixelWrites;
void dg_test_fill_rect(int x,int y,int w,int h,uint16_t color) {
    assert(x>=0 && y>=0 && w>0 && h>0 && x+w<=320 && y+h<=240);
    pixelWrites+=(unsigned long)w*(unsigned long)h;
    for(int yy=y;yy<y+h;yy++) for(int xx=x;xx<x+w;xx++)
        framebuffer[yy*320+xx]=color;
}
void dg_test_reference_frame(const DG_Game *g);
void drawDungeon(const DG_Game *g,bool force);
static void compare_current_to_full(const DG_Game *g) {
    memcpy(selected,framebuffer,sizeof(framebuffer));
    dg_test_reference_frame(g);
    if(memcmp(selected,framebuffer,sizeof(framebuffer))) {
        for(unsigned i=0;i<320u*240u;i++) if(selected[i]!=framebuffer[i]) {
            fprintf(stderr,"FAIL: dirty rendering mismatch at (%u,%u) dirty=%04x full=%04x\n",
                    i%320,i/320,selected[i],framebuffer[i]);
            abort();
        }
    }
}
int main(void) {
    DG_Game g;
    unsigned long totalWrites=0;
    for(dg_test_theme=0;dg_test_theme<3;dg_test_theme++) {
        memset(framebuffer,0,sizeof(framebuffer));
        dg_start(&g,1001+dg_test_theme);
        drawDungeon(&g,true);
        compare_current_to_full(&g);
        /* Turns don't appear in the HUD; a quiet wait should paint nothing. */
        g.enemyCount=0;
        g.message=DG_MSG_NONE;
        drawDungeon(&g,false);
        pixelWrites=0;
        assert(dg_action(&g,DG_WAIT));
        drawDungeon(&g,false);
        assert(pixelWrites==0);
        compare_current_to_full(&g);

        /* Single-value HUD changes must not repaint the entire sidebar. */
        g.hp--;
        pixelWrites=0;drawDungeon(&g,false);
        assert(pixelWrites>0 && pixelWrites<4500u);
        compare_current_to_full(&g);
        g.gold=123;
        pixelWrites=0;drawDungeon(&g,false);
        assert(pixelWrites>0 && pixelWrites<4500u);
        compare_current_to_full(&g);
        g.weapon=DG_BOW;g.arrows=9;
        drawDungeon(&g,false);compare_current_to_full(&g);
        g.arrows=8;
        pixelWrites=0;drawDungeon(&g,false);
        assert(pixelWrites>0 && pixelWrites<4500u);
        compare_current_to_full(&g);
        /* The two new decision overlays must be fully cache-safe. */
        g.phase=DG_LEVELUP;g.menuChoice=0;
        drawDungeon(&g,false);compare_current_to_full(&g);
        g.menuChoice=2;
        drawDungeon(&g,false);compare_current_to_full(&g);
        assert(dg_choose_upgrade(&g,2));
        drawDungeon(&g,false);compare_current_to_full(&g);
        g.phase=DG_EQUIP;g.pendingWeapon=DG_AXE;g.menuChoice=0;
        drawDungeon(&g,false);compare_current_to_full(&g);
        g.menuChoice=1;
        drawDungeon(&g,false);compare_current_to_full(&g);
        assert(dg_choose_weapon(&g,1));
        drawDungeon(&g,false);compare_current_to_full(&g);

        /* Pause-menu selection must not repaint the underlying dungeon. */
        g.phase=DG_PAUSED;g.menuChoice=0;
        drawDungeon(&g,false);
        compare_current_to_full(&g);
        g.menuChoice=1;
        pixelWrites=0;
        drawDungeon(&g,false);
        assert(pixelWrites>0 && pixelWrites<60000u);
        compare_current_to_full(&g);
        g.menuChoice=2;
        drawDungeon(&g,false);
        compare_current_to_full(&g);
        g.phase=DG_PLAYING;
        drawDungeon(&g,false);
        compare_current_to_full(&g);

        for(unsigned run=0;run<5;run++) {
            dg_start(&g,(uint32_t)((run+1u)*7937u+dg_test_theme));
            drawDungeon(&g,true);
            for(unsigned step=0;step<500;step++) {
                if(g.phase==DG_DEAD)dg_start(&g,(uint32_t)(step*621u+run+1u));
                else (void)dg_action(&g,(DG_Action)((step*19u+run*3u)%6u));
                if(step%93u==0 && g.phase==DG_PLAYING) {
                    g.phase=DG_PAUSED;
                    drawDungeon(&g,false);
                    compare_current_to_full(&g);
                    g.menuChoice=(uint8_t)(step%4u);
                    drawDungeon(&g,false);
                    compare_current_to_full(&g);
                    g.phase=DG_PLAYING;
                }
                if(g.phase==DG_EQUIP) {
                    drawDungeon(&g,false);
                    compare_current_to_full(&g);
                    g.menuChoice=(uint8_t)(step%2u);
                    drawDungeon(&g,false);
                    compare_current_to_full(&g);
                    assert(dg_choose_weapon(&g,g.menuChoice));
                }
                if(g.phase==DG_LEVELUP) {
                    drawDungeon(&g,false);
                    compare_current_to_full(&g);
                    g.menuChoice=(uint8_t)(step%3u);
                    drawDungeon(&g,false);
                    compare_current_to_full(&g);
                    assert(dg_choose_upgrade(&g,g.menuChoice));
                }
                drawDungeon(&g,false);
                compare_current_to_full(&g);
            }
        }
        totalWrites+=pixelWrites;
    }
    printf("PASS: 3 themes; 7,500 randomized-frame checks plus pause/resume and HUD invalidation checks; %lu pixel writes\n",totalWrites);
    return 0;
}
