/* Rad Pro 3.1.1 GC-01 arcade: procedural, zero-bitmap graphics.
 * Only compiled for GC01_ARCADE. No graphics heap or framebuffer.
 * Gameplay, timing, measurement, display driver and stored settings untouched.
 * License: MIT
 */
#if defined(GC01_ARCADE)
#include <stdint.h>
#include <stdbool.h>
#include "arcade.h"
#include "draw.h"
#include "../system/settings.h"
#include "../system/cstring.h"

/* Direct RGB565 is supported by the existing mcu-renderer used by Rad Pro. */
extern mr_t mr;
#define RGB(hex) mr_get_color(hex)
#define FIELD_SIZE 240
#define PANEL_X 240
#define PANEL_W 80

/* These colors are ROM constants (3 themes, no runtime allocation). */
typedef struct {
    mr_color_t field, grid, panel, panelEdge, text, muted, accent;
    mr_color_t mint, mintDark, mintLight, red, redLight, gold;
    mr_color_t sky, skyTop, cloud, pipe, pipeLight, pipeDark;
} ArcadeColors;
static const ArcadeColors palettes[3] = {
    /* Light Rad Pro UI: restrained navy arcade screen, pale status panel. */
    { RGB(0x173340),RGB(0x244653),RGB(0xe9f2f5),RGB(0xb3c7d0),RGB(0x183946),RGB(0x567884),RGB(0x0b827c),
      RGB(0x38c8a3),RGB(0x19876d),RGB(0x8af1ce),RGB(0xe65b68),RGB(0xffadab),RGB(0xf1bf55),
      RGB(0x497fa0),RGB(0x5a94b2),RGB(0xaad0da),RGB(0x239475),RGB(0x82e3a7),RGB(0x126658) },
    /* Dark Rad Pro UI. */
    { RGB(0x102733),RGB(0x1b3845),RGB(0x0d1c27),RGB(0x294453),RGB(0xeaf7f8),RGB(0x96b6c3),RGB(0x55d6c4),
      RGB(0x45cfae),RGB(0x157a69),RGB(0x9cf2d8),RGB(0xf06e7b),RGB(0xffafb0),RGB(0xf4c869),
      RGB(0x305e7a),RGB(0x3c7796),RGB(0x77aac0),RGB(0x24916d),RGB(0x80e1a3),RGB(0x135848) },
    /* Retro Rad Pro UI: warmer palette and amber status. */
    { RGB(0x202a20),RGB(0x304233),RGB(0x141d17),RGB(0x435a3d),RGB(0xf0c878),RGB(0xc6a46a),RGB(0xf4c36e),
      RGB(0x79c786),RGB(0x397f4b),RGB(0xafe5a0),RGB(0xeb7971),RGB(0xffbba2),RGB(0xf3cd74),
      RGB(0x516e62),RGB(0x627e68),RGB(0x8ea38a),RGB(0x56865b),RGB(0xa3c588),RGB(0x345e45) },
};

/* Every rectangle is clipped to the physical 320x240 display. */
static void block(int16_t x, int16_t y, int16_t w, int16_t h, mr_color_t color)
{
    if (w <= 0 || h <= 0) return;
    int32_t x2=(int32_t)x+w, y2=(int32_t)y+h;
    if (x<0) x=0;
    if (y<0) y=0;
    if (x2>DISPLAY_WIDTH) x2=DISPLAY_WIDTH;
    if (y2>DISPLAY_HEIGHT) y2=DISPLAY_HEIGHT;
    if (x>=x2 || y>=y2) return;
    mr_set_fill_color(&mr,color);
    drawRectangle(&(mr_rectangle_t){x,y,(int16_t)(x2-x),(int16_t)(y2-y)});
}

/* 3x5 pixel alphabet: 72 bytes total, reused by tiles, sidebar and overlays.
 * Unlike the stock 30px font, it fits 4-10 digit 2048 tiles into 56px.
 */
static const uint16_t digitBits[10] = { 0x7b6f, 0x2c97, 0x73e7, 0x73cf, 0x5bc9, 0x79cf, 0x79ef, 0x7292, 0x7bef, 0x7bcf };
static const uint16_t letterBits[26] = { 0x2bed, 0x6bae, 0x3923, 0x6b6e, 0x79a7, 0x79a4, 0x396b, 0x5bed, 0x7497, 0x126a, 0x5bad, 0x4927, 0x5fed, 0x5ffd, 0x2b6a, 0x6ba4, 0x2b7b, 0x6bad, 0x388e, 0x7492, 0x5b6f, 0x5b6a, 0x5bfd, 0x5aad, 0x5a92, 0x72a7 };

static uint16_t glyph(char ch)
{
    if (ch>='0' && ch<='9') return digitBits[(uint8_t)(ch-'0')];
    if (ch>='A' && ch<='Z') return letterBits[(uint8_t)(ch-'A')];
    return 0;
}

static int textWidth(const char *s, int scale)
{
    int length=0;
    while (*s++) ++length;
    return length ? length*4*scale-scale : 0;
}

/* Render contiguous runs in a row as one rectangle instead of per-pixel calls. */
static void textAt(const char *s, int x, int y, int scale, mr_color_t color)
{
    for (;*s;s++,x+=4*scale) {
        uint16_t bits=glyph(*s);
        for (int row=0;row<5;++row) {
            int col=0;
            while(col<3) {
                while(col<3 && !(bits & (1u << (14-(row*3+col))))) ++col;
                int first=col;
                while(col<3 && (bits & (1u << (14-(row*3+col))))) ++col;
                if(col>first) block((int16_t)(x+first*scale),
                    (int16_t)(y+row*scale),(int16_t)((col-first)*scale),
                    (int16_t)scale,color);
            }
        }
    }
}
static void textCenter(const char *s,int x,int y,int width,int scale,mr_color_t color)
{
    textAt(s,x+(width-textWidth(s,scale))/2,y,scale,color);
}
static void numberCenter(uint32_t n,int x,int y,int width,int scale,mr_color_t color)
{
    char t[16];
    strclr(t);
    strcatUInt32(t,n,0);
    textCenter(t,x,y,width,scale,color);
}

static void sidebar(const ArcadeState *a, const ArcadeColors *p)
{
    static const char *const titles[ARCADE_COUNT]={"SNAKE","2048","FLAPPY","BREAKOUT"};
    block(PANEL_X,0,PANEL_W,DISPLAY_HEIGHT,p->panel);
    block(PANEL_X,0,2,DISPLAY_HEIGHT,p->panelEdge);
    block(PANEL_X+7,9,66,2,p->accent);
    textCenter(titles[a->kind],PANEL_X,16,PANEL_W,2,p->text);
    block(PANEL_X+9,36,62,1,p->panelEdge);
    textCenter("SCORE",PANEL_X,51,PANEL_W,2,p->muted);
    uint32_t shown=a->score>999999 ? 999999 : a->score;
    int scale=shown>999 ? 2 : 3;
    numberCenter(shown,PANEL_X,70,PANEL_W,scale,p->text);
    block(PANEL_X+9,114,62,1,p->panelEdge);
    if(a->kind==ARCADE_BREAKOUT) {
        textCenter("LIVES",PANEL_X,132,PANEL_W,2,p->muted);
        numberCenter(a->game.breakout.lives,PANEL_X,153,PANEL_W,3,p->text);
        textCenter("LEVEL",PANEL_X,181,PANEL_W,2,p->muted);
        numberCenter(a->game.breakout.level,PANEL_X,200,PANEL_W,2,p->text);
    } else if(a->phase==ARCADE_READY) {
        textCenter("READY",PANEL_X,205,PANEL_W,2,p->accent);
    } else if(a->kind==ARCADE_2048) {
        textCenter("GOAL",PANEL_X,159,PANEL_W,2,p->muted);
        numberCenter(2048,PANEL_X,178,PANEL_W,2,p->accent);
    }
}

static void snake(const ArcadeState *a, const ArcadeColors *p)
{
    const ArcadeSnake *s=&a->game.snake;
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->field);
    /* Sparse grid: 30 strips instead of 256 colored cell backgrounds. */
    for(int i=1;i<16;++i) {
        block(i*15,0,1,FIELD_SIZE,p->grid);
        block(0,i*15,FIELD_SIZE,1,p->grid);
    }
    for(int i=0;i<256;++i) {
        if(s->occupied[i>>3] & (1u << (i&7))) {
            int x=(i&15)*15, y=(i>>4)*15;
            block(x+1,y+1,13,13,((i^(i>>4))&1)?p->mint:p->mintDark);
        }
    }
    /* Head and eyes are on top of body, respecting the existing 15px cells. */
    uint8_t head=s->body[(uint8_t)(s->tail+s->length-1)];
    int hx=(head&15)*15, hy=(head>>4)*15;
    block(hx+1,hy+1,13,13,p->mintLight);
    if(s->direction==ARCADE_LEFT || s->direction==ARCADE_RIGHT) {
        int eyeX=hx+(s->direction==ARCADE_RIGHT?10:3);
        block(eyeX,hy+3,2,2,p->field);
        block(eyeX,hy+10,2,2,p->field);
    } else {
        int eyeY=hy+(s->direction==ARCADE_DOWN?10:3);
        block(hx+3,eyeY,2,2,p->field);
        block(hx+10,eyeY,2,2,p->field);
    }
    /* A completely filled board has no remaining food cell. */
    if (s->length<256) {
        int fx=(s->food&15)*15, fy=(s->food>>4)*15;
        block(fx+3,fy+4,9,9,p->red);
        block(fx+4,fy+4,6,2,p->redLight);
        block(fx+7,fy+1,2,4,p->mintLight);
    }
}

/* Tile color is a compact RGB565 constant, not an image asset. */
static const mr_color_t tileColors[] = {
    RGB(0x2d4350),RGB(0xb6e3d9),RGB(0x89d8ca),RGB(0x67c8d4),
    RGB(0x51b7d4),RGB(0x4c94d0),RGB(0x777dca),RGB(0x9d77c6),
    RGB(0xc07eae),RGB(0xdd8e8b),RGB(0xe2aa6e),RGB(0xe7c762),
    RGB(0x8bd1ad)
};
static void puzzle2048(const ArcadeState *a, const ArcadeColors *p)
{
    const Arcade2048 *g=&a->game.puzzle;
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->field);
    for(int i=0;i<16;++i) {
        uint8_t exp=g->cells[i];
        if (exp>30) exp=30; /* Defensive shift bound. Valid game tiles are 0..30. */
        int x=(i&3)*60, y=(i>>2)*60;
        mr_color_t color=tileColors[exp<12 ? exp : 12];
        block(x+3,y+4,55,55,p->panelEdge); /* bottom-edge shadow */
        block(x+2,y+2,55,54,color);
        if(exp) {
            block(x+5,y+4,49,2,exp<5 ? RGB(0xeafff9) : RGB(0xf6e2c9));
            /* uint32_t shift is valid for all game exponents (1..30). */
            char t[16]; strclr(t);
            strcatUInt32(t,1u<<exp,0);
            int digits=0;for(const char *q=t;*q;++q) ++digits;
            int scale=digits<=4 ? 3 : (digits<=6 ? 2 : 1);
            mr_color_t fg=exp<=4 ? RGB(0x203745) : RGB(0xfffaf2);
            textCenter(t,x+2,y+30-(5*scale)/2,55,scale,fg);
        }
    }
}

static void flappy(const ArcadeState *a, const ArcadeColors *p)
{
    const ArcadeFlappy *f=&a->game.flappy;
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->sky);
    block(0,0,FIELD_SIZE,56,p->skyTop);
    /* Three small stationary clouds; no bitmap storage or scrolling state. */
    static const uint8_t clouds[][2]={{16,34},{123,67},{192,21}};
    for(int i=0;i<3;++i) {
        int x=clouds[i][0],y=clouds[i][1];
        block(x,y+5,29,5,p->cloud);
        block(x+7,y,15,12,p->cloud);
    }
    int halfGap=38-(int)(a->score/3>8 ? 8 : a->score/3);
    for(int i=0;i<3;++i) {
        int x=f->pipeX[i], center=f->pipeGap[i];
        int top=center-halfGap, bottom=center+halfGap;
        /* All pipe decorations remain INSIDE the collision width (28px). */
        block(x,0,28,top,p->pipeDark);
        block(x+3,0,22,top,p->pipe);
        block(x+4,0,3,top,p->pipeLight);
        block(x,top-7,28,7,p->pipeDark);
        block(x+2,top-6,24,3,p->pipeLight);
        block(x,bottom,28,FIELD_SIZE-bottom,p->pipeDark);
        block(x+3,bottom,22,FIELD_SIZE-bottom,p->pipe);
        block(x+4,bottom,3,FIELD_SIZE-bottom,p->pipeLight);
        block(x,bottom,28,7,p->pipeDark);
        block(x+2,bottom+1,24,2,p->pipeLight);
    }
    int y=f->y>>4;
    /* Bird pixel art fits the original x=43..62, y-7..y+7 collision box. */
    block(46,y-7,13,13,p->gold);
    block(47,y-6,11,3,RGB(0xffe69a));
    block(44,y+1,8,6,RGB(0xe8a746)); /* wing */
    block(45,y+2,6,3,RGB(0xffd66f));
    block(58,y-1,4,4,RGB(0xef9356)); /* beak */
    block(54,y-4,4,4,RGB(0xfffaf2));
    block(56,y-3,2,2,RGB(0x183342)); /* eye */
    block(0,237,FIELD_SIZE,3,p->pipeDark);
}

static void breakout(const ArcadeState *a, const ArcadeColors *p)
{
    const ArcadeBreakout *b=&a->game.breakout;
    block(0,0,FIELD_SIZE,FIELD_SIZE,p->field);
    block(2,7,236,2,p->grid);
    static const mr_color_t brickColors[4] = {
        RGB(0xed777f),RGB(0xf0bd68),RGB(0x55c3ab),RGB(0x619fd2)
    };
    for(int i=0;i<32;++i) if(b->bricks[i]) {
        int x=(i&7)*30, y=20+(i>>3)*14;
        /* Existing 28x12 collision footprint remains unchanged. */
        block(x+1,y+1,28,12,p->panelEdge);
        block(x+1,y+1,28,10,brickColors[i>>3]);
        block(x+3,y+2,24,2,RGB(0xf4f6ee));
    }
    block(b->paddleX-20,216,40,7,p->pipeDark);
    block(b->paddleX-18,216,36,4,p->mint);
    block(b->paddleX-16,216,32,1,p->mintLight);
    int bx=(b->ballX>>4),by=(b->ballY>>4);
    block(bx-5,by-5,11,11,p->grid);
    block(bx-3,by-3,7,7,RGB(0xfff5c6));
    block(bx-2,by-2,4,4,RGB(0xffffff));
}

static void statusOverlay(const ArcadeState *a, const ArcadeColors *p)
{
    if(a->phase!=ARCADE_PAUSED && a->phase!=ARCADE_LOST &&
       a->phase!=ARCADE_WON && a->phase!=ARCADE_READY) return;
    if(a->phase==ARCADE_READY && a->kind==ARCADE_SNAKE) return;
    if(a->phase==ARCADE_READY) {
        block(32,99,176,42,p->panel);
        block(32,99,176,2,p->accent);
        textCenter(a->kind==ARCADE_FLAPPY ? "UP TO FLAP":"UP TO LAUNCH",
                   32,115,176,2,p->text);
    } else if(a->phase==ARCADE_PAUSED) {
        block(24,46,192,149,p->panel);
        block(24,46,192,2,p->accent);
        textCenter("PAUSED",24,59,192,3,p->text);
        static const char *const options[]={"RESUME","RESTART","EXIT"};
        for(int i=0;i<3;++i) {
            int y=92+i*31;
            if(a->pauseChoice==i) block(43,y-2,154,28,p->panelEdge);
            textCenter(options[i],43,y+4,154,2,a->pauseChoice==i?p->accent:p->text);
        }
    } else {
        block(28,91,184,63,p->panel);
        block(28,91,184,2,p->accent);
        textCenter(a->phase==ARCADE_WON?"YOU WIN":"GAME OVER",28,103,184,3,p->text);
        textCenter(a->phase==ARCADE_WON?"OK CONTINUE":"OK RESTART",
                   28,135,184,2,p->muted);
    }
}

void drawArcade(const ArcadeState *a)
{
    if(!a || a->kind>=ARCADE_COUNT) return;
    uint8_t theme=(uint8_t)settings.displayTheme;
    const ArcadeColors *p=&palettes[theme<3 ? theme : 1];
    switch(a->kind) {
    case ARCADE_SNAKE: snake(a,p); break;
    case ARCADE_2048: puzzle2048(a,p); break;
    case ARCADE_FLAPPY: flappy(a,p); break;
    case ARCADE_BREAKOUT: breakout(a,p); break;
    default: return;
    }
    sidebar(a,p);
    statusOverlay(a,p);
}
#endif /* GC01_ARCADE */
