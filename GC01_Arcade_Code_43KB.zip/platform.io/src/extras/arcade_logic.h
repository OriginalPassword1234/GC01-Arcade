/* Rad Pro 3.1.1 GC-01 arcade extension; MIT licensed. Pure game logic. */
#ifndef ARCADE_LOGIC_H
#define ARCADE_LOGIC_H
#include <stdint.h>
#include <stdbool.h>

typedef enum { ARCADE_SNAKE, ARCADE_2048, ARCADE_FLAPPY, ARCADE_BREAKOUT, ARCADE_COUNT } ArcadeKind;
typedef enum { ARCADE_READY, ARCADE_RUNNING, ARCADE_PAUSED, ARCADE_LOST, ARCADE_WON } ArcadePhase;
typedef enum { ARCADE_LEFT, ARCADE_RIGHT, ARCADE_UP, ARCADE_DOWN } ArcadeDirection;

typedef struct {
    uint8_t body[256];
    uint8_t occupied[32];
    uint8_t tail, direction, nextDirection, food;
    uint16_t length;
} ArcadeSnake;
typedef struct { uint8_t cells[16]; bool wonAlready; } Arcade2048;
typedef struct {
    int16_t y, velocity;
    int16_t pipeX[3];
    uint8_t pipeGap[3];
    uint8_t pipeScored[3];
} ArcadeFlappy;
typedef struct {
    uint8_t bricks[32];
    int16_t ballX, ballY, velocityX, velocityY;
    uint8_t paddleX, lives, level;
    uint8_t bricksLeft;
} ArcadeBreakout;

typedef struct {
    ArcadeKind kind;
    ArcadePhase phase;
    ArcadePhase previousPhase;
    uint8_t pauseChoice;
    uint32_t score;
    uint32_t randomState;
    union {
        ArcadeSnake snake;
        Arcade2048 puzzle;
        ArcadeFlappy flappy;
        ArcadeBreakout breakout;
    } game;
} ArcadeState;

void arcadeStart(ArcadeState *game, ArcadeKind kind, uint32_t seed);
void arcadeMove(ArcadeState *game, ArcadeDirection direction);
void arcadeStep(ArcadeState *game);
void arcadeBreakoutPaddle(ArcadeState *game, int8_t step);
void arcadePause(ArcadeState *game);
void arcadeChoosePause(ArcadeState *game);
#endif
