/* Rad Pro 3.1.1 GC-01 arcade extension; MIT licensed. Pure deterministic game logic. */
#if defined(GC01_ARCADE)
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "arcade_logic.h"

static uint32_t nextRandom(ArcadeState *a)
{
    uint32_t x = a->randomState;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    a->randomState = x;
    return x;
}

static uint32_t randomBelow(ArcadeState *a, uint32_t max)
{
    return nextRandom(a) % max; /* games only, not security or statistical RNG */
}

static bool snakeOccupied(const ArcadeSnake *s, uint8_t position)
{
    return (s->occupied[position >> 3] & (1u << (position & 7))) != 0;
}

static void setSnakeOccupied(ArcadeSnake *s, uint8_t position, bool value)
{
    uint8_t mask = (uint8_t)(1u << (position & 7));
    if (value) s->occupied[position >> 3] |= mask;
    else s->occupied[position >> 3] &= (uint8_t)~mask;
}

static void placeFood(ArcadeState *a)
{
    ArcadeSnake *s = &a->game.snake;
    if (s->length == 256) { a->phase = ARCADE_WON; return; }
    uint16_t available = 256u - s->length;
    uint16_t index = (uint16_t)randomBelow(a, available);
    for (uint16_t i = 0; i < 256; ++i)
        if (!snakeOccupied(s, (uint8_t)i))
            if (index-- == 0) { s->food = (uint8_t)i; return; }
}

static bool add2048Tile(ArcadeState *a)
{
    Arcade2048 *g = &a->game.puzzle;
    uint8_t freeCount = 0;
    for (uint8_t i = 0; i < 16; ++i) if (!g->cells[i]) ++freeCount;
    if (!freeCount) return false;
    uint8_t emptyIndex = (uint8_t)randomBelow(a, freeCount);
    for (uint8_t i = 0; i < 16; ++i)
        if (!g->cells[i] && emptyIndex-- == 0) {
            g->cells[i] = (randomBelow(a, 10) == 0) ? 2 : 1;
            return true;
        }
    return false;
}

static bool can2048Move(const Arcade2048 *g)
{
    for (int i = 0; i < 16; ++i) {
        if (!g->cells[i]) return true;
        if ((i % 4 < 3 && g->cells[i] == g->cells[i+1]) ||
            (i / 4 < 3 && g->cells[i] == g->cells[i+4])) return true;
    }
    return false;
}

static void step2048(ArcadeState *a, ArcadeDirection dir)
{
    Arcade2048 *g = &a->game.puzzle;
    bool changed = false, reached2048 = false;
    for (int line = 0; line < 4; ++line) {
        uint8_t input[4], output[4] = {0};
        for (int j = 0; j < 4; ++j) {
            int index = (dir == ARCADE_LEFT) ? 4*line+j :
                        (dir == ARCADE_RIGHT) ? 4*line+(3-j) :
                        (dir == ARCADE_UP) ? 4*j+line : 4*(3-j)+line;
            input[j] = g->cells[index];
        }
        int count = 0;
        for (int j = 0; j < 4; ++j) if (input[j]) {
            if (count && output[count-1] == input[j] && !(output[count-1] & 0x80)) {
                uint8_t merged = (uint8_t)((output[count-1] & 0x7f) + 1);
                if (merged > 30) merged = 30; /* score and tile values fit uint32_t */
                output[count-1] = (uint8_t)(merged | 0x80); /* merges once per turn */
                uint32_t points = 1u << merged;
                a->score = (UINT32_MAX - a->score < points) ? UINT32_MAX : a->score + points;
                if (merged >= 11 && !g->wonAlready) reached2048 = true;
            } else output[count++] = input[j];
        }
        for (int j = 0; j < 4; ++j) {
            int index = (dir == ARCADE_LEFT) ? 4*line+j :
                        (dir == ARCADE_RIGHT) ? 4*line+(3-j) :
                        (dir == ARCADE_UP) ? 4*j+line : 4*(3-j)+line;
            uint8_t value = output[j] & 0x7f;
            if (g->cells[index] != value) changed = true;
            g->cells[index] = value;
        }
    }
    if (changed) add2048Tile(a);
    if (reached2048) { g->wonAlready = true; a->phase = ARCADE_WON; }
    else if (!can2048Move(g)) a->phase = ARCADE_LOST;
}

static void initBricks(ArcadeBreakout *b)
{
    for (uint8_t i=0;i<32;++i) b->bricks[i] = 1;
    b->bricksLeft = 32;
    b->ballX = (int16_t)b->paddleX << 4;
    b->ballY = 206 << 4;
    uint8_t speedLevel = b->level > 7 ? 6 : (uint8_t)(b->level - 1);
    b->velocityX = (int16_t)(18 + 2 * speedLevel);
    b->velocityY = (int16_t)(-52 - 5 * speedLevel);
}

void arcadeStart(ArcadeState *a, ArcadeKind kind, uint32_t seed)
{
    memset(a, 0, sizeof(*a));
    a->kind = kind;
    a->randomState = seed ? seed : 0x6d2b79f5u;
    a->phase = ARCADE_RUNNING;
    if (kind == ARCADE_SNAKE) {
        ArcadeSnake *s = &a->game.snake;
        s->tail = 0; s->length = 3; s->direction = ARCADE_RIGHT; s->nextDirection = ARCADE_RIGHT;
        s->body[0] = 8 * 16 + 5; s->body[1] = 8 * 16 + 6; s->body[2] = 8 * 16 + 7;
        for (uint8_t i=0;i<3;++i) setSnakeOccupied(s,s->body[i],true);
        placeFood(a);
    } else if (kind == ARCADE_2048) {
        add2048Tile(a); add2048Tile(a);
    } else if (kind == ARCADE_FLAPPY) {
        ArcadeFlappy *f = &a->game.flappy;
        f->y = 115 << 4;
        for (int i=0;i<3;++i) {
            f->pipeX[i] = (int16_t)(175+i*100);
            f->pipeGap[i] = (uint8_t)(70+randomBelow(a,100));
        }
        a->phase = ARCADE_READY;
    } else if (kind == ARCADE_BREAKOUT) {
        ArcadeBreakout *b = &a->game.breakout;
        b->paddleX = 120; b->lives=3; b->level=1;
        initBricks(b);
        a->phase = ARCADE_READY;
    }
}

void arcadeMove(ArcadeState *a, ArcadeDirection direction)
{
    if (a->phase != ARCADE_RUNNING && a->phase != ARCADE_READY) return;
    if (a->kind == ARCADE_SNAKE) {
        ArcadeSnake *s = &a->game.snake;
        if ((s->direction ^ 1) != direction) s->nextDirection = (uint8_t)direction;
    } else if (a->kind == ARCADE_2048) {
        step2048(a, direction);
    } else if (a->kind == ARCADE_FLAPPY) {
        if (direction == ARCADE_UP) { a->phase = ARCADE_RUNNING; a->game.flappy.velocity = -72; }
    } else if (a->kind == ARCADE_BREAKOUT && direction == ARCADE_UP && a->phase == ARCADE_READY) {
        a->phase = ARCADE_RUNNING;
    }
}

void arcadeBreakoutPaddle(ArcadeState *a, int8_t step)
{
    if (a->kind != ARCADE_BREAKOUT || (a->phase != ARCADE_RUNNING && a->phase != ARCADE_READY)) return;
    ArcadeBreakout *b = &a->game.breakout;
    int16_t x = (int16_t)b->paddleX + step;
    if (x<21) x=21;
    if (x>218) x=218;
    b->paddleX=(uint8_t)x;
    if (a->phase == ARCADE_READY) b->ballX = x << 4;
}

static void snakeStep(ArcadeState *a)
{
    ArcadeSnake *s = &a->game.snake;
    s->direction = s->nextDirection;
    uint8_t head = s->body[(uint8_t)(s->tail+s->length-1)];
    int x = head & 15, y = head >> 4;
    if (s->direction == ARCADE_LEFT) --x;
    else if (s->direction == ARCADE_RIGHT) ++x;
    else if (s->direction == ARCADE_UP) --y;
    else ++y;
    if (x<0 || x>=16 || y<0 || y>=16) { a->phase=ARCADE_LOST; return; }
    uint8_t next = (uint8_t)(y*16+x);
    bool eating = next == s->food;
    if (snakeOccupied(s,next) && (eating || next != s->body[s->tail])) {
        a->phase=ARCADE_LOST; return;
    }
    if (!eating) {
        setSnakeOccupied(s,s->body[s->tail],false);
        ++s->tail;
        --s->length;
    }
    s->body[(uint8_t)(s->tail+s->length)]=next;
    ++s->length;
    setSnakeOccupied(s,next,true);
    if (eating) { ++a->score; placeFood(a); }
}

static void flappyStep(ArcadeState *a)
{
    ArcadeFlappy *f = &a->game.flappy;
    if (f->velocity < 62) f->velocity += 5;
    f->y += f->velocity;
    int birdY = f->y >> 4;
    if (birdY < 7 || birdY > 232) { a->phase=ARCADE_LOST; return; }
    int halfGap=38-(int)(a->score/3 > 8 ? 8 : a->score/3);
    for (int i=0;i<3;++i) {
        f->pipeX[i] -= 3;
        if (!f->pipeScored[i] && f->pipeX[i]+28<49) { ++a->score; f->pipeScored[i]=1; }
        if (f->pipeX[i] < -29) {
            int16_t maxX=240;
            for (int j=0;j<3;++j) if (f->pipeX[j]>maxX) maxX=f->pipeX[j];
            f->pipeX[i]=maxX+100;
            f->pipeGap[i]=(uint8_t)(70+randomBelow(a,100));
            f->pipeScored[i]=0;
        }
        if (f->pipeX[i] < 62 && f->pipeX[i]+28>43 &&
            (birdY-7 < (int)f->pipeGap[i]-halfGap || birdY+7 > (int)f->pipeGap[i]+halfGap)) {
            a->phase=ARCADE_LOST; return;
        }
    }
}

static void breakoutStep(ArcadeState *a)
{
    ArcadeBreakout *b = &a->game.breakout;
    b->ballX += b->velocityX;
    b->ballY += b->velocityY;
    int x=b->ballX>>4, y=b->ballY>>4;
    if (x<4) { b->ballX=4<<4; b->velocityX=(int16_t)-b->velocityX; }
    if (x>235) { b->ballX=235<<4; b->velocityX=(int16_t)-b->velocityX; }
    if (y<5) { b->ballY=5<<4; b->velocityY=(int16_t)-b->velocityY; }
    if (b->velocityY>0 && y>=210 && y<=220 && x>=b->paddleX-22 && x<=b->paddleX+22) {
        b->velocityY=(int16_t)-b->velocityY;
        b->velocityX=(int16_t)((x-(int)b->paddleX)*2);
        if (b->velocityX==0) b->velocityX=4;
        b->ballY=209<<4;
    }
    if (y>=238) {
        if (--b->lives==0) a->phase=ARCADE_LOST;
        else { a->phase=ARCADE_READY; b->ballX=(int16_t)b->paddleX<<4; b->ballY=206<<4; b->velocityX=(int16_t)(18 + 2*(b->level>7?6:b->level-1));
            b->velocityY=(int16_t)(-52 - 5*(b->level>7?6:b->level-1)); }
        return;
    }
    if (y>=20 && y<76 && x>=0 && x<240) {
        int row=(y-20)/14, col=x/30, idx=row*8+col;
        if (row<4 && b->bricks[idx]) {
            b->bricks[idx]=0; --b->bricksLeft; a->score+=10;
            b->velocityY=(int16_t)-b->velocityY;
            if (b->bricksLeft==0) {
                if (b->level<255) ++b->level;
                initBricks(b); a->phase=ARCADE_READY;
            }
        }
    }
}

void arcadeStep(ArcadeState *a)
{
    if (a->phase != ARCADE_RUNNING) return;
    switch (a->kind) {
    case ARCADE_SNAKE: snakeStep(a); break;
    case ARCADE_FLAPPY: flappyStep(a); break;
    case ARCADE_BREAKOUT: breakoutStep(a); break;
    default: break;
    }
}

void arcadePause(ArcadeState *a)
{
    if (a->phase==ARCADE_PAUSED) { a->phase=a->previousPhase; return; }
    if (a->phase==ARCADE_RUNNING || a->phase==ARCADE_READY) {
        a->previousPhase=a->phase; a->phase=ARCADE_PAUSED; a->pauseChoice=0;
    } else if (a->phase==ARCADE_LOST || a->phase==ARCADE_WON) {
        uint32_t seed=a->randomState;
        ArcadeKind kind=a->kind;
        if (kind == ARCADE_2048 && a->phase==ARCADE_WON) a->phase=ARCADE_RUNNING;
        else arcadeStart(a,kind,seed);
    }
}

void arcadeChoosePause(ArcadeState *a)
{
    if (a->phase!=ARCADE_PAUSED) return;
    if (a->pauseChoice==0) { a->phase=a->previousPhase; }
    else if (a->pauseChoice==1) arcadeStart(a,a->kind,a->randomState);
    /* Exit choice handled by UI to restore keyboard mode. */
}

#endif /* GC01_ARCADE */
