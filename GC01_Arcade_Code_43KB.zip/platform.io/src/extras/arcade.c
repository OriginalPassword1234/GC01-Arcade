/* Rad Pro 3.1.1 GC-01 arcade extension; MIT licensed. UI and scheduling. */
#if defined(GC01_ARCADE)
#include <stdint.h>
#include <stdbool.h>

#include "arcade_logic.h"
#include "game.h"
#include "../measurements/measurements.h"
#include "../peripherals/keyboard.h"
#include "../system/events.h"
#include "../system/power.h"
#include "../system/settings.h"
#include "../ui/arcade.h"
#include "../ui/menu.h"
#include "../ui/view.h"

static ArcadeState arcade;
static bool arcadeActive;
static uint32_t lastStepTick;
static MenuState arcadeMenuState;
static const Menu arcadeMenu;

static void leaveArcade(void)
{
    arcadeActive=false;
    setKeyboardMode(KEYBOARD_MODE_MENU);
    showGameMenu();
}

static void onArcadeViewEvent(ViewEvent event)
{
    switch(event) {
    case EVENT_KEY_GAME_EXIT:
        leaveArcade();
        break;
    case EVENT_KEY_GAME_OK:
        if (arcade.phase == ARCADE_PAUSED && arcade.pauseChoice == 2) leaveArcade();
        else if (arcade.phase == ARCADE_PAUSED) arcadeChoosePause(&arcade);
        else arcadePause(&arcade);
        lastStepTick=currentTick;
        requestViewUpdate();
        break;
    case EVENT_KEY_GAME_UP:
    case EVENT_KEY_GAME_DOWN:
        if (arcade.phase == ARCADE_PAUSED) {
            arcade.pauseChoice = (uint8_t)((arcade.pauseChoice +
                (event==EVENT_KEY_GAME_UP ? 2 : 1)) % 3);
        } else arcadeMove(&arcade, event==EVENT_KEY_GAME_UP ? ARCADE_UP : ARCADE_DOWN);
        requestViewUpdate();
        break;
    case EVENT_KEY_GAME_LEFT:
    case EVENT_KEY_GAME_RIGHT:
        if (arcade.phase != ARCADE_PAUSED) {
            /* Support short taps as well as held-button paddle movement. */
            if (arcade.kind == ARCADE_BREAKOUT)
                arcadeBreakoutPaddle(&arcade, event==EVENT_KEY_GAME_LEFT ? -8 : 8);
            else
                arcadeMove(&arcade, event==EVENT_KEY_GAME_LEFT ? ARCADE_LEFT : ARCADE_RIGHT);
        }
        requestViewUpdate();
        break;
    case EVENT_DRAW:
        drawArcade(&arcade);
        break;
    default:
        break;
    }
}

static const char *getArcadeOption(menu_size_t index, MenuStyle *style)
{
    static const char *const titles[ARCADE_COUNT] = {"Snake", "2048", "Flappy Bird", "Breakout"};
    *style = MENUSTYLE_SUBMENU;
    return (index < ARCADE_COUNT) ? titles[index] : "";
}

static void selectArcadeOption(menu_size_t index)
{
    if (index >= ARCADE_COUNT) return;
    arcadeStart(&arcade, (ArcadeKind)index, currentTick ^ 0xa12e24f3u);
    arcadeActive=true;
    lastStepTick=currentTick;
    setKeyboardMode(KEYBOARD_MODE_GAME);
    showView(onArcadeViewEvent);
}

static const Menu arcadeMenu = {
    STRING_GAME,
    &arcadeMenuState,
    ARCADE_COUNT,
    getArcadeOption,
    selectArcadeOption,
    showSettingsMenu,
};

void resetGame(void)
{
    arcadeActive=false;
    selectMenuItem(&arcadeMenu,0);
}

void showGameMenu(void)
{
    if (isKeyboardGameMode()) setKeyboardMode(KEYBOARD_MODE_MENU);
    arcadeActive=false;
    showMenu(&arcadeMenu);
}

/* Called only by the main loop, never from the 1kHz timer interrupt. */
void updateGame(void)
{
    if (!arcadeActive) return;
    if (!isPoweredOn() || !isKeyboardGameMode()) { arcadeActive=false; return; }
    /* Active radiation alarms take priority over all game transitions. */
    if (getAlertLevel() != ALERTLEVEL_NONE) {
        arcadeActive=false;
        setMeasurementView();
        return;
    }
    /* Never continue game execution after another module replaces this view. */
    if (!isCurrentView(onArcadeViewEvent)) {
        arcadeActive = false;
        setKeyboardMode(KEYBOARD_MODE_MENU);
        return;
    }
    uint32_t now=currentTick;
    if (!isDisplayAwake()) { lastStepTick=now; return; }

    uint32_t period;
    switch (arcade.kind) {
    case ARCADE_SNAKE: period=(uint32_t)(220 - (arcade.score < 12 ? arcade.score*10 : 120)); break;
    case ARCADE_FLAPPY: period=80; break;
    case ARCADE_BREAKOUT: period=80; break;
    default: return;
    }
    if ((uint32_t)(now-lastStepTick)<period) return;
    lastStepTick=now;
    if (arcade.phase != ARCADE_RUNNING &&
        !(arcade.kind == ARCADE_BREAKOUT && arcade.phase == ARCADE_READY)) return;
    bool movedPaddle = false;
    if (arcade.kind==ARCADE_BREAKOUT) {
        /* Sample held buttons. Left may move the paddle while being held to exit. */
        bool left=isGameKeyHeld(KEY_LEFT);
        bool right=isGameKeyHeld(KEY_RIGHT);
        if (left!=right) {
            arcadeBreakoutPaddle(&arcade,left ? -5 : 5);
            movedPaddle=true;
        }
    }
    if (arcade.phase == ARCADE_RUNNING) arcadeStep(&arcade);
    if (arcade.phase == ARCADE_RUNNING || movedPaddle) requestViewUpdate();
}
#endif
