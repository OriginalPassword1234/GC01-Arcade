# FNIRSI GC-01 Rad Pro 3.1.1 — source regression audit

**Status: SOURCE ONLY — NOT A COMPILED OR FLASHABLE FIRMWARE.**

This audit compares the modified tree against the user-provided exact Rad Pro 3.1.1 source and checks the four-game extension. It cannot guarantee the absence of bugs, nor certify the modified unit for radiation measurements.

## Original-firmware preservation

- Original source tree: 604 files. All 604 still exist; 597 are **byte-identical** to the reference.
- Exactly **seven existing files** differ: `platform.io/platformio.ini`, `platform.io/src/extras/game.c`, `platform.io/src/ui/game.c`, `platform.io/src/peripherals/keyboard.c`, `platform.io/src/peripherals/keyboard.h`, `platform.io/src/ui/view.c`, `platform.io/src/ui/view.h`.
- Five new *device* modules: `src/extras/arcade.c`, `src/extras/arcade_logic.c`, `src/extras/arcade_logic.h`, `src/ui/arcade.c`, `src/ui/arcade.h`.
- All existing measurement, radiation pulse, alarm, logging, USB, power, flash-access, tube, hardware startup, timebase, linker, saved settings, signing and display driver files are byte-identical.
- The original chess implementations in `extras/game.c` and `ui/game.c` are preserved text-for-text behind a conditional compiler guard and remain available in other build configurations. `GC01_ARCADE` is defined in **only** the English APM32 GC-01 PlatformIO environment.
- Existing numeric `ViewEvent` values are unaltered; game-specific events are appended.
- The only original control behavior changes are scoped to the new game keyboard mode. Existing measurement/menu modes retain their event behavior; the stock-versus-modified event-trace comparison passes.
- `ui/view.c` has an added read-only view-ownership query behind `GC01_ARCADE`; all original view function bodies are unchanged.
- Verify these claims again with: `python arcade-tests/verify_preservation.py /path/to/untouched/radpro-3.1.1`.

## Bugs and risks found and mitigated in this audit

1. **Interrupt/main-loop key samples:** Breakout originally read a non-`volatile` keyboard sampling array directly from the main loop. It now uses a game-scoped keyboard accessor that performs volatile reads; old modes are unaffected.
2. **Unintended game updates after UI replacement:** An unrelated view could take over without changing keyboard mode. The arcade controller now checks active view ownership and stops game execution if its view is no longer current. It does not change normal view transitions.
3. **Lost long-Left exit / system controls under input queue pressure:** In game mode only, game exit, power-off and keyboard-lock events are delivered via an urgent event slot, rather than competing with the original eight-entry key queue. Tested under artificial queue flooding. Existing modes use the original queue.
4. **Breakout short taps:** Its paddle previously moved only when a held key coincided with a scheduled update. Short Left/Right game events now move the paddle too, without altering other game controls.
5. **Alert priority:** Active radiation alerts are checked before the view-ownership fallback, returning to the measurement view when playing a game.

## Software tests executed

- `sh arcade-tests/run.sh`: PASS. Host GCC unit tests, including AddressSanitizer/UndefinedBehaviorSanitizer for game logic and integration.
- 20,000 randomized 2048 moves checked against an *independent* reference line-merger, including score updates and whether a new tile appears only after a valid move: PASS.
- Snake filled-board (256 cells) and vacated-tail movement edge cases: PASS.
- Game keyboard test: short/long Left, OK/long OK, lock chord, wake from sleep, held key samples, input-queue pressure: PASS.
- Menu/game view integration: selection, exits, pause, alert return, unexpected view changes, Breakout tap: PASS.
- `sh arcade-tests/compare_legacy.sh`: PASS. Stock and modified keyboard modules produce **identical** events for the tested measurement/menu input sequences.
- ARM Cortex-M3 Clang `-Os` object-only compilation with `-Wall -Wextra -Werror` of the five modified/new C implementation modules (`arcade_logic`, `arcade`, UI arcade, keyboard, UI view): PASS.

## Preliminary memory comparison only (not linked firmware)

- New game modules: approximately 4,869 bytes `.text` and 329 bytes `.bss` from separate Clang Cortex-M3 objects, **before** link-time optimization and final linking.
- Stock chess engine + original chess controller/UI in a prior comparable object-only test: approximately 5,133 bytes `.text`, 652 bytes `.bss`.
- These cannot establish final flash or RAM headroom. PlatformIO ARM GCC builds, a linker map, signing-size verification, stack analysis, and device testing are still required.
- User-provided known-working original binary SHA-256: `11f764cc99f2356e8c0b4bec748b966f4cea0c6549b89d96e099a2e132f35088` (unchanged).
- Original uploaded source ZIP SHA-256: `c998b5bab67c74fe6be2311f94adedbf9a23838c0e040dcc65cf19a87a30cadc` (unchanged).

## Unresolved issues that prevent calling this ready to flash

1. No full original baseline build and no complete customized ARM GCC/PlatformIO linking; installed cross-compiler and PlatformIO dependencies unavailable here.
2. Final flash size against the **56 KiB signed application partition**, final static RAM, stack high-water mark and runtime memory margin unverified.
3. Real LCD drawing throughput and CPU servicing latency under Flappy Bird/Breakout redraw load unmeasured. The hardware display uses GPIO-driven parallel writes, not a full framebuffer.
4. External USB communication, radiation alarm latency, radiation pulse counting, saved settings and data-logging regression under real hardware load untested.
5. Bootloader treatment of padded storage region, firmware-install variant, and possible erasure of recorded measurements are unverified.
6. The original firmware's saved measurement history is not guaranteed to survive reflashing. Backups must be planned before any installation.
7. All four games need user-facing controller/display usability testing on a simulator or actual hardware.

## Safety gate

**Do not flash any ZIP or source file.** A candidate installable binary should be produced only after reproducible complete ARM GCC builds, memory-map review, signed-image checks, source diff approval, and recovery planning. Even then, radiation-detector measurement and alarm reliability require hardware comparison tests.
