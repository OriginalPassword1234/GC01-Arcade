# FNIRSI GC-01 Rad Pro 3.1.1 — Four-game source modification

**STATUS: SOURCE-ONLY DEVELOPMENT BUILD. NOT FLASHABLE.**

The modification is restricted to the **English APM32F103RB** build environment `fnirsi-gc01_apm32f103rb-en`, activated by `GC01_ARCADE` in `platform.io/platformio.ini`.

## Features implemented in source

- Replaces chess in this one firmware target with a four-item Game menu: Snake, 2048, Flappy Bird, Breakout.
- Snake: 16x16 field, food, growth, score, collision/game-over, progressive speed.
- 2048: 4x4, one merge per tile per move, 2/4 spawning, scoring, win/loss, continue after winning.
- Flappy Bird: flap, three pipes, score, pipe and screen collisions, narrowing gaps.
- Breakout: 32 bricks, paddle, ball, lives, launch, successive levels with increased speed.
- Shared pause/restart/exit control and colored drawing on the original GC-01 LCD driver.
- Game-only physical keyboard mode: **hold Left for 1 second to exit**; short Left is a normal game input. Long OK power-off and Left+OK lock events retain existing priority.
- All original measurement, alarm, logging, USB, power, flash and linker source files are kept unchanged. The firmware automatically switches to the measurement screen when an alert is detected while playing.
- Audit fixes: game-only volatile held-key access, urgent long-Left/power/lock event handling, active-view ownership check, and short-tap Breakout paddle response. See `ARCADE_REGRESSION_AUDIT.md`.
- No high scores or other game data written to flash.

## Build and verification status

- Pure game logic: passed host GCC tests with AddressSanitizer and UndefinedBehaviorSanitizer, including randomized simulations.
- Keyboard: passed mock 5-key hardware tests for short/long Left, OK, direction presses, sleep, and Left+OK lock shortcut.
- Integration: passed mock menu, view, exit, unexpected view ownership, Breakout short-tap, and alert transitions.
- Regression: compared actual stock and arcade keyboard modules under identical ordinary measurement/menu input traces (identical).
- Deep game logic: compared 20,000 random 2048 moves against an independent merge oracle, plus Snake full-board and tail-vacating scenarios (passed).
- Source-preservation audit: 597 original files byte-identical; exactly seven authorized originals differ; all original measurement, logging, startup, linker, storage and USB implementations unchanged.
- ARM: the newly added logic, controller, UI and modified keyboard source compiled separately to ARM Cortex-M3 objects using Clang `--target=arm-none-eabi -mcpu=cortex-m3 -mthumb -Os`. This is **not a linked firmware build**.
- Exact PlatformIO ARM GCC build: **not done**, required toolchain unavailable in this environment.
- Complete firmware memory map, signed `.bin`, hardware display performance, measured CPU/stack use, alarm testing, installer behavior and log preservation: **NOT VERIFIED**.

Under the approximate Clang ARM `-Os` object-only experiment, the three new game modules occupy about 4.8 KiB of `.text`, and the new game controller has 329 bytes of `.bss` including game state. The old chess engine and its two game modules are about 5.1 KiB of `.text` and 652 bytes of `.bss` in a separate object-only experiment. **These are not linked-image sizes and cannot establish firmware headroom.** Link-time optimization and GCC differ.

## Flash safety

The original GC-01 English application partition is 56 KiB (`FIRMWARE_SIZE=0xe000`) with the final 4 bytes reserved for CRC. **A successful link is insufficient.** Use original `tools/sign.py` to check size and create the correctly padded signed image, then verify vector addresses, CRC, flash boundary, RAM usage and persistent-storage handling. No binary in this package is a candidate for flashing.

## Reproducible tests

From the top-level modified source folder, with a native GCC compiler installed:

```
sh arcade-tests/run.sh
sh arcade-tests/compare_legacy.sh
python arcade-tests/verify_preservation.py /path/to/untouched/radpro-3.1.1
```

The `arcade-tests` directory is host-side test code and is **not** included in device builds.

## Source changes

Modified original files:
- `platform.io/platformio.ini` (English APM32 env only)
- `platform.io/src/extras/game.c` (original chess kept for all other builds)
- `platform.io/src/ui/game.c` (original chess graphics kept for all other builds)
- `platform.io/src/peripherals/keyboard.c`
- `platform.io/src/peripherals/keyboard.h`
- `platform.io/src/ui/view.h`
- `platform.io/src/ui/view.c` (new read-only getter only)

New files:
- `platform.io/src/extras/arcade.c`
- `platform.io/src/extras/arcade_logic.c`
- `platform.io/src/extras/arcade_logic.h`
- `platform.io/src/ui/arcade.c`
- `platform.io/src/ui/arcade.h`

The original `settings.h`, `measurements/`, `stm32/`, `scripts/gc01.ld`, and `tools/sign.py` remain byte-identical.

## Known limitations

This is the **first integrated source implementation**, not a hardware-tested production image. Whole-screen drawing performance and button ergonomics need device or simulator validation. No saved high scores or graphics assets were added; 2048's numerical score saturates at 32-bit range. Pausing uses OK and a resume/restart/exit menu; a long Left exits directly without a prompt.

Do not use a modified radiation detector as a safety-critical instrument until its measurement/alert/logging behavior has been independently tested.

## Updated graphics pass (7 November 2026)

Procedural polished graphics for all four games are now implemented in `platform.io/src/ui/arcade.c`, using RGB565 rectangles and a tiny ROM pixel font. The code supports all three Rad Pro display themes, adds no new framebuffer or bitmap resources and retains every existing original-firmware module unchanged during this graphics update. Full details, test results and object-only size estimates are in `ARCADE_GRAPHICS_AUDIT.md`.

Run `sh arcade-tests/run_graphics.sh` to exercise graphics and clipping, in addition to the original arcade tests. This is still **source-only**; no linked or signed APM32 firmware exists.
