# Rad Pro 3.1.1 GC-01 — Procedural arcade graphics update

**SOURCE ONLY. NOT AN INSTALLABLE FIRMWARE IMAGE.**

## Scope of this update

Only the new GC-01-specific graphics implementation `platform.io/src/ui/arcade.c` was changed. No pre-existing Rad Pro measurement, power, logging, flash, alarm, USB, bootloader, keyboard, linker, or display-driver source was changed during this graphics pass. All pre-existing arcade gameplay and input code was retained as-is.

## Visual design, without image assets

- All games use the existing **320x240** screen and the **240x240 playfield + 80px sidebar** arrangement.
- The existing `mcu-renderer` RGB565 fill-rectangle API is used; no bitmap files, texture assets, dynamic allocation, or new framebuffer.
- Three palettes are provided for the Rad Pro **light**, **dark**, and **retro** display themes. They are constant tables in firmware flash.
- A compact **3x5 ROM pixel font** (72 bytes of glyph data) provides readable sidebar text and dynamically scaled 2048 numbers; no new large glyph font is linked.
- Snake: sparse grid, two-tone body, identifiable head and eyes, two-tone fruit with leaf.
- 2048: 13 tile colors and shadow/highlight, numbers automatically scale to fit up to exponent 30.
- Flappy Bird: sky layers, clouds, highlighted green pipes, small yellow bird with wing, eye and beak.
- Breakout: multicolored bricks with highlight, three-tone paddle, luminous square ball.
- Overlays: uniform Ready, Pause, Game Over and Win cards.
- No permanent on-screen Left-exit hint: the device button already indicates exit.

## Offline checks performed

- Native GCC `-Wall -Wextra -Werror` compilation of new graphics module: PASS.
- ARM Cortex-M3 Clang `-mcpu=cortex-m3 -mthumb -Os` object-only compilation with `-Wall -Wextra -Werror`: PASS.
- Offscreen mock renderer generated twelve true 320x240 samples (4 games x 3 themes); visual inspection done.
- 3 themes x 4 games x running/paused/lost/won; no out-of-bounds rectangles in sanitizer test.
- Extremes: Snake 256 occupied cells; 2048 exponent 30 and defensive clamp of corrupted exponent values: PASS.
- `sh arcade-tests/run_graphics.sh`: PASS under AddressSanitizer/UndefinedBehaviorSanitizer.
- Existing `sh arcade-tests/run.sh`: PASS, including randomized 2048 merge oracle and input integration.
- Existing `sh arcade-tests/compare_legacy.sh`: PASS, identical ordinary measurement and menu keyboard trace.
- Preservation audit: 604 stock files still present, 597 stock files byte-identical; 7 authorized original game/integration files modified as before.

## Memory: object-only estimate, not a final firmware measurement

ARM Clang Cortex-M3 `-Os`, unlinked object files:

| UI arcade module | `.text` plus ROM constants | Static `.bss` |
|---|---:|---:|
| Previous graphics | 1,707 B | 0 B |
| New graphics | 3,266 B | 0 B |
| Approximate increase | **1,559 B** | **0 B** |

Caveat: These are separate Clang object sizes, not the final GCC/PlatformIO linked firmware sizes or stack high-water marks. Final flash headroom is **not known**. The new graphics cause more display rectangle calls, and their real-world frame time is **not measured**.

## Required before any `.bin` is considered for flashing

1. Reproducible stock and modified **ARM GCC PlatformIO** builds.
2. Linker map and signed-payload size check against 57,340 bytes before CRC; verify RAM and stack usage.
3. Render performance and event responsiveness tests on GC-01 hardware or an equivalent simulator.
4. Confirm no loss of radiation alarms, pulse counting, logging, USB and settings under game load.
5. Verify bootloader image-format and erase behavior; preserve the known-working firmware and back up logs/settings.

**Do not flash any files in this source package.**
