#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "extras/game.h"
#include "extras/arcade_logic.h"
#include "peripherals/keyboard.h"
#include "measurements/measurements.h"
#include "ui/menu.h"
#include "ui/view.h"
#include "system/events.h"

volatile uint32_t currentTick;
uint32_t keyboardKeyDown[KEY_NUM];
static KeyboardMode mode;
static const Menu *lastMenu;
static OnViewEvent *viewHandler;
static bool measurementShown;
static int redraws;
static uint8_t lastPaddle;
static AlertLevel alert;
void setKeyboardMode(KeyboardMode next) {mode=next;}
bool isGameKeyHeld(Key key) {(void)key;return false;}
bool isCurrentView(OnViewEvent *handler) {return viewHandler == handler;}
bool isKeyboardGameMode(void) {return mode==KEYBOARD_MODE_GAME;}
bool isPoweredOn(void) {return true;}
bool isDisplayAwake(void) {return true;}
AlertLevel getAlertLevel(void) {return alert;}
void setMeasurementView(void) {measurementShown=true;mode=KEYBOARD_MODE_MEASUREMENT;}
void showMenu(const Menu *m) {lastMenu=m;viewHandler=NULL;}
void showView(OnViewEvent *callback) {viewHandler=callback;lastMenu=NULL;}
void selectMenuItem(const Menu *menu,menu_size_t index) {menu->state->selectedIndex=index;}
void showSettingsMenu(void) {}
void requestViewUpdate(void) {++redraws;}
void drawArcade(const ArcadeState *game) {if (game->kind==ARCADE_BREAKOUT) lastPaddle=game->game.breakout.paddleX;}
/* From the independent hardware keyboard driver: only game-specific events are directly injected. */
int main(void) {
    resetGame(); showGameMenu();
    assert(lastMenu && lastMenu->itemCount==4);
    for(int g=0;g<4;++g) {
        assert(lastMenu && lastMenu->onSelect);
        lastMenu->onSelect(g);
        assert(viewHandler && mode==KEYBOARD_MODE_GAME);
        viewHandler(EVENT_DRAW);
        viewHandler(EVENT_KEY_GAME_UP);
        viewHandler(EVENT_KEY_GAME_OK);
        viewHandler(EVENT_KEY_GAME_DOWN);
        viewHandler(EVENT_KEY_GAME_OK);
        currentTick+=1000;updateGame();
        viewHandler(EVENT_KEY_GAME_EXIT);
        assert(lastMenu && mode==KEYBOARD_MODE_MENU);
        int last=redraws;
        currentTick+=1000;updateGame();assert(redraws==last);
    }
    lastMenu->onSelect(3);
    assert(mode==KEYBOARD_MODE_GAME);
    viewHandler(EVENT_DRAW);
    uint8_t xBefore=lastPaddle;
    viewHandler(EVENT_KEY_GAME_RIGHT);
    viewHandler(EVENT_DRAW);
    assert(lastPaddle>xBefore); /* Short taps must move the paddle. */
    alert=ALERTLEVEL_ALARM;
    currentTick+=300;updateGame();
    assert(measurementShown && mode==KEYBOARD_MODE_MEASUREMENT);
    alert=ALERTLEVEL_NONE;
    measurementShown=false;
    showGameMenu();
    lastMenu->onSelect(0);
    assert(mode==KEYBOARD_MODE_GAME);
    /* An unrelated module can replace the active view unexpectedly. */
    showView(NULL);
    currentTick+=1000;
    updateGame();
    assert(mode==KEYBOARD_MODE_MENU);
    puts("Game/menu/exit/alert/view-ownership integration tests passed.");
}
