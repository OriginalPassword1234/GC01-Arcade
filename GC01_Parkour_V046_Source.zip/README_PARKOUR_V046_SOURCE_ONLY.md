# GC-01 Parkour Gauntlet 0.4.6 — source-only candidate

**Do not flash this source ZIP.** Target is FNIRSI GC-01 APM32F103RB, English, Rad Pro 3.1.1. The original 16 KB bootloader, application address (0x08004000), settings and log partitions, and 57,340-byte raw-application limit are unchanged.

## Controls

- LEFT/RIGHT: movement only; no actions on long directional holds.
- UP: jumping and wall jumps; hold against a real wall to grip temporarily. A short collision-checked ledge pull-up works only when the character is already beside the top of a wall, not as an upward boost on a vertical wall.
- DOWN quick release (under 0.46 s): throwing dagger. Damage 1 HP, cooldown 1.2 seconds, approximate 56-logical-pixel range, at most one dagger active, no ammo or mana. Nothing happens until release.
- DOWN long release: ground slam; 1 HP each to nearby enemies, cooldown 2 seconds. Does not activate the dagger first.
- MIDDLE short: sword attack (2 HP, ~0.3 s recovery); a perfectly timed slash can reflect an incoming hostile projectile. MIDDLE medium: game pause/menu. MIDDLE long: normal power-off action remains under the existing keyboard controller.
- Player health regenerates around 3 HP/s after 3 seconds without damage.

## Gameplay and art

- Preserves full-color pixel art, three themed environments, responsive fixed-step physics, three room orientations, wall-jumping and gripping, bouncing and breakable platforms, elevated doorways, enemy types, and boss every sixth room.
- Boss retains rush and volley and adds a telegraphed ground shockwave. Advanced rooms have narrower, more fragile ledges. Later non-boss rooms introduce one oscillating electrical orb, using the existing collision and graphics system.
- Projectile pool is reused for dagger, sword reflections, and shockwaves. Existing sprites remain 4-bit indexed and fully detailed. No game-art reduction or compact-game fallback.
- Renderer uses the same 512-byte RGB565 tile buffer. Dirty-tile flags have been compressed from 260 to 33 bytes of RAM. The renderer's full and partial outputs pass pixel-for-pixel regression testing for sampled scenes.

## Device safety / optimization

- Does NOT change measurement processing, tube voltage/calibration, dose calculation, alarms, history graph display, persistent logging, data download, USB, battery, power, bootloader, signing or storage partitions.
- All three Rad Pro display themes remain. Previously excluded chess and optional RNG menus stay excluded; the underlying random-byte source needed for USB is preserved.
- Link-time dead-code removal, section-based compilation and compressed game sprites remain. A matching GitHub workflow tests a secondary code-size compiler profile and optionally applies upstream 2-bpp Rad Pro fonts only if necessary. This font fallback preserves glyph sizes but may slightly change instrument text edge antialiasing. Game art is unchanged.
- No 1–3 KB saving is claimed without a measured full ARM build. The build checks the same strict 57,340-byte limit before producing any signed candidate.

## Tests / known limitations

- Native GCC and Clang with AddressSanitizer/UBSan, normal and legacy compact define: 8 passing configurations; 600 randomized 520-tick simulations per configuration, projectile controls, sword reflection, boss patterns, hazards, ledge mantles, camera rendering.
- 184 RGB565 dirty/full comparisons per drawing test configuration.
- Locally ARM Cortex-M3 game objects were compiled with Clang for approximate sizes only. Full PlatformIO ARM build and size verification must run in GitHub Actions. No claim of perfect bug-free behavior, hardware performance or measurement equivalence is made.

## Build

1. Upload `GC01_Parkour_V046_Source.zip` UNEXTRACTED to the root of your GitHub repository.
2. Replace the CONTENTS of `.github/workflows/GC01_Dungeon_Prototype_Build.yml` with the matching downloaded workflow. Do not delete the file/folder.
3. Run the workflow named `GC-01 Parkour Gauntlet 0.4.6 - build, optimize, verify and sign EXPERIMENTAL` on main.
4. Download the new signed artifact only after the green success; examine `SIZE_REPORT.txt` and `BUILD_VARIANT.txt`, and have its ZIP reviewed before considering hardware flashing.

Keep your previously working firmware and recovery method available. Do not rely on experimental builds for radiation-safety measurements.
