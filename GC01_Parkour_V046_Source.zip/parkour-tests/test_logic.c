/* Parkour 0.4.6 native deterministic physics/control regression. MIT. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../platform.io/src/extras/parkour_logic.h"
#define FP 16
static void quiet(PG_Game *g) {
    pg_new(g,0x12345678u);
    memset(g->cells,PG_AIR,sizeof(g->cells));
    for(int x=0;x<PG_COLS;x++) {
        g->cells[22*PG_COLS+x]=PG_STONE;
        g->cells[23*PG_COLS+x]=PG_STONE;
    }
    memset(g->enemies,0,sizeof(g->enemies));
    memset(g->shots,0,sizeof(g->shots));
    g->enemyCount=0;g->roomStyle=0;
    g->x=20*FP;g->y=(PG_H-30)*FP;
    g->vx=0;g->vy=0;g->grounded=1;g->previousInput=0;
    g->invulnerable=0;
}
static void movement(void) {
    PG_Game g;
    quiet(&g);
    pg_tick(&g,PG_UP);
    assert(g.vy<0 && !g.grounded);
    for(int i=0;i<60;i++)pg_tick(&g,0);
    assert(g.grounded&&g.y==(PG_H-30)*FP&&g.vy==0);

    quiet(&g);
    for(int col=2;col<=4;col++)g.cells[19*PG_COLS+col]=PG_PLATFORM;
    pg_tick(&g,PG_UP);
    for(int i=0;i<9;i++)pg_tick(&g,PG_UP);
    assert(g.y<(PG_H-54)*FP);
    for(int i=0;i<60;i++)pg_tick(&g,0);
    assert(g.grounded&&g.y==(19*8-PG_PLAYER_H)*FP);

    /* No penetration through solid wall at any allowed velocity. */
    quiet(&g);
    for(int row=13;row<=21;row++)g.cells[row*PG_COLS+10]=PG_STONE;
    for(int i=0;i<130;i++)pg_tick(&g,PG_RIGHT);
    assert(g.x+PG_PLAYER_W*FP<=80*FP);
    assert(g.x>=0);

    /* Walk room transitions without relying on chance or random seed:
     * real generated vertical and mixed rooms must have elevated exits. */
    pg_new(&g,77);
    unsigned seen[3]={0,0,0};
    for(int r=0;r<12;r++) {
        assert(g.room==(uint16_t)r);
        assert(g.roomStyle==r%3);
        seen[g.roomStyle]++;
        int exitCol=-1,exitRow=-1,exitCount=0;
        for(int row=0;row<PG_WORLD_ROWS;row++)
            for(int col=0;col<PG_COLS;col++)
                if(g.cells[row*PG_COLS+col]==PG_EXIT) {
                    exitRow=row;exitCol=col;exitCount++;
                }
        assert(exitCol==18);
        assert(exitCount==9); /* clear three-by-three doorway */
        if(g.roomStyle) {
            assert(exitRow==3);
            for(int y=19;y>=4;y-=3) {
                int hasPlatform=0;
                for(int x=0;x<PG_COLS;x++)
                    hasPlatform+=(g.cells[y*PG_COLS+x]==PG_PLATFORM);
                assert(hasPlatform>=4); /* vertical stepping stones exist */
            }
        } else assert(exitRow==21);
        g.x=(int16_t)((exitCol*8-5)*FP);
        g.y=(int16_t)((exitRow*8-5)*FP);
        if(r%6==5) {
            assert(g.enemyCount==1 && g.enemies[0].kind==PG_BOSS);
            /* The next room must remain locked before the boss dies. */
            g.vx=g.vy=0;g.grounded=1;
            pg_tick(&g,0);
            assert(g.room==(uint16_t)r);
            g.enemies[0].hp=0;
        }
        g.vx=g.vy=0;
        g.grounded=1;
        pg_tick(&g,0);
        assert(g.room==(uint16_t)(r+1));
    }
    assert(seen[0]>=3 && seen[1]>=3 && seen[2]>=3);
    /* Actual camera tracking as player ascends inside the tall world. */
    quiet(&g);g.roomStyle=1;g.cameraY=PG_H-PG_VIEW_H;
    g.y=40*FP;g.grounded=0;g.x=15*FP;
    pg_tick(&g,0);
    assert(g.cameraY<PG_H-PG_VIEW_H);

    /* Breakable ledges crumble after landing; no per-frame destruction. */
    quiet(&g);
    g.cells[22*PG_COLS+4]=PG_BREAK;
    g.x=32*FP;
    pg_tick(&g,0);
    assert(g.breakTimer);
    for(int i=0;i<21;i++)pg_tick(&g,0);
    assert(g.cells[22*PG_COLS+4]==PG_AIR);

    /* Coyote time and buffered jump. */
    quiet(&g);g.grounded=0;g.coyote=4;
    pg_tick(&g,PG_UP);assert(g.vy<0);
    quiet(&g);g.y=(PG_H-60)*FP;g.grounded=0;g.vy=40;
    g.jumpBuffer=4;
    for(int i=0;i<30;i++)pg_tick(&g,0);
    assert(g.y<PG_H*FP);
}
static void combat_and_controls(void) {
    PG_Game g;
    quiet(&g);g.hp=40;
    /* Holding Left or Right for several seconds cannot consume resources,
     * heal, attack or slow locomotion. */
    for(int i=0;i<210;i++)pg_tick(&g,PG_RIGHT);
    assert(g.downHold==0&&g.slamCooldown==0&&g.daggerCooldown==0);
    for(int i=0;i<210;i++)pg_tick(&g,PG_LEFT);
    assert(g.downHold==0&&g.slamCooldown==0&&g.daggerCooldown==0);
    /* Short DOWN is mutually exclusive with long DOWN and only throws
     * a dagger once the player releases the key. */
    quiet(&g);
    for(int i=0;i<10;i++)pg_tick(&g,PG_DOWN);
    assert(g.daggerCooldown==0&&g.slamCooldown==0);
    for(int j=0;j<PG_PROJECTILES;j++)assert(!g.shots[j].live);
    pg_tick(&g,0);
    assert(g.daggerCooldown>0&&g.slamCooldown==0);
    int daggerCount=0;
    for(int j=0;j<PG_PROJECTILES;j++)daggerCount+=(g.shots[j].live==PG_SHOT_DAGGER);
    assert(daggerCount==1);
    for(int i=0;i<5;i++)pg_tick(&g,PG_DOWN);
    pg_tick(&g,0);
    daggerCount=0;
    for(int j=0;j<PG_PROJECTILES;j++)daggerCount+=(g.shots[j].live==PG_SHOT_DAGGER);
    assert(daggerCount==1); /* still just one dagger */
    for(int i=0;i<40;i++)pg_tick(&g,0);
    daggerCount=0;
    for(int j=0;j<PG_PROJECTILES;j++)daggerCount+=(g.shots[j].live==PG_SHOT_DAGGER);
    assert(daggerCount==0); /* short throw range, not unlimited */
    /* Projectile reaches a distant foe for 1 HP versus sword's 2 HP. */
    quiet(&g);g.enemyCount=1;
    g.enemies[0].kind=PG_SHOOTER;g.enemies[0].hp=4;
    g.enemies[0].cooldown=250;
    g.enemies[0].x=(int16_t)(g.x+33*FP);g.enemies[0].y=g.y;
    for(int i=0;i<5;i++)pg_tick(&g,PG_DOWN);
    pg_tick(&g,0);
    for(int i=0;i<24;i++)pg_tick(&g,0);
    assert(g.enemies[0].hp==3);
    /* Ordinary sword swings can redirect a well-timed hostile projectile. */
    quiet(&g);
    g.shots[0].live=PG_SHOT_ENEMY;
    g.shots[0].x=(int16_t)(g.x+18*FP);
    g.shots[0].y=(int16_t)(g.y+7*FP);
    g.shots[0].vx=-25;
    pg_quick_attack(&g);
    assert(g.shots[0].live==PG_SHOT_REFLECT);
    assert(g.shots[0].vx>0);
    /* Long DOWN must produce slam, never a dagger, even while held for seconds. */
    quiet(&g);
    for(int i=0;i<34;i++)pg_tick(&g,PG_DOWN);
    assert(g.slamCooldown==0&&g.daggerCooldown==0&&g.effectKind!=2);
    pg_tick(&g,0);
    assert(g.slamCooldown>0&&g.daggerCooldown==0&&g.effectKind==2);
    quiet(&g);
    g.enemyCount=3;
    for(int i=0;i<3;i++) {
        g.enemies[i].kind=PG_SHOOTER;
        g.enemies[i].hp=5;
        g.enemies[i].cooldown=250;
        g.enemies[i].x=(int16_t)((18+i*5)*FP);
        g.enemies[i].y=(int16_t)((PG_H-30)*FP);
    }
    for(int i=0;i<30;i++)pg_tick(&g,PG_DOWN);
    pg_tick(&g,0);
    assert(g.enemies[0].hp==4&&g.enemies[1].hp==4&&g.enemies[2].hp==4);
    /* Single-target attack deals 2 per hit. */
    quiet(&g);g.enemyCount=1;
    g.enemies[0].kind=PG_SHOOTER;g.enemies[0].hp=5;
    g.enemies[0].x=(int16_t)(g.x+15*FP);g.enemies[0].y=g.y;
    pg_quick_attack(&g);assert(g.enemies[0].hp==3);
}
static void boss_encounter(void) {
    PG_Game g;
    pg_new(&g,0x27u);
    /* Build the first boss room through legitimate successful exits. */
    for(int r=0;r<5;r++) {
        int er=r%3==0?21:3;
        g.x=(int16_t)((18*8-5)*FP);
        g.y=(int16_t)((er*8-5)*FP);
        pg_tick(&g,0);
        assert(g.room==(uint16_t)r+1);
    }
    assert(g.enemyCount==1 && g.enemies[0].kind==PG_BOSS);
    assert(g.enemies[0].hp==14);
    PG_Enemy *e=&g.enemies[0];
    /* Avoid the sprite while observing deterministic boss telegraphs. */
    g.x=15*FP;g.y=(PG_H-30)*FP;g.invulnerable=250;
    unsigned seenCharge=0,seenVolley=0,seenWave=0,seenRecovery=0,seenShots=0;
    for(int i=0;i<600;i++) {
        pg_tick(&g,0);
        if(e->phase==1||e->phase==2)seenCharge=1;
        if(e->phase==4)seenVolley=1;
        if(e->phase==5)seenWave=1;
        if(e->phase==3)seenRecovery=1;
        for(int j=0;j<PG_PROJECTILES;j++)seenShots+=(g.shots[j].live!=0);
        if(g.phase==PG_DEAD) {g.hp=100;g.phase=PG_RUN;g.invulnerable=250;}
    }
    assert(seenCharge && seenVolley && seenWave && seenRecovery && seenShots);
    /* A large enemy needs more attacks than a regular grunt; windup
     * armor and recovery vulnerability must both be accounted for. */
    e->x=(int16_t)(g.x+12*FP);e->y=g.y-8*FP;
    e->hp=14;e->phase=1;
    g.facing=1;
    pg_quick_attack(&g);
    assert(e->hp==13);
    g.attackTime=0;e->phase=3;
    pg_quick_attack(&g);
    assert(e->hp==11);
    /* No transition is possible while boss lives, even at the exit. */
    g.x=(18*8-5)*FP;g.y=(3*8-5)*FP;
    e->hp=1;
    pg_tick(&g,0);
    assert(g.room==5);
    e->hp=0;
    pg_tick(&g,0);
    assert(g.room==6);
}
static void regeneration(void) {
    PG_Game g;quiet(&g);
    g.hp=40;g.hurtClock=0;
    for(int i=0;i<149;i++)pg_tick(&g,0);
    assert(g.hp==40);
    for(int i=0;i<170;i++)pg_tick(&g,0);
    assert(g.hp>=48&&g.hp<=51); /* around 3 HP/s, not 8 HP/s */
    pg_toggle_pause(&g);
    PG_Game frozen=g;
    for(int i=0;i<50;i++)pg_tick(&g,PG_RIGHT|PG_DOWN);
    assert(memcmp(&g,&frozen,sizeof(g))==0);
    pg_toggle_pause(&g);
    g.hp=0;g.phase=PG_DEAD;
    pg_quick_attack(&g);
    assert(g.phase==PG_RUN&&g.hp==100);
}
static void wall_grip(void) {
    PG_Game g;quiet(&g);
    for(int row=4;row<=21;row++)g.cells[row*PG_COLS+9]=PG_STONE;
    g.x=62*FP;g.y=120*FP;g.grounded=0;g.vy=42;
    for(int i=0;i<14;i++)pg_tick(&g,PG_RIGHT|PG_UP);
    assert(g.gripLeft<60);
    assert(g.gripping);
    assert(g.vy<=5);
    /* Releasing and re-pressing Jump when touching wall provides a push. */
    pg_tick(&g,PG_RIGHT);
    pg_tick(&g,PG_RIGHT|PG_UP);
    pg_tick(&g,PG_RIGHT); /* short Up release makes a wall jump */
    assert(g.vy<0&&g.wallLock>0);
    /* A held Up can mantle a ledge only with empty space above it.
     * A full-height wall cannot produce a magical upward scramble. */
    quiet(&g);
    for(int row=10;row<=18;row++)g.cells[row*PG_COLS+9]=PG_STONE;
    g.x=62*FP;g.y=68*FP;g.grounded=0;g.vy=0;
    for(int i=0;i<15;i++)pg_tick(&g,PG_RIGHT|PG_UP);
    assert(g.x>=70*FP && g.grounded);
    quiet(&g);
    for(int row=4;row<=21;row++)g.cells[row*PG_COLS+9]=PG_STONE;
    g.x=62*FP;g.y=80*FP;g.grounded=0;g.vy=20;
    for(int i=0;i<15;i++)pg_tick(&g,PG_RIGHT|PG_UP);
    assert(g.x<70*FP); /* no mantle through a solid wall */
}
static void moving_hazard(void) {
    PG_Game g;quiet(&g);
    g.room=3;g.roomStyle=0;g.grounded=0;
    int hx,hy;pg_hazard_position(&g,&hx,&hy);
    assert(hx>=0&&hy>=0);
    g.x=(int16_t)((hx-5)*FP);g.y=(int16_t)((hy-7)*FP);
    uint8_t before=g.hp;
    pg_tick(&g,0);
    assert(g.hp<before);
    quiet(&g);pg_hazard_position(&g,&hx,&hy);
    assert(hx<0); /* tutorial rooms do not use moving hazards */
}
static void fuzz(void) {
    uint32_t checksum=0;
    for(uint32_t seed=1;seed<=600;seed++) {
        PG_Game g;pg_new(&g,seed*4567u);
        for(unsigned i=0;i<520;i++) {
            uint8_t h=(uint8_t)(((i+seed)&7)==0?PG_RIGHT:
                        ((i+seed)&7)==1?PG_LEFT:
                        ((i+seed)&7)==2?PG_UP:
                        ((i+seed)&7)==3?(PG_RIGHT|PG_DOWN):
                        ((i+seed)&7)==4?(PG_LEFT|PG_UP):
                        ((i+seed)&7)==5?PG_DOWN:
                        ((i+seed)&7)==6?(PG_RIGHT|PG_UP):0);
            pg_tick(&g,h);
            if(i%19==0)pg_quick_attack(&g);
            if(g.phase==PG_DEAD)pg_quick_attack(&g);
            assert(g.hp<=100);
            assert(g.enemyCount<=PG_ENEMIES);
            assert(g.theme<3);
            assert(g.cameraY<=PG_H-PG_VIEW_H);
            assert(g.x>=0&&g.x<PG_W*FP);
            assert(g.y>=0&&g.y<=PG_H*FP);
            assert(g.downHold<=250);
        }
        checksum^=g.rng+(uint32_t)g.hp*17u+g.score;
    }
    assert(checksum);
    puts("PASS: 600 randomized 520-step simulations (312,000 ticks)");
}
int main(void) {
    movement();combat_and_controls();boss_encounter();regeneration();wall_grip();moving_hazard();fuzz();
    puts("PASS: collisions, boss charge/volley/wave, dagger/sword/reflect/slam, wall grip/ledge mantle, moving hazard");
    return 0;
}
