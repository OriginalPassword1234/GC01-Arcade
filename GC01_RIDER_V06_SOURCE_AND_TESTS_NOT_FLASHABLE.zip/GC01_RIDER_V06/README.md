# GC01 Rider v0.6 — experimental improved firmware source

**Not a verified firmware image.** This source is packaged with a self-contained GitHub Actions build workflow that retrieves the same pinned Rad Pro 3.1.1 code and creates a CRC-checked, signed APM32 update candidate **only if all tests and partition checks pass**. The resulting file is not automatically safe to flash. The final ARM build has not been run in this environment and the updated game has not been measured on the physical GC01.

## Why this release exists

The earlier v0.5 on a GC01 reportedly felt slow (~10 FPS), overly glued to the track, sluggish to accelerate, and had too little visible scoring or special content.

## New code

- Physically separate airborne motion with increased speed, free flight over ramps and gaps, gravity, airborne rotation and wheel penetration-only contact correction. This is still a **reduced approximation**, NOT the original Box2D engine.
- The 60 Hz fixed timestep is retained; maximum ordinary forward speed raised from 5 to 8 game pixels/step and the acceleration is increased.
- Faster controllable airborne rotation: a 24-tick hold/release strategy on a seeded generated track earns a real score point in a host regression test. Still takes skill; not every run scores automatically.
- More varied compact ramp/gap templates and selected earlier under-track saws with rotating teeth, alongside boosts and diamonds.
- Bounded-region sprite/vehicle/diamond/saw drawing avoids testing all objects at every pixel.
- One additional darker violet under-rail band to give the track a more layered appearance.
- A 320-byte hash cache avoids transmitting unchanged 3-row display strips. In the host fixture, after motion only **37 of 80** strips changed. This is an indicator of traffic reduction, not an on-device FPS benchmark.
- Display cache resets whenever Rider is entered and when the LCD sleeps.

## Tests actually run

- GCC and Clang with AddressSanitizer / UndefinedBehaviorSanitizer: pass.
- 500 deterministic seeded early/mid-piece driving runs under a simple policy: pass.
- 256 random-input/restart sequences: pass.
- Recorded generated-run flip scoring (not staged): pass.
- Renderer stress test: 7 seeds × 800 physics steps: pass.
- Dirty-strip cache: first frame 80 strips, repeated frame 0, motion fixture 37, cache invalidate 80: pass.
- Native renderer-only RAM: 3,275 B; display dirty-hash table 320 B; 2 gameplay states on host 344 B, total identified 3,939 B. This excludes firmware, stack, ISR and other Rad Pro globals.

## Important limitations

- **Still no real loops**: the heightfield collision system cannot model a track crossing itself. Don't treat a curved hill as a loop.
- Full original Rider 95-piece section library, swing/tilt/falling platforms, original exact body-wheel joints and original graphics assets are not present.
- All challenging layouts have not been exhaustively proven reachable. The 500/500 run test only verifies a basic early/mid policy.
- No guarantee of zero bugs or a specific FPS on physical hardware. Actual time, IRQ latency, SPI transfer rate and Geiger operation must be verified on the device.
- This version retains the existing 68 KiB application, 2 KiB reserved game saves, 1 KiB settings and 41 KiB history layout; original USB bootloader region is unchanged.
- The experimental lossless radiation log codec is still NOT integrated; there is no settings/history migration.

## Build

The `.github/workflows/gc01-rider-v06-68k-firmware-build.yml` file is self-contained: create that one file in GitHub to test and build the pinned source. The build will **not** emit a candidate firmware artifact if the compile, CRC, flash-layout or >=3 KiB nominal SRAM-headroom audit fails. Re-run with the actual ARM output artifact when it succeeds, and inspect it before flashing.
