#include "../src/rider_core.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void test_continuity(void)
{
    RiderState s; rider_init(&s, 12345678);
    for (uint32_t i=1;i<RIDER_TRACK_SLOTS;i++) {
        int32_t a,b;
        assert(rider_surface_q(&s,(int32_t)i*256*256,&b));
        assert(rider_surface_q(&s,(int32_t)i*256*256-1,&a));
        assert((a-b)<256 && (a-b)>-256);
    }
}
static void test_determinism(void)
{
    RiderState a,b; rider_init(&a, 7123); rider_init(&b,7123);
    for(int i=0;i<50000;i++) {
        bool down=(i%117)<105;
        rider_step(&a, down); rider_step(&b,down);
        assert(rider_hash(&a)==rider_hash(&b));
        assert(a.next_piece <= 12+(uint32_t)(a.x/(256*256))+2);
        assert(a.phase>=RIDER_READY && a.phase<=RIDER_CRASHED);
        if(a.phase==RIDER_CRASHED) { rider_restart(&a); rider_restart(&b); }
    }
}
static void test_restarts(void)
{
    RiderState s; rider_init(&s,0);
    s.best=128; s.diamonds=77; for(int i=0;i<300;i++)rider_step(&s,true);
    int best=s.best, diamonds=s.diamonds;
    rider_restart(&s); assert(s.best==best && s.diamonds==diamonds && s.phase==RIDER_READY);
    assert(s.track[0].number==0 && s.x==70*RIDER_Q);
}
static void test_generated_reachability(void)
{
    int crashes=0;
    uint64_t distance=0;
    for(uint32_t seed=1;seed<=500;seed++) {
        RiderState s;rider_init(&s,seed);
        for(int j=0;j<3500;j++) {
            rider_step(&s,s.grounded != 0);
            if((uint32_t)(s.x/(256*256)) >= 70u) break;
            if(s.phase==RIDER_CRASHED) { crashes++;break; }
        }
        distance += (uint32_t)(s.x/(256*256));
    }
    assert(crashes==0);
    printf("500/500 deterministic tracks pass a grounded-only policy through early/mid pieces, distance = %llu pieces\n", (unsigned long long)distance);
}
static void test_start_ground_contact(void)
{
    RiderState s; rider_init(&s, 0x312af77u);
    assert(s.phase==RIDER_READY && s.grounded);
    rider_step(&s,true);
    assert(s.phase==RIDER_RUNNING && s.grounded);
    assert(s.airborne_ticks==0);
}
static void test_random_input_survival_and_recovery(void)
{
    for(uint32_t seed=1;seed<=256;seed++) {
        RiderState s; rider_init(&s,seed*0x9e3779b9u);
        uint32_t z=seed ^ 0x1234cafeu;
        for(int t=0;t<3200;t++) {
            z^=z<<13;z^=z>>17;z^=z<<5;
            bool pressed=(z&15u)<(t%201<100?13u:4u);
            rider_step(&s,pressed);
            if(s.phase==RIDER_CRASHED){
                assert(s.pending_ticks==0 && s.pending_score==0);
                rider_restart(&s);
                assert(s.grounded && s.phase==RIDER_READY);
            }
            assert(s.vx>=0 && s.vx<=9*RIDER_Q);
            assert(s.phase<=RIDER_CRASHED);
        }
    }
}
static void test_saw_metadata(void)
{
    RiderState s; rider_init(&s,1234);
    while(s.next_piece < 100) {
        rider_step(&s, s.grounded != 0);
        if(s.phase==RIDER_CRASHED) rider_restart(&s);
    }
    int seen=0;
    for(uint32_t i=0;i<RIDER_TRACK_SLOTS;i++) {
        uint32_t piece=s.track[i].number;
        int32_t x,y,r;
        if(rider_piece_saw_q(&s,piece,&x,&y,&r)) {
            assert(r > 0);
            seen=1;
        }
    }
    assert(seen);
}
static void test_score_in_generated_gameplay(void)
{
    /* Not a synthetic setup: follow an ordinary generated run, holding
     * briefly after a ramp and releasing before the landing. */
    RiderState s; rider_init(&s,3u);
    for(int i=0;i<400;++i){
        rider_step(&s,s.grounded || s.airborne_ticks < 24u);
        if(s.score>=1)break;
        assert(s.phase!=RIDER_CRASHED);
    }
    assert(s.score>=1);
}

static void test_ground_acceleration_and_airtime(void)
{
    RiderState s; rider_init(&s,0x19772106u);
    for(int tick=0;tick<59;++tick)rider_step(&s,true);
    assert(s.phase==RIDER_RUNNING);
    assert(s.vx>4*RIDER_Q);  /* faster acceleration than the previous 5 px/tick cap */
    int air=0;
    for(int tick=0;tick<1400;++tick){
        rider_step(&s,s.grounded!=0);
        if(s.phase==RIDER_CRASHED)break;
        if(!s.grounded)++air;
    }
    assert(air>=30);  /* real airborne periods exist with no jump button */
}

static void test_landed_flip_score(void)
{
    RiderState s; rider_init(&s,1);
    s.phase=RIDER_RUNNING;
    s.grounded=0;
    s.y=(166-240)*RIDER_Q;
    s.vx=0;
    s.vy=0;
    s.takeoff_angle=0;
    int landed=0;
    for(int j=0;j<62;j++) {
        rider_step(&s,j<24);
        if(s.grounded){ landed=1; break; }
    }
    assert(landed && s.phase==RIDER_RUNNING);
    assert(s.pending_score==1 && s.pending_ticks==30);
    for(int i=0;i<30;i++) rider_step(&s,false);
    assert(s.score==1 && s.best==1 && s.pending_score==0);
}

int main(void)
{
    test_continuity();
    test_determinism();
    test_restarts();
    test_start_ground_contact();
    test_random_input_survival_and_recovery();
    test_generated_reachability();
    test_saw_metadata();
    test_ground_acceleration_and_airtime();
    test_score_in_generated_gameplay();
    test_landed_flip_score();
    puts("Core tests passed");
    return 0;
}
